# Downloads - Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS v1.0.0

## Downloads

* Artifact Definitions: Examples
  * [XML](../definitions.xml.zip): [XML](../examples.xml.zip)
  * [JSON](../definitions.json.zip): [JSON](../examples.json.zip)
  * [Turtle](../definitions.ttl.zip): [Turtle](../examples.ttl.zip)

 **Package** [`package.tgz`](../package.tgz) 

