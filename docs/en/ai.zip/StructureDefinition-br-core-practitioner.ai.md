# BR Core Practitioner - Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS v1.0.0-release

## Resource Profile: BR Core Practitioner 

 
O Profissional é uma pessoa que está direta ou indiretamente envolvida na prestação de cuidados de saúde ou serviços relacionados ao paciente. 

**Usos:**

* Refere a este Perfil: [BR Core Composition](StructureDefinition-br-core-composition.md) and [BR Core PractitionerRole](StructureDefinition-br-core-practitionerrole.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/br.gov.saude.redfm.fhir|current/StructureDefinition/StructureDefinition-br-core-practitioner.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-br-core-practitioner.csv), [Excel](../StructureDefinition-br-core-practitioner.xlsx), [Schematron](../StructureDefinition-br-core-practitioner.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "br-core-practitioner",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/redfm/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/redfm/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-practitioner",
  "version" : "1.0.0-release",
  "name" : "BRCorePractitioner",
  "title" : "BR Core Practitioner",
  "status" : "active",
  "date" : "2026-09-25T17:16:20-03:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "O Profissional é uma pessoa que está direta ou indiretamente envolvida na prestação de cuidados de saúde ou serviços relacionados ao paciente.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Practitioner",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Practitioner",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Practitioner",
      "path" : "Practitioner"
    },
    {
      "id" : "Practitioner.id",
      "path" : "Practitioner.id",
      "short" : "Identificador Lógico do Artefato",
      "definition" : "Identificador Lógico do Artefato"
    },
    {
      "id" : "Practitioner.meta",
      "path" : "Practitioner.meta",
      "short" : "Metadados do Artefato",
      "definition" : "Metadados que descrevem o artefato"
    },
    {
      "id" : "Practitioner.implicitRules",
      "path" : "Practitioner.implicitRules",
      "short" : "Regras Implícitas de Uso",
      "definition" : "Regras implícitas de uso do artefato"
    },
    {
      "id" : "Practitioner.language",
      "path" : "Practitioner.language",
      "short" : "Linguagem do Artefato",
      "definition" : "Linguagem do conteúdo do artefato"
    },
    {
      "id" : "Practitioner.text",
      "path" : "Practitioner.text",
      "short" : "Texto narrativo do artefato",
      "definition" : "Texto narrativo que descreve o artefato"
    },
    {
      "id" : "Practitioner.contained",
      "path" : "Practitioner.contained",
      "short" : "Artefatos Contidos",
      "definition" : "Artefatos contidos no artefato"
    },
    {
      "id" : "Practitioner.extension",
      "path" : "Practitioner.extension",
      "short" : "Extensões do Artefato",
      "definition" : "Extensões incluídas no artefato"
    },
    {
      "id" : "Practitioner.modifierExtension",
      "path" : "Practitioner.modifierExtension",
      "short" : "Extensões Modificadoras do Artefato",
      "definition" : "Extensões modificadoras incluídas no artefato"
    },
    {
      "id" : "Practitioner.identifier",
      "path" : "Practitioner.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "type"
        }],
        "rules" : "open"
      },
      "short" : "Identificadores do profissional",
      "definition" : "Identificadores do profissional",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:cns",
      "path" : "Practitioner.identifier",
      "sliceName" : "cns",
      "short" : "Identificador do profissional",
      "definition" : "Identificador do profissional",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:cns.id",
      "path" : "Practitioner.identifier.id",
      "short" : "Id lógico do identificador do profissional",
      "definition" : "Id lógico do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cns.extension",
      "path" : "Practitioner.identifier.extension",
      "short" : "Extensões do identificador do profissional",
      "definition" : "Extensões incluídas no identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cns.use",
      "path" : "Practitioner.identifier.use",
      "short" : "Uso do identificador do profissional",
      "definition" : "usual: identificador usual do profissional. official: identificador oficial do profissional. temp: identificador temporário do profissional. secondary: identificador secundário do profissional.",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Practitioner.identifier:cns.type",
      "path" : "Practitioner.identifier.type",
      "short" : "Tipo do identificador do profissional",
      "definition" : "Código que representa o tipo do identificador do profissional",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "PHO"
        }]
      },
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v2-0203"
      }
    },
    {
      "id" : "Practitioner.identifier:cns.type.id",
      "path" : "Practitioner.identifier.type.id",
      "short" : "Id lógico do tipo do identificador do profissional",
      "definition" : "Id lógico do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cns.type.extension",
      "path" : "Practitioner.identifier.type.extension",
      "short" : "Extensões do tipo do identificador do profissional",
      "definition" : "Extensões incluídas no tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cns.type.coding",
      "path" : "Practitioner.identifier.type.coding",
      "short" : "Codificação do tipo do identificador do profissional",
      "definition" : "Codificação que representa o tipo do identificador do profissional",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Practitioner.identifier:cns.type.coding.id",
      "path" : "Practitioner.identifier.type.coding.id",
      "short" : "Id lógico da codificação do tipo do identificador do profissional",
      "definition" : "Id lógico da codificação do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cns.type.coding.extension",
      "path" : "Practitioner.identifier.type.coding.extension",
      "short" : "Extensões da codificação do tipo do identificador do profissional",
      "definition" : "Extensões incluídas na codificação do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cns.type.coding.system",
      "path" : "Practitioner.identifier.type.coding.system",
      "short" : "Sistema da codificação do tipo do identificador do profissional",
      "definition" : "Sistema que identifica a codificação do tipo do identificador do profissional",
      "min" : 1,
      "fixedUri" : "http://terminology.hl7.org/CodeSystem/v2-0203"
    },
    {
      "id" : "Practitioner.identifier:cns.type.coding.version",
      "path" : "Practitioner.identifier.type.coding.version",
      "short" : "Versão da codificação do tipo do identificador do profissional",
      "definition" : "Versão da codificação do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cns.type.coding.code",
      "path" : "Practitioner.identifier.type.coding.code",
      "short" : "Código da codificação do tipo do identificador do profissional",
      "definition" : "Código que representa a codificação do tipo do identificador do profissional",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:cns.type.coding.display",
      "path" : "Practitioner.identifier.type.coding.display",
      "short" : "Texto da codificação do tipo do identificador do profissional",
      "definition" : "Texto que representa a codificação do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cns.type.coding.userSelected",
      "path" : "Practitioner.identifier.type.coding.userSelected",
      "short" : "Seleção do usuário da codificação do tipo do identificador do profissional",
      "definition" : "Indica se a codificação do tipo do identificador do profissional foi selecionada pelo usuário"
    },
    {
      "id" : "Practitioner.identifier:cns.type.text",
      "path" : "Practitioner.identifier.type.text",
      "short" : "Texto do tipo do identificador do profissional",
      "definition" : "Texto que representa o tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cns.system",
      "path" : "Practitioner.identifier.system",
      "short" : "Sistema do identificador do profissional",
      "definition" : "Sistema que identifica o tipo do identificador do profissional",
      "min" : 1,
      "fixedUri" : "https://saude.gov.br/sid/cns"
    },
    {
      "id" : "Practitioner.identifier:cns.value",
      "path" : "Practitioner.identifier.value",
      "short" : "Valor do identificador do profissional",
      "definition" : "Valor do identificador do profissional",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:cns.period",
      "path" : "Practitioner.identifier.period",
      "short" : "Período de uso do identificador do profissional",
      "definition" : "Período de tempo durante o qual o identificador do profissional foi utilizado"
    },
    {
      "id" : "Practitioner.identifier:cns.assigner",
      "path" : "Practitioner.identifier.assigner",
      "short" : "Entidade que atribuiu o identificador do profissional",
      "definition" : "Entidade que atribuiu o identificador do profissional",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Practitioner.identifier:cns.assigner.display",
      "path" : "Practitioner.identifier.assigner.display",
      "short" : "Nome da entidade que atribuiu o identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf",
      "path" : "Practitioner.identifier",
      "sliceName" : "cpf",
      "short" : "Identificador do profissional",
      "definition" : "Identificador do profissional",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:cpf.id",
      "path" : "Practitioner.identifier.id",
      "short" : "Id lógico do identificador do profissional",
      "definition" : "Id lógico do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf.extension",
      "path" : "Practitioner.identifier.extension",
      "short" : "Extensões do identificador do profissional",
      "definition" : "Extensões incluídas no identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf.use",
      "path" : "Practitioner.identifier.use",
      "short" : "Uso do identificador do profissional",
      "definition" : "usual: identificador usual do profissional. official: identificador oficial do profissional. temp: identificador temporário do profissional. secondary: identificador secundário do profissional.",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Practitioner.identifier:cpf.type",
      "path" : "Practitioner.identifier.type",
      "short" : "Tipo do identificador do profissional",
      "definition" : "Código que representa o tipo do identificador do profissional",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "TAX"
        }]
      },
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v2-0203"
      }
    },
    {
      "id" : "Practitioner.identifier:cpf.type.id",
      "path" : "Practitioner.identifier.type.id",
      "short" : "Id lógico do tipo do identificador do profissional",
      "definition" : "Id lógico do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf.type.extension",
      "path" : "Practitioner.identifier.type.extension",
      "short" : "Extensões do tipo do identificador do profissional",
      "definition" : "Extensões incluídas no tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf.type.coding",
      "path" : "Practitioner.identifier.type.coding",
      "short" : "Codificação do tipo do identificador do profissional",
      "definition" : "Codificação que representa o tipo do identificador do profissional",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Practitioner.identifier:cpf.type.coding.id",
      "path" : "Practitioner.identifier.type.coding.id",
      "short" : "Id lógico da codificação do tipo do identificador do profissional",
      "definition" : "Id lógico da codificação do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf.type.coding.extension",
      "path" : "Practitioner.identifier.type.coding.extension",
      "short" : "Extensões da codificação do tipo do identificador do profissional",
      "definition" : "Extensões incluídas na codificação do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf.type.coding.system",
      "path" : "Practitioner.identifier.type.coding.system",
      "short" : "Sistema da codificação do tipo do identificador do profissional",
      "definition" : "Sistema que identifica a codificação do tipo do identificador do profissional",
      "min" : 1,
      "fixedUri" : "http://terminology.hl7.org/CodeSystem/v2-0203"
    },
    {
      "id" : "Practitioner.identifier:cpf.type.coding.version",
      "path" : "Practitioner.identifier.type.coding.version",
      "short" : "Versão da codificação do tipo do identificador do profissional",
      "definition" : "Versão da codificação do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf.type.coding.code",
      "path" : "Practitioner.identifier.type.coding.code",
      "short" : "Código da codificação do tipo do identificador do profissional",
      "definition" : "Código que representa a codificação do tipo do identificador do profissional",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:cpf.type.coding.display",
      "path" : "Practitioner.identifier.type.coding.display",
      "short" : "Texto da codificação do tipo do identificador do profissional",
      "definition" : "Texto que representa a codificação do tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf.type.coding.userSelected",
      "path" : "Practitioner.identifier.type.coding.userSelected",
      "short" : "Seleção do usuário da codificação do tipo do identificador do profissional",
      "definition" : "Indica se a codificação do tipo do identificador do profissional foi selecionada pelo usuário"
    },
    {
      "id" : "Practitioner.identifier:cpf.type.text",
      "path" : "Practitioner.identifier.type.text",
      "short" : "Texto do tipo do identificador do profissional",
      "definition" : "Texto que representa o tipo do identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:cpf.system",
      "path" : "Practitioner.identifier.system",
      "short" : "Sistema do identificador do profissional",
      "definition" : "Sistema que identifica o tipo do identificador do profissional",
      "min" : 1,
      "fixedUri" : "https://saude.gov.br/sid/cpf"
    },
    {
      "id" : "Practitioner.identifier:cpf.value",
      "path" : "Practitioner.identifier.value",
      "short" : "Valor do identificador do profissional",
      "definition" : "Valor do identificador do profissional",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:cpf.period",
      "path" : "Practitioner.identifier.period",
      "short" : "Período de uso do identificador do profissional",
      "definition" : "Período de tempo durante o qual o identificador do profissional foi utilizado"
    },
    {
      "id" : "Practitioner.identifier:cpf.assigner",
      "path" : "Practitioner.identifier.assigner",
      "short" : "Entidade que atribuiu o identificador do profissional",
      "definition" : "Entidade que atribuiu o identificador do profissional",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Practitioner.identifier:cpf.assigner.display",
      "path" : "Practitioner.identifier.assigner.display",
      "short" : "Nome da entidade que atribuiu o identificador do profissional"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico",
      "path" : "Practitioner.identifier",
      "sliceName" : "identificadorMedico",
      "short" : "Identificador do médico",
      "definition" : "Identificador do médico",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.id",
      "path" : "Practitioner.identifier.id",
      "short" : "Id lógico do identificador do médico",
      "definition" : "Id lógico do identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.extension",
      "path" : "Practitioner.identifier.extension",
      "short" : "Extensões do identificador do médico",
      "definition" : "Extensões incluídas no identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.use",
      "path" : "Practitioner.identifier.use",
      "short" : "Uso do identificador do médico",
      "definition" : "usual: identificador usual do médico. official: identificador oficial do médico. temp: identificador temporário do médico. secondary: identificador secundário do médico.",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type",
      "path" : "Practitioner.identifier.type",
      "short" : "Tipo do identificador do médico",
      "definition" : "Código que representa o tipo do identificador do médico",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "MD"
        }]
      },
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v2-0203"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.id",
      "path" : "Practitioner.identifier.type.id",
      "short" : "Id lógico do tipo do identificador do médico",
      "definition" : "Id lógico do tipo do identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.extension",
      "path" : "Practitioner.identifier.type.extension",
      "short" : "Extensões do tipo do identificador do médico",
      "definition" : "Extensões incluídas no tipo do identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.coding",
      "path" : "Practitioner.identifier.type.coding",
      "short" : "Codificação do tipo do identificador do médico",
      "definition" : "Codificação que representa o tipo do identificador do médico",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.coding.id",
      "path" : "Practitioner.identifier.type.coding.id",
      "short" : "Id lógico da codificação do tipo do identificador do médico",
      "definition" : "Id lógico da codificação do tipo do identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.coding.extension",
      "path" : "Practitioner.identifier.type.coding.extension",
      "short" : "Extensões da codificação do tipo do identificador do médico",
      "definition" : "Extensões incluídas na codificação do tipo do identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.coding.system",
      "path" : "Practitioner.identifier.type.coding.system",
      "short" : "Sistema da codificação do tipo do identificador do médico",
      "definition" : "Sistema que identifica a codificação do tipo do identificador do médico",
      "min" : 1,
      "fixedUri" : "http://terminology.hl7.org/CodeSystem/v2-0203"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.coding.version",
      "path" : "Practitioner.identifier.type.coding.version",
      "short" : "Versão da codificação do tipo do identificador do médico",
      "definition" : "Versão da codificação do tipo do identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.coding.code",
      "path" : "Practitioner.identifier.type.coding.code",
      "short" : "Código da codificação do tipo do identificador do médico",
      "definition" : "Código que representa a codificação do tipo do identificador do médico",
      "min" : 1,
      "patternCode" : "MD"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.coding.display",
      "path" : "Practitioner.identifier.type.coding.display",
      "short" : "Texto da codificação do tipo do identificador do médico",
      "definition" : "Texto que representa a codificação do tipo do identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.coding.userSelected",
      "path" : "Practitioner.identifier.type.coding.userSelected",
      "short" : "Seleção do usuário da codificação do tipo do identificador do médico",
      "definition" : "Indica se a codificação do tipo do identificador do médico foi selecionada pelo usuário"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.type.text",
      "path" : "Practitioner.identifier.type.text",
      "short" : "Texto do tipo do identificador do médico",
      "definition" : "Texto que representa o tipo do identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.system",
      "path" : "Practitioner.identifier.system",
      "short" : "Sistema do identificador do médico",
      "definition" : "Sistema que identifica o tipo do identificador do médico",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "description" : "Sistema do identificador do médico",
        "valueSet" : "https://terminologia.saude.gov.br/fhir/ValueSet/BRCRM"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.value",
      "path" : "Practitioner.identifier.value",
      "short" : "Valor do identificador do médico",
      "definition" : "Valor do identificador do médico",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.period",
      "path" : "Practitioner.identifier.period",
      "short" : "Período de uso do identificador do médico",
      "definition" : "Período de tempo durante o qual o identificador do médico foi utilizado"
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.assigner",
      "path" : "Practitioner.identifier.assigner",
      "short" : "Entidade que atribuiu o identificador do médico",
      "definition" : "Entidade que atribuiu o identificador do médico",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Practitioner.identifier:identificadorMedico.assigner.display",
      "path" : "Practitioner.identifier.assigner.display",
      "short" : "Nome da entidade que atribuiu o identificador do médico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico",
      "path" : "Practitioner.identifier",
      "sliceName" : "identificadorFarmaceutico",
      "short" : "Identificador do farmacêutico",
      "definition" : "Identificador do farmacêutico",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.id",
      "path" : "Practitioner.identifier.id",
      "short" : "Id lógico do identificador do farmacêutico",
      "definition" : "Id lógico do identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.extension",
      "path" : "Practitioner.identifier.extension",
      "short" : "Extensões do identificador do farmacêutico",
      "definition" : "Extensões incluídas no identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.use",
      "path" : "Practitioner.identifier.use",
      "short" : "Uso do identificador do farmacêutico",
      "definition" : "usual: identificador usual do farmacêutico. official: identificador oficial do farmacêutico. temp: identificador temporário do farmacêutico. secondary: identificador secundário do farmacêutico.",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type",
      "path" : "Practitioner.identifier.type",
      "short" : "Tipo do identificador do farmacêutico",
      "definition" : "Código que representa o tipo do identificador do farmacêutico",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "RPH"
        }]
      },
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v2-0203"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.id",
      "path" : "Practitioner.identifier.type.id",
      "short" : "Id lógico do tipo do identificador do farmacêutico",
      "definition" : "Id lógico do tipo do identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.extension",
      "path" : "Practitioner.identifier.type.extension",
      "short" : "Extensões do tipo do identificador do farmacêutico",
      "definition" : "Extensões incluídas no tipo do identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.coding",
      "path" : "Practitioner.identifier.type.coding",
      "short" : "Codificação do tipo do identificador do farmacêutico",
      "definition" : "Codificação que representa o tipo do identificador do farmacêutico",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.coding.id",
      "path" : "Practitioner.identifier.type.coding.id",
      "short" : "Id lógico da codificação do tipo do identificador do farmacêutico",
      "definition" : "Id lógico da codificação do tipo do identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.coding.extension",
      "path" : "Practitioner.identifier.type.coding.extension",
      "short" : "Extensões da codificação do tipo do identificador do farmacêutico",
      "definition" : "Extensões incluídas na codificação do tipo do identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.coding.system",
      "path" : "Practitioner.identifier.type.coding.system",
      "short" : "Sistema da codificação do tipo do identificador do farmacêutico",
      "definition" : "Sistema que identifica a codificação do tipo do identificador do farmacêutico",
      "min" : 1,
      "fixedUri" : "http://terminology.hl7.org/CodeSystem/v2-0203"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.coding.version",
      "path" : "Practitioner.identifier.type.coding.version",
      "short" : "Versão da codificação do tipo do identificador do farmacêutico",
      "definition" : "Versão da codificação do tipo do identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.coding.code",
      "path" : "Practitioner.identifier.type.coding.code",
      "short" : "Código da codificação do tipo do identificador do farmacêutico",
      "definition" : "Código que representa a codificação do tipo do identificador do farmacêutico",
      "min" : 1,
      "patternCode" : "RPH"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.coding.display",
      "path" : "Practitioner.identifier.type.coding.display",
      "short" : "Texto da codificação do tipo do identificador do farmacêutico",
      "definition" : "Texto que representa a codificação do tipo do identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.coding.userSelected",
      "path" : "Practitioner.identifier.type.coding.userSelected",
      "short" : "Seleção do usuário da codificação do tipo do identificador do farmacêutico",
      "definition" : "Indica se a codificação do tipo do identificador do farmacêutico foi selecionada pelo usuário"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.type.text",
      "path" : "Practitioner.identifier.type.text",
      "short" : "Texto do tipo do identificador do farmacêutico",
      "definition" : "Texto que representa o tipo do identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.system",
      "path" : "Practitioner.identifier.system",
      "short" : "Sistema do identificador do farmacêutico",
      "definition" : "Sistema que identifica o tipo do identificador do farmacêutico",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "description" : "Sistema do identificador do farmacêutico",
        "valueSet" : "https://terminologia.saude.gov.br/fhir/ValueSet/BRCRF"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.value",
      "path" : "Practitioner.identifier.value",
      "short" : "Valor do identificador do farmacêutico",
      "definition" : "Valor do identificador do farmacêutico",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.period",
      "path" : "Practitioner.identifier.period",
      "short" : "Período de uso do identificador do farmacêutico",
      "definition" : "Período de tempo durante o qual o identificador do farmacêutico foi utilizado"
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.assigner",
      "path" : "Practitioner.identifier.assigner",
      "short" : "Entidade que atribuiu o identificador do farmacêutico",
      "definition" : "Entidade que atribuiu o identificador do farmacêutico",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Practitioner.identifier:identificadorFarmaceutico.assigner.display",
      "path" : "Practitioner.identifier.assigner.display",
      "short" : "Nome da entidade que atribuiu o identificador do farmacêutico"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo",
      "path" : "Practitioner.identifier",
      "sliceName" : "identificadorOdontologo",
      "short" : "Identificador do odontólogo",
      "definition" : "Identificador do odontólogo",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.id",
      "path" : "Practitioner.identifier.id",
      "short" : "Id lógico do identificador do odontólogo",
      "definition" : "Id lógico do identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.extension",
      "path" : "Practitioner.identifier.extension",
      "short" : "Extensões do identificador do odontólogo",
      "definition" : "Extensões incluídas no identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.use",
      "path" : "Practitioner.identifier.use",
      "short" : "Uso do identificador do odontólogo",
      "definition" : "usual: identificador usual do odontólogo. official: identificador oficial do odontólogo. temp: identificador temporário do odontólogo. secondary: identificador secundário do odontólogo.",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type",
      "path" : "Practitioner.identifier.type",
      "short" : "Tipo do identificador do odontólogo",
      "definition" : "Código que representa o tipo do identificador do odontólogo",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "DDS"
        }]
      },
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v2-0203"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.id",
      "path" : "Practitioner.identifier.type.id",
      "short" : "Id lógico do tipo do identificador do odontólogo",
      "definition" : "Id lógico do tipo do identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.extension",
      "path" : "Practitioner.identifier.type.extension",
      "short" : "Extensões do tipo do identificador do odontólogo",
      "definition" : "Extensões incluídas no tipo do identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.coding",
      "path" : "Practitioner.identifier.type.coding",
      "short" : "Codificação do tipo do identificador do odontólogo",
      "definition" : "Codificação que representa o tipo do identificador do odontólogo",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.coding.id",
      "path" : "Practitioner.identifier.type.coding.id",
      "short" : "Id lógico da codificação do tipo do identificador do odontólogo",
      "definition" : "Id lógico da codificação do tipo do identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.coding.extension",
      "path" : "Practitioner.identifier.type.coding.extension",
      "short" : "Extensões da codificação do tipo do identificador do odontólogo",
      "definition" : "Extensões incluídas na codificação do tipo do identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.coding.system",
      "path" : "Practitioner.identifier.type.coding.system",
      "short" : "Sistema da codificação do tipo do identificador do odontólogo",
      "definition" : "Sistema que identifica a codificação do tipo do identificador do odontólogo",
      "min" : 1,
      "fixedUri" : "http://terminology.hl7.org/CodeSystem/v2-0203"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.coding.version",
      "path" : "Practitioner.identifier.type.coding.version",
      "short" : "Versão da codificação do tipo do identificador do odontólogo",
      "definition" : "Versão da codificação do tipo do identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.coding.code",
      "path" : "Practitioner.identifier.type.coding.code",
      "short" : "Código da codificação do tipo do identificador do odontólogo",
      "definition" : "Código que representa a codificação do tipo do identificador do odontólogo",
      "min" : 1,
      "patternCode" : "RI"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.coding.display",
      "path" : "Practitioner.identifier.type.coding.display",
      "short" : "Texto da codificação do tipo do identificador do odontólogo",
      "definition" : "Texto que representa a codificação do tipo do identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.coding.userSelected",
      "path" : "Practitioner.identifier.type.coding.userSelected",
      "short" : "Seleção do usuário da codificação do tipo do identificador do odontólogo",
      "definition" : "Indica se a codificação do tipo do identificador do odontólogo foi selecionada pelo usuário"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.type.text",
      "path" : "Practitioner.identifier.type.text",
      "short" : "Texto do tipo do identificador do odontólogo",
      "definition" : "Texto que representa o tipo do identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.system",
      "path" : "Practitioner.identifier.system",
      "short" : "Sistema do identificador do odontólogo",
      "definition" : "Sistema que identifica o tipo do identificador do odontólogo",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "description" : "Sistema do identificador do odontólogo",
        "valueSet" : "https://terminologia.saude.gov.br/fhir/ValueSet/BRCRO"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.value",
      "path" : "Practitioner.identifier.value",
      "short" : "Valor do identificador do odontólogo",
      "definition" : "Valor do identificador do odontólogo",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.period",
      "path" : "Practitioner.identifier.period",
      "short" : "Período de uso do identificador do odontólogo",
      "definition" : "Período de tempo durante o qual o identificador do odontólogo foi utilizado"
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.assigner",
      "path" : "Practitioner.identifier.assigner",
      "short" : "Entidade que atribuiu o identificador do odontólogo",
      "definition" : "Entidade que atribuiu o identificador do odontólogo",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Practitioner.identifier:identificadorOdontologo.assigner.display",
      "path" : "Practitioner.identifier.assigner.display",
      "short" : "Nome da entidade que atribuiu o identificador do odontólogo"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro",
      "path" : "Practitioner.identifier",
      "sliceName" : "identificadorEnfermeiro",
      "short" : "Identificador do enfermeiro",
      "definition" : "Identificador do enfermeiro",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.id",
      "path" : "Practitioner.identifier.id",
      "short" : "Id lógico do identificador do enfermeiro",
      "definition" : "Id lógico do identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.extension",
      "path" : "Practitioner.identifier.extension",
      "short" : "Extensões do identificador do enfermeiro",
      "definition" : "Extensões incluídas no identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.use",
      "path" : "Practitioner.identifier.use",
      "short" : "Uso do identificador do enfermeiro",
      "definition" : "usual: identificador usual do enfermeiro. official: identificador oficial do enfermeiro. temp: identificador temporário do enfermeiro. secondary: identificador secundário do enfermeiro.",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type",
      "path" : "Practitioner.identifier.type",
      "short" : "Tipo do identificador do enfermeiro",
      "definition" : "Código que representa o tipo do identificador do enfermeiro",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "RN"
        }]
      },
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v2-0203"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.id",
      "path" : "Practitioner.identifier.type.id",
      "short" : "Id lógico do tipo do identificador do enfermeiro",
      "definition" : "Id lógico do tipo do identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.extension",
      "path" : "Practitioner.identifier.type.extension",
      "short" : "Extensões do tipo do identificador do enfermeiro",
      "definition" : "Extensões incluídas no tipo do identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.coding",
      "path" : "Practitioner.identifier.type.coding",
      "short" : "Codificação do tipo do identificador do enfermeiro",
      "definition" : "Codificação que representa o tipo do identificador do enfermeiro",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.coding.id",
      "path" : "Practitioner.identifier.type.coding.id",
      "short" : "Id lógico da codificação do tipo do identificador do enfermeiro",
      "definition" : "Id lógico da codificação do tipo do identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.coding.extension",
      "path" : "Practitioner.identifier.type.coding.extension",
      "short" : "Extensões da codificação do tipo do identificador do enfermeiro",
      "definition" : "Extensões incluídas na codificação do tipo do identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.coding.system",
      "path" : "Practitioner.identifier.type.coding.system",
      "short" : "Sistema da codificação do tipo do identificador do enfermeiro",
      "definition" : "Sistema que identifica a codificação do tipo do identificador do enfermeiro",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.coding.version",
      "path" : "Practitioner.identifier.type.coding.version",
      "short" : "Versão da codificação do tipo do identificador do enfermeiro",
      "definition" : "Versão da codificação do tipo do identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.coding.code",
      "path" : "Practitioner.identifier.type.coding.code",
      "short" : "Código da codificação do tipo do identificador do enfermeiro",
      "definition" : "Código que representa a codificação do tipo do identificador do enfermeiro",
      "min" : 1,
      "patternCode" : "RN"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.coding.display",
      "path" : "Practitioner.identifier.type.coding.display",
      "short" : "Texto da codificação do tipo do identificador do enfermeiro",
      "definition" : "Texto que representa a codificação do tipo do identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.coding.userSelected",
      "path" : "Practitioner.identifier.type.coding.userSelected",
      "short" : "Seleção do usuário da codificação do tipo do identificador do enfermeiro",
      "definition" : "Indica se a codificação do tipo do identificador do enfermeiro foi selecionada pelo usuário"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.type.text",
      "path" : "Practitioner.identifier.type.text",
      "short" : "Texto do tipo do identificador do enfermeiro",
      "definition" : "Texto que representa o tipo do identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.system",
      "path" : "Practitioner.identifier.system",
      "short" : "Sistema do identificador do enfermeiro",
      "definition" : "Sistema que identifica o tipo do identificador do enfermeiro",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "description" : "Sistema do identificador do enfermeiro",
        "valueSet" : "https://terminologia.saude.gov.br/fhir/ValueSet/BRCOREN"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.value",
      "path" : "Practitioner.identifier.value",
      "short" : "Valor do identificador do enfermeiro",
      "definition" : "Valor do identificador do enfermeiro",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.period",
      "path" : "Practitioner.identifier.period",
      "short" : "Período de uso do identificador do enfermeiro",
      "definition" : "Período de tempo durante o qual o identificador do enfermeiro foi utilizado"
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.assigner",
      "path" : "Practitioner.identifier.assigner",
      "short" : "Entidade que atribuiu o identificador do enfermeiro",
      "definition" : "Entidade que atribuiu o identificador do enfermeiro",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Practitioner.identifier:identificadorEnfermeiro.assigner.display",
      "path" : "Practitioner.identifier.assigner.display",
      "short" : "Nome da entidade que atribuiu o identificador do enfermeiro"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais",
      "path" : "Practitioner.identifier",
      "sliceName" : "identificadorOutrosProfissionais",
      "short" : "Identificador de outros profissionais",
      "definition" : "Identificador de outros profissionais",
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.id",
      "path" : "Practitioner.identifier.id",
      "short" : "Id lógico do identificador de outros profissionais",
      "definition" : "Id lógico do identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.extension",
      "path" : "Practitioner.identifier.extension",
      "short" : "Extensões do identificador de outros profissionais",
      "definition" : "Extensões incluídas no identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.use",
      "path" : "Practitioner.identifier.use",
      "short" : "Uso do identificador de outros profissionais",
      "definition" : "usual: identificador usual de outros profissionais. official: identificador oficial de outros profissionais. temp: identificador temporário de outros profissionais. secondary: identificador secundário de outros profissionais.",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type",
      "path" : "Practitioner.identifier.type",
      "short" : "Tipo do identificador de outros profissionais",
      "definition" : "Código que representa o tipo do identificador de outros profissionais",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "RI"
        }]
      },
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v2-0203"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.id",
      "path" : "Practitioner.identifier.type.id",
      "short" : "Id lógico do tipo do identificador de outros profissionais",
      "definition" : "Id lógico do tipo do identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.extension",
      "path" : "Practitioner.identifier.type.extension",
      "short" : "Extensões do tipo do identificador de outros profissionais",
      "definition" : "Extensões incluídas no tipo do identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.coding",
      "path" : "Practitioner.identifier.type.coding",
      "short" : "Codificação do tipo do identificador de outros profissionais",
      "definition" : "Codificação que representa o tipo do identificador de outros profissionais",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.coding.id",
      "path" : "Practitioner.identifier.type.coding.id",
      "short" : "Id lógico da codificação do tipo do identificador de outros profissionais",
      "definition" : "Id lógico da codificação do tipo do identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.coding.extension",
      "path" : "Practitioner.identifier.type.coding.extension",
      "short" : "Extensões da codificação do tipo do identificador de outros profissionais",
      "definition" : "Extensões incluídas na codificação do tipo do identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.coding.system",
      "path" : "Practitioner.identifier.type.coding.system",
      "short" : "Sistema da codificação do tipo do identificador de outros profissionais",
      "definition" : "Sistema que identifica a codificação do tipo do identificador de outros profissionais",
      "min" : 1,
      "fixedUri" : "http://terminology.hl7.org/CodeSystem/v2-0203"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.coding.version",
      "path" : "Practitioner.identifier.type.coding.version",
      "short" : "Versão da codificação do tipo do identificador de outros profissionais",
      "definition" : "Versão da codificação do tipo do identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.coding.code",
      "path" : "Practitioner.identifier.type.coding.code",
      "short" : "Código da codificação do tipo do identificador de outros profissionais",
      "definition" : "Código que representa a codificação do tipo do identificador de outros profissionais",
      "min" : 1,
      "patternCode" : "RI"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.coding.display",
      "path" : "Practitioner.identifier.type.coding.display",
      "short" : "Texto da codificação do tipo do identificador de outros profissionais",
      "definition" : "Texto que representa a codificação do tipo do identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.coding.userSelected",
      "path" : "Practitioner.identifier.type.coding.userSelected",
      "short" : "Seleção do usuário da codificação do tipo do identificador de outros profissionais",
      "definition" : "Indica se a codificação do tipo do identificador de outros profissionais foi selecionada pelo usuário"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.type.text",
      "path" : "Practitioner.identifier.type.text",
      "short" : "Texto do tipo do identificador de outros profissionais",
      "definition" : "Texto que representa o tipo do identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.system",
      "path" : "Practitioner.identifier.system",
      "short" : "Sistema do identificador de outros profissionais",
      "definition" : "Sistema que identifica o tipo do identificador de outros profissionais",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "description" : "Sistema do identificador de outros profissionais",
        "valueSet" : "https://terminologia.saude.gov.br/fhir/ValueSet/BROutrosProfissionais"
      }
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.value",
      "path" : "Practitioner.identifier.value",
      "short" : "Valor do identificador de outros profissionais",
      "definition" : "Valor do identificador de outros profissionais",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.period",
      "path" : "Practitioner.identifier.period",
      "short" : "Período de uso do identificador de outros profissionais",
      "definition" : "Período de tempo durante o qual o identificador de outros profissionais foi utilizado"
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.assigner",
      "path" : "Practitioner.identifier.assigner",
      "short" : "Entidade que atribuiu o identificador de outros profissionais",
      "definition" : "Entidade que atribuiu o identificador de outros profissionais",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Practitioner.identifier:identificadorOutrosProfissionais.assigner.display",
      "path" : "Practitioner.identifier.assigner.display",
      "short" : "Nome da entidade que atribuiu o identificador de outros profissionais"
    },
    {
      "id" : "Practitioner.active",
      "path" : "Practitioner.active",
      "short" : "Indica se o registro deste profissional está ativo",
      "definition" : "Indica se o registro deste profissional está ativo",
      "min" : 1
    },
    {
      "id" : "Practitioner.name",
      "path" : "Practitioner.name",
      "short" : "Nome do profissional",
      "definition" : "Nome(s) associado(s) ao profissional."
    },
    {
      "id" : "Practitioner.name.id",
      "path" : "Practitioner.name.id",
      "short" : "Identificador único do nome do profissional",
      "definition" : "Identificador único para referenciar o nome do profissional"
    },
    {
      "id" : "Practitioner.name.extension",
      "path" : "Practitioner.name.extension",
      "short" : "Extensões do nome do profissional",
      "definition" : "Extensões incluídas no nome do profissional"
    },
    {
      "id" : "Practitioner.name.use",
      "path" : "Practitioner.name.use",
      "short" : "Usos do nome do profissional",
      "definition" : "official: nome oficial atual, conforme registrado na certidão de registro civil mais atual do profissional. maiden: nome oficial de solteiro(a), quando houve uma alteração de nome decorrente de uma união de qualquer tipo. old: nome oficial anterior, quando houve uma alteração de nome em uma certidão de registro civil ou decisão judicial decorrente de qualquer outra situação que não seja uma união. usual: nome social. temp: nome temporário, como aqueles utilizados em programas de proteção a testemunhas. anonymous: uso exclusivo para anonimização de registros de profissionais."
    },
    {
      "id" : "Practitioner.name.text",
      "path" : "Practitioner.name.text",
      "short" : "Texto do nome do profissional",
      "definition" : "Nome completo do profissional, composto pelo nome próprio, que pode ser mais de um quando trata-se de um nome composto, pelo sobrenome e pelo sufixo (Filho, Neto, Júnior etc.) quando aplicável."
    },
    {
      "id" : "Practitioner.name.family",
      "path" : "Practitioner.name.family",
      "short" : "Sobrenome",
      "definition" : "O(s) sobrenome(s) do indivíduo, quando é possível coletar esta informação desagregada."
    },
    {
      "id" : "Practitioner.name.given",
      "path" : "Practitioner.name.given",
      "short" : "Nome próprio",
      "definition" : "O(s) nome(s) próprio(s) do indivíduo, quando é possível coletar esta informação desagregada."
    },
    {
      "id" : "Practitioner.name.prefix",
      "path" : "Practitioner.name.prefix",
      "short" : "Prefixo do nome",
      "definition" : "Prefixo do nome do indivíduo, quando é possível coletar esta informação desagregada."
    },
    {
      "id" : "Practitioner.name.suffix",
      "path" : "Practitioner.name.suffix",
      "short" : "Sufixo do nome",
      "definition" : "Sufixo do nome do indivíduo, quando é possível coletar esta informação desagregada."
    },
    {
      "id" : "Practitioner.name.period",
      "path" : "Practitioner.name.period",
      "short" : "Período de uso do nome",
      "definition" : "Período de tempo durante o qual o nome foi utilizado pelo indivíduo."
    },
    {
      "id" : "Practitioner.telecom",
      "path" : "Practitioner.telecom",
      "short" : "Contatos do profissional",
      "definition" : "nformações do(s) meio(s) de contato com o profissional. Não devem ser informados meios de contato pessoais, apenas profissionais."
    },
    {
      "id" : "Practitioner.address",
      "path" : "Practitioner.address",
      "short" : "Endereços do profissional",
      "definition" : "Dados do(s) endereço(s) onde o profissional pode ser localizado. Não devem ser informados endereços pessoais, apenas profissionais."
    },
    {
      "id" : "Practitioner.gender",
      "path" : "Practitioner.gender",
      "short" : "Sexo",
      "definition" : "male: masculino. female: feminino. unknown: ignorado."
    },
    {
      "id" : "Practitioner.birthDate",
      "path" : "Practitioner.birthDate",
      "short" : "Data de nascimento",
      "definition" : "Data de nascimento do profissional."
    },
    {
      "id" : "Practitioner.photo",
      "path" : "Practitioner.photo",
      "short" : "Fotografia do profissional"
    },
    {
      "id" : "Practitioner.qualification",
      "path" : "Practitioner.qualification",
      "short" : "Qualificações do profissional",
      "definition" : "A(s) qualificação(ões), conforme a formação, certificações ou acreditações que o profissional possui.",
      "max" : "1"
    },
    {
      "id" : "Practitioner.qualification.id",
      "path" : "Practitioner.qualification.id",
      "short" : "Identificador único da qualificação do profissional",
      "definition" : "Identificador único para referenciar a qualificação do profissional"
    },
    {
      "id" : "Practitioner.qualification.extension",
      "path" : "Practitioner.qualification.extension",
      "short" : "Extensões da qualificação do profissional",
      "definition" : "Extensões incluídas na qualificação do profissional"
    },
    {
      "id" : "Practitioner.qualification.identifier",
      "path" : "Practitioner.qualification.identifier",
      "short" : "Identificador da qualificação do profissional",
      "definition" : "Identificador da qualificação do profissional"
    },
    {
      "id" : "Practitioner.qualification.code",
      "path" : "Practitioner.qualification.code",
      "short" : "Código da qualificação do profissional",
      "definition" : "Código da qualificação do profissional",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BROcupacao-1.0"
      }
    },
    {
      "id" : "Practitioner.qualification.code.coding",
      "path" : "Practitioner.qualification.code.coding",
      "short" : "Codificação da qualificação do profissional",
      "definition" : "Codificação da qualificação do profissional"
    },
    {
      "id" : "Practitioner.qualification.code.coding.system",
      "path" : "Practitioner.qualification.code.coding.system",
      "short" : "Sistema de codificação da qualificação do profissional",
      "definition" : "Sistema de codificação da qualificação do profissional"
    },
    {
      "id" : "Practitioner.qualification.code.coding.version",
      "path" : "Practitioner.qualification.code.coding.version",
      "short" : "Versão do sistema de codificação da qualificação do profissional",
      "definition" : "Versão do sistema de codificação da qualificação do profissional"
    },
    {
      "id" : "Practitioner.qualification.code.coding.code",
      "path" : "Practitioner.qualification.code.coding.code",
      "short" : "Código da qualificação do profissional",
      "definition" : "Código da qualificação do profissional"
    },
    {
      "id" : "Practitioner.qualification.period",
      "path" : "Practitioner.qualification.period",
      "short" : "Período de validade da qualificação do profissional",
      "definition" : "Período de validade da qualificação do profissional"
    },
    {
      "id" : "Practitioner.qualification.issuer",
      "path" : "Practitioner.qualification.issuer",
      "short" : "Emissor da qualificação do profissional",
      "definition" : "Emissor da qualificação do profissional",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Practitioner.communication",
      "path" : "Practitioner.communication",
      "short" : "Idiomas que o profissional domina",
      "definition" : "Idiomas que o profissional domina"
    }]
  }
}

```
