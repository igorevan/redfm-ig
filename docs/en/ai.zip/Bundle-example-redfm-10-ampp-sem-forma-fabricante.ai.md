# Bundle 10 de exemplo do REDFM (AMPP sem forma e com fabricante) - Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS v1.0.0-release

## Example Bundle: Bundle 10 de exemplo do REDFM (AMPP sem forma e com fabricante)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "example-redfm-10-ampp-sem-forma-fabricante",
  "identifier" : {
    "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-12334",
    "value" : "60eabcf4-27fe-4409-9e22-890d3d23ce7d"
  },
  "type" : "document",
  "timestamp" : "2026-06-20T14:59:51.244-03:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:58e54a1d-550e-48bc-9e09-6230c972078a",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "58e54a1d-550e-48bc-9e09-6230c972078a",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSRegistroEletronicoDispensacaoFornecimentoMedicamentos"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_58e54a1d-550e-48bc-9e09-6230c972078a\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Composition 58e54a1d-550e-48bc-9e09-6230c972078a</b></p><a name=\"58e54a1d-550e-48bc-9e09-6230c972078a\"> </a><a name=\"hc58e54a1d-550e-48bc-9e09-6230c972078a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSRegistroEletronicoDispensacaoFornecimentoMedicamentos.html\">Registro Eletrônico de Dispensação ou Fornecimento de Medicamentos - REDFM</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento REDFM}\">Registro Eletrônico de Dispensação ou Fornecimento de Medicamentos</span></p><p><b>date</b>: 2026-06-20</p><p><b>author</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/5354072</p><p><b>title</b>: Registro Eletrônico de Dispensação ou Fornecimento de Medicamentos</p></div>"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento",
          "code" : "REDFM"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      },
      "date" : "2026-06-20",
      "author" : [{
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
          "value" : "5354072"
        }
      }],
      "title" : "Registro Eletrônico de Dispensação ou Fornecimento de Medicamentos",
      "section" : [{
        "title" : "Medicamentos Dispensados",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "56445-0"
          }]
        },
        "entry" : [{
          "reference" : "urn:uuid:a54219b8-f741-4c47-b662-e4f8dfa49ab6"
        },
        {
          "reference" : "urn:uuid:1a9af1c7-1010-4b4d-9391-abf319c4fea9"
        },
        {
          "reference" : "urn:uuid:8352374b-dd32-4091-b381-35c9b31a8e2d"
        }]
      },
      {
        "title" : "Informações da Prescrição",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "57828-6"
          }]
        },
        "section" : [{
          "title" : "Motivo(s) da Prescrição",
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "75310-3"
            }]
          },
          "entry" : [{
            "reference" : "urn:uuid:97704a02-cd01-4415-8848-d674a9475385"
          },
          {
            "reference" : "urn:uuid:02ed6495-4d87-4ef5-bd30-e350aebd370e"
          }]
        },
        {
          "title" : "Medicamentos Prescritos",
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "57828-6"
            }]
          },
          "entry" : [{
            "reference" : "urn:uuid:44b8028b-6005-45d2-9ea7-bbc2d6e76c26"
          },
          {
            "reference" : "urn:uuid:7e4ff9a3-b0b0-44f9-be0e-c4a18a754b1e"
          },
          {
            "reference" : "urn:uuid:fce2b352-aeb8-4bc9-8932-4171ff2afe61"
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:a54219b8-f741-4c47-b662-e4f8dfa49ab6",
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "a54219b8-f741-4c47-b662-e4f8dfa49ab6",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSDispensacaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationDispense_a54219b8-f741-4c47-b662-e4f8dfa49ab6\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MedicationDispense a54219b8-f741-4c47-b662-e4f8dfa49ab6</b></p><a name=\"a54219b8-f741-4c47-b662-e4f8dfa49ab6\"> </a><a name=\"hca54219b8-f741-4c47-b662-e4f8dfa49ab6\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSDispensacaoMedicamento.html\">Dispensação ou Fornecimento de Medicamento</a></p></div><p><b>identifier</b>: <code>http://www.saude.gov.br/fhir/r4/NamingSystem/dispensed-item-id</code>/e6f89964-b218-4fb3-9603-e0897c5c2181</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/medicationrequest-category community}\">Community</span></p><p><b>medication</b>: <a href=\"Bundle-example-redfm-01-prescricao-na-rnds.html#urn-uuid-c509592e-d4ec-45fd-8603-60daf58ae739\">Medication Dimesilato de Lisdexanfetamina 30mg Cápsula</a></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-example-redfm-01-prescricao-na-rnds.html#urn-uuid-f08edf47-df0b-41a9-8786-95dca79bb399\">PractitionerRole FARMACEUTICO</a></td></tr></table><p><b>authorizingPrescription</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-44b8028b-6005-45d2-9ea7-bbc2d6e76c26\">MedicationRequest: identifier = http://www.saude.gov.br/fhir/r4/NamingSystem/prescription-item-id#ec918ffe-23e1-42bc-8eb4-5f32fc6200d7; status = active; intent = order; category = Community; medication[x] = -&gt;Medication Dimesilato de Lisdexanfetamina 30mg Cápsula; authoredOn = 2026-06-15 16:29:18-0300; groupIdentifier = http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061#ae2f417f-963d-460a-ab7a-68d7285cb5c3</a></p><p><b>type</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDispensacaoRealizada fully-dispensing}\">Fully Dispensing</span></p><p><b>quantity</b>: 10 Comprimido<span style=\"background: LightGoldenRodYellow\"> (Detalhes: Unidade de Medida código19 = 'Comprimido')</span></p><p><b>whenHandedOver</b>: 2026-06-20 14:59:51-0300</p><p><b>receiver</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p></div>"
      },
      "identifier" : [{
        "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/dispensed-item-id",
        "value" : "e6f89964-b218-4fb3-9603-e0897c5c2181"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medicationrequest-category",
          "code" : "community"
        }]
      },
      "medicationReference" : {
        "reference" : "urn:uuid:c509592e-d4ec-45fd-8603-60daf58ae739"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      },
      "performer" : [{
        "actor" : {
          "reference" : "urn:uuid:f08edf47-df0b-41a9-8786-95dca79bb399"
        }
      }],
      "authorizingPrescription" : [{
        "id" : "out-of-rnds",
        "reference" : "urn:uuid:44b8028b-6005-45d2-9ea7-bbc2d6e76c26"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDispensacaoRealizada",
          "code" : "fully-dispensing"
        }]
      },
      "quantity" : {
        "value" : 10,
        "unit" : "Comprimido",
        "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
        "code" : "19"
      },
      "whenHandedOver" : "2026-06-20T14:59:51.244-03:00",
      "receiver" : [{
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:c509592e-d4ec-45fd-8603-60daf58ae739",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "c509592e-d4ec-45fd-8603-60daf58ae739",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_c509592e-d4ec-45fd-8603-60daf58ae739\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Medication c509592e-d4ec-45fd-8603-60daf58ae739</b></p><a name=\"c509592e-d4ec-45fd-8603-60daf58ae739\"> </a><a name=\"hcc509592e-d4ec-45fd-8603-60daf58ae739\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSMedicamento.html\">Medicamento</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmAMPP @brasil51974687095}\">Cloridrato de Fluoxetina 20 mg cápsula (Medley Farmacêutica Ltda) x 30 cápsulas</span></p><h3>Batches</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>LotNumber</b></td><td><b>ExpirationDate</b></td></tr><tr><td style=\"display: none\">*</td><td>587AT765H</td><td>2027-10-31</td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmAMPP",
          "code" : "@brasil51974687095"
        }]
      },
      "batch" : {
        "lotNumber" : "587AT765H",
        "expirationDate" : "2027-10-31"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:1a9af1c7-1010-4b4d-9391-abf319c4fea9",
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "1a9af1c7-1010-4b4d-9391-abf319c4fea9",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSDispensacaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationDispense_1a9af1c7-1010-4b4d-9391-abf319c4fea9\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MedicationDispense 1a9af1c7-1010-4b4d-9391-abf319c4fea9</b></p><a name=\"1a9af1c7-1010-4b4d-9391-abf319c4fea9\"> </a><a name=\"hc1a9af1c7-1010-4b4d-9391-abf319c4fea9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSDispensacaoMedicamento.html\">Dispensação ou Fornecimento de Medicamento</a></p></div><p><b>identifier</b>: <code>http://www.saude.gov.br/fhir/r4/NamingSystem/dispensed-item-id</code>/e6f89964-b218-4fb3-9603-e0897c5c2181</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/medicationrequest-category community}\">Community</span></p><p><b>medication</b>: <a href=\"Bundle-example-redfm-01-prescricao-na-rnds.html#urn-uuid-05b1af54-94cd-4766-ad8f-d39bdb23eafe\">Medication Acetilcisteína 600mg Comprimido efervescente</a></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-example-redfm-01-prescricao-na-rnds.html#urn-uuid-f08edf47-df0b-41a9-8786-95dca79bb399\">PractitionerRole FARMACEUTICO</a></td></tr></table><p><b>authorizingPrescription</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-7e4ff9a3-b0b0-44f9-be0e-c4a18a754b1e\">MedicationRequest: identifier = http://www.saude.gov.br/fhir/r4/NamingSystem/prescription-item-id#5923026f-c64b-42b7-81b8-c282c7822828; status = active; intent = order; category = Community; medication[x] = -&gt;Medication Acetilcisteína 600mg Comprimido efervescente; authoredOn = 2026-06-15 07:21:52-0300; groupIdentifier = http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061#ae2f417f-963d-460a-ab7a-68d7285cb5c3</a></p><p><b>type</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDispensacaoRealizada fully-dispensing}\">Fully Dispensing</span></p><p><b>quantity</b>: 10 Comprimido<span style=\"background: LightGoldenRodYellow\"> (Detalhes: Unidade de Medida código19 = 'Comprimido')</span></p><p><b>whenHandedOver</b>: 2026-06-20 14:59:51-0300</p><p><b>receiver</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p></div>"
      },
      "identifier" : [{
        "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/dispensed-item-id",
        "value" : "e6f89964-b218-4fb3-9603-e0897c5c2181"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medicationrequest-category",
          "code" : "community"
        }]
      },
      "medicationReference" : {
        "reference" : "urn:uuid:05b1af54-94cd-4766-ad8f-d39bdb23eafe"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      },
      "performer" : [{
        "actor" : {
          "reference" : "urn:uuid:f08edf47-df0b-41a9-8786-95dca79bb399"
        }
      }],
      "authorizingPrescription" : [{
        "id" : "out-of-rnds",
        "reference" : "urn:uuid:7e4ff9a3-b0b0-44f9-be0e-c4a18a754b1e"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDispensacaoRealizada",
          "code" : "fully-dispensing"
        }]
      },
      "quantity" : {
        "value" : 10,
        "unit" : "Comprimido",
        "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
        "code" : "19"
      },
      "whenHandedOver" : "2026-06-20T14:59:51.244-03:00",
      "receiver" : [{
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:05b1af54-94cd-4766-ad8f-d39bdb23eafe",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "05b1af54-94cd-4766-ad8f-d39bdb23eafe",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_05b1af54-94cd-4766-ad8f-d39bdb23eafe\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Medication 05b1af54-94cd-4766-ad8f-d39bdb23eafe</b></p><a name=\"05b1af54-94cd-4766-ad8f-d39bdb23eafe\"> </a><a name=\"hc05b1af54-94cd-4766-ad8f-d39bdb23eafe\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSMedicamento.html\">Medicamento</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmVMP @brasil27983500460}\">Acetilcisteína 600mg Comprimido efervescente</span></p><p><b>manufacturer</b>: Identifier: <code>https://saude.gov.br/sid/cnpj</code>/83588144000138</p><p><b>form</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida 19}\">Comprimido</span></p><h3>Batches</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>LotNumber</b></td><td><b>ExpirationDate</b></td></tr><tr><td style=\"display: none\">*</td><td>587AT76587687H</td><td>2026-11-20</td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmVMP",
          "code" : "@brasil27983500460"
        }]
      },
      "manufacturer" : {
        "identifier" : {
          "system" : "https://saude.gov.br/sid/cnpj",
          "value" : "83588144000138"
        }
      },
      "form" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
          "code" : "19"
        }]
      },
      "batch" : {
        "lotNumber" : "587AT76587687H",
        "expirationDate" : "2026-11-20"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:8352374b-dd32-4091-b381-35c9b31a8e2d",
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "8352374b-dd32-4091-b381-35c9b31a8e2d",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSDispensacaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationDispense_8352374b-dd32-4091-b381-35c9b31a8e2d\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MedicationDispense 8352374b-dd32-4091-b381-35c9b31a8e2d</b></p><a name=\"8352374b-dd32-4091-b381-35c9b31a8e2d\"> </a><a name=\"hc8352374b-dd32-4091-b381-35c9b31a8e2d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSDispensacaoMedicamento.html\">Dispensação ou Fornecimento de Medicamento</a></p></div><p><b>identifier</b>: <code>http://www.saude.gov.br/fhir/r4/NamingSystem/dispensed-item-id</code>/e6f89964-b218-4fb3-9603-e0897c5c2181</p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/medicationrequest-category community}\">Community</span></p><p><b>medication</b>: <a href=\"Bundle-example-redfm-01-prescricao-na-rnds.html#urn-uuid-053ecfcf-ba49-43e1-a0a3-442dfab3b6c1\">Medication Dipirona Monoidratada 500mg comprimido</a></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-example-redfm-01-prescricao-na-rnds.html#urn-uuid-f08edf47-df0b-41a9-8786-95dca79bb399\">PractitionerRole FARMACEUTICO</a></td></tr></table><p><b>authorizingPrescription</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-fce2b352-aeb8-4bc9-8932-4171ff2afe61\">MedicationRequest: identifier = http://www.saude.gov.br/fhir/r4/NamingSystem/prescription-item-id#5923026f-c64b-42b7-81b8-c282c63546; status = active; intent = order; category = Community; medication[x] = -&gt;Medication Dipirona Monoidratada 500mg comprimido; authoredOn = 2026-06-15 07:21:52-0300; groupIdentifier = http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061#ae2f417f-963d-460a-ab7a-68d7285cb5c3</a></p><p><b>type</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDispensacaoRealizada fully-dispensing}\">Fully Dispensing</span></p><p><b>quantity</b>: 1.0 Comprimido<span style=\"background: LightGoldenRodYellow\"> (Detalhes: Unidade de Medida código19 = 'Comprimido')</span></p><p><b>whenHandedOver</b>: 2026-06-20 14:59:51-0300</p><p><b>receiver</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p></div>"
      },
      "identifier" : [{
        "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/dispensed-item-id",
        "value" : "e6f89964-b218-4fb3-9603-e0897c5c2181"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medicationrequest-category",
          "code" : "community"
        }]
      },
      "medicationReference" : {
        "reference" : "urn:uuid:053ecfcf-ba49-43e1-a0a3-442dfab3b6c1"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      },
      "performer" : [{
        "actor" : {
          "reference" : "urn:uuid:f08edf47-df0b-41a9-8786-95dca79bb399"
        }
      }],
      "authorizingPrescription" : [{
        "id" : "out-of-rnds",
        "reference" : "urn:uuid:fce2b352-aeb8-4bc9-8932-4171ff2afe61"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDispensacaoRealizada",
          "code" : "fully-dispensing"
        }]
      },
      "quantity" : {
        "value" : 1.0,
        "unit" : "Comprimido",
        "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
        "code" : "19"
      },
      "whenHandedOver" : "2026-06-20T14:59:51.244-03:00",
      "receiver" : [{
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:053ecfcf-ba49-43e1-a0a3-442dfab3b6c1",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "053ecfcf-ba49-43e1-a0a3-442dfab3b6c1",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_053ecfcf-ba49-43e1-a0a3-442dfab3b6c1\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Medication 053ecfcf-ba49-43e1-a0a3-442dfab3b6c1</b></p><a name=\"053ecfcf-ba49-43e1-a0a3-442dfab3b6c1\"> </a><a name=\"hc053ecfcf-ba49-43e1-a0a3-442dfab3b6c1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSMedicamento.html\">Medicamento</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmVMP @brasil20832536006}\">Dipirona Monoidratada 500mg comprimido</span></p><p><b>manufacturer</b>: Identifier: <code>https://saude.gov.br/sid/cnpj</code>/83588144000138</p><p><b>form</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida 19}\">Comprimido</span></p><h3>Batches</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>LotNumber</b></td><td><b>ExpirationDate</b></td></tr><tr><td style=\"display: none\">*</td><td>587AT7HJKJH6255765H</td><td>2026-09-27</td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmVMP",
          "code" : "@brasil20832536006"
        }]
      },
      "manufacturer" : {
        "identifier" : {
          "system" : "https://saude.gov.br/sid/cnpj",
          "value" : "83588144000138"
        }
      },
      "form" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
          "code" : "19"
        }]
      },
      "batch" : {
        "lotNumber" : "587AT7HJKJH6255765H",
        "expirationDate" : "2026-09-27"
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:f08edf47-df0b-41a9-8786-95dca79bb399",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "f08edf47-df0b-41a9-8786-95dca79bb399",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSLotacaoProfissional"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_f08edf47-df0b-41a9-8786-95dca79bb399\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: PractitionerRole f08edf47-df0b-41a9-8786-95dca79bb399</b></p><a name=\"f08edf47-df0b-41a9-8786-95dca79bb399\"> </a><a name=\"hcf08edf47-df0b-41a9-8786-95dca79bb399\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSLotacaoProfissional.html\">RNDSLotacaoProfissional</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Bundle-example-redfm-01-prescricao-na-rnds.html#urn-uuid-a21d5e5b-9443-4b5f-8b6e-866317682293\">Practitioner: identifier = Tax ID number,Pharmacist license number (use: official, )</a></p><p><b>organization</b>: <a href=\"Bundle-example-redfm-01-prescricao-na-rnds.html#urn-uuid-1756fd72-7d86-496c-a2bd-8ecbb75daa75\">Organization: identifier = https://saude.gov.br/sid/cnes#5354072</a></p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO 223405}\">FARMACEUTICO</span></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "urn:uuid:a21d5e5b-9443-4b5f-8b6e-866317682293"
      },
      "organization" : {
        "reference" : "urn:uuid:1756fd72-7d86-496c-a2bd-8ecbb75daa75"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO",
          "code" : "223405"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:a21d5e5b-9443-4b5f-8b6e-866317682293",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "a21d5e5b-9443-4b5f-8b6e-866317682293",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSProfissional"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_a21d5e5b-9443-4b5f-8b6e-866317682293\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Practitioner a21d5e5b-9443-4b5f-8b6e-866317682293</b></p><a name=\"a21d5e5b-9443-4b5f-8b6e-866317682293\"> </a><a name=\"hca21d5e5b-9443-4b5f-8b6e-866317682293\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSProfissional.html\">Profissional RNDS</a></p></div><p><b>identifier</b>: Tax ID number/31687007039, Pharmacist license number/154735 (utilização: official, )</p><p><b>active</b>: true</p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "TAX"
          }]
        },
        "system" : "https://saude.gov.br/sid/cpf",
        "value" : "31687007039"
      },
      {
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "RPH"
          }]
        },
        "system" : "https://saude.gov.br/sid/crf-sp",
        "value" : "154735"
      }],
      "active" : true
    }
  },
  {
    "fullUrl" : "urn:uuid:1756fd72-7d86-496c-a2bd-8ecbb75daa75",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "1756fd72-7d86-496c-a2bd-8ecbb75daa75",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSEstabelecimentoSaude"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_1756fd72-7d86-496c-a2bd-8ecbb75daa75\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Organization 1756fd72-7d86-496c-a2bd-8ecbb75daa75</b></p><a name=\"1756fd72-7d86-496c-a2bd-8ecbb75daa75\"> </a><a name=\"hc1756fd72-7d86-496c-a2bd-8ecbb75daa75\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSEstabelecimentoSaude.html\">Estabelecimento de Saúde RNDS</a></p></div><p><b>identifier</b>: <code>https://saude.gov.br/sid/cnes</code>/5354072</p><p><b>active</b>: true</p></div>"
      },
      "identifier" : [{
        "system" : "https://saude.gov.br/sid/cnes",
        "value" : "5354072"
      }],
      "active" : true
    }
  },
  {
    "fullUrl" : "urn:uuid:97704a02-cd01-4415-8848-d674a9475385",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "97704a02-cd01-4415-8848-d674a9475385",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProblemaDiagnostico"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_97704a02-cd01-4415-8848-d674a9475385\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Condition 97704a02-cd01-4415-8848-d674a9475385</b></p><a name=\"97704a02-cd01-4415-8848-d674a9475385\"> </a><a name=\"hc97704a02-cd01-4415-8848-d674a9475385\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRProblemaDiagnostico.html\">ProblemaDiagnóstico</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10 I10}\">Hipertensão essencial (primária)</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10",
          "code" : "I10"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:02ed6495-4d87-4ef5-bd30-e350aebd370e",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "02ed6495-4d87-4ef5-bd30-e350aebd370e",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProblemaDiagnostico"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_02ed6495-4d87-4ef5-bd30-e350aebd370e\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Condition 02ed6495-4d87-4ef5-bd30-e350aebd370e</b></p><a name=\"02ed6495-4d87-4ef5-bd30-e350aebd370e\"> </a><a name=\"hc02ed6495-4d87-4ef5-bd30-e350aebd370e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRProblemaDiagnostico.html\">ProblemaDiagnóstico</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCIAP2 L18}\">Dores musculares</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCIAP2",
          "code" : "L18"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:44b8028b-6005-45d2-9ea7-bbc2d6e76c26",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "44b8028b-6005-45d2-9ea7-bbc2d6e76c26",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSPrescricaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_44b8028b-6005-45d2-9ea7-bbc2d6e76c26\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MedicationRequest 44b8028b-6005-45d2-9ea7-bbc2d6e76c26</b></p><a name=\"44b8028b-6005-45d2-9ea7-bbc2d6e76c26\"> </a><a name=\"hc44b8028b-6005-45d2-9ea7-bbc2d6e76c26\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSPrescricaoMedicamento.html\">Prescrição de Medicamento - RNDS</a></p></div><p><b>identifier</b>: <code>http://www.saude.gov.br/fhir/r4/NamingSystem/prescription-item-id</code>/ec918ffe-23e1-42bc-8eb4-5f32fc6200d7</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/medicationrequest-category community}\">Community</span></p><p><b>medication</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-56efbacd-8f3d-417a-b870-57be181cecc3\">Medication Dimesilato de Lisdexanfetamina 30mg Cápsula</a></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p><p><b>authoredOn</b>: 2026-06-15 16:29:18-0300</p><p><b>requester</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-2bf69a6c-643d-45eb-8e23-9d8e9450fc0c\">PractitionerRole MEDICO DA ESTRATEGIA DE SAUDE DA FAMILIA</a></p><p><b>groupIdentifier</b>: <code>http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061</code>/ae2f417f-963d-460a-ab7a-68d7285cb5c3</p><blockquote><p><b>dosageInstruction</b></p><p><b>text</b>: Posologia: 1 comprimido, pela noite.</p><p><b>timing</b>: Contagem 1  times, Noite, Uma vez</p><p><b>route</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao 10907}\">Oral</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1.0 Comprimido<span style=\"background: LightGoldenRodYellow\"> (Detalhes: Unidade de Medida código19 = 'Comprimido')</span></td></tr></table></blockquote><h3>DispenseRequests</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ValidityPeriod</b></td><td><b>Quantity</b></td></tr><tr><td style=\"display: none\">*</td><td>2026-06-15 00:00:00+0000 --&gt; 2026-06-24 00:00:00+0000</td><td>10</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/prescription-item-id",
        "value" : "ec918ffe-23e1-42bc-8eb4-5f32fc6200d7"
      }],
      "status" : "active",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medicationrequest-category",
          "code" : "community"
        }]
      }],
      "medicationReference" : {
        "reference" : "urn:uuid:56efbacd-8f3d-417a-b870-57be181cecc3"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      },
      "authoredOn" : "2026-06-15T16:29:18.226-03:00",
      "requester" : {
        "reference" : "urn:uuid:2bf69a6c-643d-45eb-8e23-9d8e9450fc0c"
      },
      "groupIdentifier" : {
        "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061",
        "value" : "ae2f417f-963d-460a-ab7a-68d7285cb5c3"
      },
      "dosageInstruction" : [{
        "text" : "Posologia: 1 comprimido, pela noite.",
        "timing" : {
          "repeat" : {
            "count" : 1,
            "countMax" : 10,
            "frequency" : 1,
            "when" : ["NIGHT"]
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao",
            "code" : "10907"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1.0,
            "unit" : "Comprimido",
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
            "code" : "19"
          }
        }]
      }],
      "dispenseRequest" : {
        "validityPeriod" : {
          "start" : "2026-06-15T00:00:00Z",
          "end" : "2026-06-24T00:00:00Z"
        },
        "quantity" : {
          "value" : 10
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:56efbacd-8f3d-417a-b870-57be181cecc3",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "56efbacd-8f3d-417a-b870-57be181cecc3",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_56efbacd-8f3d-417a-b870-57be181cecc3\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Medication 56efbacd-8f3d-417a-b870-57be181cecc3</b></p><a name=\"56efbacd-8f3d-417a-b870-57be181cecc3\"> </a><a name=\"hc56efbacd-8f3d-417a-b870-57be181cecc3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSMedicamento.html\">Medicamento</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmAMPP @brasil51974687095}\">Cloridrato de Fluoxetina 20 mg cápsula (Medley Farmacêutica Ltda) x 30 cápsulas</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmAMPP",
          "code" : "@brasil51974687095"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:7e4ff9a3-b0b0-44f9-be0e-c4a18a754b1e",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "7e4ff9a3-b0b0-44f9-be0e-c4a18a754b1e",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSPrescricaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_7e4ff9a3-b0b0-44f9-be0e-c4a18a754b1e\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MedicationRequest 7e4ff9a3-b0b0-44f9-be0e-c4a18a754b1e</b></p><a name=\"7e4ff9a3-b0b0-44f9-be0e-c4a18a754b1e\"> </a><a name=\"hc7e4ff9a3-b0b0-44f9-be0e-c4a18a754b1e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSPrescricaoMedicamento.html\">Prescrição de Medicamento - RNDS</a></p></div><p><b>identifier</b>: <code>http://www.saude.gov.br/fhir/r4/NamingSystem/prescription-item-id</code>/5923026f-c64b-42b7-81b8-c282c7822828</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/medicationrequest-category community}\">Community</span></p><p><b>medication</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-12488d06-405a-4cc7-b9d7-f0c533d55ebe\">Medication Acetilcisteína 600mg Comprimido efervescente</a></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p><p><b>authoredOn</b>: 2026-06-15 07:21:52-0300</p><p><b>requester</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-2bf69a6c-643d-45eb-8e23-9d8e9450fc0c\">PractitionerRole MEDICO DA ESTRATEGIA DE SAUDE DA FAMILIA</a></p><p><b>groupIdentifier</b>: <code>http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061</code>/ae2f417f-963d-460a-ab7a-68d7285cb5c3</p><blockquote><p><b>dosageInstruction</b></p><p><b>text</b>: Posologia: 1 comprimido, a cada 12 horas.</p><p><b>timing</b>: Contagem 1  times, Uma vez</p><p><b>route</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao 10907}\">Oral</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1.0 Comprimido<span style=\"background: LightGoldenRodYellow\"> (Detalhes: Unidade de Medida código19 = 'Comprimido')</span></td></tr></table></blockquote><h3>DispenseRequests</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ValidityPeriod</b></td><td><b>Quantity</b></td></tr><tr><td style=\"display: none\">*</td><td>2026-06-15 00:00:00+0000 --&gt; 2026-06-19 00:00:00+0000</td><td>10</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/prescription-item-id",
        "value" : "5923026f-c64b-42b7-81b8-c282c7822828"
      }],
      "status" : "active",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medicationrequest-category",
          "code" : "community"
        }]
      }],
      "medicationReference" : {
        "reference" : "urn:uuid:12488d06-405a-4cc7-b9d7-f0c533d55ebe"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      },
      "authoredOn" : "2026-06-15T07:21:52.321-03:00",
      "requester" : {
        "reference" : "urn:uuid:2bf69a6c-643d-45eb-8e23-9d8e9450fc0c"
      },
      "groupIdentifier" : {
        "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061",
        "value" : "ae2f417f-963d-460a-ab7a-68d7285cb5c3"
      },
      "dosageInstruction" : [{
        "text" : "Posologia: 1 comprimido, a cada 12 horas.",
        "timing" : {
          "repeat" : {
            "count" : 1,
            "countMax" : 10,
            "frequency" : 1
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao",
            "code" : "10907"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1.0,
            "unit" : "Comprimido",
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
            "code" : "19"
          }
        }]
      }],
      "dispenseRequest" : {
        "validityPeriod" : {
          "start" : "2026-06-15T00:00:00Z",
          "end" : "2026-06-19T00:00:00Z"
        },
        "quantity" : {
          "value" : 10
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:12488d06-405a-4cc7-b9d7-f0c533d55ebe",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "12488d06-405a-4cc7-b9d7-f0c533d55ebe",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_12488d06-405a-4cc7-b9d7-f0c533d55ebe\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Medication 12488d06-405a-4cc7-b9d7-f0c533d55ebe</b></p><a name=\"12488d06-405a-4cc7-b9d7-f0c533d55ebe\"> </a><a name=\"hc12488d06-405a-4cc7-b9d7-f0c533d55ebe\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSMedicamento.html\">Medicamento</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmVMP @brasil27983500460}\">Acetilcisteína 600mg Comprimido efervescente</span></p><p><b>form</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida 19}\">Comprimido</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmVMP",
          "code" : "@brasil27983500460"
        }]
      },
      "form" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
          "code" : "19"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:fce2b352-aeb8-4bc9-8932-4171ff2afe61",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "fce2b352-aeb8-4bc9-8932-4171ff2afe61",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSPrescricaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_fce2b352-aeb8-4bc9-8932-4171ff2afe61\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MedicationRequest fce2b352-aeb8-4bc9-8932-4171ff2afe61</b></p><a name=\"fce2b352-aeb8-4bc9-8932-4171ff2afe61\"> </a><a name=\"hcfce2b352-aeb8-4bc9-8932-4171ff2afe61\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSPrescricaoMedicamento.html\">Prescrição de Medicamento - RNDS</a></p></div><p><b>identifier</b>: <code>http://www.saude.gov.br/fhir/r4/NamingSystem/prescription-item-id</code>/5923026f-c64b-42b7-81b8-c282c63546</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/medicationrequest-category community}\">Community</span></p><p><b>medication</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-6484142c-733d-4354-863d-3777d88e8c74\">Medication Dipirona Monoidratada 500mg comprimido</a></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/700004841233002</p><p><b>authoredOn</b>: 2026-06-15 07:21:52-0300</p><p><b>requester</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-2bf69a6c-643d-45eb-8e23-9d8e9450fc0c\">PractitionerRole MEDICO DA ESTRATEGIA DE SAUDE DA FAMILIA</a></p><p><b>groupIdentifier</b>: <code>http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061</code>/ae2f417f-963d-460a-ab7a-68d7285cb5c3</p><blockquote><p><b>dosageInstruction</b></p><p><b>text</b>: Posologia: 1 comprimido, a cada 6 horas.</p><p><b>patientInstruction</b>: SE DOR OU FEBRE.</p><p><b>timing</b>: Contagem 1  times, Uma vez</p><p><b>route</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao 10907}\">Oral</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1.0 Comprimido<span style=\"background: LightGoldenRodYellow\"> (Detalhes: Unidade de Medida código19 = 'Comprimido')</span></td></tr></table></blockquote><h3>DispenseRequests</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ValidityPeriod</b></td><td><b>Quantity</b></td></tr><tr><td style=\"display: none\">*</td><td>2026-06-15 00:00:00+0000 --&gt; 2026-06-19 00:00:00+0000</td><td>10</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/prescription-item-id",
        "value" : "5923026f-c64b-42b7-81b8-c282c63546"
      }],
      "status" : "active",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/medicationrequest-category",
          "code" : "community"
        }]
      }],
      "medicationReference" : {
        "reference" : "urn:uuid:6484142c-733d-4354-863d-3777d88e8c74"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "700004841233002"
        }
      },
      "authoredOn" : "2026-06-15T07:21:52.321-03:00",
      "requester" : {
        "reference" : "urn:uuid:2bf69a6c-643d-45eb-8e23-9d8e9450fc0c"
      },
      "groupIdentifier" : {
        "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-3061",
        "value" : "ae2f417f-963d-460a-ab7a-68d7285cb5c3"
      },
      "dosageInstruction" : [{
        "text" : "Posologia: 1 comprimido, a cada 6 horas.",
        "patientInstruction" : "SE DOR OU FEBRE.",
        "timing" : {
          "repeat" : {
            "count" : 1,
            "countMax" : 20,
            "frequency" : 1
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao",
            "code" : "10907"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1.0,
            "unit" : "Comprimido",
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
            "code" : "19"
          }
        }]
      }],
      "dispenseRequest" : {
        "validityPeriod" : {
          "start" : "2026-06-15T00:00:00Z",
          "end" : "2026-06-19T00:00:00Z"
        },
        "quantity" : {
          "value" : 10
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:6484142c-733d-4354-863d-3777d88e8c74",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "6484142c-733d-4354-863d-3777d88e8c74",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_6484142c-733d-4354-863d-3777d88e8c74\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Medication 6484142c-733d-4354-863d-3777d88e8c74</b></p><a name=\"6484142c-733d-4354-863d-3777d88e8c74\"> </a><a name=\"hc6484142c-733d-4354-863d-3777d88e8c74\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSMedicamento.html\">Medicamento</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmVMP @brasil20832536006}\">Dipirona Monoidratada 500mg comprimido</span></p><p><b>form</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida 19}\">Comprimido</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmVMP",
          "code" : "@brasil20832536006"
        }]
      },
      "form" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
          "code" : "19"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:2bf69a6c-643d-45eb-8e23-9d8e9450fc0c",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "2bf69a6c-643d-45eb-8e23-9d8e9450fc0c",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSLotacaoProfissional"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_2bf69a6c-643d-45eb-8e23-9d8e9450fc0c\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: PractitionerRole 2bf69a6c-643d-45eb-8e23-9d8e9450fc0c</b></p><a name=\"2bf69a6c-643d-45eb-8e23-9d8e9450fc0c\"> </a><a name=\"hc2bf69a6c-643d-45eb-8e23-9d8e9450fc0c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSLotacaoProfissional.html\">RNDSLotacaoProfissional</a></p></div><p><b>active</b>: true</p><p><b>practitioner</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-dadef999-5891-43b7-82db-ebfe5a2ea78a\">Practitioner: identifier = Tax ID number,Medical License number</a></p><p><b>organization</b>: <a href=\"Bundle-example-redfm-02-prescricao-fora-rnds.html#urn-uuid-4439b818-0c91-4a6a-b67c-3956448b48bc\">Organization: identifier = https://saude.gov.br/sid/cnes#2492555</a></p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO 225142}\">MEDICO DA ESTRATEGIA DE SAUDE DA FAMILIA</span></p></div>"
      },
      "active" : true,
      "practitioner" : {
        "reference" : "urn:uuid:dadef999-5891-43b7-82db-ebfe5a2ea78a"
      },
      "organization" : {
        "reference" : "urn:uuid:4439b818-0c91-4a6a-b67c-3956448b48bc"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO",
          "code" : "225142"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:dadef999-5891-43b7-82db-ebfe5a2ea78a",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "dadef999-5891-43b7-82db-ebfe5a2ea78a",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSProfissional"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_dadef999-5891-43b7-82db-ebfe5a2ea78a\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Practitioner dadef999-5891-43b7-82db-ebfe5a2ea78a</b></p><a name=\"dadef999-5891-43b7-82db-ebfe5a2ea78a\"> </a><a name=\"hcdadef999-5891-43b7-82db-ebfe5a2ea78a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSProfissional.html\">Profissional RNDS</a></p></div><p><b>identifier</b>: Tax ID number/05507028141, Medical License number/31248</p><p><b>active</b>: true</p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "TAX"
          }]
        },
        "system" : "https://saude.gov.br/sid/cpf",
        "value" : "05507028141"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MD"
          }]
        },
        "system" : "https://saude.gov.br/sid/crm-df",
        "value" : "31248"
      }],
      "active" : true
    }
  },
  {
    "fullUrl" : "urn:uuid:4439b818-0c91-4a6a-b67c-3956448b48bc",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "4439b818-0c91-4a6a-b67c-3956448b48bc",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/RNDSEstabelecimentoSaude"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_4439b818-0c91-4a6a-b67c-3956448b48bc\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Organization 4439b818-0c91-4a6a-b67c-3956448b48bc</b></p><a name=\"4439b818-0c91-4a6a-b67c-3956448b48bc\"> </a><a name=\"hc4439b818-0c91-4a6a-b67c-3956448b48bc\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-RNDSEstabelecimentoSaude.html\">Estabelecimento de Saúde RNDS</a></p></div><p><b>identifier</b>: <code>https://saude.gov.br/sid/cnes</code>/2492555</p><p><b>active</b>: true</p></div>"
      },
      "identifier" : [{
        "system" : "https://saude.gov.br/sid/cnes",
        "value" : "2492555"
      }],
      "active" : true
    }
  }]
}

```
