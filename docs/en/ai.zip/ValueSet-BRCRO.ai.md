# Conselhos regionais de Odontologia do Brasil - Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS v1.0.0-release

## ValueSet: Conselhos regionais de Odontologia do Brasil 

 
Conjunto de todos os conselhos regionais de farmácia do Brasil 

 **References** 

* [Profissional RNDS](StructureDefinition-RNDSProfissional.md)
* [BR Core Practitioner](StructureDefinition-br-core-practitioner.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BRCRO",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/redfm/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/redfm/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "https://terminologia.saude.gov.br/fhir/ValueSet/BRCRO",
  "version" : "1.0.0-release",
  "name" : "BRCRO",
  "title" : "Conselhos regionais de Odontologia do Brasil",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-07-18T13:52:24+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Conjunto de todos os conselhos regionais de farmácia do Brasil",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "purpose" : "O propósito deste conjunto é agrupar todos os conselhos regionais de farmácia para fins de validação do identificador profissional do odontólogo",
  "copyright" : "CC-1.0",
  "compose" : {
    "include" : [{
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRConselhoProfissional",
      "concept" : [{
        "code" : "https://saude.gov.br/sid/cro-ac",
        "display" : "CRO-AC"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-al",
        "display" : "CRO-AL"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-am",
        "display" : "CRO-AM"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-ap",
        "display" : "CRO-AP"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-ba",
        "display" : "CRO-BA"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-ce",
        "display" : "CRO-CE"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-df",
        "display" : "CRO-DF"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-es",
        "display" : "CRO-ES"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-go",
        "display" : "CRO-GO"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-ma",
        "display" : "CRO-MA"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-mg",
        "display" : "CRO-MG"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-ms",
        "display" : "CRO-MS"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-mt",
        "display" : "CRO-MT"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-pa",
        "display" : "CRO-PA"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-pb",
        "display" : "CRO-PB"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-pe",
        "display" : "CRO-PE"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-pi",
        "display" : "CRO-PI"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-pr",
        "display" : "CRO-PR"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-rj",
        "display" : "CRO-RJ"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-rn",
        "display" : "CRO-RN"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-ro",
        "display" : "CRO-RO"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-rr",
        "display" : "CRO-RR"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-rs",
        "display" : "CRO-RS"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-sc",
        "display" : "CRO-SC"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-se",
        "display" : "CRO-SE"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-sp",
        "display" : "CRO-SP"
      },
      {
        "code" : "https://saude.gov.br/sid/cro-to",
        "display" : "CRO-TO"
      }]
    }]
  }
}

```
