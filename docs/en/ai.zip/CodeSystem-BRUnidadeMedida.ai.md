# Unidade de Medida - Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS v1.0.0-release

## CodeSystem: Unidade de Medida 

 
CodeSystem utilizado para definir a unidade de medida de um medicamento prescrito, para consumo ou especificação do fabricante. 

This Code system is referenced in the definition of the following value sets:

* [BRUnidadeMedidaMedicamento](ValueSet-BRUnidadeMedidaMedicamento.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRUnidadeMedida",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/redfm/1.0.0/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/redfm/1.0.0/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
  "version" : "1.0.0-release",
  "name" : "BRUnidadeMedida",
  "title" : "Unidade de Medida",
  "status" : "active",
  "experimental" : false,
  "date" : "2021-12-01T13:16:09.8385573+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "CodeSystem utilizado para definir a unidade de medida de um medicamento prescrito, para consumo ou especificação do fabricante.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "1",
    "display" : "Adesivo"
  },
  {
    "code" : "2",
    "display" : "Ampola"
  },
  {
    "code" : "3",
    "display" : "Anel"
  },
  {
    "code" : "4",
    "display" : "Aplicação"
  },
  {
    "code" : "5",
    "display" : "Aplicador"
  },
  {
    "code" : "6",
    "display" : "Atomização"
  },
  {
    "code" : "7",
    "display" : "Bandagem"
  },
  {
    "code" : "8",
    "display" : "Barra"
  },
  {
    "code" : "9",
    "display" : "Bisnaga"
  },
  {
    "code" : "10",
    "display" : "Blíster"
  },
  {
    "code" : "11",
    "display" : "Bolsa"
  },
  {
    "code" : "12",
    "display" : "Caixa"
  },
  {
    "code" : "13",
    "display" : "Cápsula"
  },
  {
    "code" : "14",
    "display" : "Carpule"
  },
  {
    "code" : "15",
    "display" : "Cartucho"
  },
  {
    "code" : "16",
    "display" : "Catéter"
  },
  {
    "code" : "17",
    "display" : "cm (Centímetro)"
  },
  {
    "code" : "18",
    "display" : "cm² (Centímetro Quadrado)"
  },
  {
    "code" : "19",
    "display" : "Comprimido"
  },
  {
    "code" : "20",
    "display" : "Desconhecido"
  },
  {
    "code" : "21",
    "display" : "Dispositivo"
  },
  {
    "code" : "22",
    "display" : "Dispositivo de injeção pré-carregado"
  },
  {
    "code" : "23",
    "display" : "Dose"
  },
  {
    "code" : "24",
    "display" : "Emplastro"
  },
  {
    "code" : "25",
    "display" : "Endosporos"
  },
  {
    "code" : "26",
    "display" : "Enema"
  },
  {
    "code" : "27",
    "display" : "Envelope"
  },
  {
    "code" : "28",
    "display" : "Estojo"
  },
  {
    "code" : "29",
    "display" : "Filme"
  },
  {
    "code" : "30",
    "display" : "Flaconete"
  },
  {
    "code" : "31",
    "display" : "Frasco"
  },
  {
    "code" : "32",
    "display" : "Frasco-ampola"
  },
  {
    "code" : "33",
    "display" : "g (Grama)"
  },
  {
    "code" : "34",
    "display" : "Goma"
  },
  {
    "code" : "35",
    "display" : "Gota"
  },
  {
    "code" : "36",
    "display" : "Hora"
  },
  {
    "code" : "37",
    "display" : "Implante"
  },
  {
    "code" : "38",
    "display" : "kg (Quilograma)"
  },
  {
    "code" : "39",
    "display" : "L (Litro)"
  },
  {
    "code" : "40",
    "display" : "Lata"
  },
  {
    "code" : "41",
    "display" : "m (Metro)"
  },
  {
    "code" : "42",
    "display" : "mEq (Miliequivalente)"
  },
  {
    "code" : "43",
    "display" : "mg (Miligrama)"
  },
  {
    "code" : "44",
    "display" : "Micrograma"
  },
  {
    "code" : "45",
    "display" : "Microlitro"
  },
  {
    "code" : "46",
    "display" : "Milhões"
  },
  {
    "code" : "47",
    "display" : "MUI (Milhões de unidades internacionais)"
  },
  {
    "code" : "48",
    "display" : "mL (Mililitro)"
  },
  {
    "code" : "49",
    "display" : "mm (Milímetro)"
  },
  {
    "code" : "50",
    "display" : "ng (Nanograma)"
  },
  {
    "code" : "51",
    "display" : "nL (Nanolitro)"
  },
  {
    "code" : "52",
    "display" : "Pastilha"
  },
  {
    "code" : "53",
    "display" : "Pastilha dura"
  },
  {
    "code" : "54",
    "display" : "Pastilha gomosa"
  },
  {
    "code" : "55",
    "display" : "Pílula"
  },
  {
    "code" : "56",
    "display" : "Saco"
  },
  {
    "code" : "57",
    "display" : "Seringa"
  },
  {
    "code" : "58",
    "display" : "Strip"
  },
  {
    "code" : "59",
    "display" : "Supositório"
  },
  {
    "code" : "60",
    "display" : "UI (Unidade Internacional)"
  },
  {
    "code" : "61",
    "display" : "UIC (Unidade Inibidora de Calicreína)"
  },
  {
    "code" : "62",
    "display" : "Unidade"
  },
  {
    "code" : "63",
    "display" : "UTR (Unidade Redutora da Turbidez)"
  },
  {
    "code" : "64",
    "display" : "Óvulo"
  },
  {
    "code" : "66",
    "display" : "Bastão"
  },
  {
    "code" : "69",
    "display" : "Capsula inalante"
  },
  {
    "code" : "70",
    "display" : "Cartão"
  },
  {
    "code" : "71",
    "display" : "Cartela"
  },
  {
    "code" : "74",
    "display" : "Drágea"
  },
  {
    "code" : "75",
    "display" : "Pote"
  },
  {
    "code" : "76",
    "display" : "Sachê"
  },
  {
    "code" : "77",
    "display" : "Seringa preenchida"
  },
  {
    "code" : "78",
    "display" : "Tablete"
  },
  {
    "code" : "79",
    "display" : "Tubete"
  },
  {
    "code" : "80",
    "display" : "Tubo"
  },
  {
    "code" : "82",
    "display" : "Glóbulo"
  }]
}

```
