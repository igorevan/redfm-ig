# Terminologia de Produto Medicinal Virtual (VMP) no Catálogo de Materiais (CATMAT) - Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS v1.0.0-release

## CodeSystem: Terminologia de Produto Medicinal Virtual (VMP) no Catálogo de Materiais (CATMAT) 

 
Apresenta o Produto Medicinal Virtual (VMP) e seu código no Catálogo de Materiais (CATMAT) 

This Code system is referenced in the definition of the following value sets:

* [BRTerminologiaMedicamento](ValueSet-BRTerminologiaMedicamento.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRObmCATMAT",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/redfm/1.0.0/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/redfm/1.0.0/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmCATMAT",
  "version" : "1.0.0-release",
  "name" : "BRObmCATMAT",
  "title" : "Terminologia de Produto Medicinal Virtual (VMP) no Catálogo de Materiais (CATMAT)",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-04-06T09:48:11.6743763+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Apresenta o Produto Medicinal Virtual (VMP) e seu código no Catálogo de Materiais (CATMAT)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "BR0356705",
    "display" : "Mercaptamina 50mg comprimido"
  },
  {
    "code" : "BR0260160-2E",
    "display" : "Imunoglobulina humana anti-hepatite B 500unidades internacionais/10 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266532-1",
    "display" : "Fenoterol 2mg/1mL solução aerossol; Tubo"
  },
  {
    "code" : "BR0266532-2",
    "display" : "Fenoterol 2mg/1mL solução aerossol; Tubo"
  },
  {
    "code" : "BR0266587",
    "display" : "Fenitoína Sódica 25mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0266597",
    "display" : "Fumarato de Formoterol 12micrograma cápsula para inalação"
  },
  {
    "code" : "BR0266599",
    "display" : "Formoterol 12 microgramas/dose pó para inalação"
  },
  {
    "code" : "BR0266599E",
    "display" : "Formoterol 12 microgramas/dose pó para inalação"
  },
  {
    "code" : "BR0266627",
    "display" : "Alfaepoetina 1.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266627E",
    "display" : "Alfaepoetina 1.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266629",
    "display" : "Alfaepoetina 4.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266629E",
    "display" : "Alfaepoetina 4.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266630",
    "display" : "Alfaepoetina 10.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266665",
    "display" : "Arteméter 80mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0266699",
    "display" : "Budesonida 50micrograma/1dose Suspensão aerossol; frasco"
  },
  {
    "code" : "BR0266700",
    "display" : "Budesonida 200micrograma/1dose suspensão aerossol; frasco"
  },
  {
    "code" : "BR0266701",
    "display" : "Budesonida 50micrograma/1dose Suspensão nasal; frasco"
  },
  {
    "code" : "BR0266701-1",
    "display" : "Budesonida 50micrograma/1dose Suspensão nasal; frasco"
  },
  {
    "code" : "BR0266701-3",
    "display" : "Budesonida 50micrograma/1dose Suspensão nasal; frasco"
  },
  {
    "code" : "BR0266701-4",
    "display" : "Budesonida 50micrograma/1dose Suspensão nasal; frasco"
  },
  {
    "code" : "BR0266706U0066",
    "display" : "Budesonida 32micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0266706-1",
    "display" : "Budesonida 32micrograma/1dose suspensão nasal; frasco"
  },
  {
    "code" : "BR0266707",
    "display" : "Budesonida 64micrograma/1dose suspensão spray"
  },
  {
    "code" : "BR0266707-1",
    "display" : "Budesonida 64micrograma/1dose Solução nasal; frasco"
  },
  {
    "code" : "BR0266713",
    "display" : "Pancrelipase 20.000UI Cápsula"
  },
  {
    "code" : "BR0266713E",
    "display" : "Pancrelipase 20.000UI Cápsula"
  },
  {
    "code" : "BR0266714",
    "display" : "Pancrelipase 4.500UI Cápsula"
  },
  {
    "code" : "BR0266714E",
    "display" : "Pancrelipase 4.500UI Cápsula"
  },
  {
    "code" : "BR02667158",
    "display" : "Pancrelipase 12.000UI Cápsula"
  },
  {
    "code" : "BR0266715E",
    "display" : "Pancrelipase 12.000UI Cápsula"
  },
  {
    "code" : "BR0266716E",
    "display" : "Pancrelipase 18.000UI Cápsula"
  },
  {
    "code" : "BR0266736E",
    "display" : "Desferroxamina 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266750",
    "display" : "Hidrogenotartrato de rivastigmina 2mg/1mL Solução oral"
  },
  {
    "code" : "BR0266750E",
    "display" : "Hidrogenotartrato de rivastigmina 2mg/1mL Solução oral"
  },
  {
    "code" : "BR0266762-1",
    "display" : "Alfainterferona 2a 3MUI/0,5mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0266765",
    "display" : "Alfainterferona 2b 5MUI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266765E",
    "display" : "Alfainterferona 2b 5MUI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266766",
    "display" : "Alfainterferona 2b 10.000.000UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266766E",
    "display" : "Alfainterferona 2b 10.000.000UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266767",
    "display" : "Alfainterferona 2b 3.000.000UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266767E",
    "display" : "Alfainterferona 2b 3.000.000UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266788-1",
    "display" : "Nistatina 25.000UI/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0266788-2",
    "display" : "Nistatina 25.000UI/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0266809",
    "display" : "Xinafoato de Salmeterol 50micrograma/1dose Pó para inalação; frasco"
  },
  {
    "code" : "BR0266809E",
    "display" : "Xinafoato de Salmeterol 50micrograma/1dose Pó para inalação; frasco"
  },
  {
    "code" : "BR0266820",
    "display" : "Imunoglobulina Humana 5g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266822E",
    "display" : "Imunoglobulina Humana 2,5g/25mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266823E",
    "display" : "Imunoglobulina humana 1g/5 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266827",
    "display" : "Imunoglobulina Anti-Rho (D) 300micrograma/2mL Solução para injeção"
  },
  {
    "code" : "BR0266863-1",
    "display" : "Benzoilmetronidazol 40mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0266863-2",
    "display" : "Benzoilmetronidazol 40mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0266863-3",
    "display" : "Benzoilmetronidazol 40mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0266962",
    "display" : "Somatropina 4UI pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266962E",
    "display" : "Somatropina 4UI pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266963",
    "display" : "Somatropina 12UI/1,5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267077",
    "display" : "Bezafibrato 200mg comprimido revestido"
  },
  {
    "code" : "BR0267077E",
    "display" : "Bezafibrato 200mg comprimido revestido"
  },
  {
    "code" : "BR0267079",
    "display" : "Alfaepoetina 3.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267081",
    "display" : "Fenofibrato 200mg Cápsula"
  },
  {
    "code" : "BR0267081E",
    "display" : "Fenofibrato 200mg Cápsula"
  },
  {
    "code" : "BR0267082",
    "display" : "Fluvastatina Sódica 80mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0267083",
    "display" : "Fluvastatina 20mg Cápsula"
  },
  {
    "code" : "BR0267083E",
    "display" : "Fluvastatina 20mg Cápsula"
  },
  {
    "code" : "BR0267084",
    "display" : "Fluvastatina 40mg Cápsula"
  },
  {
    "code" : "BR0267084E",
    "display" : "Fluvastatina 40mg Cápsula"
  },
  {
    "code" : "BR0267087",
    "display" : "Genfibrozila 900mg comprimido revestido"
  },
  {
    "code" : "BR0267087E",
    "display" : "Genfibrozila 900mg comprimido revestido"
  },
  {
    "code" : "BR0267088",
    "display" : "Genfibrozila 600mg comprimido revestido"
  },
  {
    "code" : "BR0267088E",
    "display" : "Genfibrozila 600mg comprimido revestido"
  },
  {
    "code" : "BR0267089",
    "display" : "Genfibrozila 300mg Cápsula"
  },
  {
    "code" : "BR0267092E",
    "display" : "Lovastatina 40mg comprimido"
  },
  {
    "code" : "BR0267107",
    "display" : "Fenitoína Sódica 250mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0267139",
    "display" : "Ampicilina 50mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0267140",
    "display" : "Azitromicina Di-Hidratada 500mg comprimido revestido"
  },
  {
    "code" : "BR0267151",
    "display" : "Cetoconazol 200mg Comprimido"
  },
  {
    "code" : "BR0267159",
    "display" : "Cloreto de Potássio 600mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0267160",
    "display" : "Cloreto de Potássio 15% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267161",
    "display" : "Cloreto de Potássio 10% solução para injeção; ampola"
  },
  {
    "code" : "BR0267162",
    "display" : "Cloreto de Potássio 19,1% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267164-1",
    "display" : "Cloreto de Potássio 60mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267164-2",
    "display" : "Cloreto de Potássio 60mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267187",
    "display" : "Dexametasona 1mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0267195",
    "display" : "Diazepam 5mg Comprimido"
  },
  {
    "code" : "BR0267197",
    "display" : "Diazepam 10mg comprimido"
  },
  {
    "code" : "BR0267203",
    "display" : "Dipirona Monoidratada 500mg comprimido"
  },
  {
    "code" : "BR0267205-1",
    "display" : "Dipirona Monoidratada 500mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267205-2",
    "display" : "Dipirona Monoidratada 500mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267205-3",
    "display" : "Dipirona Monoidratada 500mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267206",
    "display" : "Dipirona Monoidratada 50mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267208",
    "display" : "Estriol 1mg/1g Creme vaginal"
  },
  {
    "code" : "BR0267210",
    "display" : "Estriol 2mg comprimido"
  },
  {
    "code" : "BR0267256",
    "display" : "Bromidrato de Fenoterol 5mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0267271",
    "display" : "Hidróxido de Alumínio 300mg comprimido"
  },
  {
    "code" : "BR0267271E",
    "display" : "Hidróxido de Alumínio 300mg comprimido"
  },
  {
    "code" : "BR0267281-1",
    "display" : "Butilbrometo de Escopolamina 10mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267281-2",
    "display" : "Butilbrometo de Escopolamina 10mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267282",
    "display" : "Butilbrometo de Escopolamina 20mg/1mL Solução para injeção"
  },
  {
    "code" : "BR0267283",
    "display" : "Butilbrometo de Escopolamina 10mg comprimido revestido"
  },
  {
    "code" : "BR0267292",
    "display" : "Cloridrato de Imipramina 25mg comprimido revestido"
  },
  {
    "code" : "BR0267293",
    "display" : "Cloridrato de Imipramina 10mg comprimido revestido"
  },
  {
    "code" : "BR0267294",
    "display" : "Pamoato de Imipramina 75mg cápsula"
  },
  {
    "code" : "BR0267309",
    "display" : "Acetato de Medroxiprogesterona 5mg Comprimido"
  },
  {
    "code" : "BR0267311",
    "display" : "Cloridrato de Metoclopramida 4mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267312",
    "display" : "Cloridrato de Metoclopramida 10mg Comprimido"
  },
  {
    "code" : "BR0267328",
    "display" : "Fosfato de Sódio Monobásico 160mg/mL + Fosfato de Sódio Dibásico 60 mg/mL solução retal"
  },
  {
    "code" : "BR0267328-1",
    "display" : "Fosfato de Sódio Monobásico 160mg/mL + Fosfato de Sódio Dibásico 60 mg/mL solução retal"
  },
  {
    "code" : "BR0267355",
    "display" : "Nitrato de Isoconazol 10mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0267376",
    "display" : "Midazolam 7,5mg comprimido revestido"
  },
  {
    "code" : "BR0267378-1",
    "display" : "Nistatina 100.000UI/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0267378-2",
    "display" : "Nistatina 100.000UI/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0267378-3",
    "display" : "Nistatina 100.000UI/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0267378-4",
    "display" : "Nistatina 100.000UI/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0267378-5",
    "display" : "Nistatina 100.000UI/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0267393",
    "display" : "Tetraciclina 500mg Comprimido"
  },
  {
    "code" : "BR0267395",
    "display" : "Ibuprofeno 400mg comprimido"
  },
  {
    "code" : "BR0267416",
    "display" : "Teofilina 200mg Cápsula"
  },
  {
    "code" : "BR0267418 -1",
    "display" : "Tiabendazol 50mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0267418 -2",
    "display" : "Tiabendazol 50mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0267418 -3",
    "display" : "Tiabendazol 50mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0267419",
    "display" : "Tiabendazol 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0267419-1",
    "display" : "Tiabendazol 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0267425",
    "display" : "Cloridrato de Verapamil 80mg Comprimido"
  },
  {
    "code" : "BR0267470",
    "display" : "Alfapeginterferona 2a 180micrograma/0,5mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0267470E",
    "display" : "Alfapeginterferona 2a 180micrograma/0,5mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0267471",
    "display" : "Alfapeginterferona 2b 177,6micrograma pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267471E",
    "display" : "Alfapeginterferona 2b 177,6micrograma pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267472E",
    "display" : "Alfapeginterferona 2b 118,4 microgramas pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267473",
    "display" : "Alfapeginterferona 2b 148micrograma pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267473E",
    "display" : "Alfapeginterferona 2b 148micrograma pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267501",
    "display" : "Ácido Acetilsalicílico 500mg Comprimido"
  },
  {
    "code" : "BR0267502",
    "display" : "Ácido Acetilsalicílico 100mg Comprimido"
  },
  {
    "code" : "BR0267504-1",
    "display" : "Ácido Valproico 250mg Cápsula"
  },
  {
    "code" : "BR0267504-2",
    "display" : "Ácido Valproico 250mg Comprimido"
  },
  {
    "code" : "BR0267505",
    "display" : "Valproato de Sódio 500mg comprimido revestido"
  },
  {
    "code" : "BR0267506",
    "display" : "Albendazol 400mg comprimido mastigável"
  },
  {
    "code" : "BR0267507-1",
    "display" : "Albendazol 40mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0267507-2",
    "display" : "Albendazol 40mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0267508",
    "display" : "Alopurinol 100mg comprimido revestido"
  },
  {
    "code" : "BR0267509",
    "display" : "Alopurinol 300mg Comprimido"
  },
  {
    "code" : "BR0267510",
    "display" : "Cloridrato de Amiodarona 200mg comprimido"
  },
  {
    "code" : "BR0267511",
    "display" : "Aminofilina 100mg Comprimido"
  },
  {
    "code" : "BR0267512",
    "display" : "Cloridrato de Amitriptilina 25mg comprimido revestido"
  },
  {
    "code" : "BR0267515-1",
    "display" : "Ampicilina 500mg Cápsula"
  },
  {
    "code" : "BR0267515-2",
    "display" : "Ampicilina Tri-Hidratada 500mg Comprimido"
  },
  {
    "code" : "BR0267516",
    "display" : "Atenolol 25mg comprimido"
  },
  {
    "code" : "BR0267517",
    "display" : "Atenolol 50mg Comprimido"
  },
  {
    "code" : "BR0267518",
    "display" : "Atenolol 100mg Comprimido"
  },
  {
    "code" : "BR0267522",
    "display" : "Cloridrato de Clomipramina 25mg comprimido revestido"
  },
  {
    "code" : "BR0267523",
    "display" : "Clomipramina 10mg comprimido revestido"
  },
  {
    "code" : "BR0267526",
    "display" : "Cloxazolam 1mg comprimido"
  },
  {
    "code" : "BR0267527",
    "display" : "Cloxazolam 2mg Comprimido"
  },
  {
    "code" : "BR0267531",
    "display" : "Indapamida 2,5mg comprimido revestido"
  },
  {
    "code" : "BR0267531-1",
    "display" : "Perindopril Erbumina 4mg + Indapamida 1,25mg Comprimido"
  },
  {
    "code" : "BR0267540",
    "display" : "Glicose 2,5g (25%)/10mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0267541",
    "display" : "Glicose 50% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267544-2",
    "display" : "Glicose 10% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "BR0267544-3",
    "display" : "Glicose 10% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "BR0267544-4",
    "display" : "Glicose 10% solução para injeção 1000 mL; bolsa"
  },
  {
    "code" : "BR0267564",
    "display" : "Carvedilol 12,5mg comprimido"
  },
  {
    "code" : "BR0267565",
    "display" : "Carvedilol 6,25mg Comprimido"
  },
  {
    "code" : "BR0267566",
    "display" : "Carvedilol 3,125mg Comprimido"
  },
  {
    "code" : "BR0267567",
    "display" : "Carvedilol 25mg Comprimido"
  },
  {
    "code" : "BR0267568",
    "display" : "Cloridrato de Diltiazem 60mg Comprimido"
  },
  {
    "code" : "BR0267569",
    "display" : "Cloridrato de Diltiazem 30mg comprimido"
  },
  {
    "code" : "BR0267570",
    "display" : "Cloridrato de Diltiazem 180mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0267571",
    "display" : "Cloridrato de Diltiazem 90mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0267572-1",
    "display" : "Cloridrato de Diltiazem 120mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0267573",
    "display" : "Cloridrato de Verapamil 80mg comprimido revestido"
  },
  {
    "code" : "BR0267574",
    "display" : "Cloreto de Sódio 20% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267582-1",
    "display" : "Dipropionato de Beclometasona 50micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0267582-3",
    "display" : "Dipropionato de Beclometasona 50micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0267585",
    "display" : "Beclometasona 400 micrograma cápsula para inalação"
  },
  {
    "code" : "BR0267586",
    "display" : "Dipropionato de Beclometasona 200micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0267586E",
    "display" : "Dipropionato de Beclometasona 200micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0267587",
    "display" : "Dipropionato de Beclometasona 200micrograma/1dose solução aerossol; dispositivo"
  },
  {
    "code" : "BR0267587E",
    "display" : "Dipropionato de Beclometasona 200micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0267589",
    "display" : "Dipropionato de Beclometasona 400micrograma/1dose pó para inalação; dispositivo"
  },
  {
    "code" : "BR0267589E",
    "display" : "Dipropionato de Beclometasona 400micrograma/1dose pó para inalação; dispositivo"
  },
  {
    "code" : "BR0267613",
    "display" : "Captopril 25mg Comprimido"
  },
  {
    "code" : "BR0267614",
    "display" : "Captopril 12,5mg comprimido"
  },
  {
    "code" : "BR0267615",
    "display" : "Captopril 50mg comprimido"
  },
  {
    "code" : "BR0267617",
    "display" : "Carbamazepina 400mg comprimido"
  },
  {
    "code" : "BR0267618",
    "display" : "Carbamazepina 200mg Comprimido"
  },
  {
    "code" : "BR0267621",
    "display" : "Carbonato de Lítio 300mg Comprimido"
  },
  {
    "code" : "BR0267625-1",
    "display" : "Cefalexina Monoidratada 500mg Cápsula"
  },
  {
    "code" : "BR0267625-2",
    "display" : "Cefalexina Monoidratada 500mg Comprimido"
  },
  {
    "code" : "BR0267627",
    "display" : "Cimetidina 200mg comprimido"
  },
  {
    "code" : "BR0267628",
    "display" : "Cinarizina 25mg Comprimido"
  },
  {
    "code" : "BR0267629",
    "display" : "Cinarizina 75mg comprimido"
  },
  {
    "code" : "BR0267631",
    "display" : "Cloridrato de Ciprofloxacino 250mg comprimido revestido"
  },
  {
    "code" : "BR0267632",
    "display" : "Cloridrato de Ciprofloxacino 500mg comprimido revestido"
  },
  {
    "code" : "BR0267635",
    "display" : "Clorpromazina 25mg comprimido revestido"
  },
  {
    "code" : "BR0267638",
    "display" : "Clorpromazina 100mg comprimido revestido"
  },
  {
    "code" : "BR0267641",
    "display" : "Clorpropamida 250mg Comprimido"
  },
  {
    "code" : "BR0267642",
    "display" : "Colchicina 0,5mg Comprimido"
  },
  {
    "code" : "BR0267643",
    "display" : "Acetato de Dexametasona 1mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0267643-2",
    "display" : "Acetato de Dexametasona 1mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0267644",
    "display" : "Dexametasona 0,5mg comprimido"
  },
  {
    "code" : "BR0267645",
    "display" : "Maleato de Dexclorfeniramina 2mg Comprimido"
  },
  {
    "code" : "BR0267646-1",
    "display" : "Maleato de Dexclorfeniramina 0,4mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267646-2",
    "display" : "Maleato de Dexclorfeniramina 0,4mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267646-3",
    "display" : "Maleato de Dexclorfeniramina 0,4mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267647",
    "display" : "Digoxina 0,25mg Comprimido"
  },
  {
    "code" : "BR0267648",
    "display" : "Digoxina 0,05mg/1mL Elixir"
  },
  {
    "code" : "BR0267649",
    "display" : "Digoxina 0,5mg/1mL Elixir; frasco"
  },
  {
    "code" : "BR0267650",
    "display" : "Maleato de Enalapril 5mg Comprimido"
  },
  {
    "code" : "BR0267652",
    "display" : "Maleato de Enalapril 20mg comprimido"
  },
  {
    "code" : "BR0267653",
    "display" : "Espironolactona 25mg Comprimido"
  },
  {
    "code" : "BR0267654",
    "display" : "Espironolactona 100mg Comprimido"
  },
  {
    "code" : "BR0267657",
    "display" : "Fenitoína 100mg Comprimido"
  },
  {
    "code" : "BR0267660",
    "display" : "Fenobarbital 100mg Comprimido"
  },
  {
    "code" : "BR0267661",
    "display" : "Fluconazol 100mg cápsula"
  },
  {
    "code" : "BR0267662",
    "display" : "Fluconazol 150mg Cápsula"
  },
  {
    "code" : "BR0267663",
    "display" : "Furosemida 40mg Comprimido"
  },
  {
    "code" : "BR0267666",
    "display" : "Furosemida 20mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267668",
    "display" : "Gentamicina 10mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267669",
    "display" : "Haloperidol 5mg Comprimido"
  },
  {
    "code" : "BR0267670",
    "display" : "Haloperidol 1mg Comprimido"
  },
  {
    "code" : "BR0267675",
    "display" : "Hidroclorotiazida 50mg Comprimido"
  },
  {
    "code" : "BR0267676",
    "display" : "Ibuprofeno 600mg Comprimido"
  },
  {
    "code" : "BR0267677",
    "display" : "Ibuprofeno 300mg Comprimido"
  },
  {
    "code" : "BR0267688",
    "display" : "Metildopa 500mg comprimido revestido"
  },
  {
    "code" : "BR0267689",
    "display" : "Metildopa 250mg comprimido revestido"
  },
  {
    "code" : "BR0267692",
    "display" : "Mebendazol 100mg Comprimido"
  },
  {
    "code" : "BR0267694",
    "display" : "Mebendazol 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0267711",
    "display" : "Omeprazol 10mg cápsula de liberação retardada"
  },
  {
    "code" : "BR0267712",
    "display" : "Omeprazol 20mg Cápsula de liberação retardada"
  },
  {
    "code" : "BR0267713",
    "display" : "Omeprazol Magnésico 40mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0267728-1",
    "display" : "Nifedipino 10mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0267728-2",
    "display" : "Nifedipino 10mg Cápsula"
  },
  {
    "code" : "BR0267729",
    "display" : "Nifedipino 20mg Comprimido"
  },
  {
    "code" : "BR0267730",
    "display" : "Nifedipino 10mg Comprimido de liberação prolongada; comprimido"
  },
  {
    "code" : "BR0267731",
    "display" : "Nifedipino 20mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0267732",
    "display" : "Vitelinato de Prata 100mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0267734",
    "display" : "Ranitidina 15mg/mL xarope"
  },
  {
    "code" : "BR0267735",
    "display" : "Cloridrato de Ranitidina 50mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267736",
    "display" : "Ranitidina 150mg comprimido revestido"
  },
  {
    "code" : "BR0267737",
    "display" : "Cloridrato de Ranitidina 300mg comprimido revestido"
  },
  {
    "code" : "BR0267741",
    "display" : "Prednisona 5mg Comprimido"
  },
  {
    "code" : "BR0267743",
    "display" : "Prednisona 20mg Comprimido"
  },
  {
    "code" : "BR0267744",
    "display" : "Sinvastatina 80mg comprimido revestido"
  },
  {
    "code" : "BR0267765",
    "display" : "Sulfadiazina 500mg Comprimido"
  },
  {
    "code" : "BR0267768",
    "display" : "Cloridrato de Prometazina 25mg comprimido revestido"
  },
  {
    "code" : "BR0267769",
    "display" : "Cloridrato de Prometazina 50mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0267770",
    "display" : "Cloridrato de Propranolol 80mg Comprimido"
  },
  {
    "code" : "BR0267771",
    "display" : "Cloridrato de Propranolol 10mg Comprimido"
  },
  {
    "code" : "BR0267773-1",
    "display" : "Permetrina 10mg/1mL Loção; frasco"
  },
  {
    "code" : "BR0267773-2",
    "display" : "Permetrina 10mg/1mL Loção; frasco"
  },
  {
    "code" : "BR0267774",
    "display" : "Piridoxina 40mg comprimido revestido"
  },
  {
    "code" : "BR0267776-1",
    "display" : "Paracetamol 100mg/1mL Solução oral"
  },
  {
    "code" : "BR0267776-2",
    "display" : "Paracetamol 100mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0267777-1",
    "display" : "Paracetamol 200mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267777-2",
    "display" : "Paracetamol 200mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267777-3",
    "display" : "Paracetamol 200mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267778",
    "display" : "Paracetamol 500mg Comprimido"
  },
  {
    "code" : "BR0267894",
    "display" : "Hemitartarato de Rivastigmina 3mg Cápsula"
  },
  {
    "code" : "BR0267894E",
    "display" : "Hemitartarato de Rivastigmina 3mg Cápsula"
  },
  {
    "code" : "BR0267895",
    "display" : "Hemitartarato de Rivastigmina 6mg cápsula"
  },
  {
    "code" : "BR0267895E",
    "display" : "Hemitartarato de Rivastigmina 6mg cápsula"
  },
  {
    "code" : "BR0267896",
    "display" : "Hemitartarato de Rivastigmina 1,5mg Cápsula"
  },
  {
    "code" : "BR0267896E",
    "display" : "Hemitartarato de Rivastigmina 1,5mg Cápsula"
  },
  {
    "code" : "BR0267897",
    "display" : "Hemitartarato de Rivastigmina 4,5mg cápsula"
  },
  {
    "code" : "BR0267897E",
    "display" : "Hemitartarato de Rivastigmina 4,5mg cápsula"
  },
  {
    "code" : "BR0267907",
    "display" : "Dipropionato de Beclometasona 400micrograma/1mL suspensão para inalação; flaconete"
  },
  {
    "code" : "BR0267936",
    "display" : "Dicloridrato de Betaistina 16mg comprimido"
  },
  {
    "code" : "BR0268000",
    "display" : "Dipirona Monoidratada 300mg supositório"
  },
  {
    "code" : "BR0268005",
    "display" : "Travoprosta 0,04mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0268005-2",
    "display" : "Travoprosta 0,04mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0268005E",
    "display" : "Travoprosta 0,04mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0268037",
    "display" : "Lovastatina 10mg Comprimido"
  },
  {
    "code" : "BR0268037E",
    "display" : "Lovastatina 10mg Comprimido"
  },
  {
    "code" : "BR0268038",
    "display" : "Lovastatina 20mg Comprimido"
  },
  {
    "code" : "BR0268038E",
    "display" : "Lovastatina 20mg Comprimido"
  },
  {
    "code" : "BR0268069",
    "display" : "Cloridrato de Clorpromazina 25mg/5mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268072",
    "display" : "Cloridrato de Selegilina 5mg Comprimido"
  },
  {
    "code" : "BR0268072E",
    "display" : "Cloridrato de Selegilina 5mg Comprimido"
  },
  {
    "code" : "BR0268073E",
    "display" : "Cloridrato de Selegilina 10mg comprimido"
  },
  {
    "code" : "BR0268074E",
    "display" : "Acetato de Desmopressina 0,1mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0268075",
    "display" : "Sulfato de Magnésio Heptaidratado 50%/10mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268076",
    "display" : "Sulfato de Magnésio Heptaidratado 10%/10mL solução para injeção"
  },
  {
    "code" : "BR0268077",
    "display" : "Acetato de Ciproterona 50mg Comprimido"
  },
  {
    "code" : "BR0268077E",
    "display" : "Acetato de Ciproterona 50mg Comprimido"
  },
  {
    "code" : "BR0268079",
    "display" : "Cloridrato de Amantadina 100mg Comprimido"
  },
  {
    "code" : "BR0268079E",
    "display" : "Cloridrato de Amantadina 100mg Comprimido"
  },
  {
    "code" : "BR0268080",
    "display" : "Atorvastatina Cálcica 10mg comprimido revestido"
  },
  {
    "code" : "BR0268080E",
    "display" : "Atorvastatina Cálcica 10mg comprimido revestido"
  },
  {
    "code" : "BR0268081",
    "display" : "Atorvastatina Cálcica 20mg comprimido revestido"
  },
  {
    "code" : "BR0268081E",
    "display" : "Atorvastatina Cálcica 20mg comprimido revestido"
  },
  {
    "code" : "BR0268082",
    "display" : "Atorvastatina Cálcica 40mg comprimido revestido"
  },
  {
    "code" : "BR0268082E",
    "display" : "Atorvastatina Cálcica 40mg comprimido revestido"
  },
  {
    "code" : "BR0268083",
    "display" : "Azatioprina 50mg Comprimido"
  },
  {
    "code" : "BR0268083E",
    "display" : "Azatioprina 50mg Comprimido"
  },
  {
    "code" : "BR0268084",
    "display" : "Cabergolina 0,5mg comprimido"
  },
  {
    "code" : "BR0268084E",
    "display" : "Cabergolina 0,5mg comprimido"
  },
  {
    "code" : "BR0268092",
    "display" : "Cloridrato de Metadona 5mg comprimido"
  },
  {
    "code" : "BR0268092E",
    "display" : "Cloridrato de Metadona 5mg comprimido"
  },
  {
    "code" : "BR0268093",
    "display" : "Cloridrato de Metadona 10mg Comprimido"
  },
  {
    "code" : "BR0268093E",
    "display" : "Cloridrato de Metadona 10mg Comprimido"
  },
  {
    "code" : "BR0268094",
    "display" : "Cloridrato de Metadona 10mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268094E",
    "display" : "Cloridrato de Metadona 10mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268097",
    "display" : "Tacrolimo Monoidratado 5mg cápsula"
  },
  {
    "code" : "BR0268097E",
    "display" : "Tacrolimo Monoidratado 5mg cápsula"
  },
  {
    "code" : "BR0268103",
    "display" : "Fosfato de Codeína 60mg comprimido"
  },
  {
    "code" : "BR0268103E",
    "display" : "Fosfato de Codeína 60mg comprimido"
  },
  {
    "code" : "BR0268106",
    "display" : "Gabapentina 400mg cápsula"
  },
  {
    "code" : "BR0268106E",
    "display" : "Gabapentina 400mg cápsula"
  },
  {
    "code" : "BR0268107",
    "display" : "Gabapentina 300mg cápsula"
  },
  {
    "code" : "BR0268107E",
    "display" : "Gabapentina 300mg cápsula"
  },
  {
    "code" : "BR0268108E",
    "display" : "Acetato de Gosserrelina 10,8mg implante; Seringa preenchida"
  },
  {
    "code" : "BR0268109E",
    "display" : "Acetato de Gosserrelina 3,6mg implante; Seringa preenchida"
  },
  {
    "code" : "BR0268110",
    "display" : "Hidroxiureia 500mg cápsula"
  },
  {
    "code" : "BR0268110E",
    "display" : "Hidroxiureia 500mg cápsula"
  },
  {
    "code" : "BR0268112",
    "display" : "Hidralazina 50mg comprimido"
  },
  {
    "code" : "BR0268113",
    "display" : "Leflunomida 100mg comprimido revestido"
  },
  {
    "code" : "BR0268114",
    "display" : "Leflunomida 20mg comprimido revestido"
  },
  {
    "code" : "BR0268114E",
    "display" : "Leflunomida 20mg comprimido revestido"
  },
  {
    "code" : "BR0268115",
    "display" : "Cloridrato de Hidralazina 20mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268118",
    "display" : "Filgrastim 300micrograma/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268118E",
    "display" : "Filgrastim 300micrograma/0,5mL solução para injeção"
  },
  {
    "code" : "BR0268119",
    "display" : "Sulfato de Hidroxicloroquina 400mg comprimido revestido"
  },
  {
    "code" : "BR0268119E",
    "display" : "Sulfato de Hidroxicloroquina 400mg comprimido revestido"
  },
  {
    "code" : "BR0268123",
    "display" : "Levotiroxina Sódica 50micrograma Comprimido"
  },
  {
    "code" : "BR0268124",
    "display" : "Levotiroxina Sódica 25micrograma Comprimido"
  },
  {
    "code" : "BR0268125",
    "display" : "Levotiroxina Sódica 100micrograma Comprimido"
  },
  {
    "code" : "BR0268126",
    "display" : "Levotiroxina Sódica 150micrograma comprimido"
  },
  {
    "code" : "BR0268128",
    "display" : "Levomepromazina 25mg comprimido revestido"
  },
  {
    "code" : "BR0268129",
    "display" : "Levomepromazina 100mg comprimido revestido"
  },
  {
    "code" : "BR0268130-1",
    "display" : "Maleato de Levomepromazina 40mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0268132",
    "display" : "Cloridrato de Levomepromazina 25mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268143",
    "display" : "Micofenolato de Mofetila 500mg comprimido revestido"
  },
  {
    "code" : "BR0268143E",
    "display" : "Micofenolato de Mofetila 500mg comprimido revestido"
  },
  {
    "code" : "BR0268147E",
    "display" : "Pravastatina Sódica 10mg Comprimido"
  },
  {
    "code" : "BR0268148",
    "display" : "Pravastatina Sódica 20mg comprimido"
  },
  {
    "code" : "BR0268148E",
    "display" : "Pravastatina Sódica 20mg comprimido"
  },
  {
    "code" : "BR0268149",
    "display" : "Risperidona 2mg comprimido revestido"
  },
  {
    "code" : "BR0268149E",
    "display" : "Risperidona 2mg comprimido revestido"
  },
  {
    "code" : "BR0268150-1",
    "display" : "Fosfato Sódico de Prednisolona 3mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0268150-2",
    "display" : "Fosfato Sódico de Prednisolona 3mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0268150-3",
    "display" : "Fosfato Sódico de Prednisolona 3mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0268151-1",
    "display" : "Prednisolona 1mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0268151-2",
    "display" : "Prednisolona 1mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0268151-3",
    "display" : "Prednisolona 1mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0268152",
    "display" : "Sirolimo 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0268152E",
    "display" : "Sirolimo 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0268153",
    "display" : "Sulfassalazina 500mg comprimido revestido"
  },
  {
    "code" : "BR0268153E",
    "display" : "Sulfassalazina 500mg comprimido revestido"
  },
  {
    "code" : "BR0268155",
    "display" : "Tiabendazol 500mg Comprimido"
  },
  {
    "code" : "BR0268159",
    "display" : "Pentoxifilina 400mg comprimido revestido"
  },
  {
    "code" : "BR0268160",
    "display" : "Omeprazol Sódico 40mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268162-1",
    "display" : "Nitrato de Miconazol 20mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0268162-2",
    "display" : "Nitrato de Miconazol 20mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0268162-3",
    "display" : "Nitrato de Miconazol 20mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0268163",
    "display" : "Minociclina 100mg comprimido revestido"
  },
  {
    "code" : "BR0268177",
    "display" : "Flutamida 250mg comprimido"
  },
  {
    "code" : "BR0268185",
    "display" : "Glicerol 95% Supositório"
  },
  {
    "code" : "BR0268186",
    "display" : "Glicerol 95% Supositório"
  },
  {
    "code" : "BR0268202",
    "display" : "Acarbose 50mg Comprimido"
  },
  {
    "code" : "BR0268207",
    "display" : "Ampicilina 1g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268214",
    "display" : "Atropina 0.25mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268222-1",
    "display" : "Bicarbonato de Sódio 8,4% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0268222-2",
    "display" : "Bicarbonato de Sódio 8,4% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "BR0268222-3",
    "display" : "Bicarbonato de Sódio 8,4% solução para injeção 250 ml; frasco"
  },
  {
    "code" : "BR0268228",
    "display" : "Cefalotina Sódica 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268236-1",
    "display" : "Cloreto de Sódio 0,9%  solução para injeção 100 mL; frasco"
  },
  {
    "code" : "BR0268236-3",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 250 mL; frasco"
  },
  {
    "code" : "BR0268236-4",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 500mL ; frasco"
  },
  {
    "code" : "BR0268236-5",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 1 L; frasco"
  },
  {
    "code" : "BR0268237-4",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 500mL ; frasco"
  },
  {
    "code" : "BR0268241",
    "display" : "Deltametrina 0,2mg/1mL loção; frasco"
  },
  {
    "code" : "BR0268242",
    "display" : "Deltametrina 0,2mg/1mL xampu; frasco"
  },
  {
    "code" : "BR0268243-1",
    "display" : "Dexametasona 0,1mg/1mL Elixir; frasco"
  },
  {
    "code" : "BR0268243-2",
    "display" : "Dexametasona 0,1mg/1mL Elixir; frasco"
  },
  {
    "code" : "BR0268253",
    "display" : "Dipiridamol 75mg comprimido"
  },
  {
    "code" : "BR0268255",
    "display" : "Epinefrina 1mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268256-1",
    "display" : "Gentamicina 40mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268256-2",
    "display" : "Sulfato de Gentamicina 60mg/1,5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268256-3",
    "display" : "Sulfato de Gentamicina 80mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268262",
    "display" : "Maleato de Metilergometrina 0,2mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268263",
    "display" : "Maleato de Metilergometrina 0,125mg Comprimido"
  },
  {
    "code" : "BR0268265-1",
    "display" : "Iodeto de Potássio 20mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0268265-2",
    "display" : "Iodeto de Potássio 20mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0268268",
    "display" : "Nitrato de Miconazol 20mg/1g Pó cutâneo; frasco"
  },
  {
    "code" : "BR0268269",
    "display" : "Miconazol 20mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0268270",
    "display" : "Sulfiram 250mg/1mL solução cutânea; frasco"
  },
  {
    "code" : "BR0268273-1",
    "display" : "Nitrofurantoína 100mg Cápsula"
  },
  {
    "code" : "BR0268273-2",
    "display" : "Nitrofurantoína 100mg Comprimido"
  },
  {
    "code" : "BR0268274-1",
    "display" : "Nitrofural 2mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0268274-2",
    "display" : "Nitrofural 2mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0268277",
    "display" : "Ocitocina 5UI/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268285",
    "display" : "Nitrazepam 5mg comprimido"
  },
  {
    "code" : "BR0268286-1",
    "display" : "Nitrato de Miconazol 20mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0268286-2",
    "display" : "Nitrato de Miconazol 20mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0268286-3",
    "display" : "Nitrato de Miconazol 20mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0268286-4",
    "display" : "Nitrato de Miconazol 20mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0268292",
    "display" : "Folinato de Cálcio 15mg Comprimido"
  },
  {
    "code" : "BR0268295",
    "display" : "Ácido Nalidíxico 500mg Comprimido"
  },
  {
    "code" : "BR0268296",
    "display" : "Ácido Nalidíxico 50mg Suspensão oral; frasco"
  },
  {
    "code" : "BR0268296-1",
    "display" : "Ácido Nalidíxico 50mg Suspensão oral; frasco"
  },
  {
    "code" : "BR0268297",
    "display" : "Ofloxacino 400mg comprimido revestido"
  },
  {
    "code" : "BR0268298",
    "display" : "Praziquantel 500mg comprimido"
  },
  {
    "code" : "BR0268300",
    "display" : "Secnidazol 500mg Comprimido"
  },
  {
    "code" : "BR0268301-1",
    "display" : "Secnidazol 30mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0268301-2",
    "display" : "Secnidazol 30mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0268302",
    "display" : "Sulfato de Salbutamol 2mg comprimido"
  },
  {
    "code" : "BR0268315",
    "display" : "Abacavir 300mg comprimido revestido"
  },
  {
    "code" : "BR0268317",
    "display" : "Sulfato de Abacavir  20mg/1 mL solução oral"
  },
  {
    "code" : "BR0268320",
    "display" : "Amprenavir 150mg Cápsula"
  },
  {
    "code" : "BR0268322",
    "display" : "Amprenavir 15mg/1mL Solução oral"
  },
  {
    "code" : "BR0268331U0075",
    "display" : "Brometo de Ipratrópio 0,25mg/1mL Solução para inalação; frasco"
  },
  {
    "code" : "BR0268331U0086",
    "display" : "Brometo de Ipratrópio 0,25mg/1mL Solução para inalação; frasco"
  },
  {
    "code" : "BR0268337",
    "display" : "Efavirenz 200mg Cápsula"
  },
  {
    "code" : "BR0268340",
    "display" : "Estavudina 40mg cápsula"
  },
  {
    "code" : "BR0268341",
    "display" : "Estavudina 30mg cápsula"
  },
  {
    "code" : "BR0268344",
    "display" : "Sulfato de Indinavir 400mg Cápsula"
  },
  {
    "code" : "BR0268345",
    "display" : "Lamivudina 150mg comprimido revestido"
  },
  {
    "code" : "BR0268345E",
    "display" : "Lamivudina 150mg comprimido revestido"
  },
  {
    "code" : "BR0268349",
    "display" : "Nelfinavir 250mg comprimido revestido"
  },
  {
    "code" : "BR0268350",
    "display" : "Mesilato de Nelfinavir 50mg/1g Pó para solução oral; frasco"
  },
  {
    "code" : "BR0268352-1",
    "display" : "Tartarato de Brimonidina 2mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0268352-2",
    "display" : "Tartarato de Brimonidina 2mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0268352E",
    "display" : "Tartarato de Brimonidina 2mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0268353",
    "display" : "Nevirapina 200mg Comprimido"
  },
  {
    "code" : "BR0268356",
    "display" : "Ritonavir 80mg/1mL Pó para suspensão oral"
  },
  {
    "code" : "BR0268359",
    "display" : "Zidovudina 100mg Cápsula"
  },
  {
    "code" : "BR0268370",
    "display" : "Aciclovir 200mg Comprimido"
  },
  {
    "code" : "BR0268372",
    "display" : "Aciclovir 400mg Comprimido"
  },
  {
    "code" : "BR0268373",
    "display" : "Aciclovir 30mg/1g Pomada oftálmica; bisnaga"
  },
  {
    "code" : "BR0268374",
    "display" : "Aciclovir 250mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268375-2",
    "display" : "Aciclovir 50mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0268377",
    "display" : "Albumina Humana 10g/50mL solução para injeção; bolsa"
  },
  {
    "code" : "BR0268378",
    "display" : "Cloridrato de Alfentanila 2,72mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268380",
    "display" : "Alprostadil 20micrograma pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268381-2",
    "display" : "Sulfato de Amicacina 500mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268382-2",
    "display" : "Sulfato de Amicacina 250mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268383",
    "display" : "Sulfato de Amicacina 100mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268390",
    "display" : "Glicose 20g + Cloreto de Potássio 1,5g + Cloreto de Sódio 3,5g + Citrato de Sódio 2,9g Pó para solução oral"
  },
  {
    "code" : "BR0268393",
    "display" : "Ampicilina 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268394",
    "display" : "Anfotericina B 50mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268395",
    "display" : "Anfotericina B 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268396",
    "display" : "Besilato de Atracúrio 50mg/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268396-1",
    "display" : "Besilato de Atracúrio 25mg/2,5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268397",
    "display" : "Aztreonam 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268403",
    "display" : "Capecitabina 500mg comprimido revestido"
  },
  {
    "code" : "BR0268404",
    "display" : "Capecitabina 150mg comprimido"
  },
  {
    "code" : "BR0268405",
    "display" : "Cefazolina 1g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268410",
    "display" : "Cefotaxima Sódica 500mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268411",
    "display" : "Cefotaxima 1g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268412",
    "display" : "Ceftazidima Pentaidratada 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268414",
    "display" : "Ceftriaxona Sódica 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268415",
    "display" : "Ceftriaxona Sódica 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268417",
    "display" : "Ceftriaxona Dissódica Hemieptaidratada 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268422",
    "display" : "Cetoprofeno 50mg Cápsula"
  },
  {
    "code" : "BR0268423",
    "display" : "Cetoprofeno 25mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0268424",
    "display" : "Cetoprofeno 20mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0268427",
    "display" : "Ciclofosfamida Monoidratada 50mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0268427E",
    "display" : "Ciclofosfamida Monoidratada 50mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0268432",
    "display" : "Cloridrato de Ciprofloxacino 3mg/1g pomada oftálmica; bisnaga"
  },
  {
    "code" : "BR0268436",
    "display" : "Cloridrato de Clindamicina 300mg Cápsula"
  },
  {
    "code" : "BR0268439-1",
    "display" : "Claritromicina 500mg comprimido revestido"
  },
  {
    "code" : "BR0268439-2",
    "display" : "Claritromicina 500mg cápsula"
  },
  {
    "code" : "BR0268439-3",
    "display" : "Claritromicina 500mg comprimido revestido"
  },
  {
    "code" : "BR0268440",
    "display" : "Claritromicina 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268442",
    "display" : "Cloreto de Suxametônio 100mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268443",
    "display" : "Fosfato de Codeína 60mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268443E",
    "display" : "Fosfato de Codeína 60mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268446",
    "display" : "Cloridrato de Dobutamina 250mg/20mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268451",
    "display" : "Cloridrato de Doxorrubicina 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268454",
    "display" : "Enoxaparina Sódica 60mg/0,6mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0268455",
    "display" : "Enoxaparina Sódica 80mg/0,8mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0268456",
    "display" : "Enoxaparina Sódica 100mg/1mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0268458",
    "display" : "Ganciclovir 250mg Cápsula"
  },
  {
    "code" : "BR0268462",
    "display" : "Halotano 1mL/1mL  Solução para inalação; frasco-ampola"
  },
  {
    "code" : "BR0268462-1",
    "display" : "Halotano 1mL/1mL inalante; frasco"
  },
  {
    "code" : "BR0268463",
    "display" : "Heparina Sódica 5.000UI/0,25mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268469",
    "display" : "Isoflurano 100mL/1mL Solução para inalação"
  },
  {
    "code" : "BR0268469-2",
    "display" : "Isoflurano 100mL/1mL Solução para inalação"
  },
  {
    "code" : "BR0268471",
    "display" : "Cloridrato de Levobupivacaína 100mg/20mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268472",
    "display" : "Cloridrato de Levobupivacaína 20mg/4mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268477",
    "display" : "Fluoruracila 250mg/10mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268481-4",
    "display" : "Midazolam 15mg/3mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268482",
    "display" : "Midazolam 5mg/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268487",
    "display" : "Meropeném Tri-Hidratado 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268488",
    "display" : "Meropeném Tri-Hidratado 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268492",
    "display" : "Cloridrato de Lincomicina 300mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268492-1",
    "display" : "Cloridrato de Lincomicina 600mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268493",
    "display" : "Mesilato de Doxazosina 2mg Comprimido"
  },
  {
    "code" : "BR0268494",
    "display" : "Mesilato de Doxazosina 1mg Comprimido"
  },
  {
    "code" : "BR0268495",
    "display" : "Mesilato de Doxazosina 4mg Comprimido"
  },
  {
    "code" : "BR0268499",
    "display" : "Metronidazol 400mg comprimido revestido"
  },
  {
    "code" : "BR0268501",
    "display" : "Cloridrato de Nalbufina 10mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268504",
    "display" : "Cloridrato de Ondansetrona Di-Hidratado 4mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268504-1",
    "display" : "Cloridrato de Ondansetrona Di-Hidratado 8mg/4mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268505",
    "display" : "Ondansetrona 8mg comprimido revestido"
  },
  {
    "code" : "BR0268506",
    "display" : "Ondansetrona 4mg comprimido revestido"
  },
  {
    "code" : "BR0268509",
    "display" : "Fosfato de Fludarabina 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268510",
    "display" : "Flumazenil 0,5mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268513",
    "display" : "Oxacilina Sódica 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268520",
    "display" : "Rituximabe 500mg/50mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268520-1",
    "display" : "Rituximabe 100mg/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268520E",
    "display" : "Rituximabe 500mg/50mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268521",
    "display" : "Brometo de Rocurônio 50mg/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268523",
    "display" : "Sulfato de Salbutamol 0.5mg/1mL solução para injeção"
  },
  {
    "code" : "BR0268528",
    "display" : "Teicoplanina 400mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268529",
    "display" : "Teicoplanina 200mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268531",
    "display" : "Tenoxicam 20mg comprimido revestido"
  },
  {
    "code" : "BR0268532",
    "display" : "Tenoxicam 20mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268533",
    "display" : "Tenoxicam 40mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268534-1",
    "display" : "Cloridrato de Tramadol 50mg Cápsula"
  },
  {
    "code" : "BR0268534-2",
    "display" : "Cloridrato de Tramadol 50mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0268540",
    "display" : "Cloridrato de Vancomicina 500mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268541",
    "display" : "Cloridrato de Vancomicina 1g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268542",
    "display" : "Sulfato de Vimblastina 10mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268553",
    "display" : "Sufentanila 50micrograma/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268572",
    "display" : "Acetato de Desmopressina 0,2mg comprimido"
  },
  {
    "code" : "BR0268575",
    "display" : "Acetato de Desmopressina 4micrograma/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268580E",
    "display" : "Pamidronato Dissódico Pentaidratado 30mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268581",
    "display" : "Pamidronato Dissódico 60mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268581E",
    "display" : "Pamidronato Dissódico 60mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268609",
    "display" : "Levosimendana 12,5mg/5mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268808",
    "display" : "Efavirenz 30mg/1mL Solução oral"
  },
  {
    "code" : "BR0268812",
    "display" : "Efavirenz 600mg comprimido revestido"
  },
  {
    "code" : "BR0268816",
    "display" : "Nevirapina Hemi-Hidratada 10mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0268816-1",
    "display" : "Nevirapina Hemi-Hidratada 10mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0268819",
    "display" : "Atazanavir 150mg Cápsula"
  },
  {
    "code" : "BR0268820",
    "display" : "Sulfato de Atazanavir 200mg Cápsula"
  },
  {
    "code" : "BR0268825",
    "display" : "Fumarato de Tenofovir Desoproxila 300mg comprimido revestido"
  },
  {
    "code" : "BR0268825E",
    "display" : "Fumarato de Tenofovir Desoproxila 300mg comprimido revestido"
  },
  {
    "code" : "BR0268829",
    "display" : "Terizidona 250mg cápsula"
  },
  {
    "code" : "BR0268831",
    "display" : "Saquinavir 200mg cápsula"
  },
  {
    "code" : "BR0268837",
    "display" : "Saccharomyces Boulardii-17 100mg cápsula"
  },
  {
    "code" : "BR0268848",
    "display" : "Pantoprazol Sódico Sesqui-Hidratado 20mg comprimido revestido"
  },
  {
    "code" : "BR0268851",
    "display" : "Norfloxacino 400mg comprimido revestido"
  },
  {
    "code" : "BR0268856",
    "display" : "Losartana Potássica 50mg comprimido revestido"
  },
  {
    "code" : "BR0268859",
    "display" : "Levotiroxina Sódica 75micrograma Comprimido"
  },
  {
    "code" : "BR0268860",
    "display" : "Levotiroxina Sódica 125micrograma Comprimido"
  },
  {
    "code" : "BR0268861",
    "display" : "Itraconazol 100mg Cápsula"
  },
  {
    "code" : "BR0268862",
    "display" : "Fosinopril Sódico 10mg Comprimido"
  },
  {
    "code" : "BR0268864",
    "display" : "Cloridrato de Ticlopidina 250mg comprimido revestido"
  },
  {
    "code" : "BR0268866",
    "display" : "Celecoxibe 200mg Cápsula"
  },
  {
    "code" : "BR0268869",
    "display" : "Benzoato de Rizatriptana 10mg comprimido"
  },
  {
    "code" : "BR0268896",
    "display" : "Besilato de Anlodipino 10mg Comprimido"
  },
  {
    "code" : "BR0268951",
    "display" : "Azitromicina 1g comprimido revestido"
  },
  {
    "code" : "BR0268952",
    "display" : "Azitromicina Di-Hidratada 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268953",
    "display" : "Benznidazol 100mg Comprimido"
  },
  {
    "code" : "BR0268954",
    "display" : "Praziquantel 600mg comprimido"
  },
  {
    "code" : "BR0268956",
    "display" : "Levonorgestrel 0,75mg Comprimido"
  },
  {
    "code" : "BR0268957",
    "display" : "Levonorgestrel 30 micrograma comprimido"
  },
  {
    "code" : "BR0268958-1",
    "display" : "Colagenase 0,6UI/1g Pomada"
  },
  {
    "code" : "BR0268958-2",
    "display" : "Colagenase 0,6UI/1g Pomada"
  },
  {
    "code" : "BR0268959-1",
    "display" : "Colagenase 1,2UI/1g Pomada"
  },
  {
    "code" : "BR0268959-2",
    "display" : "Colagenase 1,2UI/1g Pomada"
  },
  {
    "code" : "BR0268960",
    "display" : "Cloridrato de Dopamina 50mg/10mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268970-1",
    "display" : "Nitroglicerina 25mg/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268970-2",
    "display" : "Nitroglicerina 50mg/10mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268971",
    "display" : "Sulfato de Polimixina B 500.000UI pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268972",
    "display" : "Cloridrato de Remifentanila 5mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268973",
    "display" : "Cloridrato de Remifentanila 2mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268994",
    "display" : "Cloridrato de Bupropiona 150mg Comprimido"
  },
  {
    "code" : "BR0268994-1",
    "display" : "Bupropiona 150mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0269388",
    "display" : "Dexametasona 4mg Comprimido"
  },
  {
    "code" : "BR0269389",
    "display" : "Prometazina 20mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0269390",
    "display" : "Furosemida 10mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0269391",
    "display" : "Fenitoína 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0269460",
    "display" : "Ácido Ursodesoxicólico 150mg comprimido"
  },
  {
    "code" : "BR0269468",
    "display" : "Cloridrato de Ropivacaína 200mg/20mL Solução para injeção"
  },
  {
    "code" : "BR0269470",
    "display" : "Ropivacaína 150mg/20mL Solução para injeção"
  },
  {
    "code" : "BR0269567",
    "display" : "Brometo de Pancurônio 4mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0269571-1",
    "display" : "Cloridrato de Proximetacaína 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0269571-2",
    "display" : "Cloridrato de Proximetacaína 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0269573",
    "display" : "Cloridrato de Bupivacaína 50mg/20mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269574",
    "display" : "Cloridrato de Bupivacaína 100mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269574-1",
    "display" : "Cloridrato de Bupivacaína Monoidratado 5%mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0269575",
    "display" : "Cloridrato de Bupivacaína 150mg/20mL (0,75%) Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269591",
    "display" : "Simeticona 125mg cápsula"
  },
  {
    "code" : "BR0269595",
    "display" : "Picossulfato de Sódio Monoidratado 7,5mg/1mL Solução oral;"
  },
  {
    "code" : "BR0269603",
    "display" : "Bisacodil 5mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0269622-1",
    "display" : "Glicerol 120mg/1mL Solução retal; frasco"
  },
  {
    "code" : "BR0269622-2",
    "display" : "Glicerol 120mg/1mL Solução retal; frasco"
  },
  {
    "code" : "BR0269622-3",
    "display" : "Glicerol 120mg/1mL Solução retal; frasco"
  },
  {
    "code" : "BR0269622-4",
    "display" : "Glicerol 120mg/1mL Solução retal; frasco"
  },
  {
    "code" : "BR0269628",
    "display" : "Albendazol 200mg Comprimido"
  },
  {
    "code" : "BR0269633",
    "display" : "Piperazina 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0269634",
    "display" : "Praziquantel 150mg Comprimido"
  },
  {
    "code" : "BR0269759",
    "display" : "Gentamicina 160mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269760",
    "display" : "Gentamicina 140mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269760-1",
    "display" : "Sulfato de Gentamicina 280mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0269761",
    "display" : "Sulfato de Gentamicina 20mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269810",
    "display" : "Aminofilina 200mg comprimido"
  },
  {
    "code" : "BR0269817",
    "display" : "Sulfato de Terbutalina 0,3mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0269818",
    "display" : "Sulfato de Terbutalina 0,5mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0269821",
    "display" : "Cloridrato de Bromexina 1,6mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0269822",
    "display" : "Cloridrato de Bromexina 0,8mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0269823",
    "display" : "Cloridrato de Bromexina 2mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0269833",
    "display" : "Cloridrato de Prilocaína 54mg/1,8mL + Felipressina 0,054UI/1,8mL Solução para injeção; carpule"
  },
  {
    "code" : "BR0269835-1",
    "display" : "Prilocaína 25mg/1g + Lidocaína 25mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0269835-2",
    "display" : "Prilocaína 25mg/1g + Lidocaína 25mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0269842-1",
    "display" : "Lidocaína 50mg/5 mL (1%) solução para injeção; ampola"
  },
  {
    "code" : "BR0269842-2",
    "display" : "Cloridrato de Lidocaína 200mg/20mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269842-3",
    "display" : "Lidocaína 500mg/50mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269843-1",
    "display" : "Cloridrato de Lidocaína 100mg/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269843-2",
    "display" : "Lidocaína 400mg/20 mL (2%) solução para injeção; ampola"
  },
  {
    "code" : "BR0269845-1",
    "display" : "Lidocaína 100mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0269845-2",
    "display" : "Lidocaína 100mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0269846-1",
    "display" : "Cloridrato de Lidocaína 20mg/1g gel; Seringa preenchida"
  },
  {
    "code" : "BR0269846-2",
    "display" : "Cloridrato de Lidocaína 20mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0269848",
    "display" : "Glicose 150mg/2mL + Cloridrato de Lidocaína 100mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0269851",
    "display" : "Cloridrato de Lidocaína 36mg/1.8mL + Epinefrina 18micrograma/1.8mL solução para injeção; carpule"
  },
  {
    "code" : "BR0269872",
    "display" : "Hidrocortisona 5mg/g (0,5%)+ Lidocaína 20mg/g (0,2%) + Subgalato de Bismuto 20mg/g (0,2%) + Óxido de Zinco 100mg/g (10%) Pomada"
  },
  {
    "code" : "BR0269954-1",
    "display" : "Bromoprida 10mg cápsula"
  },
  {
    "code" : "BR0269954-2",
    "display" : "Bromoprida 10mg Comprimido"
  },
  {
    "code" : "BR0269956",
    "display" : "Bromoprida 4mg/mL solução oral"
  },
  {
    "code" : "BR0269958-1",
    "display" : "Bromoprida 10mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0269960",
    "display" : "Cefoxitina Sódica 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269962",
    "display" : "Domperidona 10mg Comprimido"
  },
  {
    "code" : "BR0269963",
    "display" : "Domperidona 1mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0269963-1",
    "display" : "Domperidona 1mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0269964",
    "display" : "Lansoprazol 15mg cápsula"
  },
  {
    "code" : "BR0269965",
    "display" : "Lansoprazol 30mg Cápsula"
  },
  {
    "code" : "BR0269977",
    "display" : "Omeprazol 20mg cápsula + Claritromicina 500mg comprimido revestido + Amoxicilina 500mg cápsula"
  },
  {
    "code" : "BR0269986-1",
    "display" : "Claritromicina 250mg Cápsula;"
  },
  {
    "code" : "BR0269986-2",
    "display" : "Claritromicina 250mg Comprimido"
  },
  {
    "code" : "BR0269987",
    "display" : "Claritromicina 25mg/1mL granulado para suspensão; frasco"
  },
  {
    "code" : "BR0269987-1",
    "display" : "Claritromicina 25mg/1mL granulado para suspensão; frasco"
  },
  {
    "code" : "BR0269987-2",
    "display" : "Claritromicina 25mg/1mL granulado para suspensão; frasco"
  },
  {
    "code" : "BR0269988-1",
    "display" : "Claritromicina 50mg/1mL Granulado para suspensão; frasco"
  },
  {
    "code" : "BR0269988-2",
    "display" : "Claritromicina 50mg/1mL Granulado para suspensão; frasco"
  },
  {
    "code" : "BR0269990",
    "display" : "Estearato de Eritromicina 25mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0269991",
    "display" : "Estearato de Eritromicina 250mg Comprimido"
  },
  {
    "code" : "BR0269994-1",
    "display" : "Estearato de Eritromicina 50mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0269994-2",
    "display" : "Estearato de Eritromicina 50mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0269994-3",
    "display" : "Estearato de Eritromicina 50mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0269996",
    "display" : "Estolato de Eritromicina 500mg Comprimido"
  },
  {
    "code" : "BR0269997-2",
    "display" : "Estolato de Eritromicina 25mg/mL suspensão oral"
  },
  {
    "code" : "BR0269998",
    "display" : "Estolato de Eritromicina 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0269998-1",
    "display" : "Estolato de Eritromicina 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0269998-2",
    "display" : "Estolato de Eritromicina 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0270007",
    "display" : "Nimodipino 30mg comprimido revestido"
  },
  {
    "code" : "BR0270019",
    "display" : "Gliconato de Cálcio 1g/10mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270020",
    "display" : "Cloreto de Benzalcônio 0,1mg/1mL + Cloreto de Sódio 9mg/1mL Solução nasal; frasco"
  },
  {
    "code" : "BR0270020-1",
    "display" : "Cloreto de Benzalcônio 0,1mg/1mL + Cloreto de Sódio 9mg/1mL Solução nasal; frasco"
  },
  {
    "code" : "BR0270042",
    "display" : "Hipromelose 5mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0270045",
    "display" : "Dextrana 70 (99m Tc) 1mg/1mL + Hipromelose 3mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0270092",
    "display" : "Glicose 5% solução para injeção 100 mL; bolsa"
  },
  {
    "code" : "BR0270092-1",
    "display" : "Glicose 5% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "BR0270092-2",
    "display" : "Glicose 5% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "BR0270092-3",
    "display" : "Glicose 5% solução para injeção 1 L; bolsa"
  },
  {
    "code" : "BR0270093",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 1 L; frasco"
  },
  {
    "code" : "BR0270093-1",
    "display" : "Cloreto de Sódio 0,9% + Glicose 5% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "BR0270096",
    "display" : "Bupivacaína 50mg/20mL + Epinefrina 0,182mg/20mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270114-2",
    "display" : "Cloridrato de Cetamina 50mg/10mL Solução para injeção"
  },
  {
    "code" : "BR0270116",
    "display" : "Etomidato 20mg/10mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270118",
    "display" : "Clonazepam 0,5mg Comprimido"
  },
  {
    "code" : "BR0270119",
    "display" : "Clonazepam 2mg comprimido"
  },
  {
    "code" : "BR0270120",
    "display" : "Clonazepam 2,5mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0270126",
    "display" : "Cloridrato de Benserazida 50mg + Levodopa 200mg Comprimido"
  },
  {
    "code" : "BR0270126-1",
    "display" : "Levodopa 200mg + Benserazida 50 mg comprimido de liberação modificada"
  },
  {
    "code" : "BR0270127",
    "display" : "Levodopa 100mg + Cloridrato de Benserazida 25mg comprimido"
  },
  {
    "code" : "BR0270128",
    "display" : "Levodopa 100mg + Benserazida 25 mg comprimido para suspensão"
  },
  {
    "code" : "BR0270129",
    "display" : "Levodopa 200mg + Carbidopa 50mg Comprimido"
  },
  {
    "code" : "BR0270130",
    "display" : "Levodopa 250mg + Carbidopa 25 mg comprimido"
  },
  {
    "code" : "BR0270138",
    "display" : "Lactato de Biperideno 5mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0270140",
    "display" : "Cloridrato de Biperideno 2mg Comprimido"
  },
  {
    "code" : "BR0270141",
    "display" : "Cloridrato de Biperideno 4mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0270143",
    "display" : "Mesilato de Bromocriptina 2,5mg comprimido"
  },
  {
    "code" : "BR0270143E",
    "display" : "Mesilato de Bromocriptina 2,5mg comprimido"
  },
  {
    "code" : "BR0270220",
    "display" : "Succinato Sódico de Hidrocortisona 100mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270224",
    "display" : "Prednisolona 10mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0270228",
    "display" : "Sulfato de Polimixina B 10.000UI/1mL + Hidrocortisona 10mg/1mL + Sulfato de Neomicina 5mg/1mL suspensão otológica; frasco"
  },
  {
    "code" : "BR0270231",
    "display" : "Dexametasona 1mg/g + Neomicina 5 mg/g + Polimixina B 6.000 unidades internacionais/g pomada oftálmica"
  },
  {
    "code" : "BR0270366",
    "display" : "Cloridrato de Epirrubicina 50mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270371",
    "display" : "Etoposídeo 50mg cápsula"
  },
  {
    "code" : "BR0270372",
    "display" : "Etoposídeo 100mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270376",
    "display" : "Vincristina 1mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270398",
    "display" : "Mitomicina 5mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270409",
    "display" : "Carboplatina 450mg/45mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270415",
    "display" : "Oxaliplatina 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270416",
    "display" : "Oxaliplatina 100mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270423",
    "display" : "Mercaptopurina 50mg comprimido"
  },
  {
    "code" : "BR0270430",
    "display" : "Cloridrato de Gencitabina 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270436",
    "display" : "Metotrexato 2,5mg Comprimido"
  },
  {
    "code" : "BR0270436E",
    "display" : "Metotrexato 2,5mg Comprimido"
  },
  {
    "code" : "BR0270438",
    "display" : "Dacarbazina 200mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270440",
    "display" : "Melfalana 2mg comprimido revestido"
  },
  {
    "code" : "BR0270443",
    "display" : "Ifosfamida 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270444",
    "display" : "Ifosfamida 2g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270445",
    "display" : "Clorambucila 2mg comprimido revestido"
  },
  {
    "code" : "BR0270456",
    "display" : "Cloranfenicol 5mg/1mL + Cloridrato de Tetrizolina 0,25mg/1mL + Dexametasona 0,05mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0270457",
    "display" : "Fosfato Dissódico de Dexametasona 1mg/1mL + Sulfato de Neomicina 3,5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0270458",
    "display" : "Sulfato de Neomicina 5mg/1mL + Cloridrato de Nafazolina 0,75mg/1mL + Fosfato Dissódico de Dexametasona 0,5mg/1mL Solução nasal; frasco"
  },
  {
    "code" : "BR0270495-1",
    "display" : "Cloranfenicol 10mg/1g + Colagenase 0,6UI/1g pomada; bisnaga"
  },
  {
    "code" : "BR0270495-2",
    "display" : "Cloranfenicol 10mg/1g + Colagenase 0,6UI/1g pomada; bisnaga"
  },
  {
    "code" : "BR0270548",
    "display" : "Ácido Acetilsalicílico 325mg comprimido revestido"
  },
  {
    "code" : "BR0270555",
    "display" : "Ampicilina 2g + Sulbactam 1g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270556",
    "display" : "Ampicilina Sódica 1g + Sulbactam 500mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270557",
    "display" : "Acetilcisteína 200mg/5g granulado; envelope"
  },
  {
    "code" : "BR0270558-1",
    "display" : "Acetilcisteína 20mg/1mL Xarope"
  },
  {
    "code" : "BR0270558-2",
    "display" : "Acetilcisteína 20mg/1mL Xarope"
  },
  {
    "code" : "BR0270558-3",
    "display" : "Acetilcisteína 20mg/1mL Xarope"
  },
  {
    "code" : "BR0270587",
    "display" : "Dipropionato de Betametasona 0,64mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0270588",
    "display" : "Dipropionato de Betametasona 0,64mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0270590",
    "display" : "Dipropionato de Betametasona 5mg/1mL + Fosfato Dissódico de Betametasona 2mg/1mL Suspensão para injeção; ampola"
  },
  {
    "code" : "BR0270591",
    "display" : "Sulfato de Gentamicina 1mg/1g + Dipropionato de Betametasona 0,64mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0270593",
    "display" : "Cetoconazol 20mg/1g + Sulfato de Neomicina 2,5mg/1g + Dipropionato de Betametasona 0,5mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0270596",
    "display" : "Dipropionato de Betametasona 0,5mg/1g + Sulfato de Gentamicina 1mg/1g Pomada"
  },
  {
    "code" : "BR0270597",
    "display" : "Acetato de Betametasona 3mg/1mL + Fosfato Dissódico de Betametasona 3mg/1mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0270602",
    "display" : "Clioquinol 10mg/1g + Gentamicina 1mg/1g + Tolnaftato 10mg/1g + Betametasona 0,5mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0270602-1",
    "display" : "Clioquinol 10mg/1g + Gentamicina 1mg/1g + Tolnaftato 10mg/1g + Betametasona 0,5mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0270605",
    "display" : "Tiabendazol 166mg/1mL + Mebendazol 100mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0270606",
    "display" : "Tiabendazol 166mg + Mebendazol 100mg Comprimido"
  },
  {
    "code" : "BR0270606-1",
    "display" : "Tiabendazol 332mg + Mebendazol 200mg comprimido mastigável"
  },
  {
    "code" : "BR0270612",
    "display" : "Benzilpenicilina Benzatina 1.200.000UI Pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270613",
    "display" : "Benzilpenicilina Benzatina 600.000UI pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270615",
    "display" : "Benzilpenicilina Potássica 1.000.000UI/2mL pó para solução para injeção; frasco"
  },
  {
    "code" : "BR0270616",
    "display" : "Benzilpenicilina Potássica 5.000.000UI Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270620",
    "display" : "Dipirona 250mg + Escopolamina 10mg comprimido revestido"
  },
  {
    "code" : "BR0270621",
    "display" : "Escopolamina 20mg/5 mL + Dipirona 2.5 g/5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270622",
    "display" : "Butilbrometo de Escopolamina 6,67mg/1mL + Dipirona Monoidratada 333,4mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0270622-1",
    "display" : "Butilbrometo de Escopolamina 6,67mg/1mL + Dipirona Monoidratada 333,4mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0270711",
    "display" : "Amoxicilina 500mg cápsula + Claritromicina 500mg comprimido revestido + Lansoprazol 30mg comprimido liberação retardada"
  },
  {
    "code" : "BR0270713",
    "display" : "Tenecteplase 40mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270768",
    "display" : "Levotiroxina Sódica 175micrograma comprimido"
  },
  {
    "code" : "BR0270769",
    "display" : "Nitrato de Isoconazol 600mg Óvulo"
  },
  {
    "code" : "BR0270773-2",
    "display" : "Nitrato de Isoconazol 10mg/1g Creme vaginal"
  },
  {
    "code" : "BR0270779",
    "display" : "Nifedipino 20mg + Atenolol 50 mg comprimido"
  },
  {
    "code" : "BR0270782",
    "display" : "Etoricoxibe 60mg comprimido revestido"
  },
  {
    "code" : "BR0270785",
    "display" : "Bromidrato de Fenoterol 100micrograma/1dose Solução aerossol; frasco"
  },
  {
    "code" : "BR0270785E",
    "display" : "Bromidrato de Fenoterol 100micrograma/1dose Solução aerossol; frasco"
  },
  {
    "code" : "BR0270786",
    "display" : "Losartana Potássica 25mg comprimido revestido"
  },
  {
    "code" : "BR0270788",
    "display" : "Losartana Potássica 50mg + Hidroclorotiazida 12,5mg comprimido revestido"
  },
  {
    "code" : "BR0270791",
    "display" : "Atenolol 100mg + Clortalidona 25mg comprimido"
  },
  {
    "code" : "BR0270792",
    "display" : "Atenolol 50mg + Clortalidona 12,5mg comprimido"
  },
  {
    "code" : "BR0270793",
    "display" : "Atenolol 25mg + Clortalidona 12,5mg comprimido"
  },
  {
    "code" : "BR0270796",
    "display" : "Cloridrato de Fexofenadina 60mg + Cloridrato de Pseudoefedrina 120mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0270798",
    "display" : "Cloridrato de Fexofenadina 120mg comprimido revestido"
  },
  {
    "code" : "BR0270799",
    "display" : "Cloridrato de Fexofenadina 180mg comprimido revestido"
  },
  {
    "code" : "BR0270813-1",
    "display" : "Cianocobalamina 5mg + Tiamina 100mg + Piridoxina 100mg comprimido revestido"
  },
  {
    "code" : "BR0270813-2",
    "display" : "Cianocobalamina 5mg/2mL + Cloridrato de Piridoxina 100mg/2mL + Cloridrato de Tiamina 100mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270835",
    "display" : "Estradiol 50micrograma/24hora Adesivo Transdérmico"
  },
  {
    "code" : "BR0270836",
    "display" : "Estradiol Hemi-Hidratado 25micrograma/24hora adesivo transdérmico"
  },
  {
    "code" : "BR0270839",
    "display" : "Estradiol 0,75mg/1dose gel; bisnaga"
  },
  {
    "code" : "BR0270848",
    "display" : "Estradiol 2mg + Acetato de Noretisterona 1mg comprimido revestido"
  },
  {
    "code" : "BR0270877",
    "display" : "Besilato de Anlodipino 2mg + Maleato de Enalapril 10mg Cápsula"
  },
  {
    "code" : "BR0270878",
    "display" : "Maleato de Enalapril 10mg + Besilato de Anlodipino 5mg Cápsula"
  },
  {
    "code" : "BR0270879",
    "display" : "Anlodipino 5mg + Enalapril 20mg comprimido"
  },
  {
    "code" : "BR0270889",
    "display" : "Polissulfato de Escina Sódica 10mg/1g + Salicilato de Dietilamônio 50mg/1g + Escina 10mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0270889-1",
    "display" : "Polissulfato de Escina Sódica 10mg/1g + Salicilato de Dietilamônio 50mg/1g + Escina 10mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0270893",
    "display" : "Carbonato de Cálcio 1,25g + Colecalciferol 200UI comprimido"
  },
  {
    "code" : "BR0270895-1",
    "display" : "Carbonato de Cálcio 500mg comprimido revestido"
  },
  {
    "code" : "BR0270895-2",
    "display" : "Carbonato de Cálcio 1,25g (Cálcio 500 mg) comprimido mastigável"
  },
  {
    "code" : "BR0270906",
    "display" : "Fosfato de Codeína 7,5mg + Paracetamol 500mg comprimido"
  },
  {
    "code" : "BR0270907",
    "display" : "Paracetamol 500mg + Fosfato de Codeína 30mg comprimido"
  },
  {
    "code" : "BR0270911",
    "display" : "Paracetamol 350mg + Cafeína 50mg + Carisoprodol 150mg Comprimido"
  },
  {
    "code" : "BR0270916",
    "display" : "Paracetamol 300mg + Carisoprodol 150mg + Fenilbutazona 75mg Comprimido"
  },
  {
    "code" : "BR0270917",
    "display" : "Carisoprodol 125mg + Diclofenaco Sódico 50mg + Cafeína 30mg + Paracetamol 300mg comprimido"
  },
  {
    "code" : "BR0270965",
    "display" : "Ácido Acetilsalicílico 100mg + Carbonato de Magnésio 30mg + Glicinato de Alumínio 15mg comprimido revestido"
  },
  {
    "code" : "BR0270971",
    "display" : "Butilbrometo de Escopolamina 10mg + Paracetamol 500mg comprimido revestido"
  },
  {
    "code" : "BR0270986",
    "display" : "Maleato de Clorfeniramina 4mg + Paracetamol 400mg + Cloridrato de Fenilefrina 4mg Comprimido"
  },
  {
    "code" : "BR0270990",
    "display" : "Colestiramina 4g/1envelope Pó para suspensão oral"
  },
  {
    "code" : "BR0270991",
    "display" : "Diclofenaco Colestiramina 70mg Cápsula"
  },
  {
    "code" : "BR0270992",
    "display" : "Diclofenaco Potássico 50mg comprimido revestido"
  },
  {
    "code" : "BR0270999-1",
    "display" : "Diclofenaco Potássico 75mg/3mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271003",
    "display" : "Diclofenaco Sódico 75mg/3mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0271004",
    "display" : "Diclofenaco Sódico 225mg/3mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271006",
    "display" : "Diclofenaco Sódico 1mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0271028-1",
    "display" : "Diclofenaco Resinato 15mg/1mL suspensão; frasco"
  },
  {
    "code" : "BR0271028-2",
    "display" : "Diclofenaco Resinato 15mg/1mL suspensão; frasco"
  },
  {
    "code" : "BR0271036",
    "display" : "Doxiciclina 100mg comprimido revestido"
  },
  {
    "code" : "BR0271036-1",
    "display" : "Doxiciclina 100mg comprimido revestido"
  },
  {
    "code" : "BR0271050",
    "display" : "Sulfato de Atropina 5mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0271051",
    "display" : "Sulfato de Atropina 10mg/1mL solução oftálmica"
  },
  {
    "code" : "BR0271064",
    "display" : "Hidróxido de Alumínio 40mg/1mL + Simeticona 5mg/1mL + Hidróxido de Magnésio 30mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0271064-1",
    "display" : "Hidróxido de Alumínio 40mg/1mL + Simeticona 5mg/1mL + Hidróxido de Magnésio 30mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0271077",
    "display" : "Pidolato de Magnésio 1,5g/10mL solução oral"
  },
  {
    "code" : "BR0271089-1",
    "display" : "Amoxicilina Tri-Hidratada 500mg Cápsula"
  },
  {
    "code" : "BR0271089-2",
    "display" : "Amoxicilina Tri-Hidratada 500mg Comprimido"
  },
  {
    "code" : "BR0271099",
    "display" : "Amoxicilina Sódica 500mg + Clavulanato de Potássio 100mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271101",
    "display" : "Calcitriol 0.25micrograma Cápsula"
  },
  {
    "code" : "BR0271101E",
    "display" : "Calcitriol 0.25micrograma Cápsula"
  },
  {
    "code" : "BR0271102",
    "display" : "Carbonato de Lítio 450mg Comprimido"
  },
  {
    "code" : "BR0271103-1",
    "display" : "Cetoconazol 20mg/1mL Xampu; frasco"
  },
  {
    "code" : "BR0271103-2",
    "display" : "Cetoconazol 20mg/1mL Xampu; frasco"
  },
  {
    "code" : "BR0271104",
    "display" : "Ciclosporina 25mg cápsula"
  },
  {
    "code" : "BR0271104E",
    "display" : "Ciclosporina 25mg cápsula"
  },
  {
    "code" : "BR0271106",
    "display" : "Ciclosporina 50mg cápsula"
  },
  {
    "code" : "BR0271106E",
    "display" : "Ciclosporina 50mg cápsula"
  },
  {
    "code" : "BR0271107",
    "display" : "Ciclosporina 100mg Cápsula"
  },
  {
    "code" : "BR0271107E",
    "display" : "Ciclosporina 100mg Cápsula"
  },
  {
    "code" : "BR0271109",
    "display" : "Etinilestradiol 0,05mg + Levonorgestrel 0,25mg comprimido revestido"
  },
  {
    "code" : "BR0271110",
    "display" : "Ciproterona 2mg + Etinilestradiol 0,035mg comprimido revestido"
  },
  {
    "code" : "BR0271111-1",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0271111-2",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0271111-3",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0271111-4",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0271116",
    "display" : "Fluconazol 200mg/100mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271118",
    "display" : "Enantato de Flufenazina 25mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0271120-1",
    "display" : "Cloridrato de Tetraciclina 25mg/1g + Anfotericina B 12,5mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0271120-2",
    "display" : "Cloridrato de Tetraciclina 25mg/1g + Anfotericina B 12,5mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0271123-1",
    "display" : "Cloridrato de Tetraciclina 5mg/1g pomada oftálmica; bisnaga"
  },
  {
    "code" : "BR0271124-1",
    "display" : "Fumarato de Cetotifeno 0,2mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0271124-2",
    "display" : "Fumarato de Cetotifeno 0,2mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0271124-3",
    "display" : "Fumarato de Cetotifeno 0,2mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0271125",
    "display" : "Fumarato de Cetotifeno 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0271126",
    "display" : "Fumarato de Cetotifeno 1mg comprimido"
  },
  {
    "code" : "BR0271129",
    "display" : "Bisoprolol 5mg + Hidroclorotiazida 6,25mg comprimido revestido"
  },
  {
    "code" : "BR0271134-1",
    "display" : "Ibuprofeno 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0271134-2",
    "display" : "Ibuprofeno 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0271138",
    "display" : "Isoniazida 200mg + Rifampicina 300mg Cápsula"
  },
  {
    "code" : "BR0271139",
    "display" : "Isoniazida 100mg + Rifampicina 150mg Cápsula"
  },
  {
    "code" : "BR0271140",
    "display" : "Rifamicina Sv Sódica 10mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0271154-1",
    "display" : "Insulina Humana Regular 1.000UI/10mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271154-2",
    "display" : "Insulina Humana Regular 300UI/3mL Solução para injeção; carpule"
  },
  {
    "code" : "BR0271162",
    "display" : "Cloridrato de Amilorida 5mg + Hidroclorotiazida 50mg Comprimido"
  },
  {
    "code" : "BR0271165",
    "display" : "Cloridrato de Amilorida 2,5mg + Hidroclorotiazida 25mg comprimido"
  },
  {
    "code" : "BR0271166",
    "display" : "Furosemida 40mg + Cloridrato de Amilorida 10mg Comprimido"
  },
  {
    "code" : "BR0271167",
    "display" : "Lisinopril 5mg comprimido"
  },
  {
    "code" : "BR0271168",
    "display" : "Lisinopril 10mg comprimido"
  },
  {
    "code" : "BR0271169",
    "display" : "Lisinopril 20mg comprimido"
  },
  {
    "code" : "BR0271170",
    "display" : "Lisinopril 20mg + Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0271171",
    "display" : "Maleato de Enalapril 20mg + Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0271172",
    "display" : "Hidroclorotiazida 25mg + Maleato de Enalapril 10mg Comprimido"
  },
  {
    "code" : "BR0271197",
    "display" : "Pindolol 10mg + Clopamida 5mg Comprimido"
  },
  {
    "code" : "BR0271217",
    "display" : "Amoxicilina 500mg + Clavulanato de Potássio 125mg comprimido revestido"
  },
  {
    "code" : "BR0271218",
    "display" : "Clavulanato de Potássio 6,25mg/1mL + Amoxicilina Tri-Hidratada 25mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0271352",
    "display" : "Cloridrato de Pilocarpina 10mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271353",
    "display" : "Cloridrato de Pilocarpina 20mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271353-1",
    "display" : "Cloridrato de Pilocarpina 20mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271353E",
    "display" : "Cloridrato de Pilocarpina 20mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271354",
    "display" : "Cloridrato de Pilocarpina 40mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271355",
    "display" : "Nistatina 20.000UI/1g + Metronidazol 100mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0271356",
    "display" : "Alprazolam 1mg comprimido"
  },
  {
    "code" : "BR0271357",
    "display" : "Alprazolam 0,5mg comprimido"
  },
  {
    "code" : "BR0271357-1",
    "display" : "Alprazolam 0.5mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0271358",
    "display" : "Alprazolam 0,25mg comprimido"
  },
  {
    "code" : "BR0271359",
    "display" : "Carbonato de Cálcio 1.750mg + Lactogliconato de Cálcio 2.263mg comprimido efervescente"
  },
  {
    "code" : "BR0271360",
    "display" : "Carbonato de Cálcio 875mg + Lactogliconato de Cálcio 1.132mg comprimido efervescente"
  },
  {
    "code" : "BR0271391",
    "display" : "Sulfato de Morfina 30mg comprimido"
  },
  {
    "code" : "BR0271391E",
    "display" : "Sulfato de Morfina 30mg comprimido"
  },
  {
    "code" : "BR0271392",
    "display" : "Sulfato de Morfina Pentaidratado 10mg Comprimido"
  },
  {
    "code" : "BR0271392E",
    "display" : "Sulfato de Morfina Pentaidratado 10mg Comprimido"
  },
  {
    "code" : "BR0271394",
    "display" : "Sulfato de Morfina Pentaidratado 10mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0271394E",
    "display" : "Sulfato de Morfina Pentaidratado 10mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0271435",
    "display" : "Estrogênios Conjugados 0,625mg/1g Creme vaginal"
  },
  {
    "code" : "BR0271444",
    "display" : "Medroxiprogesterona 2,5mg Comprimido"
  },
  {
    "code" : "BR0271445",
    "display" : "Medroxiprogesterona 10mg comprimido"
  },
  {
    "code" : "BR0271556",
    "display" : "Cloridrato de Midazolam 2mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0271570",
    "display" : "Dexametasona 1mg/1g + Tobramicina 3mg/1g pomada oftálmica; bisnaga"
  },
  {
    "code" : "BR02715701",
    "display" : "Dexametasona 1mg/1g pomada oftálmica; bisnaga"
  },
  {
    "code" : "BR0271578",
    "display" : "Sulfato de Tobramicina 75mg/1,5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271581",
    "display" : "Tobramicina 3mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0271582",
    "display" : "Tobramicina 3mg/g pomada oftálmica"
  },
  {
    "code" : "BR0271599",
    "display" : "Succinato Sódico de Metilprednisolona 500mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271604",
    "display" : "Aceponato de Metilprednisolona 1mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0271606",
    "display" : "Cloridrato de Nortriptilina 25mg Cápsula"
  },
  {
    "code" : "BR0271607",
    "display" : "Cloridrato de Nortriptilina 75mg cápsula"
  },
  {
    "code" : "BR0271608",
    "display" : "Cloridrato de Nortriptilina 2mg/1mL Solução oral"
  },
  {
    "code" : "BR0271609-1",
    "display" : "Cloridrato de Nortriptilina 10mg cápsula"
  },
  {
    "code" : "BR0271609-2",
    "display" : "Nortriptilina 10mg Comprimido"
  },
  {
    "code" : "BR0271610",
    "display" : "Cloridrato de Nortriptilina 50mg Cápsula"
  },
  {
    "code" : "BR0271610-1",
    "display" : "Nortriptilina 50mg Comprimido"
  },
  {
    "code" : "BR0271620",
    "display" : "Olanzapina 5mg comprimido revestido"
  },
  {
    "code" : "BR0271620E",
    "display" : "Olanzapina 5mg comprimido revestido"
  },
  {
    "code" : "BR0271621",
    "display" : "Olanzapina 10mg comprimido revestido"
  },
  {
    "code" : "BR0271621E",
    "display" : "Olanzapina 10mg comprimido revestido"
  },
  {
    "code" : "BR0271644",
    "display" : "Oximetolona 50mg comprimido"
  },
  {
    "code" : "BR0271645",
    "display" : "Cloridrato de Oximetazolina 0,5mg/1mL Solução nasal"
  },
  {
    "code" : "BR0271647",
    "display" : "Cloridrato de Oximetazolina 0.25mg/1mL Solução nasal"
  },
  {
    "code" : "BR0271651",
    "display" : "Hidroxocobalamina 5mg/2,5 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271652",
    "display" : "Hidroxocobalamina 30mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0271653-1",
    "display" : "Hidroxocobalamina 5mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271653-2",
    "display" : "Hidroxocobalamina 2mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271654",
    "display" : "Acetato de Megestrol 160mg Comprimido"
  },
  {
    "code" : "BR0271656",
    "display" : "Acetato de Caspofungina 70mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271657",
    "display" : "Acetato de Caspofungina 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271659-1",
    "display" : "Cloridrato de Ambroxol 6mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0271659-2",
    "display" : "Cloridrato de Ambroxol 6mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0271660-1",
    "display" : "Cloridrato de Ambroxol 3mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0271660-2",
    "display" : "Cloridrato de Ambroxol 3mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0271661-1",
    "display" : "Ambroxol 7,5mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0271661-2",
    "display" : "Ambroxol 7,5mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0271666",
    "display" : "Aceclofenaco 100mg comprimido revestido"
  },
  {
    "code" : "BR0271670",
    "display" : "Ácido Mefenâmico 500mg comprimido"
  },
  {
    "code" : "BR0271686",
    "display" : "Ácido Ascórbico 2g Comprimido efervescente"
  },
  {
    "code" : "BR0271687",
    "display" : "Ácido Ascórbico 500mg/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271689-1",
    "display" : "Ácido Ascórbico 200mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0271689-2",
    "display" : "Ácido Ascórbico 200mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0271710",
    "display" : "Cloridrato de Amiodarona 150mg/3mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0271724",
    "display" : "Piperacilina Sódica 2g + Tazobactam Sódico 250mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271725",
    "display" : "Piperacilina 4g + Tazobactam 500 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271727",
    "display" : "Pravastatina Sódica 40mg comprimido"
  },
  {
    "code" : "BR0271727E",
    "display" : "Pravastatina Sódica 40mg comprimido"
  },
  {
    "code" : "BR0271746",
    "display" : "Baclofeno 10mg comprimido"
  },
  {
    "code" : "BR0271747",
    "display" : "Benciclano 100mg comprimido revestido"
  },
  {
    "code" : "BR0271748",
    "display" : "Benciclano 200mg comprimido revestido"
  },
  {
    "code" : "BR0271758",
    "display" : "Cloreto de Betanecol 10mg cápsula"
  },
  {
    "code" : "BR0271761",
    "display" : "Bicalutamida 50mg comprimido revestido"
  },
  {
    "code" : "BR0271764",
    "display" : "Brometo de Piridostigmina 60mg comprimido"
  },
  {
    "code" : "BR0271764E",
    "display" : "Brometo de Piridostigmina 60mg comprimido"
  },
  {
    "code" : "BR0271773",
    "display" : "Bromazepam 3mg comprimido"
  },
  {
    "code" : "BR0271774",
    "display" : "Bromazepam 6mg Comprimido"
  },
  {
    "code" : "BR0271790-1",
    "display" : "Fenilefrina 10% solução oftálmica; frasco"
  },
  {
    "code" : "BR0271790-2",
    "display" : "Fenilefrina 10% solução oftálmica; frasco"
  },
  {
    "code" : "BR0271790-3",
    "display" : "Fenilefrina 10% solução oftálmica; frasco"
  },
  {
    "code" : "BR0271848-1",
    "display" : "Bimatoprosta 0,3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271848-2",
    "display" : "Bimatoprosta 0,3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271848E",
    "display" : "Bimatoprosta 0,3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271866-1",
    "display" : "Brinzolamida 10mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271866-2",
    "display" : "Brinzolamida 10mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271866E",
    "display" : "Brinzolamida 10mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0271876",
    "display" : "Solução Ringer; bolsa"
  },
  {
    "code" : "BR0271946",
    "display" : "Fentanila 4,2mg/1adesivo Adesivo Transdérmico"
  },
  {
    "code" : "BR0271948",
    "display" : "Fentanila 16,8mg/1adesivo Adesivo Transdérmico"
  },
  {
    "code" : "BR0271949",
    "display" : "Fentanila 8,4mg/1adesivo Adesivo Transdérmico"
  },
  {
    "code" : "BR0271950-1",
    "display" : "Citrato de Fentanila 0,1mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271950-2",
    "display" : "Citrato de Fentanila 0.25mg/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271953-1",
    "display" : "Droperidol 2,5mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271982",
    "display" : "Cefadroxila 500mg Cápsula"
  },
  {
    "code" : "BR0271987",
    "display" : "Cefuroxima Sódica 750mg Pó para solução para injeção; ; frasco-ampola"
  },
  {
    "code" : "BR0271988",
    "display" : "Axetilcefuroxima 250mg comprimido revestido"
  },
  {
    "code" : "BR0271989",
    "display" : "Axetilcefuroxima 500mg comprimido revestido"
  },
  {
    "code" : "BR0271992",
    "display" : "Celecoxibe 100mg cápsula"
  },
  {
    "code" : "BR0272005",
    "display" : "Citicolina 500mg comprimido revestido"
  },
  {
    "code" : "BR0272022",
    "display" : "Citrato de Tamoxifeno 10mg comprimido revestido"
  },
  {
    "code" : "BR0272023",
    "display" : "Citrato de Tamoxifeno 20mg comprimido revestido"
  },
  {
    "code" : "BR0272027",
    "display" : "Cloridrato de Bamifilina 600mg comprimido revestido"
  },
  {
    "code" : "BR0272028",
    "display" : "Cloridrato de Bamifilina 300mg comprimido revestido"
  },
  {
    "code" : "BR0272041",
    "display" : "Cloridrato de Clomipramina 75mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272042",
    "display" : "Cloridrato de Clonidina 0,2mg comprimido"
  },
  {
    "code" : "BR0272043",
    "display" : "Cloridrato de Clonidina 0,1mg Comprimido"
  },
  {
    "code" : "BR0272044",
    "display" : "Cloridrato de Clonidina 0,15mg Comprimido; comprimido"
  },
  {
    "code" : "BR0272045",
    "display" : "Bissulfato de Clopidogrel 75mg comprimido revestido"
  },
  {
    "code" : "BR0272045E",
    "display" : "Bissulfato de Clopidogrel 75mg comprimido revestido"
  },
  {
    "code" : "BR0272049",
    "display" : "Clordiazepóxido 25mg comprimido revestido"
  },
  {
    "code" : "BR0272083",
    "display" : "Sevelâmer 800mg comprimido revestido"
  },
  {
    "code" : "BR0272083E",
    "display" : "Sevelâmer 800mg comprimido revestido"
  },
  {
    "code" : "BR0272088-1",
    "display" : "Sulfadiazina de Prata 10mg/1g + Nitrato de Cério 4mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0272088-2",
    "display" : "Sulfadiazina de Prata 10mg/1g + Nitrato de Cério 4mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0272088-3",
    "display" : "Sulfadiazina de Prata 10mg/1g + Nitrato de Cério 4mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0272088-4",
    "display" : "Sulfadiazina de Prata 10mg/1g + Nitrato de Cério 4mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0272089",
    "display" : "Sulfadiazina de Prata 10mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0272089-2",
    "display" : "Sulfadiazina de Prata 1% Pasta"
  },
  {
    "code" : "BR0272089-3",
    "display" : "Sulfadiazina de Prata 1% Pasta"
  },
  {
    "code" : "BR0272089-4",
    "display" : "Sulfadiazina de Prata 1% Pasta"
  },
  {
    "code" : "BR0272089-5",
    "display" : "Sulfadiazina de Prata 1% Pasta"
  },
  {
    "code" : "BR0272089-6",
    "display" : "Sulfadiazina de Prata 10mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0272089-7",
    "display" : "Sulfadiazina de Prata 10mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0272094",
    "display" : "Lamivudina 150mg + Zidovudina 300mg comprimido revestido;"
  },
  {
    "code" : "BR0272131",
    "display" : "Sulfato de Quinina 500mg comprimido"
  },
  {
    "code" : "BR0272134",
    "display" : "Cloridrato de Ciclopentolato 10mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0272166",
    "display" : "Cloridrato de Ciclobenzaprina 5mg comprimido revestido"
  },
  {
    "code" : "BR0272178",
    "display" : "Cloridrato de Clobutinol 4mg/1mL Xarope"
  },
  {
    "code" : "BR0272194",
    "display" : "Cloridrato de Esmolol 100mg/10mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272198",
    "display" : "Cloridrato de Etilefrina 10mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0272201",
    "display" : "Cloridrato de Etilefrina 7,5mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0272217",
    "display" : "Cloridrato de Difenidramina 50mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0272229",
    "display" : "Lercanidipino 10mg comprimido revestido"
  },
  {
    "code" : "BR0272234",
    "display" : "Cloridrato de Levobunolol 5mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0272320",
    "display" : "Cloridrato de Metilfenidato 10mg Comprimido"
  },
  {
    "code" : "BR0272326",
    "display" : "Cloridrato de Naloxona 0,4mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0272327",
    "display" : "Cloridrato de Oxibutinina 5mg Comprimido"
  },
  {
    "code" : "BR0272328",
    "display" : "Oxibutinina 1mg/mL xarope"
  },
  {
    "code" : "BR0272329",
    "display" : "Cloridrato de Petidina 100mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0272330",
    "display" : "Ácido Ascórbico 50mg + Piperidolato 100mg + Hesperidina 50mg drágea"
  },
  {
    "code" : "BR0272331",
    "display" : "Dimenidrinato 100mg Comprimido"
  },
  {
    "code" : "BR0272333",
    "display" : "Dimenidrinato 50mg + Cloridrato de Piridoxina 10mg comprimido revestido"
  },
  {
    "code" : "BR0272334-1",
    "display" : "Dimenidrinato 50mg/1mL + Piridoxina 50mg/1mL Solução para injeção"
  },
  {
    "code" : "BR0272334-2",
    "display" : "Cloridrato de Piridoxina 50mg/10mL + Dimenidrinato 50mg/10mL solução para injeção"
  },
  {
    "code" : "BR0272335",
    "display" : "Cloridrato de Piridoxina 5mg/1mL + Dimenidrinato 25mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0272336",
    "display" : "Frutose 1g/10mL + Piridoxina 50mg/10mL + Glicose 1g/10mL + Dimenidrinato 30mg/10mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272337",
    "display" : "Cloridrato de Piridoxina 100mg comprimido"
  },
  {
    "code" : "BR0272338",
    "display" : "Cloridrato de Piridoxina 300mg Comprimido"
  },
  {
    "code" : "BR0272340",
    "display" : "Tiamina 100mg cápsula"
  },
  {
    "code" : "BR0272341",
    "display" : "Tiamina 300mg comprimido revestido"
  },
  {
    "code" : "BR0272343",
    "display" : "Cloridrato de Tiamina 100mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0272362",
    "display" : "Cloridrato de Protamina 50mg/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272363",
    "display" : "Cloridrato de Sertralina 100mg comprimido revestido"
  },
  {
    "code" : "BR0272364",
    "display" : "Cloridrato de Sertralina 25mg comprimido revestido"
  },
  {
    "code" : "BR0272364-1",
    "display" : "Sertralina 75mg comprimido revestido"
  },
  {
    "code" : "BR0272365",
    "display" : "Cloridrato de Sertralina 50mg comprimido revestido"
  },
  {
    "code" : "BR0272366",
    "display" : "Cloridrato de Tioridazina 50mg comprimido revestido"
  },
  {
    "code" : "BR0272367",
    "display" : "Cloridrato de Tioridazina 100mg comprimido revestido"
  },
  {
    "code" : "BR0272369",
    "display" : "Cloridrato de Valaciclovir 500mg comprimido revestido"
  },
  {
    "code" : "BR0272379",
    "display" : "Cloridrato de Venlafaxina 75mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0272380",
    "display" : "Cloridrato de Venlafaxina 150mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0272381",
    "display" : "Cloridrato de Venlafaxina 37,5mg comprimido"
  },
  {
    "code" : "BR0272382",
    "display" : "Cloridrato de Venlafaxina 75mg Comprimido"
  },
  {
    "code" : "BR0272383",
    "display" : "Venlafaxina 50mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272400",
    "display" : "Cloridrato de Nafazolina 0,5mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0272400-1",
    "display" : "Cloridrato de Nafazolina 0,5mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0272402",
    "display" : "Nafazolina 0,5mg/1mL + Cloreto de Benzalcônio 0,1mg/1mL Solução nasal"
  },
  {
    "code" : "BR0272406",
    "display" : "Maleato de Feniramina 3mg/1mL + Cloridrato de Nafazolina 0,25mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0272410",
    "display" : "Fluocinolona Acetonida 0,25mg/1mL + Nafazolina 0,5mg/1mL + Sulfato de Zinco 4mg/1mL + Neomicina 7mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0272411",
    "display" : "Sulfato de Berberina 0,025mg/1mL + Cloridrato de Nafazolina 0,5mg/1mL + Fenolsulfonato de Zinco 1mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0272412",
    "display" : "Cloridrato de Propafenona 300mg comprimido revestido"
  },
  {
    "code" : "BR0272417",
    "display" : "Difosfato de Cloroquina 250mg comprimido"
  },
  {
    "code" : "BR0272420",
    "display" : "Clortalidona 50mg comprimido"
  },
  {
    "code" : "BR0272423",
    "display" : "Clotrimazol 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0272423-1",
    "display" : "Clotrimazol 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0272423-2",
    "display" : "Clotrimazol 10mg/1g Creme vaginal; bisnaga"
  },
  {
    "code" : "BR0272423-3",
    "display" : "Clotrimazol 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0272429",
    "display" : "Clozapina 25mg comprimido"
  },
  {
    "code" : "BR0272429E",
    "display" : "Clozapina 25mg comprimido"
  },
  {
    "code" : "BR0272431",
    "display" : "Clozapina 100mg comprimido"
  },
  {
    "code" : "BR0272431E",
    "display" : "Clozapina 100mg comprimido"
  },
  {
    "code" : "BR0272434",
    "display" : "Besilato de Anlodipino 5mg Comprimido"
  },
  {
    "code" : "BR0272435",
    "display" : "Besilato de Anlodipino 2,5mg comprimido"
  },
  {
    "code" : "BR0272445",
    "display" : "Ciclofenila 200mg Comprimido"
  },
  {
    "code" : "BR0272454-1",
    "display" : "Carbamazepina 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0272454-2",
    "display" : "Carbamazepina 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0272457",
    "display" : "Carbamazepina 400mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272458",
    "display" : "Carbamazepina 200mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0272469",
    "display" : "Dalteparina Sódica 5.000UI/0,2mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0272470",
    "display" : "Dalteparina Sódica 2.500UI/0,2mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0272471E",
    "display" : "Danazol 50mg cápsula"
  },
  {
    "code" : "BR0272472E",
    "display" : "Danazol 200mg cápsula"
  },
  {
    "code" : "BR0272473",
    "display" : "Danazol 100mg cápsula"
  },
  {
    "code" : "BR0272473E",
    "display" : "Danazol 100mg cápsula"
  },
  {
    "code" : "BR0272475",
    "display" : "Dantroleno Sódico 20mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272476",
    "display" : "Dapsona 100mg Comprimido"
  },
  {
    "code" : "BR0272477",
    "display" : "Dicloridrato de Cetirizina 10mg comprimido revestido"
  },
  {
    "code" : "BR0272478",
    "display" : "Dicloridrato de Flunarizina 10mg Comprimido"
  },
  {
    "code" : "BR0272482",
    "display" : "Zuclopentixol 10mg comprimido revestido"
  },
  {
    "code" : "BR0272487",
    "display" : "Didanosina 25mg Comprimido"
  },
  {
    "code" : "BR0272488",
    "display" : "Didanosina 100mg Comprimido"
  },
  {
    "code" : "BR0272489",
    "display" : "Dietilcarbamazina 50mg Comprimido"
  },
  {
    "code" : "BR0272490",
    "display" : "Dietilestilbestrol 1mg comprimido revestido"
  },
  {
    "code" : "BR0272525",
    "display" : "Dipiridamol 10mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272565",
    "display" : "Retinol 150.000UI/1mL Solução oral"
  },
  {
    "code" : "BR0272567",
    "display" : "Retinol 5.500UI + Colecalciferol 2.200UI Solução oral"
  },
  {
    "code" : "BR0272568",
    "display" : "Acetato de Retinol 50.000UI/1mL + Colecalciferol 10.000UI/1mL solução oral; frasco"
  },
  {
    "code" : "BR0272568-2",
    "display" : "Acetato de Retinol 50.000UI/1mL + Colecalciferol 10.000UI/1mL solução oral; frasco"
  },
  {
    "code" : "BR0272572",
    "display" : "Cloridrato de Buspirona 5mg Comprimido; comprimido"
  },
  {
    "code" : "BR0272573",
    "display" : "Cloridrato de Buspirona 10mg Comprimido"
  },
  {
    "code" : "BR0272579",
    "display" : "Maleato de Timolol 5mg/1mL + Cloridrato de Dorzolamida 20mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0272580",
    "display" : "Cloridrato de Dorzolamida 20mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0272580E",
    "display" : "Cloridrato de Dorzolamida 20mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0272581",
    "display" : "Maleato de Timolol 5mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0272585",
    "display" : "Decanoato de Zuclopentixol 200mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0272587",
    "display" : "Dissulfiram 250mg Comprimido"
  },
  {
    "code" : "BR0272588",
    "display" : "Divalproato de Sódio 250mg comprimido revestido"
  },
  {
    "code" : "BR0272589",
    "display" : "Divalproato de Sódio 500mg comprimido revestido"
  },
  {
    "code" : "BR0272602",
    "display" : "Dropropizina 3mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0272602-3",
    "display" : "Dropropizina 3mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0272603",
    "display" : "Dropropizina 1,5mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0272603-1",
    "display" : "Dropropizina 1,5mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0272636",
    "display" : "Enflurano 1mL/1mL solução para inalação 240 mL; frasco"
  },
  {
    "code" : "BR0272644",
    "display" : "Enoxaparina Sódica 20mg/0,2mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0272645",
    "display" : "Enoxaparina Sódica 40mg/0,4mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0272653",
    "display" : "Entacapona 200mg comprimido revestido"
  },
  {
    "code" : "BR0272653E",
    "display" : "Entacapona 200mg comprimido revestido"
  },
  {
    "code" : "BR0272689",
    "display" : "Decanoato de Nandrolona 25mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272690",
    "display" : "Decanoato de Nandrolona 50mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0272737",
    "display" : "Meglumina 300mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272780E",
    "display" : "Cloroquina 150mg comprimido"
  },
  {
    "code" : "BR0272782",
    "display" : "Fosfato de Codeína 30mg Comprimido"
  },
  {
    "code" : "BR0272782E",
    "display" : "Fosfato de Codeína 30mg Comprimido"
  },
  {
    "code" : "BR0272784",
    "display" : "Fosfato de Codeína 3mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0272784E",
    "display" : "Fosfato de Codeína 3mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0272785",
    "display" : "Cloridrato de Donepezila 5mg comprimido revestido"
  },
  {
    "code" : "BR0272785E",
    "display" : "Cloridrato de Donepezila 5mg comprimido revestido"
  },
  {
    "code" : "BR0272786",
    "display" : "Cloridrato de Donepezila 10mg comprimido revestido"
  },
  {
    "code" : "BR0272786E",
    "display" : "Cloridrato de Donepezila 10mg comprimido revestido"
  },
  {
    "code" : "BR0272787",
    "display" : "Alfadornase 1mg/1mL solução para inalação; ampola"
  },
  {
    "code" : "BR0272787E",
    "display" : "Alfadornase 1mg/1mL solução para inalação; ampola"
  },
  {
    "code" : "BR0272789",
    "display" : "Levonorgestrel 0,15mg + Etinilestradiol 0,03mg Comprimido"
  },
  {
    "code" : "BR0272790",
    "display" : "Etionamida 250mg comprimido revestido"
  },
  {
    "code" : "BR0272791",
    "display" : "Etossuximida 250mg comprimido"
  },
  {
    "code" : "BR0272792",
    "display" : "Etossuximida 50mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0272792E",
    "display" : "Etossuximida 50mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0272793",
    "display" : "Acetato de Fludrocortisona 0,1mg Comprimido"
  },
  {
    "code" : "BR0272793E",
    "display" : "Acetato de Fludrocortisona 0,1mg Comprimido"
  },
  {
    "code" : "BR0272807",
    "display" : "Isotretinoína 10mg cápsula"
  },
  {
    "code" : "BR0272807E",
    "display" : "Isotretinoína 10mg cápsula"
  },
  {
    "code" : "BR0272808",
    "display" : "Isotretinoína 20mg cápsula"
  },
  {
    "code" : "BR0272808E",
    "display" : "Isotretinoína 20mg cápsula"
  },
  {
    "code" : "BR0272809",
    "display" : "Lamotrigina 100mg Comprimido"
  },
  {
    "code" : "BR0272809E",
    "display" : "Lamotrigina 100mg Comprimido"
  },
  {
    "code" : "BR0272815",
    "display" : "Penicilamina 250mg Cápsula"
  },
  {
    "code" : "BR0272815E",
    "display" : "Penicilamina 250mg Cápsula"
  },
  {
    "code" : "BR0272817",
    "display" : "Midazolam 15mg comprimido revestido"
  },
  {
    "code" : "BR0272822",
    "display" : "Pirazinamida 500mg comprimido"
  },
  {
    "code" : "BR0272824",
    "display" : "Dicloridrato de Pramipexol 0.125mg Comprimido"
  },
  {
    "code" : "BR0272824E",
    "display" : "Dicloridrato de Pramipexol 0.125mg Comprimido"
  },
  {
    "code" : "BR0272825",
    "display" : "Dicloridrato de Pramipexol 0.25mg Comprimido"
  },
  {
    "code" : "BR0272825E",
    "display" : "Dicloridrato de Pramipexol 0.25mg Comprimido"
  },
  {
    "code" : "BR0272826",
    "display" : "Dicloridrato de Pramipexol 1mg comprimido"
  },
  {
    "code" : "BR0272826E",
    "display" : "Dicloridrato de Pramipexol 1mg comprimido"
  },
  {
    "code" : "BR0272827",
    "display" : "Difosfato de Primaquina 5mg comprimido"
  },
  {
    "code" : "BR0272828",
    "display" : "Difosfato de Primaquina 15mg Comprimido"
  },
  {
    "code" : "BR0272831",
    "display" : "Hemifumarato de Quetiapina 25mg comprimido revestido"
  },
  {
    "code" : "BR0272831E",
    "display" : "Hemifumarato de Quetiapina 25mg comprimido revestido"
  },
  {
    "code" : "BR0272832",
    "display" : "Hemifumarato de Quetiapina 100mg comprimido revestido"
  },
  {
    "code" : "BR0272832E",
    "display" : "Hemifumarato de Quetiapina 100mg comprimido revestido"
  },
  {
    "code" : "BR0272833",
    "display" : "Hemifumarato de Quetiapina 200mg comprimido revestido"
  },
  {
    "code" : "BR0272833E",
    "display" : "Hemifumarato de Quetiapina 200mg comprimido revestido"
  },
  {
    "code" : "BR0272834",
    "display" : "Raloxifeno 60mg comprimido revestido"
  },
  {
    "code" : "BR0272834E",
    "display" : "Raloxifeno 60mg comprimido revestido"
  },
  {
    "code" : "BR0272835",
    "display" : "Ribavirina 250mg cápsula"
  },
  {
    "code" : "BR0272835E",
    "display" : "Ribavirina 250mg cápsula"
  },
  {
    "code" : "BR0272838",
    "display" : "Riluzol 50mg comprimido revestido"
  },
  {
    "code" : "BR0272838E",
    "display" : "Riluzol 50mg comprimido revestido"
  },
  {
    "code" : "BR0272839",
    "display" : "Risperidona 1mg comprimido revestido"
  },
  {
    "code" : "BR0272839E",
    "display" : "Risperidona 1mg comprimido revestido"
  },
  {
    "code" : "BR0272843",
    "display" : "Sinvastatina 5mg comprimido"
  },
  {
    "code" : "BR0272846",
    "display" : "Talidomida 100mg Comprimido"
  },
  {
    "code" : "BR0272847E",
    "display" : "Tolcapona 100mg comprimido revestido"
  },
  {
    "code" : "BR0272848",
    "display" : "Tolcapona 200mg comprimido"
  },
  {
    "code" : "BR0272849",
    "display" : "Topiramato 25mg comprimido revestido"
  },
  {
    "code" : "BR0272849E",
    "display" : "Topiramato 25mg comprimido revestido"
  },
  {
    "code" : "BR0272850",
    "display" : "Topiramato 50mg comprimido revestido"
  },
  {
    "code" : "BR0272850E",
    "display" : "Topiramato 50mg comprimido revestido"
  },
  {
    "code" : "BR0272851",
    "display" : "Topiramato 100mg comprimido revestido"
  },
  {
    "code" : "BR0272851E",
    "display" : "Topiramato 100mg comprimido revestido"
  },
  {
    "code" : "BR0272852",
    "display" : "Cloridrato de Triexifenidil 5mg comprimido"
  },
  {
    "code" : "BR0272852E",
    "display" : "Cloridrato de Triexifenidil 5mg comprimido"
  },
  {
    "code" : "BR0272853",
    "display" : "Vigabatrina 500mg comprimido revestido"
  },
  {
    "code" : "BR0272853E",
    "display" : "Vigabatrina 500mg comprimido revestido"
  },
  {
    "code" : "BR0272896",
    "display" : "Maleato de Dexclorfeniramina 0,4mg/1mL + Betametasona 0,05mg/1mL Xarope"
  },
  {
    "code" : "BR0272901",
    "display" : "Clobazam 10mg Comprimido"
  },
  {
    "code" : "BR0272901E",
    "display" : "Clobazam 10mg Comprimido"
  },
  {
    "code" : "BR0272902",
    "display" : "Clobazam 20mg Comprimido"
  },
  {
    "code" : "BR0272902E",
    "display" : "Clobazam 20mg Comprimido"
  },
  {
    "code" : "BR0272931",
    "display" : "Flunitrazepam 1mg comprimido revestido"
  },
  {
    "code" : "BR0272944",
    "display" : "Fluoresceína 1%/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0272971",
    "display" : "Fenoximetilpenicilina Potássica 500.000UI Comprimido"
  },
  {
    "code" : "BR0272972",
    "display" : "Fenoximetilpenicilina Potássica 80.000UI/1mL Pó para solução oral"
  },
  {
    "code" : "BR0272996",
    "display" : "Famotidina 40mg comprimido"
  },
  {
    "code" : "BR0273009-1",
    "display" : "Cloridrato de Fluoxetina 20mg Cápsula"
  },
  {
    "code" : "BR0273009-2",
    "display" : "Cloridrato de Fluoxetina 20mg comprimido revestido"
  },
  {
    "code" : "BR0273011",
    "display" : "Cloridrato de Flurazepam 30mg comprimido revestido"
  },
  {
    "code" : "BR0273112",
    "display" : "Griseofulvina 500mg Comprimido"
  },
  {
    "code" : "BR0273115",
    "display" : "Gliclazida 80mg Comprimido"
  },
  {
    "code" : "BR0273116",
    "display" : "Gliclazida 30mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273119",
    "display" : "Glimepirida 2mg Comprimido"
  },
  {
    "code" : "BR0273120",
    "display" : "Glimepirida 1mg Comprimido"
  },
  {
    "code" : "BR0273121",
    "display" : "Glimepirida 4mg Comprimido"
  },
  {
    "code" : "BR0273132",
    "display" : "Cloridrato de Difenidramina 10mg/1mL + Calamina 80mg/1mL + Cânfora 1mg/1mL loção; frasco"
  },
  {
    "code" : "BR0273135",
    "display" : "Propatilnitrato 10mg Comprimido"
  },
  {
    "code" : "BR0273137",
    "display" : "Diclofenaco Sódico 75mg comprimido"
  },
  {
    "code" : "BR0273140",
    "display" : "Cloridrato de Verapamil 240mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273148",
    "display" : "Deflazacorte 6mg comprimido"
  },
  {
    "code" : "BR0273149",
    "display" : "Deflazacorte 7,5mg comprimido"
  },
  {
    "code" : "BR0273150",
    "display" : "Deflazacorte 30mg comprimido"
  },
  {
    "code" : "BR0273166",
    "display" : "Neomicina 3,5mg/g pomada"
  },
  {
    "code" : "BR0273167-1",
    "display" : "Sulfato de Neomicina 5mg/1g + Bacitracina 250UI/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0273167-2",
    "display" : "Sulfato de Neomicina 5mg/1g + Bacitracina 250UI/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0273167-3",
    "display" : "Sulfato de Neomicina 5mg/1g + Bacitracina 250UI/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0273167-4",
    "display" : "Sulfato de Neomicina 5mg/1g + Bacitracina 250UI/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0273192",
    "display" : "Temozolomida 250mg cápsula"
  },
  {
    "code" : "BR0273193",
    "display" : "Temozolomida 5mg cápsula"
  },
  {
    "code" : "BR0273194",
    "display" : "Temozolomida 20mg Cápsula"
  },
  {
    "code" : "BR0273195",
    "display" : "Temozolomida 100mg cápsula"
  },
  {
    "code" : "BR0273221",
    "display" : "Cloridrato de Memantina 10mg comprimido revestido"
  },
  {
    "code" : "BR0273255",
    "display" : "Oxcarbazepina 60mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0273256",
    "display" : "Oxcarbazepina 600mg comprimido revestido"
  },
  {
    "code" : "BR0273257",
    "display" : "Oxcarbazepina 300mg comprimido revestido"
  },
  {
    "code" : "BR0273258",
    "display" : "Pamidronato Dissódico Pentaidratado 90mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273258E",
    "display" : "Pamidronato Dissódico Pentaidratado 90mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273264",
    "display" : "Cloridrato de Loperamida 2mg comprimido"
  },
  {
    "code" : "BR0273266",
    "display" : "Cloridrato de Naltrexona 50mg comprimido revestido"
  },
  {
    "code" : "BR0273310",
    "display" : "Cloridrato de Hidroxizina 25mg Comprimido"
  },
  {
    "code" : "BR0273311",
    "display" : "Cloridrato de Hidroxizina 10mg Comprimido"
  },
  {
    "code" : "BR0273314",
    "display" : "Cianocobalamina 5mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273317",
    "display" : "Mesilato de Imatinibe 100mg comprimido revestido"
  },
  {
    "code" : "BR0273319",
    "display" : "Indometacina 25mg cápsula"
  },
  {
    "code" : "BR0273320",
    "display" : "Indometacina 50mg Cápsula"
  },
  {
    "code" : "BR0273328",
    "display" : "Ivermectina 6mg Comprimido"
  },
  {
    "code" : "BR0273387",
    "display" : "Irbesartana 150mg comprimido revestido"
  },
  {
    "code" : "BR0273388",
    "display" : "Irbesartana 300mg comprimido revestido"
  },
  {
    "code" : "BR0273389",
    "display" : "Irbesartana 150mg + Hidroclorotiazida 12,5mg Comprimido"
  },
  {
    "code" : "BR0273390",
    "display" : "Irbesartana 300mg + Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0273395",
    "display" : "Dinitrato de Isossorbida 5mg Comprimido sublingual"
  },
  {
    "code" : "BR0273396",
    "display" : "Dinitrato de Isossorbida 10mg comprimido"
  },
  {
    "code" : "BR0273400",
    "display" : "Mononitrato de Isossorbida 20mg Comprimido"
  },
  {
    "code" : "BR0273401",
    "display" : "Mononitrato de Isossorbida 40mg Comprimido"
  },
  {
    "code" : "BR0273402",
    "display" : "Mononitrato de Isossorbida 5mg Comprimido sublingual"
  },
  {
    "code" : "BR0273403",
    "display" : "Mononitrato de Isossorbida 50mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0273404",
    "display" : "Mononitrato de Isossorbida 10mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0273412",
    "display" : "Linezolida 600mg comprimido revestido"
  },
  {
    "code" : "BR0273413",
    "display" : "Linezolida 600mg/300mL solução para injeção; frasco"
  },
  {
    "code" : "BR0273434",
    "display" : "Sorbitol 27mg/1mL + Manitol 5,4mg/1mL solução; bolsa"
  },
  {
    "code" : "BR0273450",
    "display" : "Moxifloxacino 400mg comprimido revestido"
  },
  {
    "code" : "BR0273455",
    "display" : "Mupirocina 20mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0273457",
    "display" : "Metilsulfato de Neostigmina 0,5mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0273466",
    "display" : "Loratadina 10mg Comprimido"
  },
  {
    "code" : "BR0273467",
    "display" : "Loratadina 1mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0273467-1",
    "display" : "Loratadina 1mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0273467-2",
    "display" : "Loratadina 1mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0273469",
    "display" : "Loratadina 10mg + Pseudoefedrina 240mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273470",
    "display" : "Sulfato de Pseudoefedrina 120mg + Loratadina 5mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273471",
    "display" : "Sulfato de Pseudoefedrina 12mg/1mL + Loratadina 1mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0273472",
    "display" : "Lorazepam 1mg Comprimido"
  },
  {
    "code" : "BR0273473",
    "display" : "Lorazepam 2mg Comprimido"
  },
  {
    "code" : "BR0273474",
    "display" : "Lactato de Milrinona 10mg/10mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273479",
    "display" : "Minoxidil 10mg comprimido"
  },
  {
    "code" : "BR0273483",
    "display" : "Mitotano 500mg Comprimido"
  },
  {
    "code" : "BR0273484",
    "display" : "Furoato de Mometasona 1mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0273553",
    "display" : "Meloxicam 7,5mg comprimido"
  },
  {
    "code" : "BR0273554",
    "display" : "Meloxicam 15mg Comprimido"
  },
  {
    "code" : "BR0273555",
    "display" : "Meloxicam 22,5mg/1,5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273579",
    "display" : "Cloridrato de Difenidramina 1,5mgmL + Dropropizina 1,5mgmL + Paracetamol 12mgmL + Pseudoefedrina 1,5mgmL xarope; frasco"
  },
  {
    "code" : "BR0273589",
    "display" : "Propiltiouracila 100mg Comprimido"
  },
  {
    "code" : "BR0273596",
    "display" : "Cloridrato de Tioridazina 200mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0273597",
    "display" : "Cloridrato de Tioridazina 25mg comprimido revestido"
  },
  {
    "code" : "BR0273598",
    "display" : "Cloridrato de Tioridazina 10mg comprimido revestido"
  },
  {
    "code" : "BR0273599",
    "display" : "Cloridrato de Terbinafina 250mg comprimido"
  },
  {
    "code" : "BR0273618",
    "display" : "Teclozana 10mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0273619",
    "display" : "Teclozana 500mg Comprimido"
  },
  {
    "code" : "BR0273621",
    "display" : "Sulfato Ferroso 60mg comprimido revestido"
  },
  {
    "code" : "BR0273626",
    "display" : "Fenobarbital 50mg Comprimido"
  },
  {
    "code" : "BR0273642",
    "display" : "Hidróxido de Alumínio 200mg + Hidróxido de Magnésio 200mg comprimido mastigável"
  },
  {
    "code" : "BR0273664",
    "display" : "Mesna 400mg/4mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273668",
    "display" : "Mesilato de Pralidoxima 200mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273675",
    "display" : "Hemitartarato de Metaraminol 10mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273675-1",
    "display" : "Hemitartarato de Metaraminol 10mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0273690",
    "display" : "Metilcelulose 2% solução oftálmica; frasco"
  },
  {
    "code" : "BR0273694",
    "display" : "Metilcelulose 30mg/1,5mL Solução para injeção"
  },
  {
    "code" : "BR0273700",
    "display" : "Tiamazol 5mg comprimido"
  },
  {
    "code" : "BR0273702E",
    "display" : "Naproxeno 250mg Comprimido"
  },
  {
    "code" : "BR0273703",
    "display" : "Naproxeno Sódico 500mg comprimido"
  },
  {
    "code" : "BR0273703E",
    "display" : "Naproxeno Sódico 500mg comprimido"
  },
  {
    "code" : "BR0273704",
    "display" : "Naproxeno Sódico 275mg comprimido revestido"
  },
  {
    "code" : "BR0273706",
    "display" : "Naratriptana 2,5mg comprimido revestido"
  },
  {
    "code" : "BR0273710",
    "display" : "Nimesulida 100mg comprimido"
  },
  {
    "code" : "BR0273711",
    "display" : "Nimesulida 50mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0273712",
    "display" : "Nimesulida 10mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0273719",
    "display" : "Nitroprusseto de Sódio 50mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273810",
    "display" : "Olanzapina 2,5mg comprimido revestido"
  },
  {
    "code" : "BR0273818",
    "display" : "Hesperidina 50mg + Diosmina 450mg comprimido revestido"
  },
  {
    "code" : "BR0273820",
    "display" : "Sildenafila 25mg comprimido revestido"
  },
  {
    "code" : "BR0273820E",
    "display" : "Sildenafila 25mg comprimido revestido"
  },
  {
    "code" : "BR0273821E",
    "display" : "Citrato de Sildenafila 50mg comprimido revestido"
  },
  {
    "code" : "BR0273824",
    "display" : "Ácido Fólico 2mg comprimido revestido"
  },
  {
    "code" : "BR0273830",
    "display" : "Acetato de Hidroxocobalamina 1mg + Trifosfato Trissódico de Uridina 1,5mg + Fosfato Dissódico de Citidina 2,5mg cápsula"
  },
  {
    "code" : "BR0273836-1",
    "display" : "Insulina Glargina 300UI/3mL Solução para injeção; carpule"
  },
  {
    "code" : "BR0273836-2",
    "display" : "Insulina Glargina 1.000UI/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273839",
    "display" : "Cloridrato de Sibutramina 15mg Cápsula"
  },
  {
    "code" : "BR0273892-1",
    "display" : "Budesonida 0,5mg/1mL suspensão para inalação; frasco"
  },
  {
    "code" : "BR0273893",
    "display" : "Budesonida 0,25mg/1mL Suspensão para inalação"
  },
  {
    "code" : "BR0273931",
    "display" : "Orlistate 120mg cápsula"
  },
  {
    "code" : "BR0273939",
    "display" : "Parecoxibe Sódico 40mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0273940",
    "display" : "Cloridrato de Paroxetina 20mg comprimido revestido"
  },
  {
    "code" : "BR0273941",
    "display" : "Cloridrato de Paroxetina 30mg comprimido revestido"
  },
  {
    "code" : "BR0273944",
    "display" : "Perindopril Erbumina 4mg comprimido"
  },
  {
    "code" : "BR0273952",
    "display" : "Progesterona 200mg Cápsula"
  },
  {
    "code" : "BR0273953",
    "display" : "Progesterona 100mg Cápsula"
  },
  {
    "code" : "BR0274036-1",
    "display" : "Piroxicam 20mg Comprimido"
  },
  {
    "code" : "BR0274036-2",
    "display" : "Piroxicam 20mg cápsula"
  },
  {
    "code" : "BR0274041",
    "display" : "Piroxicam 5mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0274049-1",
    "display" : "Propionato de Fluticasona 50micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0274049-2",
    "display" : "Propionato de Fluticasona 50micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0274105",
    "display" : "Penfluridol 20mg comprimido"
  },
  {
    "code" : "BR0274149",
    "display" : "Ertapeném Sódico 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0274150",
    "display" : "Nifedipino 30mg Comprimido"
  },
  {
    "code" : "BR0274191-1",
    "display" : "Tartarato de Brimonidina 1,5mg/1mL (0,15%) Solução oftálmica"
  },
  {
    "code" : "BR0274191-2",
    "display" : "Tartarato de Brimonidina 1,5mg/1mL (0,15%) Solução oftálmica"
  },
  {
    "code" : "BR0274226",
    "display" : "Femprocumona 3mg Comprimido"
  },
  {
    "code" : "BR0274227",
    "display" : "Sulfato de Condroitina 400mg + Sulfato de Glicosamina 500mg Cápsula"
  },
  {
    "code" : "BR0274393",
    "display" : "Brometo de Ipratrópio 20micrograma/1dose + Salbutamol 120micrograma/1dose Suspensão aerossol; frasco"
  },
  {
    "code" : "BR0274438",
    "display" : "Valsartana 80mg comprimido revestido"
  },
  {
    "code" : "BR0274467-1",
    "display" : "Hialuronato de Sódio 20mg/2mL solução para injeção; ; ampola"
  },
  {
    "code" : "BR0274467-2",
    "display" : "Hialuronato de Sódio 25mg/2,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0274482",
    "display" : "Cloridrato de Isoxsuprina 10mg comprimido"
  },
  {
    "code" : "BR0274497",
    "display" : "Clortalidona 25mg Comprimido"
  },
  {
    "code" : "BR0274502",
    "display" : "Cefaclor Monoidratado 50mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0274506",
    "display" : "Candesartana Cilexetila 8mg comprimido"
  },
  {
    "code" : "BR0274527",
    "display" : "Nitrofural 2mg/1mL solução cutânea; frasco"
  },
  {
    "code" : "BR0274561",
    "display" : "Tropicamida 10mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0274573",
    "display" : "Cloridrato de Fenilefrina 10mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0274575",
    "display" : "Cloridrato de Fenilefrina 15mg + Maleato de Bronfeniramina 12mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0274576",
    "display" : "Mesilato de Di-Hidroergocristina 6mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0274631-1",
    "display" : "Montelucaste de Sódio 4mg comprimido mastigável"
  },
  {
    "code" : "BR0274631-2",
    "display" : "Montelucaste de Sódio 4mg granulado"
  },
  {
    "code" : "BR0274647",
    "display" : "Cloridrato de Sotalol 160mg Comprimido"
  },
  {
    "code" : "BR0274704",
    "display" : "Mesilato de Imatinibe 400mg comprimido revestido"
  },
  {
    "code" : "BR0274806",
    "display" : "Acetilcisteína 600mg/5g granulado; envelope"
  },
  {
    "code" : "BR0274807",
    "display" : "Dicloridrato de Betaistina 8mg Comprimido"
  },
  {
    "code" : "BR0274808",
    "display" : "Clortalidona 12,5mg comprimido"
  },
  {
    "code" : "BR0274811",
    "display" : "Clonixinato de Lisina 125mg comprimido revestido"
  },
  {
    "code" : "BR0274918-1",
    "display" : "Cloranfenicol 5mg/1g + Metionina (11 C) 5mg/1g + Acetato de Retinol 10.000UI/1g + Aminoácidos 25mg/1g pomada oftálmica; bisnaga"
  },
  {
    "code" : "BR0274918-2",
    "display" : "Cloranfenicol 5mg/1g + Metionina (11 C) 5mg/1g + Acetato de Retinol 10.000UI/1g + Aminoácidos 25mg/1g pomada oftálmica; bisnaga"
  },
  {
    "code" : "BR0274921",
    "display" : "Pindolol 5mg comprimido"
  },
  {
    "code" : "BR0274922",
    "display" : "Mesilato de Codergocrina 1mg Cápsula"
  },
  {
    "code" : "BR0274936",
    "display" : "Nistatina 100.000UI/1g + Neomicina 2,5mg/1g + Gramicidina 0,25mg/1g + Triancinolona 1mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0274995",
    "display" : "Ferripolimaltose 100mg comprimido mastigável"
  },
  {
    "code" : "BR0274995-1",
    "display" : "Ferripolimaltose 100mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0274996-1",
    "display" : "Ferripolimaltose 10mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0274996-2",
    "display" : "Ferripolimaltose 10mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0275117",
    "display" : "Nitrendipino 20mg Comprimido"
  },
  {
    "code" : "BR0275118",
    "display" : "Prednisolona 5mg comprimido"
  },
  {
    "code" : "BR0275119",
    "display" : "Prednisolona 20mg Comprimido"
  },
  {
    "code" : "BR0275121",
    "display" : "Piracetam 1g/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0275122",
    "display" : "Piracetam 60mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0275123",
    "display" : "Piracetam 400mg comprimido revestido"
  },
  {
    "code" : "BR0275124",
    "display" : "Piracetam 800mg comprimido revestido"
  },
  {
    "code" : "BR0275422",
    "display" : "Alteplase 20mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275423",
    "display" : "Alteplase 50mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275428",
    "display" : "Sulfato de Neomicina 5mg/1g + Acetato de Clostebol 5mg/1g Creme;"
  },
  {
    "code" : "BR0275428-1",
    "display" : "Sulfato de Neomicina 5mg/1g + Acetato de Clostebol 5mg/1g Creme;"
  },
  {
    "code" : "BR0275436",
    "display" : "Sucralfato 1g comprimido mastigável"
  },
  {
    "code" : "BR0275475-1",
    "display" : "Cloridrato de Prometazina 5mg/15mL + Dipirona Monoidratada 500mg/15mL + Cloridrato de Adifenina 10mg/15mL solução oral; frasco"
  },
  {
    "code" : "BR0275475-2",
    "display" : "Cloridrato de Prometazina 5mg/15mL + Dipirona Monoidratada 500mg/15mL + Cloridrato de Adifenina 10mg/15mL solução oral; frasco"
  },
  {
    "code" : "BR0275475-3",
    "display" : "Dipirona 500mg + Prometazina 5 mg + Adifenina 10 mg comprimido"
  },
  {
    "code" : "BR0275477",
    "display" : "Ofloxacino 3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0275478",
    "display" : "Periciazina 10mg comprimido revestido"
  },
  {
    "code" : "BR0275651",
    "display" : "Alfacoriogonadotropina 250micrograma/0,5mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0275852-1",
    "display" : "Pimecrolimo 10mg/1g Creme"
  },
  {
    "code" : "BR0275852-2",
    "display" : "Pimecrolimo 10mg/1g Creme"
  },
  {
    "code" : "BR0275884",
    "display" : "Colistimetato de Sódio 1.000.000UI pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275888",
    "display" : "Colistina 150mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0275944",
    "display" : "Rilmenidina 1mg Comprimido"
  },
  {
    "code" : "BR0275963",
    "display" : "Finasterida 5mg comprimido revestido"
  },
  {
    "code" : "BR0275964",
    "display" : "Finasterida 1mg comprimido revestido"
  },
  {
    "code" : "BR0275989",
    "display" : "Saccharomyces Boulardii-17 200mg pó para solução oral; envelope"
  },
  {
    "code" : "BR0275989-1",
    "display" : "Saccharomyces Boulardii-17 200mg cápsula"
  },
  {
    "code" : "BR0276095",
    "display" : "Levotiroxina Sódica 200micrograma Comprimido"
  },
  {
    "code" : "BR0276097",
    "display" : "Bicarbonato de Sódio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0276233-1",
    "display" : "Insulina Lispro 100unidade/1mL Solução para injeção; carpule"
  },
  {
    "code" : "BR0276233-2",
    "display" : "Insulina Lispro 1.000UI/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276234-1",
    "display" : "Insulina Asparte 1.000UI/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276234-2",
    "display" : "Insulina Asparte 300UI/3mL Solução para injeção; carpule"
  },
  {
    "code" : "BR0276235",
    "display" : "Insulina Lispro Protamina 225UI/3mL + Insulina Lispro 75UI/3mL Suspensão para injeção"
  },
  {
    "code" : "BR0276258",
    "display" : "Ramipril 5mg comprimido"
  },
  {
    "code" : "BR0276259",
    "display" : "Ramipril 10mg Comprimido"
  },
  {
    "code" : "BR0276260",
    "display" : "Ramipril 2,5mg Comprimido"
  },
  {
    "code" : "BR0276261",
    "display" : "Ramipril 5mg + Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0276262",
    "display" : "Ramipril 5mg + Hidroclorotiazida 25mg comprimido"
  },
  {
    "code" : "BR0276263",
    "display" : "Ramipril 5mg + Anlodipino 2,5mg cápsula"
  },
  {
    "code" : "BR0276264",
    "display" : "Ramipril 5mg + Besilato de Anlodipino 5mg cápsula"
  },
  {
    "code" : "BR0276270",
    "display" : "Montelucaste de Sódio 5mg comprimido mastigável"
  },
  {
    "code" : "BR0276271",
    "display" : "Montelucaste de Sódio 10mg comprimido revestido"
  },
  {
    "code" : "BR0276283",
    "display" : "Deslanosídeo 0,4mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0276332",
    "display" : "Óleo Mineral 282,25mg/1mL + Ágar-Ágar 2,72mg/1mL + Picossulfato de Sódio 0,334mg/1mL emulsão oral; frasco"
  },
  {
    "code" : "BR0276336",
    "display" : "Cloridrato de Amitriptilina 12,5mg + Clordiazepóxido 5mg cápsula"
  },
  {
    "code" : "BR0276374",
    "display" : "Cloridrato de Diltiazem 240mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276375",
    "display" : "Cloridrato de Diltiazem 300mg Cápsula de liberação prolongada; cápsula"
  },
  {
    "code" : "BR0276377",
    "display" : "Cilostazol 50mg Comprimido"
  },
  {
    "code" : "BR0276378",
    "display" : "Cilostazol 100mg Comprimido"
  },
  {
    "code" : "BR0276384",
    "display" : "Budesonida 3mg cápsula de liberação retardada"
  },
  {
    "code" : "BR0276388",
    "display" : "Bromidrato de Galantamina 8mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276388E",
    "display" : "Bromidrato de Galantamina 8mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0276393",
    "display" : "Trometamol Cetorolaco 5mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0276452",
    "display" : "Silimarina 70mg drágea"
  },
  {
    "code" : "BR0276456",
    "display" : "Silimarina 70mg + Racemetionina 100mg comprimido revestido"
  },
  {
    "code" : "BR0276656",
    "display" : "Succinato de Metoprolol 25mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0276657",
    "display" : "Succinato de Metoprolol 50mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0276658",
    "display" : "Succinato de Metoprolol 100mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0276664",
    "display" : "Iobitridol 15g/50mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276670",
    "display" : "Ioxitalamato de Meglumina 17.500mg/50mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276774",
    "display" : "Acetato de Sódio Tri-Hidratado 20mEq/10mL solução para infusão; frasco-ampola"
  },
  {
    "code" : "BR0276823",
    "display" : "Anfotericina B 100mg/20mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276839-4",
    "display" : "Água Para Injetáveis 1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0276856",
    "display" : "Acetato de Noretisterona 10mg comprimido"
  },
  {
    "code" : "BR0276862",
    "display" : "Tioconazol 65mg/g pomada vaginal"
  },
  {
    "code" : "BR0276866",
    "display" : "Tioconazol 10mg/1mL Emulsão; frasco"
  },
  {
    "code" : "BR0276867",
    "display" : "Tioconazol 20mg/1g + Tinidazol 30mg/1g Creme vaginal; bisnaga"
  },
  {
    "code" : "BR0276867-1",
    "display" : "Secnidazol 1g comprimido revestido + Tioconazol 20mg/g + Tinidazol 30mg/g creme vaginal;"
  },
  {
    "code" : "BR0276871-1",
    "display" : "Fluoruracila 50mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0276871-2",
    "display" : "Fluoruracila 50mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0276871-3",
    "display" : "Fluoruracila 50mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0276871-4",
    "display" : "Fluoruracila 50mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0276948",
    "display" : "Cloridrato de Trazodona 50mg Comprimido"
  },
  {
    "code" : "BR0276959",
    "display" : "Alfatirotropina 1,1mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276961",
    "display" : "Cloridrato de Tizanidina 2mg Comprimido"
  },
  {
    "code" : "BR0276965",
    "display" : "Telmisartana 40mg Comprimido"
  },
  {
    "code" : "BR0276966",
    "display" : "Telmisartana 80mg Comprimido"
  },
  {
    "code" : "BR0277184",
    "display" : "Cloridrato de Valganciclovir 450mg comprimido revestido"
  },
  {
    "code" : "BR0277319",
    "display" : "Peróxido de Hidrogênio 3% Líquido; frasco"
  },
  {
    "code" : "BR0277319-1",
    "display" : "Peróxido de Hidrogênio 3% Líquido; frasco"
  },
  {
    "code" : "BR0277434E",
    "display" : "Betainterferona 1a Recombinante 44micrograma/0,5mL solução para injeção"
  },
  {
    "code" : "BR0277435E",
    "display" : "Betainterferona 1a Recombinante 22micrograma/0,5mL Solução para injeção"
  },
  {
    "code" : "BR0277513",
    "display" : "Cloridrato de Fluoxetina 20mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0277519",
    "display" : "Ácido Ursodesoxicólico 50mg comprimido"
  },
  {
    "code" : "BR0277525-2",
    "display" : "Didanosina 250mg Cápsula de liberação retardada"
  },
  {
    "code" : "BR0277526-1",
    "display" : "Didanosina 400mg Comprimido"
  },
  {
    "code" : "BR0277526-2",
    "display" : "Didanosina 400mg cápsula de liberação retardada"
  },
  {
    "code" : "BR0277649",
    "display" : "Cloridrato de Anagrelida 0,5mg Cápsula"
  },
  {
    "code" : "BR0277934-1",
    "display" : "Atropina 0,5mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0277973",
    "display" : "Maleato de Ergometrina 0,2mg Comprimido"
  },
  {
    "code" : "BR0278257",
    "display" : "Tinidazol 500mg comprimido revestido"
  },
  {
    "code" : "BR0278259",
    "display" : "Tiocolchicosídeo 4mg Comprimido"
  },
  {
    "code" : "BR0278260",
    "display" : "Tiopental Sódico 500mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278261",
    "display" : "Tiopental 1g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278265",
    "display" : "Trolamina 140mg/1mL + Hidroxiquinolina 0,4mg/1mL Solução otológica; frasco"
  },
  {
    "code" : "BR0278268",
    "display" : "Trifluoperazina 5mg comprimido revestido"
  },
  {
    "code" : "BR0278268-1",
    "display" : "Trifluoperazina 2mg comprimido revestido"
  },
  {
    "code" : "BR0278281",
    "display" : "Adenosina 6mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0278283",
    "display" : "Acetazolamida 250mg Comprimido"
  },
  {
    "code" : "BR0278283E",
    "display" : "Acetazolamida 250mg Comprimido"
  },
  {
    "code" : "BR0278316",
    "display" : "Hemitartarato de Zolpidem 10mg comprimido sublingual"
  },
  {
    "code" : "BR0278338",
    "display" : "Ácido Tranexâmico 250mg Comprimido"
  },
  {
    "code" : "BR0278348",
    "display" : "Anastrozol 1mg comprimido revestido"
  },
  {
    "code" : "BR0278356",
    "display" : "Cloridrato de Azelastina 1mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0278357",
    "display" : "Azelastina 1mg/1mL solução aerossol; frasco"
  },
  {
    "code" : "BR0278378",
    "display" : "Tretinoína 0,25mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0278393",
    "display" : "Tretinoína 10mg Cápsula"
  },
  {
    "code" : "BR0278429-1",
    "display" : "Hemitartarato de Epinefrina 100ng/20mL + Cloridrato de Bupivacaína Monoidratado 52.8mg/20mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278482",
    "display" : "Primidona 250mg comprimido"
  },
  {
    "code" : "BR0278482E",
    "display" : "Primidona 250mg comprimido"
  },
  {
    "code" : "BR0278489",
    "display" : "Ácido Fólico 0,2mg/1mL Solução oral"
  },
  {
    "code" : "BR0278490",
    "display" : "Ácido Fólico 0,4mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0278587-1",
    "display" : "Polissulfato de Mucopolissacarídeo 5mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0278587-2",
    "display" : "Polissulfato de Mucopolissacarídeo 5mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0278588",
    "display" : "Polissulfato de Mucopolissacarídeo 5mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0278588-1",
    "display" : "Polissulfato de Mucopolissacarídeo 5mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0278589-1",
    "display" : "Polissulfato de Mucopolissacarídeo 3mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0278589-2",
    "display" : "Polissulfato de Mucopolissacarídeo 3mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0278646",
    "display" : "Ácido Aminocaproico 1.000mg/20mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278647",
    "display" : "Cloridrato de Metformina 250mg + Glibenclamida 1,25mg comprimido revestido"
  },
  {
    "code" : "BR0278648",
    "display" : "Glibenclamida 2,5mg + Metformina 500mg comprimido revestido"
  },
  {
    "code" : "BR0278649",
    "display" : "Cloridrato de Metformina 500mg + Glibenclamida 5mg comprimido revestido"
  },
  {
    "code" : "BR0278655",
    "display" : "Trolamina 20mg/1g + Sulfacetamida Sódica 74mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0279118",
    "display" : "Ticarcilina 3g + Clavulanato de Potássio 100 mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0279269",
    "display" : "Varfarina Sódica 5mg Comprimido"
  },
  {
    "code" : "BR0279270",
    "display" : "Varfarina Sódica 2,5mg comprimido"
  },
  {
    "code" : "BR0279271",
    "display" : "Varfarina Sódica 1mg Comprimido"
  },
  {
    "code" : "BR0279297-1",
    "display" : "Nistatina 100.000UI/1g + Óxido de Zinco 200mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0279297-2",
    "display" : "Nistatina 100.000UI/1g + Óxido de Zinco 200mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0279298",
    "display" : "Bromidrato de Fenoterol 0,1mg/1dose + Brometo de Ipratrópio 0,04mg/1dose solução aerossol; frasco"
  },
  {
    "code" : "BR0279338-1",
    "display" : "Carbômer 2mg/1g Gel oftálmico"
  },
  {
    "code" : "BR0279338-2",
    "display" : "Carbômer 2mg/1g Gel oftálmico"
  },
  {
    "code" : "BR0279432",
    "display" : "Etabonato de Loteprednol 5mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0279493-3",
    "display" : "Óxido de Zinco 150mg/1g + Palmitato de Retinol 5.000UI/1g + Colecalciferol 900UI/1g pomada; bisnaga"
  },
  {
    "code" : "BR0279493-4",
    "display" : "Óxido de Zinco 150mg/1g + Palmitato de Retinol 5.000UI/1g + Colecalciferol 900UI/1g pomada; bisnaga"
  },
  {
    "code" : "BR0279493-5",
    "display" : "Óxido de Zinco 150mg/1g + Palmitato de Retinol 5.000UI/1g + Colecalciferol 900UI/1g pomada; bisnaga"
  },
  {
    "code" : "BR0280115",
    "display" : "Bosentana Monoidratada 125mg comprimido revestido"
  },
  {
    "code" : "BR0280115E",
    "display" : "Bosentana Monoidratada 125mg comprimido revestido"
  },
  {
    "code" : "BR0280116",
    "display" : "Bosentana Monoidratada 62,5mg comprimido revestido"
  },
  {
    "code" : "BR0280116E",
    "display" : "Bosentana Monoidratada 62,5mg comprimido revestido"
  },
  {
    "code" : "BR0280201",
    "display" : "Bortezomibe 3,5mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0280205E",
    "display" : "Adefovir Dipivoxila 10mg Comprimido"
  },
  {
    "code" : "BR0280505",
    "display" : "Adefovir Dipivoxila 10mg Comprimido"
  },
  {
    "code" : "BR0280627",
    "display" : "Cloridrato de Levobupivacaína 50mg/20mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0280873",
    "display" : "Hidroclorotiazida 12,5mg + Candesartana Cilexetila 16mg Comprimido"
  },
  {
    "code" : "BR0280876",
    "display" : "Espironolactona 50mg + Hidroclorotiazida 50mg Comprimido"
  },
  {
    "code" : "BR0280877",
    "display" : "Espironolactona 100mg + Furosemida 20mg cápsula"
  },
  {
    "code" : "BR0280881",
    "display" : "Propionato de Fluticasona 250micrograma/1dose + Xinafoato de Salmeterol 25micrograma/1dose suspensão aerossol; frasco"
  },
  {
    "code" : "BR0280883",
    "display" : "Glicosamina 1,5g + Condroitina 1,2 g pó para solução oral"
  },
  {
    "code" : "BR0280947",
    "display" : "Ofloxacino 200mg comprimido"
  },
  {
    "code" : "BR0281135-1",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL + Clavulanato de Potássio 12,5mg/1mL Pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0281135-2",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL + Clavulanato de Potássio 12,5mg/1mL Pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0281135-3",
    "display" : "Amoxicilina Tri-Hidratada 40mg/1mL + Clavulanato de Potássio 5,7mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0281453",
    "display" : "Rhamnus Purshiana 10mg/1mL tintura; frasco"
  },
  {
    "code" : "BR0281470",
    "display" : "Candesartana Cilexetila 8mg + Hidroclorotiazida 12,5mg Comprimido"
  },
  {
    "code" : "BR0282040",
    "display" : "Gefitinibe 250mg comprimido revestido"
  },
  {
    "code" : "BR0282149",
    "display" : "Fosfato Sódico de Betametasona 4mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0282151",
    "display" : "Exemestano 25mg comprimido revestido"
  },
  {
    "code" : "BR0282220",
    "display" : "Cloreto de Carbacol 0,2mg/2mL Solução oftálmica; frasco-ampola"
  },
  {
    "code" : "BR0282222-1",
    "display" : "Carbocisteína 20mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0282222-2",
    "display" : "Carbocisteína 20mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0282223",
    "display" : "Carbocisteína 50mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0282224-1",
    "display" : "Carbocisteína 50mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0282224-2",
    "display" : "Carbocisteína 50mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0282237",
    "display" : "Carnitina 200mg/1mL Xarope"
  },
  {
    "code" : "BR0282298",
    "display" : "Sulpirida 20mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0282299",
    "display" : "Sulpirida 50mg Comprimido"
  },
  {
    "code" : "BR0282580",
    "display" : "monoetanolamina 100mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0282714",
    "display" : "Hidróxido de Magnésio 80mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0282757",
    "display" : "Isocaproato de Testosterona 60mg/1mL + Fempropionato de Testosterona 60mg/1mL + Propionato de Testosterona 30mg/1mL + Decanoato de Testosterona 100mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0282881",
    "display" : "Rosuvastatina Cálcica 10mg comprimido revestido"
  },
  {
    "code" : "BR0282882",
    "display" : "Rosuvastatina Cálcica 20mg comprimido revestido"
  },
  {
    "code" : "BR0283156",
    "display" : "Cafeína 50mg + Citrato de Orfenadrina 35mg + Dipirona 300mg Comprimido"
  },
  {
    "code" : "BR0284101",
    "display" : "Aripiprazol 15mg comprimido"
  },
  {
    "code" : "BR0284102",
    "display" : "Cloridrato de Ciprofloxacino 3,5mg/1mL + Dexametasona 1mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0284105",
    "display" : "Risperidona 3mg comprimido revestido"
  },
  {
    "code" : "BR0284105E",
    "display" : "Risperidona 3mg comprimido revestido"
  },
  {
    "code" : "BR0284106",
    "display" : "Risperidona 1mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0284106E",
    "display" : "Risperidona 1mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0284109",
    "display" : "Benzbromarona 100mg Comprimido"
  },
  {
    "code" : "BR0284114",
    "display" : "Cetoconazol 20mg/1g + Dipropionato de Betametasona 0,5mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0284426",
    "display" : "Telmisartana 40mg + Hidroclorotiazida 12,5mg Comprimido"
  },
  {
    "code" : "BR0284427",
    "display" : "Telmisartana 80mg + Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0284428",
    "display" : "Colchicina 1mg Comprimido"
  },
  {
    "code" : "BR0284429",
    "display" : "Dipropionato de Beclometasona 50micrograma/1dose + Sulfato de Salbutamol 100micrograma/1dose Suspensão aerossol"
  },
  {
    "code" : "BR0284435-1",
    "display" : "Cloridrato de Betaxolol 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0284435-2",
    "display" : "Cloridrato de Betaxolol 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0284435-3",
    "display" : "Cloridrato de Betaxolol 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0284458-1",
    "display" : "Propionato de Clobetasol 0,5mg/1g Creme"
  },
  {
    "code" : "BR0284458E",
    "display" : "Propionato de Clobetasol 0,5mg/1g Creme"
  },
  {
    "code" : "BR0284459",
    "display" : "Propionato de Clobetasol 0,5mg/1g Pomada"
  },
  {
    "code" : "BR0284460",
    "display" : "Propionato de Clobetasol 0,5mg/1g solução cutânea; frasco"
  },
  {
    "code" : "BR0284460E",
    "display" : "Propionato de Clobetasol 0,5mg/1g solução cutânea; frasco"
  },
  {
    "code" : "BR0284465",
    "display" : "Alprazolam 2mg Comprimido"
  },
  {
    "code" : "BR0284465-1",
    "display" : "Alprazolam 2mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0284841",
    "display" : "Alfafolitropina 450UI/0,75mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0285007",
    "display" : "Mononitrato de Isossorbida 40mg + Ácido Acetilsalicílico 100mg Cápsula"
  },
  {
    "code" : "BR0285015",
    "display" : "Cloridrato de Tramadol 37,5mg + Paracetamol 325mg comprimido revestido"
  },
  {
    "code" : "BR0285055",
    "display" : "Ácido Acetilsalicílico 81mg comprimido revestido"
  },
  {
    "code" : "BR0285063",
    "display" : "Felodipino 5mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0285064",
    "display" : "Felodipino 2,5mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0285081",
    "display" : "Cloridrato de Tansulosina 0,4mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0285686",
    "display" : "Ezetimiba 10mg Comprimido"
  },
  {
    "code" : "BR0285687",
    "display" : "Sinvastatina 10mg + Ezetimiba 10mg comprimido"
  },
  {
    "code" : "BR0285688",
    "display" : "Ezetimiba 10mg + Sinvastatina 20mg Comprimido"
  },
  {
    "code" : "BR0285689",
    "display" : "Ezetimiba 10mg + Sinvastatina 40mg Comprimido"
  },
  {
    "code" : "BR0285818E",
    "display" : "Sirolimo 2mg comprimido"
  },
  {
    "code" : "BR0285953",
    "display" : "Teofilina 300mg cápsula"
  },
  {
    "code" : "BR0285965",
    "display" : "Levetiracetam 250mg comprimido revestido"
  },
  {
    "code" : "BR0285966",
    "display" : "Levetiracetam 500mg comprimido revestido"
  },
  {
    "code" : "BR0286246",
    "display" : "Pimozida 1mg Comprimido"
  },
  {
    "code" : "BR0286247",
    "display" : "Pimozida 4mg Comprimido"
  },
  {
    "code" : "BR0286278",
    "display" : "Aripiprazol 30mg Comprimido"
  },
  {
    "code" : "BR0286631",
    "display" : "Cloxazolam 4mg Comprimido"
  },
  {
    "code" : "BR0286632",
    "display" : "Sulpirida 200mg comprimido"
  },
  {
    "code" : "BR0286765E",
    "display" : "Bromocriptina 5mg cápsula de liberação retardada"
  },
  {
    "code" : "BR0286864",
    "display" : "Acetilcisteína 100mg/5g granulado; envelope"
  },
  {
    "code" : "BR0287252",
    "display" : "Nicotina 2mg pastilha"
  },
  {
    "code" : "BR0287253",
    "display" : "Nicotina 4mg pastilha"
  },
  {
    "code" : "BR0287469",
    "display" : "Nitrato de Oxiconazol 10mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0287469-1",
    "display" : "Nitrato de Oxiconazol 10mg/1mL solução cutânea; frasco"
  },
  {
    "code" : "BR0287471",
    "display" : "Losartana Potássica 100mg + Hidroclorotiazida 25mg comprimido revestido"
  },
  {
    "code" : "BR0287473",
    "display" : "Losartana Potássica 100mg comprimido revestido"
  },
  {
    "code" : "BR0287481",
    "display" : "Nicotina 2mg Goma de mascar"
  },
  {
    "code" : "BR0287531",
    "display" : "Desonida 5mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0287533",
    "display" : "Desonida 5mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0287559",
    "display" : "Estavudina 1mg/1mL Pó para solução oral; frasco"
  },
  {
    "code" : "BR0287687",
    "display" : "Sulfato de Efedrina 50mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0287824",
    "display" : "Tiamazol 10mg comprimido"
  },
  {
    "code" : "BR0288001",
    "display" : "Ciclopirox 80mg/1g esmalte; frasco"
  },
  {
    "code" : "BR0288002",
    "display" : "Ciclopirox Olamina 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0288275",
    "display" : "Nitrato de Miconazol 20mg/1g + Tinidazol 30mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0288275-1",
    "display" : "Nitrato de Miconazol 20mg/1g + Tinidazol 30mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0288300-1",
    "display" : "Cloridrato de Moxifloxacino 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0288300-2",
    "display" : "Cloridrato de Moxifloxacino 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0288300-3",
    "display" : "Cloridrato de Moxifloxacino 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0288640",
    "display" : "Micofenolato de Sódio 180mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0288640E",
    "display" : "Micofenolato de Sódio 180mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0288641",
    "display" : "Micofenolato de Sódio 360mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0288641E",
    "display" : "Micofenolato de Sódio 360mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0288785",
    "display" : "Cloridrato de Levobupivacaína 150mg/20mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0290058",
    "display" : "Adalimumabe 40mg/0,4mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0290168",
    "display" : "Cloreto de Suxametônio 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0290673",
    "display" : "Ebastina 10mg comprimido revestido"
  },
  {
    "code" : "BR0290674",
    "display" : "Ebastina 1mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0290675",
    "display" : "Cloridrato de Pseudoefedrina 120mg + Ebastina 10mg Cápsula"
  },
  {
    "code" : "BR0290891",
    "display" : "Oxamniquina 50mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0290992",
    "display" : "Hialuronidase 2.000UTR pó para solução para injeção; ; frasco-ampola"
  },
  {
    "code" : "BR0291019-1",
    "display" : "Cloridrato de Lidocaína 50mg/1mL + Sulfato de Neomicina 5mg/1mL + Hialuronidase 100UTR/1mL solução otológica; frasco"
  },
  {
    "code" : "BR0291174",
    "display" : "Sulfato de Gentamicina 5mg/1g Pomada oftálmica"
  },
  {
    "code" : "BR0291231",
    "display" : "Sulfato de Estreptomicina 1g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0291549E",
    "display" : "Atorvastatina 80mg comprimido"
  },
  {
    "code" : "BR0291559",
    "display" : "Piracetam 400mg + Mesilato de Di-Hidroergocristina 1mg Comprimido"
  },
  {
    "code" : "BR0291690",
    "display" : "Repaglinida 0,5mg comprimido"
  },
  {
    "code" : "BR0291691",
    "display" : "Repaglinida 1mg comprimido"
  },
  {
    "code" : "BR0291692",
    "display" : "Repaglinida 2mg Comprimido"
  },
  {
    "code" : "BR0291700",
    "display" : "Gabapentina 600mg comprimido revestido"
  },
  {
    "code" : "BR0291770",
    "display" : "Oxalato de Escitalopram 10mg comprimido orodispersível"
  },
  {
    "code" : "BR0291771",
    "display" : "Oxalato de Escitalopram 20mg comprimido revestido"
  },
  {
    "code" : "BR0291772",
    "display" : "Escitalopram 15mg comprimido revestido"
  },
  {
    "code" : "BR0291802",
    "display" : "Diacereína 50mg Cápsula"
  },
  {
    "code" : "BR0291951",
    "display" : "Nitrato de Prata 10mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0292029",
    "display" : "Tibolona 1,25mg comprimido"
  },
  {
    "code" : "BR0292030",
    "display" : "Tibolona 2,5mg Comprimido"
  },
  {
    "code" : "BR0292043",
    "display" : "Saccharomyces Cerevisiae 50milhões/1mL suspensão oral; flaconete"
  },
  {
    "code" : "BR0292044",
    "display" : "Saccharomyces Cerevisiae 100milhões/1mL suspensão oral; flaconete"
  },
  {
    "code" : "BR0292194",
    "display" : "Decanoato de Haloperidol 50mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0292195-1",
    "display" : "Haloperidol 2mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0292195-2",
    "display" : "Haloperidol 2mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0292195-3",
    "display" : "Haloperidol 2mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0292195-4",
    "display" : "Haloperidol 2mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0292196",
    "display" : "Haloperidol 5mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0292205",
    "display" : "Isoniazida 100mg Comprimido"
  },
  {
    "code" : "BR0292208-1",
    "display" : "Rifampicina 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0292208-2",
    "display" : "Rifampicina 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0292208-3",
    "display" : "Rifampicina 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0292236E",
    "display" : "Mesalazina 400mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0292237",
    "display" : "Mesalazina 400mg comprimido revestido"
  },
  {
    "code" : "BR0292237E",
    "display" : "Mesalazina 400mg comprimido revestido"
  },
  {
    "code" : "BR0292238",
    "display" : "Mesalazina 800mg comprimido revestido"
  },
  {
    "code" : "BR0292238E",
    "display" : "Mesalazina 800mg comprimido revestido"
  },
  {
    "code" : "BR0292239",
    "display" : "Mesalazina 250mg supositório"
  },
  {
    "code" : "BR0292239E",
    "display" : "Mesalazina 250mg supositório"
  },
  {
    "code" : "BR0292240",
    "display" : "Mesalazina 1g supositório"
  },
  {
    "code" : "BR0292240E",
    "display" : "Mesalazina 1g supositório"
  },
  {
    "code" : "BR0292242",
    "display" : "Mesalazina 3g pó para solução oral/retal; frasco"
  },
  {
    "code" : "BR0292242E",
    "display" : "Mesalazina 3g pó para solução oral/retal; frasco"
  },
  {
    "code" : "BR0292249-1",
    "display" : "Metotrexato 50mg/2mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292249-2",
    "display" : "Metotrexato 500mg/20mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292256E",
    "display" : "Molgramostim 300micrograma pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292262E",
    "display" : "Sulfato de Morfina Pentaidratado 100mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0292263",
    "display" : "Morfina 30mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0292264",
    "display" : "Morfina 60mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0292278",
    "display" : "Pergolida 0,25mg Comprimido"
  },
  {
    "code" : "BR0292279",
    "display" : "Pergolida 1mg comprimido"
  },
  {
    "code" : "BR0292331-1",
    "display" : "Sulfato de Salbutamol 0,4mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0292331-2",
    "display" : "Sulfato de Salbutamol 0,4mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0292344",
    "display" : "Sulfato Ferroso 40mg comprimido revestido"
  },
  {
    "code" : "BR0292345",
    "display" : "Sulfato Ferroso Heptaidratado 25mg/1mL (Ferro 5 mg/mL) solução oral; frasco"
  },
  {
    "code" : "BR0292345-1",
    "display" : "Sulfato Ferroso Heptaidratado 25mg/1mL (Ferro 5 mg/mL) solução oral; frasco"
  },
  {
    "code" : "BR0292372",
    "display" : "Toxina Botulínica A 100 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292372E",
    "display" : "Toxina Botulínica A 100 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292373",
    "display" : "Toxina Botulínica A 500 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292373E",
    "display" : "Toxina Botulínica A 500 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292380",
    "display" : "Cloridrato de Tramadol 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0292382",
    "display" : "Cloridrato de Tramadol 100mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292382-1",
    "display" : "Cloridrato de Tramadol 50mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0292399-1",
    "display" : "Fitomenadiona 10mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292399-2",
    "display" : "Fitomenadiona 10mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292400E",
    "display" : "Alfacalcidol 0,25 microgramas cápsula"
  },
  {
    "code" : "BR0292401",
    "display" : "Alfacalcidol 1micrograma cápsula"
  },
  {
    "code" : "BR0292401E",
    "display" : "Alfacalcidol 1micrograma cápsula"
  },
  {
    "code" : "BR0292402",
    "display" : "Aminofilina 240mg/10mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0292409",
    "display" : "Basiliximabe 20mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292416",
    "display" : "Calcitriol 1micrograma cápsula"
  },
  {
    "code" : "BR0292416-1",
    "display" : "Calcitriol 1micrograma/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292416E",
    "display" : "Calcitriol 1micrograma/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292418-1",
    "display" : "Ciprofloxacino 200mg/100mL solução para injeção; bolsa"
  },
  {
    "code" : "BR0292418-2",
    "display" : "Ciprofloxacino 400mg/200mL solução para injeção; frasco"
  },
  {
    "code" : "BR0292419-1",
    "display" : "Fosfato de Clindamicina 300mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0292419-2",
    "display" : "Fosfato de Clindamicina 600mg/4mL solução para injeção; ampola"
  },
  {
    "code" : "BR0292427",
    "display" : "Fosfato Dissódico de Dexametasona 4mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0292468",
    "display" : "Sumatriptana 50mg comprimido revestido"
  },
  {
    "code" : "BR0292732",
    "display" : "Cloreto de Potássio 100mg + Furosemida 40mg comprimido"
  },
  {
    "code" : "BR0292764",
    "display" : "Cloridrato de Propranolol 40mg + Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0292765",
    "display" : "Hidroclorotiazida 25mg + Cloridrato de Propranolol 40mg Comprimido"
  },
  {
    "code" : "BR0292767",
    "display" : "Cloridrato de Propranolol 80mg + Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0292770",
    "display" : "Glycine Max (L.) Merr. 200mg + Persea Americana Mill. 100mg Cápsula"
  },
  {
    "code" : "BR0292778",
    "display" : "Tartarato de Metoprolol 100mg + Hidroclorotiazida 12mg comprimido"
  },
  {
    "code" : "BR0292788",
    "display" : "Cloridrato de Benzidamina 500mg pó para solução vaginal; envelope"
  },
  {
    "code" : "BR0292790",
    "display" : "Hidroclorotiazida 12,5mg + Valsartana 80mg comprimido revestido"
  },
  {
    "code" : "BR0292791",
    "display" : "Valsartana 160mg + Hidroclorotiazida 12,5mg comprimido revestido"
  },
  {
    "code" : "BR0293657",
    "display" : "Cloridrato de Dobutamina 250mg/250mL Solução para injeção"
  },
  {
    "code" : "BR0293803",
    "display" : "Amoxicilina Tri-Hidratada 875mg + Sulbactam Pivoxila 125mg comprimido revestido"
  },
  {
    "code" : "BR0293839",
    "display" : "Glicose 20g + Cloreto de Potássio 1,5g + Cloreto de Sódio 3,5g + Citrato de Sódio 2,9g Pó para solução oral"
  },
  {
    "code" : "BR0293879",
    "display" : "Tolterodina 1mg comprimido"
  },
  {
    "code" : "BR0293880",
    "display" : "Tolterodina 2mg comprimido revestido"
  },
  {
    "code" : "BR0293892",
    "display" : "Acebrofilina 10mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0293925",
    "display" : "Succinato de Doxilamina 0,75mg/1mL + Cloridrato de Clobutinol 4mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0293981",
    "display" : "Macrogol 3350 13.125g/14g + Cloreto de Potássio 0,047g/14g + Bicarbonato de Sódio 0,178g/14g + Cloreto de Sódio 0,351g/14g pó para solução oral; envelope"
  },
  {
    "code" : "BR0294094",
    "display" : "Latanoprosta 50micrograma/1mL + Timolol 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0294096",
    "display" : "Ceftriaxona Sódica 250mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0294097",
    "display" : "Ceftriaxona Sódica 250mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0294202",
    "display" : "Dexrazoxano 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0294417",
    "display" : "Latanoprosta 50micrograma/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0294417E",
    "display" : "Latanoprosta 50micrograma/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0294521",
    "display" : "Lacidipino 4mg comprimido revestido"
  },
  {
    "code" : "BR0294536",
    "display" : "Mirtazapina 30mg comprimido orodispersível"
  },
  {
    "code" : "BR0294537",
    "display" : "Mirtazapina 45mg comprimido revestido"
  },
  {
    "code" : "BR0294550",
    "display" : "Ubidecarenona 20mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0294648",
    "display" : "Ibuprofeno 200mg Comprimido"
  },
  {
    "code" : "BR0294729",
    "display" : "Voriconazol 50mg comprimido revestido"
  },
  {
    "code" : "BR0294774",
    "display" : "Alfaepoetina 40.000UI/1mL Solução para injeção"
  },
  {
    "code" : "BR0294881E",
    "display" : "Iloprosta 10micrograma/1mL solução para inalação; ampola"
  },
  {
    "code" : "BR0294912-1",
    "display" : "Cloridrato de Irinotecano Tri-Hidratado 40mg/2mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0294912-2",
    "display" : "Cloridrato de Irinotecano Tri-Hidratado 100mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0294927",
    "display" : "Promestrieno 10mg/1g Creme vaginal"
  },
  {
    "code" : "BR0295040",
    "display" : "Lamotrigina 25mg Comprimido"
  },
  {
    "code" : "BR0295040E",
    "display" : "Lamotrigina 25mg Comprimido"
  },
  {
    "code" : "BR0295266",
    "display" : "Glicerofosfato de Sódio 4,32mg/20mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0295302",
    "display" : "Trastuzumabe 440mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0295303",
    "display" : "Trastuzumabe 150mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0295391",
    "display" : "Cloridrato de Meclizina 25mg comprimido"
  },
  {
    "code" : "BR0295393",
    "display" : "Cloridrato de Meclizina 50mg comprimido"
  },
  {
    "code" : "BR0295605",
    "display" : "Algestona Acetofenida 150mg/1mL + Enantato de Estradiol 10mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0295624",
    "display" : "Ácido Fusídico 20mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0295853",
    "display" : "Levonorgestrel 1,5mg comprimido"
  },
  {
    "code" : "BR0295856",
    "display" : "Levonorgestrel 52mg (20 microgramas/24 horas) dispositivo intrauterino"
  },
  {
    "code" : "BR0296076",
    "display" : "Candesartana Cilexetila 16mg Comprimido"
  },
  {
    "code" : "BR0296302",
    "display" : "Cloridrato de Paroxetina 25mg Comprimido de liberação modificada"
  },
  {
    "code" : "BR0296389",
    "display" : "Cetoprofeno 1mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0296594",
    "display" : "Norgestimato 90micrograma + Etinilestradiol 1mg Comprimido"
  },
  {
    "code" : "BR0296649",
    "display" : "Levotiroxina Sódica 88micrograma comprimido"
  },
  {
    "code" : "BR0296657",
    "display" : "Maleato de Trimebutina 200mg cápsula"
  },
  {
    "code" : "BR0296676",
    "display" : "Acetato de Ciproterona 1mg + Valerato de Estradiol 2mg comprimido revestido"
  },
  {
    "code" : "BR0296715E",
    "display" : "Risedronato Sódico 5mg Cápsula"
  },
  {
    "code" : "BR0296717E",
    "display" : "Risedronato Sódico 35mg comprimido revestido"
  },
  {
    "code" : "BR0296741",
    "display" : "Olmesartana Medoxomila 20mg comprimido revestido"
  },
  {
    "code" : "BR0296742",
    "display" : "Olmesartana Medoxomila 40mg comprimido revestido"
  },
  {
    "code" : "BR0296743",
    "display" : "Olmesartana 40mg + Hidroclorotiazida 12.5 mg comprimido revestido"
  },
  {
    "code" : "BR0296744",
    "display" : "Olmesartana 40mg + Hidroclorotiazida 25mg comprimido revestido"
  },
  {
    "code" : "BR0296745",
    "display" : "Olmesartana 20mg + Hidroclorotiazida 12,5 mg comprimido revestido"
  },
  {
    "code" : "BR0296749",
    "display" : "Promestrieno 10mg cápsula vaginal"
  },
  {
    "code" : "BR0296792-1",
    "display" : "Xinafoato de Salmeterol 50micrograma/1dose + Propionato de Fluticasona 250micrograma/1dose Pó para inalação"
  },
  {
    "code" : "BR0296792-2",
    "display" : "Xinafoato de Salmeterol 50micrograma/1dose + Propionato de Fluticasona 250micrograma/1dose Suspensão aerossol; ; frasco"
  },
  {
    "code" : "BR0296792-3",
    "display" : "Xinafoato de Salmeterol 50micrograma/1dose + Propionato de Fluticasona 250micrograma/1dose Pó para inalação"
  },
  {
    "code" : "BR0296793-1",
    "display" : "Propionato de Fluticasona 500 microgramas/dose + Salmeterol 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0296793-2",
    "display" : "Fluticasona 500micrograma/1dose + Salmeterol 50micrograma/1dose suspensão aerossol; frasco"
  },
  {
    "code" : "BR0296876",
    "display" : "Carbonato de Cálcio 1,25g (Calcio 500 mg) + Colecalciferol 400UI comprimido revestido"
  },
  {
    "code" : "BR0297787",
    "display" : "Dicloridrato de Cetirizina 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0297787-1",
    "display" : "Dicloridrato de Cetirizina 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0297787-2",
    "display" : "Dicloridrato de Cetirizina 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0298444",
    "display" : "Cromoglicato Dissódico 40mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0298445",
    "display" : "Cromoglicato Dissódico 20mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0298445-1",
    "display" : "Cromoglicato Dissódico 20mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0298446",
    "display" : "Cromoglicato Dissódico 40mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0298454-1",
    "display" : "Maleato de Dexclorfeniramina 0,4mg/1mL Xarope"
  },
  {
    "code" : "BR0298454-2",
    "display" : "Maleato de Dexclorfeniramina 0,4mg/1mL Xarope"
  },
  {
    "code" : "BR0298530",
    "display" : "Estradiol Hemi-Hidratado 3,2mg + Acetato de Noretisterona 11,2mg adesivo transdérmico"
  },
  {
    "code" : "BR0298574-1",
    "display" : "Cloridrato de Bambuterol 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0298574-2",
    "display" : "Cloridrato de Bambuterol 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0298574-3",
    "display" : "Cloridrato de Bambuterol 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0298574-4",
    "display" : "Cloridrato de Bambuterol 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0298574-5",
    "display" : "Cloridrato de Bambuterol 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0298582",
    "display" : "Brometo de Pinavério 100mg comprimido revestido"
  },
  {
    "code" : "BR0298734",
    "display" : "Ciclosporina 0,5mg/1mL emulsão oftálmica; flaconete"
  },
  {
    "code" : "BR0298768",
    "display" : "Cloridrato de Paroxetina 10mg comprimido revestido"
  },
  {
    "code" : "BR0298769",
    "display" : "Cloridrato de Paroxetina 40mg comprimido revestido"
  },
  {
    "code" : "BR0299128",
    "display" : "Clofazimina 50mg Cápsula"
  },
  {
    "code" : "BR0299129",
    "display" : "Clofazimina 100mg Cápsula"
  },
  {
    "code" : "BR0299236-1",
    "display" : "Dexpantenol 50mg/g pomada"
  },
  {
    "code" : "BR0299236-2",
    "display" : "Dexpantenol 50mg/g pomada"
  },
  {
    "code" : "BR0299317",
    "display" : "Citrato de Fentanila 0,157mg/2mL + Droperidol 5mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0299656",
    "display" : "Cloridrato de Lidocaína 20mg/1mL + Cloreto de Benzalcônio 1,3mg/1mL solução spray"
  },
  {
    "code" : "BR0299675-2",
    "display" : "Manitol 100g/500mL (20%) solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0299690-1",
    "display" : "Acetato de Metilprednisolona 40mg/1 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0299690-2",
    "display" : "Acetato de Metilprednisolona 80mg/2mL Suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0299690-3",
    "display" : "Acetato de Metilprednisolona 200mg/5mL Suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0299692",
    "display" : "Cloridrato de Amorolfina 50mg/1mL esmalte; frasco"
  },
  {
    "code" : "BR0299693",
    "display" : "Cloridrato de Amorolfina 2,5mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0299766",
    "display" : "Cloridrato de Etambutol 400mg comprimido revestido"
  },
  {
    "code" : "BR0300252",
    "display" : "Cloreto de Sódio 0,9% + Glicose 20% Solução para injeção 1000 mL; frasco"
  },
  {
    "code" : "BR0300252-1",
    "display" : "Cloreto de Sódio 0,9% + Glicose 20% Solução para injeção 500 mL; frasco"
  },
  {
    "code" : "BR0300252-2",
    "display" : "Cloreto de Sódio 0,9% + Glicose 20% Solução para injeção 250 mL; frasco"
  },
  {
    "code" : "BR0300257",
    "display" : "Levodropropizina 6mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0300259",
    "display" : "Levodropropizina 30mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0300498",
    "display" : "Sucralfato 200mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0300722",
    "display" : "Fenobarbital Sódico 200mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0300723",
    "display" : "Fenobarbital 40mg/1mL Solução oral"
  },
  {
    "code" : "BR0300725",
    "display" : "Fenobarbital Sódico 200mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0300733",
    "display" : "Fosfato Dissódico de Dexametasona 2mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0300745",
    "display" : "Pancreatina 10.000UI cápsula de liberação retardada"
  },
  {
    "code" : "BR0300988",
    "display" : "Periciazina 10mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0300989",
    "display" : "Periciazina 40mg/1mL Solução oral"
  },
  {
    "code" : "BR0301591",
    "display" : "Fotemustina 208mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0301748",
    "display" : "Paracetamol 400mg associado a Cloridrato de Fenilefrina 20mg comprimido + Maleato de Carbinoxamina 4mg associado a Paracetamol 400mg comprimido"
  },
  {
    "code" : "BR0302442",
    "display" : "Cloridrato de Duloxetina 30mg cápsula de liberação retardada"
  },
  {
    "code" : "BR0302443",
    "display" : "Cloridrato de Duloxetina 60mg cápsula de liberação retardada"
  },
  {
    "code" : "BR0302748-1",
    "display" : "Pirazinamida 30mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0302748-2",
    "display" : "Pirazinamida 30mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0302942",
    "display" : "Ciclosporina 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0302942E",
    "display" : "Ciclosporina 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0303292-1",
    "display" : "Solução Ringer + Lactato; frasco"
  },
  {
    "code" : "BR0303292-3",
    "display" : "Solução de Ringer + Lactato; frasco-ampola"
  },
  {
    "code" : "BR0304181",
    "display" : "Timomodulina 80mg cápsula"
  },
  {
    "code" : "BR0304182",
    "display" : "Timomodulina 200mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0304788",
    "display" : "Cloridrato de Cinacalcete 30mg comprimido revestido"
  },
  {
    "code" : "BR0304790",
    "display" : "Cloridrato de Cinacalcete 60mg comprimido revestido"
  },
  {
    "code" : "BR0304845",
    "display" : "Nitroglicerina 50mg Adesivo Transdérmico"
  },
  {
    "code" : "BR0304870",
    "display" : "Sulfato de Morfina 1mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0304870-1",
    "display" : "Sulfato de Morfina Pentaidratado 2mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0304871",
    "display" : "Sulfato de Morfina Pentaidratado 10mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0304871E",
    "display" : "Sulfato de Morfina Pentaidratado 10mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0304872",
    "display" : "Sulfato de Morfina Pentaidratado 0,2mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0304875",
    "display" : "Digoxina 0,125mg Comprimido"
  },
  {
    "code" : "BR0305106",
    "display" : "Glucagon 1mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305247-1",
    "display" : "Lactulose 667mg/1mL Solução oral"
  },
  {
    "code" : "BR0305247-2",
    "display" : "Lactulose 667mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0305252",
    "display" : "Asparaginase 10.000unidade pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305258",
    "display" : "Acetato de Leuprorrelina 7,5mg pó para suspensão para injeção"
  },
  {
    "code" : "BR0305259",
    "display" : "Acetato de Leuprorrelina 22,5mg pó e diluente para suspensão para injeção"
  },
  {
    "code" : "BR0305260",
    "display" : "Acetato de Leuprorrelina 11,25mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305260E",
    "display" : "Acetato de Leuprorrelina 11,25mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305264",
    "display" : "Hemitartarato de Epinefrina 0,182mg/20mL + Cloridrato de Levobupivacaína 100mg/20mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305265",
    "display" : "Cloridrato de Levobupivacaína 150mg/20mL + Hemitartarato de Epinefrina 0,182mg/20mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305270",
    "display" : "Levofloxacino 500mg comprimido revestido"
  },
  {
    "code" : "BR0305293",
    "display" : "Mitoxantrona 20mg/10mL solução para injeção; frasco"
  },
  {
    "code" : "BR0305325",
    "display" : "Cloridrato de Moxifloxacino 400g/250mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305356",
    "display" : "Nicotina 4mg Goma de mascar"
  },
  {
    "code" : "BR0305413",
    "display" : "Ginkgo Biloba 120mg comprimido revestido"
  },
  {
    "code" : "BR0305414",
    "display" : "Ginkgo biloba 80mg cápsula"
  },
  {
    "code" : "BR0305414-1",
    "display" : "Ginkgo Biloba 80mg comprimido revestido"
  },
  {
    "code" : "BR0305415",
    "display" : "Ginkgo Biloba 40mg Cápsula"
  },
  {
    "code" : "BR0305415-1",
    "display" : "Ginkgo Biloba 40mg comprimido revestido"
  },
  {
    "code" : "BR0305428",
    "display" : "Carmelose Sódica 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0305428-1",
    "display" : "Carmelose Sódica 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0305428-3",
    "display" : "Carmelose Sódica 5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0305428-4",
    "display" : "Carmelose Sódica 10mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0305449",
    "display" : "Citrato de Potássio 540mg (5 mEq) comprimido de liberação prolongada"
  },
  {
    "code" : "BR0305450",
    "display" : "Citrato de Potássio 1.080mg (10 mEq) comprimido de liberação prolongada"
  },
  {
    "code" : "BR0305464-1",
    "display" : "Cloridrato de Fluoxetina 10mg comprimido"
  },
  {
    "code" : "BR0305464-2",
    "display" : "Cloridrato de Fluoxetina 10mg cápsula"
  },
  {
    "code" : "BR0305483",
    "display" : "Cloridrato de Maprotilina 25mg Comprimido"
  },
  {
    "code" : "BR0305484",
    "display" : "Cloridrato de Maprotilina 75mg comprimido revestido"
  },
  {
    "code" : "BR0305487",
    "display" : "Cloridrato de Mebeverina 200mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0305488",
    "display" : "Cloridrato de Metilfenidato 20mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0305489",
    "display" : "Cloridrato de Metilfenidato 40mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0305490",
    "display" : "Cloridrato de Metilfenidato 30mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0305490-1",
    "display" : "Cloridrato de Metilfenidato 40mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0305491",
    "display" : "Cloridrato de Pioglitazona 45mg comprimido"
  },
  {
    "code" : "BR0305492",
    "display" : "Cloridrato de Pioglitazona 30mg comprimido"
  },
  {
    "code" : "BR0305493",
    "display" : "Cloridrato de Pioglitazona 15mg comprimido"
  },
  {
    "code" : "BR0305494",
    "display" : "Didrogesterona 10mg comprimido revestido"
  },
  {
    "code" : "BR0305629",
    "display" : "Cimicifuga Racemosa 20mg comprimido revestido"
  },
  {
    "code" : "BR0305649E",
    "display" : "Budesonida 400micrograma + Fumarato de Formoterol Di-Hidratado 12micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0305650",
    "display" : "Budesonida 400micrograma + Fumarato de Formoterol Di-Hidratado 12micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0305652",
    "display" : "Budesonida 400micrograma/1dose + Fumarato de Formoterol Di-Hidratado 12micrograma/1dose Pó para inalação"
  },
  {
    "code" : "BR0305652E",
    "display" : "Budesonida 400micrograma/1dose + Fumarato de Formoterol Di-Hidratado 12micrograma/1dose Pó para inalação"
  },
  {
    "code" : "BR0305714",
    "display" : "Nitrofurantoína 5mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0305718",
    "display" : "Hemitartarato de Norepinefrina 8mg/4mL solução para injeção; ampola"
  },
  {
    "code" : "BR0305725",
    "display" : "Acetato de Octreotida 0,1mg/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305725E",
    "display" : "Octreotida 0,1mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0305726E",
    "display" : "Octreotida 0,5mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0305808",
    "display" : "Passiflora Incarnata 100mg + Crataegus Rhipidophylla Gand. 30mg + Salix Alba 100mg comprimido revestido"
  },
  {
    "code" : "BR0305935-3",
    "display" : "Propofol 500mg/50mL Emulsão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305938",
    "display" : "Dicloridrato de Quinina 600mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0306145",
    "display" : "Valsartana 160mg comprimido revestido"
  },
  {
    "code" : "BR0306146",
    "display" : "Valsartana 320mg comprimido revestido"
  },
  {
    "code" : "BR0306355",
    "display" : "Diclofenaco Sódico 50mg + Fosfato de Codeína 50mg comprimido revestido"
  },
  {
    "code" : "BR0306361",
    "display" : "Carbonato de Cálcio 1,5g (Cálcio 600 mg) + Colecalciferol 400 unidades internacionais comprimido"
  },
  {
    "code" : "BR0306465",
    "display" : "Trometamol Cetorolaco 30mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0306685",
    "display" : "Nateglinida 120mg Comprimido"
  },
  {
    "code" : "BR0306686",
    "display" : "Nicergolina 30mg comprimido revestido"
  },
  {
    "code" : "BR0306687",
    "display" : "Cloridrato de Alfuzosina 10mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0306947",
    "display" : "Fosfato de Oseltamivir 75mg Cápsula"
  },
  {
    "code" : "BR0306971",
    "display" : "Fosfato de Oseltamivir 15mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0307780",
    "display" : "Gatifloxacino 3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0308071",
    "display" : "Metilbrometo de Homatropina 2,5mg/1mL + Simeticona 80mg/1mL emulsão; frasco"
  },
  {
    "code" : "BR0308224",
    "display" : "Cloridrato de Metilfenidato 18mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308225",
    "display" : "Cloridrato de Metilfenidato 54mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308226",
    "display" : "Cloridrato de Metilfenidato 36mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308373",
    "display" : "Flucitosina 500mg Comprimido"
  },
  {
    "code" : "BR0308654",
    "display" : "Omalizumabe 150mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308718",
    "display" : "Acitretina 25mg cápsula"
  },
  {
    "code" : "BR0308718E",
    "display" : "Acitretina 25mg cápsula"
  },
  {
    "code" : "BR0308719E",
    "display" : "Acitretina 10mg cápsula"
  },
  {
    "code" : "BR0308726-1",
    "display" : "Benzoato de Benzila 250mg/1mL emulsão; frasco"
  },
  {
    "code" : "BR0308729",
    "display" : "Bezafibrato 400mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308729E",
    "display" : "Bezafibrato 400mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0308732",
    "display" : "Valproato de Sódio 50mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0308736-1",
    "display" : "Cetoconazol 20mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0308736-2",
    "display" : "Cetoconazol 20mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0308736-3",
    "display" : "Cetoconazol 20mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0308738",
    "display" : "Ciprofibrato 100mg comprimido"
  },
  {
    "code" : "BR0308738E",
    "display" : "Ciprofibrato 100mg comprimido"
  },
  {
    "code" : "BR0308805",
    "display" : "Fator IX 500unidades internacionais pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308874",
    "display" : "Isetionato de Pentamidina 300mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308877",
    "display" : "Sevoflurano 250mL/250mL inalante; ; frasco"
  },
  {
    "code" : "BR0308877-1",
    "display" : "Sevoflurano 100mL/100mL inalante; frasco"
  },
  {
    "code" : "BR0308882",
    "display" : "Trimetoprima 80mg + Sulfametoxazol 400mg Comprimido"
  },
  {
    "code" : "BR0308883",
    "display" : "Trimetoprima 160mg + Sulfametoxazol 800mg Comprimido"
  },
  {
    "code" : "BR0308884-1",
    "display" : "Trimetoprima 8mg/1mL + Sulfametoxazol 40mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0308884-2",
    "display" : "Trimetoprima 8mg/1mL + Sulfametoxazol 40mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0308884-3",
    "display" : "Trimetoprima 8mg/1mL + Sulfametoxazol 40mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0308884-4",
    "display" : "Trimetoprima 8mg/1mL + Sulfametoxazol 40mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0308885",
    "display" : "Sulfametoxazol 400mg/5mL + Trimetoprima 80mg/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0309040",
    "display" : "Ácido Ursodesoxicólico 300mg comprimido"
  },
  {
    "code" : "BR0309042",
    "display" : "Folinato de Cálcio 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0309045",
    "display" : "Ácido Aminocaproico 4.000mg/20mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0309062",
    "display" : "Aesculus Hippocastanum L. 100mg Cápsula"
  },
  {
    "code" : "BR0309063",
    "display" : "Aesculus Hippocastanum L. 300mg cápsula"
  },
  {
    "code" : "BR0309097",
    "display" : "Budesonida 100micrograma/1dose + Fumarato de Formoterol Di-Hidratado 6micrograma/1dose Pó para inalação"
  },
  {
    "code" : "BR0309432",
    "display" : "Cilazapril 1mg comprimido revestido"
  },
  {
    "code" : "BR0309433",
    "display" : "Cilazapril 2,5mg comprimido revestido"
  },
  {
    "code" : "BR0309434",
    "display" : "Cilazapril 5mg comprimido revestido"
  },
  {
    "code" : "BR0309437",
    "display" : "Cloridrato de Tramadol 100mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0309437-1",
    "display" : "Cloridrato de Tramadol 100mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0309441",
    "display" : "Cloridrato de Tramadol 100mg comprimido"
  },
  {
    "code" : "BR0309530-1",
    "display" : "Sulfato de Glicosamina 1,5g pó para solução oral; Sachê"
  },
  {
    "code" : "BR0309530-2",
    "display" : "Sulfato de Glicosamina 1,5g pó para solução oral; Sachê"
  },
  {
    "code" : "BR0310761",
    "display" : "Laronidase 2,9mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0311143",
    "display" : "Benzoato de Benzila 100mg/1g sabonete"
  },
  {
    "code" : "BR0311143-1",
    "display" : "Benzoato de Benzila 100mg/1g sabonete"
  },
  {
    "code" : "BR0311390-1",
    "display" : "Bevacizumabe 100mg/4mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0311390-2",
    "display" : "Bevacizumabe 400mg/16mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0312388",
    "display" : "Permetrina 10mg/1g loção; frasco"
  },
  {
    "code" : "BR0312390",
    "display" : "Glicerol 2mg/1mL + Hipromelose 3mg/1mL + Dextrana 70 (99m Tc) 1mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0312568",
    "display" : "Erlotinibe 100mg comprimido revestido"
  },
  {
    "code" : "BR0312569",
    "display" : "Erlotinibe 150mg comprimido revestido"
  },
  {
    "code" : "BR0312860",
    "display" : "Acetato de Fluormetolona 1mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0312860-1",
    "display" : "Acetato de Fluormetolona 1mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0313000",
    "display" : "Tipranavir 250mg Cápsula"
  },
  {
    "code" : "BR0313186",
    "display" : "Clotrimazol 10mg/1g + Acetato de Dexametasona 0,4mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0313591",
    "display" : "Policresuleno 18mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0313592",
    "display" : "Policresuleno 360mg/1g solução cutânea; frasco"
  },
  {
    "code" : "BR0313593",
    "display" : "Policresuleno 90mg Óvulo"
  },
  {
    "code" : "BR0313595",
    "display" : "Policresuleno 100mg/1g + Cloridrato de Cinchocaína 10mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0313689",
    "display" : "Fosfato de Potássio Monobásico 20mEq/10mL + Fosfato de Potássio Dibásico 156mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0314373-1",
    "display" : "Heparina Sódica 50UI/1mL + Cumarina 5mL/1mL creme; frasco"
  },
  {
    "code" : "BR0314373-2",
    "display" : "Heparina Sódica 50UI/1mL + Cumarina 5mL/1mL creme; frasco"
  },
  {
    "code" : "BR0314373-3",
    "display" : "Heparina Sódica 50UI/1mL + Cumarina 5mL/1mL creme; frasco"
  },
  {
    "code" : "BR0314373-4",
    "display" : "Heparina Sódica 50UI/1mL + Cumarina 5mL/1mL creme; frasco"
  },
  {
    "code" : "BR0314517-1",
    "display" : "Azitromicina 40mg/mL suspensão oral"
  },
  {
    "code" : "BR0314517-3",
    "display" : "Azitromicina 40mg/mL suspensão oral"
  },
  {
    "code" : "BR0314517-4",
    "display" : "Azitromicina 1,5g pó para suspensão oral"
  },
  {
    "code" : "BR0315088",
    "display" : "Entecavir 0,5mg comprimido revestido"
  },
  {
    "code" : "BR0315088E",
    "display" : "Entecavir 0,5mg comprimido revestido"
  },
  {
    "code" : "BR0315089",
    "display" : "Entecavir 1mg comprimido revestido"
  },
  {
    "code" : "BR0315089E",
    "display" : "Entecavir 1mg comprimido revestido"
  },
  {
    "code" : "BR0315483",
    "display" : "Sulfato de Neomicina 3,5mg/1g + Fludroxicortida 0,125mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0315604",
    "display" : "Monossialogangliosideo Sódico 100mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0315610",
    "display" : "Cloridrato de Palonosetrona 0,25mg/1mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0315734",
    "display" : "Bromidrato de Galantamina 24mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0315734E",
    "display" : "Bromidrato de Galantamina 24mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0315735",
    "display" : "Bromidrato de Galantamina 16mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0315735E",
    "display" : "Bromidrato de Galantamina 16mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0318305",
    "display" : "Ácido Salicílico 165mg/1mL + Ácido Láctico 145,2mg/1mL solução cutânea; frasco"
  },
  {
    "code" : "BR0318309",
    "display" : "Ácido Salicílico 30mg/1g + Dipropionato de Betametasona 0,5mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0318943",
    "display" : "Cloreto de Sódio 9mg/1mL + Cloreto de Benzalcônio 0,1mg/1mL + Nafazolina 0,5mg/1mL Solução nasal; frasco"
  },
  {
    "code" : "BR0318945",
    "display" : "Bromidrato de Citalopram 40mg comprimido revestido"
  },
  {
    "code" : "BR0318969",
    "display" : "Di-hidroergocristina 3mg + Flunarizina 10 mg comprimido"
  },
  {
    "code" : "BR0318988",
    "display" : "Somatropina 30UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0318993",
    "display" : "Triflusal 300mg cápsula"
  },
  {
    "code" : "BR0319000-1",
    "display" : "Tartarato de Brimonidina 2mg/1mL + Maleato de Timolol 5mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0319000-2",
    "display" : "Tartarato de Brimonidina 2mg/1mL + Maleato de Timolol 5mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0319004",
    "display" : "Dexametasona 0,75mg comprimido"
  },
  {
    "code" : "BR0319128",
    "display" : "Primidona 100mg Comprimido"
  },
  {
    "code" : "BR0319128E",
    "display" : "Primidona 100mg Comprimido"
  },
  {
    "code" : "BR0319763",
    "display" : "Maleato de Bronfeniramina 0,4mg/1mL + Cloridrato de Fenilefrina 1mg/1mL Xarope"
  },
  {
    "code" : "BR0319764",
    "display" : "Bronfeniramina 2mg/mL + Fenilefrina 2,5 mg/mL solução oral"
  },
  {
    "code" : "BR0319883",
    "display" : "Citrato de Sildenafila 20mg comprimido revestido"
  },
  {
    "code" : "BR0319883E",
    "display" : "Citrato de Sildenafila 20mg comprimido revestido"
  },
  {
    "code" : "BR0320338",
    "display" : "Sulbutiamina 200mg comprimido revestido; comprimido"
  },
  {
    "code" : "BR0320796",
    "display" : "Acetato de Desmopressina 15micrograma/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0320824",
    "display" : "Cloridrato de Benazepril 5mg comprimido revestido"
  },
  {
    "code" : "BR0320825",
    "display" : "Cloridrato de Benazepril 10mg comprimido revestido"
  },
  {
    "code" : "BR0320829",
    "display" : "Cloridrato de Benazepril 10mg + Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0321804",
    "display" : "Cloridrato de Topotecana 4mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0322033",
    "display" : "Alfalutropina 75UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0322254",
    "display" : "Estazolam 2mg Comprimido"
  },
  {
    "code" : "BR0322435",
    "display" : "Fanciclovir 500mg comprimido revestido"
  },
  {
    "code" : "BR0322436",
    "display" : "Fanciclovir 125mg comprimido revestido"
  },
  {
    "code" : "BR0323004",
    "display" : "Cloridrato de Isoxsuprina 10mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0323096",
    "display" : "Bromazepam 2,5mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0324358",
    "display" : "Anfotericina B Complexo Lipídico 100mg/20 mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0324414",
    "display" : "Lamotrigina 50mg comprimido"
  },
  {
    "code" : "BR0324414E",
    "display" : "Lamotrigina 50mg comprimido"
  },
  {
    "code" : "BR0324415",
    "display" : "Etoricoxibe 90mg comprimido revestido"
  },
  {
    "code" : "BR0324587",
    "display" : "Dicloridrato de Manidipino 20mg Comprimido"
  },
  {
    "code" : "BR0325456",
    "display" : "Dicloridrato de Manidipino 10mg comprimido"
  },
  {
    "code" : "BR0325836",
    "display" : "Deferasirox 250mg Comprimido para suspensão"
  },
  {
    "code" : "BR0325836E",
    "display" : "Deferasirox 250mg Comprimido para suspensão"
  },
  {
    "code" : "BR0325837",
    "display" : "Deferasirox 500mg Comprimido para suspensão"
  },
  {
    "code" : "BR0325837E",
    "display" : "Deferasirox 500mg Comprimido para suspensão"
  },
  {
    "code" : "BR0326010",
    "display" : "Triancinolona Acetonida 1mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0326057",
    "display" : "Glicinato Férrico 300mg comprimido revestido"
  },
  {
    "code" : "BR0326613",
    "display" : "Glicinato Férrico 500mg comprimido mastigável"
  },
  {
    "code" : "BR0326789",
    "display" : "Cefaclor 500mg comprimido"
  },
  {
    "code" : "BR0326902",
    "display" : "Dicloridrato de Etambutol 25mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0327566",
    "display" : "Ácido Tranexâmico 250mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0327699-1",
    "display" : "Permanganato de Potássio 100mg Comprimido; comprimido"
  },
  {
    "code" : "BR0327699-2",
    "display" : "Permanganato de Potássio 100mg pó cutâneo; envelope"
  },
  {
    "code" : "BR0327792",
    "display" : "Cefalexina Monoidratada 25mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0327792-1",
    "display" : "Cefalexina Monoidratada 25mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0327794",
    "display" : "Cloridrato de Ciprofloxacino 3,5mg/1g + Dexametasona 1mg/1g Pomada oftálmica; bisnaga"
  },
  {
    "code" : "BR0327802",
    "display" : "Clortalidona 25mg + Cloridrato de Amilorida Di-Hidratado 5mg Comprimido"
  },
  {
    "code" : "BR0328106",
    "display" : "Citrato de Clomifeno 50mg Comprimido"
  },
  {
    "code" : "BR0328205",
    "display" : "Mesilato de Codergocrina 1mg/1mL Solução oral"
  },
  {
    "code" : "BR0328513",
    "display" : "Artesunato 60mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0328531",
    "display" : "Valproato de Sódio 300mg comprimido de liberação retardada;"
  },
  {
    "code" : "BR0328535-1",
    "display" : "Valproato de Sódio 200mg/1mL Solução oral"
  },
  {
    "code" : "BR0328810",
    "display" : "Lamivudina 10mg/1mL Solução oral"
  },
  {
    "code" : "BR0328810E",
    "display" : "Lamivudina 10mg/1mL Solução oral"
  },
  {
    "code" : "BR0328992",
    "display" : "Tolterodina 4mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0329341",
    "display" : "Tadalafila 20mg comprimido revestido"
  },
  {
    "code" : "BR0329352",
    "display" : "Malato de Pizotifeno 0,5mg Comprimido"
  },
  {
    "code" : "BR0329359",
    "display" : "Tiocolchicosídeo 4mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0329507",
    "display" : "Palmitato de Retinol 100.000UI cápsula"
  },
  {
    "code" : "BR0329610",
    "display" : "Acetato de Racealfatocoferol 400mg cápsula"
  },
  {
    "code" : "BR0330113-1",
    "display" : "Ganciclovir 250mg/250mL Solução para infusão"
  },
  {
    "code" : "BR0330113-2",
    "display" : "Ganciclovir Sódico 500mg/500mL solução para injeção; bolsa"
  },
  {
    "code" : "BR0330114",
    "display" : "Ganciclovir Sódico 500mg/10mL solução para injeção; ampola"
  },
  {
    "code" : "BR0330115",
    "display" : "Ganciclovir Sódico 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0330335",
    "display" : "Tosilato de Sorafenibe 200mg comprimido revestido"
  },
  {
    "code" : "BR0331153",
    "display" : "Povidona 6mg/1mL + Álcool Polivinílico 14mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0331223-1",
    "display" : "Teriparatida 600micrograma/2,4mL solução para injeção; dispositivo de injeção pré-carregado"
  },
  {
    "code" : "BR0331296",
    "display" : "Maleato de Tegaserode 6mg Comprimido"
  },
  {
    "code" : "BR0331308",
    "display" : "Anlodipino 5mg + Atenolol 50 mg cápsula"
  },
  {
    "code" : "BR0331309",
    "display" : "Atenolol 25mg + Besilato de Anlodipino 5mg cápsula"
  },
  {
    "code" : "BR0331388",
    "display" : "Sitagliptina 50mg comprimido revestido"
  },
  {
    "code" : "BR0331389",
    "display" : "Sitagliptina 100mg comprimido revestido"
  },
  {
    "code" : "BR0331539",
    "display" : "Tigeciclina 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0331555-1",
    "display" : "Cefalexina Monoidratada 50mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0331555-2",
    "display" : "Cefalexina Monoidratada 50mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0331938",
    "display" : "Pemetrexede Dissódico Heptaidratado 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0331980",
    "display" : "Acetato de Ciproterona 100mg comprimido"
  },
  {
    "code" : "BR0332382",
    "display" : "Cidofovir 1.875mg/5mL solução para infusão; frasco-ampola"
  },
  {
    "code" : "BR0332383",
    "display" : "Idursulfase 6mg/3mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0332426",
    "display" : "Hidróxido de Alumínio 37mg/1mL + Hidróxido de Magnésio 35,6mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0332468-1",
    "display" : "Sulfato Ferroso Heptaidratado 25mg/1mL (Ferro 5 mg/mL) xarope; frasco"
  },
  {
    "code" : "BR0332468-2",
    "display" : "Sulfato Ferroso Heptaidratado 25mg/1mL (Ferro 5 mg/mL) xarope; frasco"
  },
  {
    "code" : "BR0332754",
    "display" : "Ibuprofeno 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0332755-3",
    "display" : "Ibuprofeno 100mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0332755-6",
    "display" : "Ibuprofeno 100mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0332761",
    "display" : "Sumatriptana 25mg comprimido revestido"
  },
  {
    "code" : "BR0332764",
    "display" : "Darunavir 300mg comprimido revestido"
  },
  {
    "code" : "BR0332788",
    "display" : "Propionato de Fluticasona 125micrograma/1dose + Xinafoato de Salmeterol 25micrograma/1dose suspensão aerossol; frasco"
  },
  {
    "code" : "BR0332789",
    "display" : "Xinafoato de Salmeterol 25micrograma/1dose + Propionato de Fluticasona 50micrograma/1dose Suspensão aerossol; frasco"
  },
  {
    "code" : "BR0332794",
    "display" : "Etinilestradiol 0.02mg + Gestodeno 0.075mg comprimido revestido"
  },
  {
    "code" : "BR0332795",
    "display" : "Gestodeno 0,075mg + Etinilestradiol 0,03mg comprimido revestido"
  },
  {
    "code" : "BR0332848",
    "display" : "Calcipotriol Monoidratado 50micrograma/1g + Dipropionato de Betametasona 0,5mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0332849-1",
    "display" : "Calcipotriol 50micrograma/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0332849-2",
    "display" : "Calcipotriol 50micrograma/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0332849E",
    "display" : "Calcipotriol 50micrograma/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0332917",
    "display" : "Vasopressina 20UI/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0332984",
    "display" : "Coaltar 40mg/1mL Xampu; frasco"
  },
  {
    "code" : "BR0332985",
    "display" : "Levofloxacino 750mg/150mL solução para injeção; bolsa"
  },
  {
    "code" : "BR0333130-1",
    "display" : "Axetilcefuroxima 50mg/1mL Pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0333142",
    "display" : "Alprostadil 500micrograma/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0333446",
    "display" : "Palivizumabe 100mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0333447",
    "display" : "Infliximabe 100mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0333447E",
    "display" : "Infliximabe 100mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0333496",
    "display" : "Cloridrato de Sotalol 120mg Comprimido"
  },
  {
    "code" : "BR0333569-1",
    "display" : "Tacrolimo Monoidratado 1mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0333569-2",
    "display" : "Tacrolimo Monoidratado 1mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0333569-3",
    "display" : "Tacrolimo Monoidratado 0,3mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0333791",
    "display" : "Clodronato Dissódico Tetraidratado 300mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0334016-1",
    "display" : "Propionato de Fluticasona 50micrograma/1dose suspensão aerossol; frasco"
  },
  {
    "code" : "BR0334016-2",
    "display" : "Propionato de Fluticasona 50micrograma/1dose suspensão aerossol; frasco"
  },
  {
    "code" : "BR0334712",
    "display" : "Fulvestranto 250mg/5mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0335091",
    "display" : "Acetilcisteína 300mg/3mL Solução para injeção; Solução para inalação; ampola"
  },
  {
    "code" : "BR0335097-1",
    "display" : "Cloranfenicol 250mg Comprimido"
  },
  {
    "code" : "BR0335097-2",
    "display" : "Cloranfenicol 250mg cápsula"
  },
  {
    "code" : "BR0335098",
    "display" : "Cloranfenicol 500mg Comprimido"
  },
  {
    "code" : "BR0335100",
    "display" : "Succinato Sódico de Cloranfenicol 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0335101-2",
    "display" : "Cloranfenicol 5mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0335104",
    "display" : "Cloranfenicol 30mg Suspensão oral"
  },
  {
    "code" : "BR0335106",
    "display" : "Cloranfenicol 25mg/mL + Lidocaína 30 mg/mL solução otológica"
  },
  {
    "code" : "BR0335112",
    "display" : "Pentoxifilina 100mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0335968",
    "display" : "Vardenafila 10mg comprimido revestido"
  },
  {
    "code" : "BR0335969",
    "display" : "Vardenafila 20mg comprimido revestido"
  },
  {
    "code" : "BR0336680",
    "display" : "Fosamprenavir Cálcico 700mg comprimido revestido"
  },
  {
    "code" : "BR0337457-1",
    "display" : "Furoato de Mometasona 50micrograma/1dose suspensão spray"
  },
  {
    "code" : "BR0337468-2",
    "display" : "Desloratadina 0,5mg/1mL Xarope"
  },
  {
    "code" : "BR0337468-3",
    "display" : "Desloratadina 0,5mg/1mL Xarope"
  },
  {
    "code" : "BR0337468-4",
    "display" : "Desloratadina 1,25mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0337472",
    "display" : "Insulina Detemir 300UI/3mL solução para injeção; dispositivo de injeção pré-carregado"
  },
  {
    "code" : "BR0337473",
    "display" : "Insulina Detemir 300UI/3mL Solução para injeção; carpule"
  },
  {
    "code" : "BR0337478-1",
    "display" : "Fluticasona 100micrograma/1dose + Salmeterol 50micrograma/1dose pó para inalação; dispositivo"
  },
  {
    "code" : "BR0337478-2",
    "display" : "Fluticasona 100micrograma/1dose + Salmeterol 50micrograma/1dose pó para inalação; dispositivo"
  },
  {
    "code" : "BR0337678",
    "display" : "Ácido Acetilsalicílico 100mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0338134",
    "display" : "Espironolactona 50mg Comprimido"
  },
  {
    "code" : "BR0338288",
    "display" : "Undecilato de Testosterona 1g/4mL solução para injeção; ampola"
  },
  {
    "code" : "BR0338297",
    "display" : "Voriconazol 200mg comprimido revestido"
  },
  {
    "code" : "BR0338298",
    "display" : "Voriconazol 200mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0338332",
    "display" : "Acetato de Zinco 2,5mEq/5mL solução para injeção; ampola"
  },
  {
    "code" : "BR0338413",
    "display" : "Dactinomicina 0,5mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0338883",
    "display" : "Calcitonina Sintética de Salmão 200UI/1dose solução nasal; frasco"
  },
  {
    "code" : "BR0338883E",
    "display" : "Calcitonina Sintética de Salmão 200UI/1dose solução nasal; frasco"
  },
  {
    "code" : "BR0338888E",
    "display" : "Calcitonina Sintética de Salmão 50UI/0,5mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0338890E",
    "display" : "Calcitonina 100unidade/1mL solução para injeção"
  },
  {
    "code" : "BR0339534",
    "display" : "Cloreto de Sódio 30mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0339846",
    "display" : "Cloridrato de Cefepima 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0339847",
    "display" : "Cloridrato de Cefepima 2g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0339979",
    "display" : "Somatropina 5mg/1,5mL solução para injeção; carpule"
  },
  {
    "code" : "BR0339980",
    "display" : "Somatropina 10mg/1,5mL solução para injeção; carpule"
  },
  {
    "code" : "BR0339981",
    "display" : "Somatropina 15mg/1,5mL solução para injeção; carpule"
  },
  {
    "code" : "BR0340100",
    "display" : "Cetoprofeno 100mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0340101",
    "display" : "Cetoprofeno 100mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340103",
    "display" : "Cetoprofeno 150mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0340104",
    "display" : "Cetoprofeno 200mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0340107",
    "display" : "Cetoprofeno 100mg Supositório"
  },
  {
    "code" : "BR0340117",
    "display" : "Vareniclina 0,5mg comprimido revestido"
  },
  {
    "code" : "BR0340118",
    "display" : "Vareniclina 1mg comprimido revestido"
  },
  {
    "code" : "BR0340120",
    "display" : "Vareniclina 0,5 mg comprimido revestido E Vareniclina 1 mg comprimido revestido; pack"
  },
  {
    "code" : "BR0340128",
    "display" : "Fumarato de Cetotifeno 0,25mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0340138",
    "display" : "Acetato de Cetrorrelix 0,25mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340148",
    "display" : "Ciclofosfamida Monoidratada 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340149",
    "display" : "Ciclofosfamida Monoidratada 200mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340153",
    "display" : "Ciclopirox Olamina 10mg/1mL solução cutânea; frasco"
  },
  {
    "code" : "BR0340167",
    "display" : "Cimetidina 300mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0340177",
    "display" : "Besilato de Cisatracúrio 150mg/30mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0340178-1",
    "display" : "Besilato de Cisatracúrio 10mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0340182",
    "display" : "Cisplatina 10mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340183",
    "display" : "Cisplatina 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340184",
    "display" : "Cisplatina 100mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340190",
    "display" : "Citarabina 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340191",
    "display" : "Citarabina 100mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340193-1",
    "display" : "Citarabina 100mg/5mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340193-2",
    "display" : "Citarabina 500mg/25mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340194",
    "display" : "Citarabina 500mg/10mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340195 -1",
    "display" : "Citarabina 100mg/1mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340195-2",
    "display" : "Citarabina 500mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340195-3",
    "display" : "Citarabina 1.000mg/10mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340195-4",
    "display" : "Citarabina 2.000mg/20mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0340206",
    "display" : "Cloridrato de Clonidina 0,15mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0340207",
    "display" : "Cloridrato de Clorpromazina 40mg/1mL Solução oral; Solução"
  },
  {
    "code" : "BR0340419",
    "display" : "Mesilato de Di-Hidroergotamina 1mg + Cafeína 100mg + Dipirona Monoidratada 350mg Comprimido"
  },
  {
    "code" : "BR0340764",
    "display" : "Dipropionato de Betametasona 1mg/1mL + Ácido Salicílico 3mg/1mL solução cutânea; frasco"
  },
  {
    "code" : "BR0340783-1",
    "display" : "Hidróxido de Alumínio 61,5mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0340783-1E",
    "display" : "Hidróxido de Alumínio 61,5mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0340783-2",
    "display" : "Hidróxido de Alumínio 61,5mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0340783-2E",
    "display" : "Hidróxido de Alumínio 61,5mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0340783-3",
    "display" : "Hidróxido de Alumínio 61,5mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0340783-3E",
    "display" : "Hidróxido de Alumínio 61,5mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0340783-4",
    "display" : "Hidróxido de Alumínio 61,5mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0341064",
    "display" : "Podofilotoxina 1,5mg/1g Creme"
  },
  {
    "code" : "BR0341108",
    "display" : "Mesilato de Codergocrina 4,5mg comprimido"
  },
  {
    "code" : "BR0341109",
    "display" : "Mesilato de Codergocrina 0,3mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0341180",
    "display" : "Poliestirenossulfonato de Cálcio 900mg/1g pó para solução oral/retal; envelope"
  },
  {
    "code" : "BR0341829",
    "display" : "Zopiclona 7,5mg comprimido revestido"
  },
  {
    "code" : "BR0341851",
    "display" : "Fluvoxamina 100mg comprimido revestido"
  },
  {
    "code" : "BR0341882",
    "display" : "Cianocobalamina 1mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0342108",
    "display" : "Progesterona 80mg/1g gel vaginal; envelope"
  },
  {
    "code" : "BR0342134",
    "display" : "Succinato Sódico de Hidrocortisona 500mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342178",
    "display" : "Etoposídeo 100mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342193-1",
    "display" : "Docetaxel Tri-Hidratado 20mg/0,5mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342193-2",
    "display" : "Docetaxel Tri-Hidratado 80mg/2mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342258",
    "display" : "Imipeném Monoidratado 500mg + Cilastatina Sódica 500mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342319",
    "display" : "Cloridrato de Ziprasidona 40mg cápsula"
  },
  {
    "code" : "BR0342319E",
    "display" : "Cloridrato de Ziprasidona 40mg cápsula"
  },
  {
    "code" : "BR0342320",
    "display" : "Cloridrato de Ziprasidona Monoidratado 80mg cápsula"
  },
  {
    "code" : "BR0342320E",
    "display" : "Cloridrato de Ziprasidona Monoidratado 80mg cápsula"
  },
  {
    "code" : "BR0342327",
    "display" : "Varfarina Sódica 7,5mg comprimido"
  },
  {
    "code" : "BR0342469",
    "display" : "Fenilbutazona Cálcica 200mg comprimido revestido"
  },
  {
    "code" : "BR0342501",
    "display" : "Fenofibrato 250mg Cápsula de liberação retardada"
  },
  {
    "code" : "BR0342501E",
    "display" : "Fenofibrato 250mg Cápsula de liberação retardada"
  },
  {
    "code" : "BR0342526",
    "display" : "Brometo de Tiotrópio 18micrograma cápsula para inalação"
  },
  {
    "code" : "BR0342666",
    "display" : "Sulfato de Gentamicina 3mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0342680E",
    "display" : "Embonato de Triptorrelina 11.25mg/2mL pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342737",
    "display" : "Heparina Sódica 200unidades internacionais/g gel"
  },
  {
    "code" : "BR0342739",
    "display" : "Heparina Sódica 10.000UI/1mL solução spray; frasco"
  },
  {
    "code" : "BR0342746",
    "display" : "Acetato de Glatirâmer 20mg/1mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0342979",
    "display" : "Octreotida 10mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342979E",
    "display" : "Acetato de Octreotida 10mg Pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342980E",
    "display" : "Acetato de Octreotida 20mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0343125",
    "display" : "Losartana Potássica 50mg + Besilato de Anlodipino 2,5mg cápsula"
  },
  {
    "code" : "BR0343126",
    "display" : "Besilato de Anlodipino 5mg + Losartana Potássica 100mg Cápsula"
  },
  {
    "code" : "BR0343437",
    "display" : "Estradiol 1mg/1g gel; frasco"
  },
  {
    "code" : "BR0343494",
    "display" : "Espiramicina 1,5MUI comprimido revestido"
  },
  {
    "code" : "BR0343573",
    "display" : "Dicloridrato de Betaistina 24mg comprimido"
  },
  {
    "code" : "BR0343604",
    "display" : "Ureia 200mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0343607",
    "display" : "Etanercepte 25mg/0,5mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0343607E",
    "display" : "Etanercepte 25mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0343608",
    "display" : "Etanercepte 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0344014",
    "display" : "Clonazepam 0,25mg comprimido sublingual"
  },
  {
    "code" : "BR0344562",
    "display" : "Malato de Sunitinibe 25mg Cápsula"
  },
  {
    "code" : "BR0344563",
    "display" : "Malato de Sunitinibe 12,5mg Cápsula"
  },
  {
    "code" : "BR0344564",
    "display" : "Malato de Sunitinibe 50mg cápsula"
  },
  {
    "code" : "BR0345001",
    "display" : "Miglustate 100mg Cápsula"
  },
  {
    "code" : "BR0345001E",
    "display" : "Miglustate 100mg Cápsula"
  },
  {
    "code" : "BR0345240-1",
    "display" : "Acetato de Hidrocortisona 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0345240-2",
    "display" : "Acetato de Hidrocortisona 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0345240-3",
    "display" : "Acetato de Hidrocortisona 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0345241",
    "display" : "Hidrocortisona 10mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0345259",
    "display" : "Tartarato de Metoprolol 5mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0345259-1",
    "display" : "Metoprolol 5mg/5mL Solução para injeção"
  },
  {
    "code" : "BR0345300",
    "display" : "Metronidazol 100mg/g creme vaginal"
  },
  {
    "code" : "BR0345638",
    "display" : "Cloranfenicol 4mg/mL solução oftálmica"
  },
  {
    "code" : "BR0345783",
    "display" : "Ureia 100mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0345783-1",
    "display" : "Ureia 100mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0345783-2",
    "display" : "Ureia 100mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0345866",
    "display" : "Levodopa 100mg + Carbidopa 25mg + Entacapona 200mg comprimido revestido"
  },
  {
    "code" : "BR0346231",
    "display" : "Alantoína 1mg/1g + Lactato de Amônio 120mg/1g Emulsão; frasco"
  },
  {
    "code" : "BR0346586-1",
    "display" : "Dipropionato de Beclometasona 50micrograma/1dose solução aerossol; dispositivo"
  },
  {
    "code" : "BR0346586-2",
    "display" : "Dipropionato de Beclometasona 50micrograma/1dose solução aerossol; dispositivo"
  },
  {
    "code" : "BR0349475",
    "display" : "Salicilato de Metila 52,5mg/1g + Terebintina 191,47mg/1g + Cânfora 44,4mg/1g + Mentol 20mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0349475-1",
    "display" : "Salicilato de Metila 52,5mg/1g + Terebintina 191,47mg/1g + Cânfora 44,4mg/1g + Mentol 20mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0350587-1",
    "display" : "Lopinavir 80mg/1mL + Ritonavir 20mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0350587-2",
    "display" : "Lopinavir 80mg/1mL + Ritonavir 20mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0350588",
    "display" : "Lopinavir 133,3mg + Ritonavir 33mg Cápsula"
  },
  {
    "code" : "BR0350589",
    "display" : "Lopinavir 200mg + Ritonavir 50mg comprimido revestido"
  },
  {
    "code" : "BR0350613",
    "display" : "Imiquimode 50mg/1g creme; envelope"
  },
  {
    "code" : "BR0351443",
    "display" : "Rabeprazol Sódico 10mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0351444",
    "display" : "Rabeprazol Sódico 20mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0351479",
    "display" : "Etodolaco 400mg comprimido revestido"
  },
  {
    "code" : "BR0351480",
    "display" : "Etodolaco 300mg comprimido revestido"
  },
  {
    "code" : "BR0352179-1",
    "display" : "Valerato de Betametasona 1mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0352179-2",
    "display" : "Valerato de Betametasona 1mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0352180",
    "display" : "Valerato de Betametasona 1mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0352192",
    "display" : "Solução Ringer; frasco"
  },
  {
    "code" : "BR0352193",
    "display" : "Tobramicina 3mg/1mL + Dexametasona 1mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0352194",
    "display" : "Cloridrato de Tioridazina 30mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0352245",
    "display" : "Citrato de Sildenafila 100mg comprimido revestido"
  },
  {
    "code" : "BR0352301",
    "display" : "Indapamida 1,5mg Comprimido"
  },
  {
    "code" : "BR0352314",
    "display" : "Pantoprazol Sódico Sesqui-Hidratado 40mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0352394",
    "display" : "Budesonida 400micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0352394E",
    "display" : "Budesonida 400micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0352395",
    "display" : "Budesonida 200micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0352395E",
    "display" : "Budesonida 200 microgramas pó aerossol"
  },
  {
    "code" : "BR0352397",
    "display" : "Budesonida 200micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0352411",
    "display" : "Dipropionato de Beclometasona 400micrograma/1mL + Sulfato de Salbutamol 800micrograma/1mL suspensão para inalação; flaconete"
  },
  {
    "code" : "BR0352414E",
    "display" : "Mesalazina 500mg Supositório"
  },
  {
    "code" : "BR0352847-1",
    "display" : "Palmitato de Pipotiazina 25mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0352847-2",
    "display" : "Palmitato de Pipotiazina 100mg/4mL solução para injeção; ampola"
  },
  {
    "code" : "BR0352911",
    "display" : "Divalproato de Sódio 125mg Cápsula"
  },
  {
    "code" : "BR0352912",
    "display" : "Divalproato de sódio 500mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0352932",
    "display" : "Ácido Salicílico 270mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0352933-1",
    "display" : "Levetiracetam 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0352933-2",
    "display" : "Levetiracetam 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0352933-3",
    "display" : "Levetiracetam 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0352944",
    "display" : "Borago Officinalis L. 900mg Cápsula"
  },
  {
    "code" : "BR0353332",
    "display" : "Raltegravir 400mg comprimido revestido"
  },
  {
    "code" : "BR0353333",
    "display" : "Amoxicilina 875mg + Clavulanato de Potássio 125mg comprimido revestido"
  },
  {
    "code" : "BR0353334",
    "display" : "Pegvisomanto 10mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0353336",
    "display" : "Pegvisomanto 15mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0353397-1",
    "display" : "Beractanto 100mg/4mL suspensão para instilação endotraqueal; frasco-ampola"
  },
  {
    "code" : "BR0353397-2",
    "display" : "Beractanto 200mg/8mL suspensão para instilação endotraqueal; frasco-ampola"
  },
  {
    "code" : "BR0353398-1",
    "display" : "Alfaporactanto 120mg/1,5mL suspensão para instilação endotraqueal; frasco-ampola"
  },
  {
    "code" : "BR0353398-2",
    "display" : "Alfaporactanto 240mg/3 mL suspensão intratraqueal; frasco-ampola"
  },
  {
    "code" : "BR0353813",
    "display" : "Mirtazapina 15mg Comprimido orodispersível"
  },
  {
    "code" : "BR0354242",
    "display" : "Metoxisaleno 10mg cápsula"
  },
  {
    "code" : "BR0354314",
    "display" : "Cimetidina 400mg Comprimido"
  },
  {
    "code" : "BR0354317",
    "display" : "Acarbose 100mg Comprimido"
  },
  {
    "code" : "BR0354498",
    "display" : "Cloridrato de Lercanidipino 20mg comprimido revestido"
  },
  {
    "code" : "BR0354516",
    "display" : "Glipizida 5mg comprimido"
  },
  {
    "code" : "BR0354627E",
    "display" : "Hidróxido de Alumínio 230mg comprimido"
  },
  {
    "code" : "BR0354632",
    "display" : "Cloridrato de Olopatadina 1mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0354633",
    "display" : "Cloridrato de Olopatadina 2mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0354953",
    "display" : "Somatostatina 3mg pó para solução para injeção; ampola"
  },
  {
    "code" : "BR0355786",
    "display" : "Acetilcisteína 40mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0355786-1",
    "display" : "Acetilcisteína 40mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0355794",
    "display" : "Cloridrato de Moxifloxacino 5mg/1mL + Fosfato Dissódico de Dexametasona 1mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0356051",
    "display" : "Ácido Zoledrônico Monoidratado 5mg/100mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0356452",
    "display" : "Travoprosta 0,04mg/1mL + Maleato de Timolol 5mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0356452-1",
    "display" : "Travoprosta 0,04mg/1mL + Maleato de Timolol 5mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0356453",
    "display" : "Tianeptina Sódica 12,5mg comprimido revestido"
  },
  {
    "code" : "BR0356602",
    "display" : "Estrogênios Conjugados 0,3mg drágea"
  },
  {
    "code" : "BR0356701",
    "display" : "Desogestrel 75 micrograma comprimido revestido"
  },
  {
    "code" : "BR0356952",
    "display" : "Acetilcisteína 600mg Comprimido efervescente"
  },
  {
    "code" : "BR0357058",
    "display" : "Cloridrato de Paroxetina 15mg comprimido revestido"
  },
  {
    "code" : "BR0357059",
    "display" : "Ibandronato de Sódio Monoidratado 150mg comprimido revestido"
  },
  {
    "code" : "BR0357061",
    "display" : "Valsartana 80mg + Besilato de Anlodipino 5mg comprimido revestido"
  },
  {
    "code" : "BR0357062",
    "display" : "Valsartana 160mg + Besilato de Anlodipino 5mg comprimido revestido"
  },
  {
    "code" : "BR0357063",
    "display" : "Valsartana 320mg + Besilato de Anlodipino 5mg comprimido revestido"
  },
  {
    "code" : "BR0357064",
    "display" : "Vildagliptina 50mg + Metformina 500mg comprimido revestido"
  },
  {
    "code" : "BR0357066",
    "display" : "Vildagliptina 50mg + Metformina 850mg comprimido revestido"
  },
  {
    "code" : "BR0357071",
    "display" : "Citrato de Cálcio 2370mg/4g + Colecalciferol 200UI/4g pó para suspensão oral; envelope"
  },
  {
    "code" : "BR0357119",
    "display" : "Beta-Agalsidase 35mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0357213",
    "display" : "Cloridrato de Metoclopramida 7mg + Dimeticona 40mg + Pepsina 50mg Cápsula"
  },
  {
    "code" : "BR0357657",
    "display" : "Etravirina 100mg Comprimido"
  },
  {
    "code" : "BR0357788",
    "display" : "Cloridrato de Mepivacaína 54mg/1,8mL Solução para injeção; carpule"
  },
  {
    "code" : "BR0358449",
    "display" : "Bromidrato de Darifenacina 7,5mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0358450",
    "display" : "Bromidrato de Darifenacina 15mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0358753",
    "display" : "Misoprostol 25micrograma Comprimido vaginal"
  },
  {
    "code" : "BR0358754",
    "display" : "Misoprostol 100micrograma comprimido vaginal"
  },
  {
    "code" : "BR0358755",
    "display" : "Misoprostol 200 microgramas comprimido vaginal"
  },
  {
    "code" : "BR0359135",
    "display" : "Dasatinibe 20mg comprimido revestido"
  },
  {
    "code" : "BR0359136",
    "display" : "Dasatinibe 50mg comprimido revestido"
  },
  {
    "code" : "BR0359286",
    "display" : "Hedera Helix 7mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0359766",
    "display" : "Ácido Hialurônico 40mg/50mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0360824",
    "display" : "Paliperidona 3mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0360826",
    "display" : "Paliperidona 9mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0361174",
    "display" : "Ditosilato de Lapatinibe 250mg comprimido revestido"
  },
  {
    "code" : "BR0361382",
    "display" : "Deferiprona 500mg comprimido revestido"
  },
  {
    "code" : "BR0361382E",
    "display" : "Deferiprona 500mg comprimido revestido"
  },
  {
    "code" : "BR0362057",
    "display" : "Hidrogenotartrato de rivastigmina (9mg) 4,6mg/24hora adesivo transdérmico"
  },
  {
    "code" : "BR0362058",
    "display" : "Hidrogenotartrato de rivastigmina (18mg) 9,5mg/24hora adesivo transdérmico"
  },
  {
    "code" : "BR0362059",
    "display" : "Hidrogenotartrato de rivastigmina (27mg) 13,3mg/24hora adesivo transdérmico"
  },
  {
    "code" : "BR0362259",
    "display" : "Cloridrato de Trazodona 100mg Comprimido"
  },
  {
    "code" : "BR0362260",
    "display" : "Cloridrato de Trazodona 150mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0362266",
    "display" : "Aprepitanto 80mg Cápsula"
  },
  {
    "code" : "BR0362661-1",
    "display" : "Fosfato de Clindamicina 20mg/1g Creme vaginal; frasco"
  },
  {
    "code" : "BR0362661-2",
    "display" : "Fosfato de Clindamicina 20mg/1g Creme vaginal; frasco"
  },
  {
    "code" : "BR0362718",
    "display" : "Bisoprolol 5mg comprimido revestido"
  },
  {
    "code" : "BR0362719",
    "display" : "Bisoprolol 1,25mg comprimido revestido"
  },
  {
    "code" : "BR0362720",
    "display" : "Bisoprolol 2.5mg comprimido revestido"
  },
  {
    "code" : "BR0362721",
    "display" : "Bisoprolol 10mg comprimido revestido"
  },
  {
    "code" : "BR0362802",
    "display" : "Vildagliptina 50mg comprimido"
  },
  {
    "code" : "BR0363379",
    "display" : "Cloridrato de Quinina 100mg + Papaverina 40mg drágea"
  },
  {
    "code" : "BR0363560",
    "display" : "Diclofenaco Sódico 50mg + Cloridrato de Piridoxina 50mg + Cianocobalamina 1mg + Nitrato de Tiamina 50mg comprimido revestido"
  },
  {
    "code" : "BR0363561",
    "display" : "Dexametasona 1,5mg/1mL + Dipirona 500mg/1mL + Hidroxocobalamina 5.000micrograma/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0363597-1",
    "display" : "Permetrina 50mg/1mL Loção; frasco"
  },
  {
    "code" : "BR0363597-2",
    "display" : "Permetrina 50mg/1mL Loção; frasco"
  },
  {
    "code" : "BR0363778",
    "display" : "Flunitrazepam 2mg comprimido revestido"
  },
  {
    "code" : "BR0363843",
    "display" : "Atazanavir 300mg cápsula"
  },
  {
    "code" : "BR0363933",
    "display" : "Maraviroque 150mg comprimido revestido"
  },
  {
    "code" : "BR0363934",
    "display" : "Maraviroque 300mg comprimido revestido"
  },
  {
    "code" : "BR0364037",
    "display" : "Rifampicina 150mg + Etambutol 275mg + Isoniazida 75mg + Pirazinamida 400mg comprimido revestido"
  },
  {
    "code" : "BR0364324",
    "display" : "Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0364780",
    "display" : "Aripiprazol 10mg comprimido"
  },
  {
    "code" : "BR0364781",
    "display" : "Aripiprazol 20mg comprimido"
  },
  {
    "code" : "BR0364789",
    "display" : "Isotretinoína 0,5mg/1g Gel"
  },
  {
    "code" : "BR0364816",
    "display" : "Lenalidomida 25mg Cápsula"
  },
  {
    "code" : "BR0364917",
    "display" : "Besilato de Anlodipino 5mg + Cloridrato de Benazepril 20mg cápsula"
  },
  {
    "code" : "BR0365047",
    "display" : "Lenalidomida 5mg cápsula"
  },
  {
    "code" : "BR0365048",
    "display" : "Lenalidomida 10mg Cápsula"
  },
  {
    "code" : "BR0365441",
    "display" : "Cloridrato de Oxibutinina 10mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0365451",
    "display" : "Abatacepte 250mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0365451E",
    "display" : "Abatacepte 250mg Pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0365454",
    "display" : "Sorbitol 714mg/1g + Laurilsulfato de Sódio 7,7mg/1g Solução retal; bisnaga"
  },
  {
    "code" : "BR0366861",
    "display" : "Peróxido de Benzoíla 50mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0366861 -2",
    "display" : "Peróxido de Benzoíla 50mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0366861-3",
    "display" : "Peróxido de Benzoíla 50mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0366883",
    "display" : "Alisquireno 150mg comprimido revestido"
  },
  {
    "code" : "BR0366884",
    "display" : "Hemifumarato de Alisquireno 300mg comprimido revestido"
  },
  {
    "code" : "BR0366914",
    "display" : "Cloridrato de Nafazolina 0,12mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0367514",
    "display" : "Hidróxido de Alumínio 230mg comprimido"
  },
  {
    "code" : "BR0367692",
    "display" : "Ácido Nicotínico 500mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0367692E",
    "display" : "Ácido Nicotínico 500mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0367693",
    "display" : "Ácido Nicotínico 750mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0367693E",
    "display" : "Ácido Nicotínico 750mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0367699",
    "display" : "Hidroxiapatita 800mg comprimido revestido"
  },
  {
    "code" : "BR0367724",
    "display" : "Entacapona 200mg + Levodopa 150mg + Carbidopa 37,5mg comprimido revestido"
  },
  {
    "code" : "BR0367725",
    "display" : "Policresuleno 50mg/1g + Cloridrato de Cinchocaína 10mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0367897",
    "display" : "Imunoglobulina Humana 500mg/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0368168",
    "display" : "Fosfato Dissódico de Dexametasona 2mg/1mL + Acetato de Dexametasona 8mg/1mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0368612",
    "display" : "Nitazoxanida 500mg comprimido revestido"
  },
  {
    "code" : "BR0368640",
    "display" : "Nitazoxanida 20mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0368654",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0368694",
    "display" : "Eculizumabe 300mg/30mL solução para infusão; frasco-ampola"
  },
  {
    "code" : "BR0368704",
    "display" : "Vitis vinifera 150mg Cápsula"
  },
  {
    "code" : "BR0368799",
    "display" : "Ubidecarenona 50mg comprimido revestido"
  },
  {
    "code" : "BR0368899",
    "display" : "Fosfato de Clindamicina 10mg/1g + Peróxido de Benzoíla 50mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0368903",
    "display" : "Bisacodil 5mg + Docusato de Sódio 60mg comprimido revestido"
  },
  {
    "code" : "BR0369106",
    "display" : "Vimpocetina 5mg Comprimido"
  },
  {
    "code" : "BR0369175E",
    "display" : "Mesalazina 10mg/1mL suspensão retal; ; frasco"
  },
  {
    "code" : "BR0369176",
    "display" : "Everolimo 0,5mg Comprimido"
  },
  {
    "code" : "BR0369176E",
    "display" : "Everolimo 0,5mg Comprimido"
  },
  {
    "code" : "BR0369178",
    "display" : "Everolimo 0,75mg comprimido"
  },
  {
    "code" : "BR0369178E",
    "display" : "Everolimo 0,75mg comprimido"
  },
  {
    "code" : "BR0369179",
    "display" : "Everolimo 1mg Comprimido"
  },
  {
    "code" : "BR0369179E",
    "display" : "Everolimo 1mg Comprimido"
  },
  {
    "code" : "BR0370117",
    "display" : "Mesilato de Etexilato de Dabigatrana 110mg Cápsula"
  },
  {
    "code" : "BR0370119",
    "display" : "Artesunato 25mg + Cloridrato de Mefloquina 55mg comprimido revestido"
  },
  {
    "code" : "BR0370119-1",
    "display" : "Artesunato 25mg + Cloridrato de Mefloquina 55mg comprimido revestido"
  },
  {
    "code" : "BR0370119-2",
    "display" : "Artesunato 25mg + Cloridrato de Mefloquina 55mg comprimido revestido"
  },
  {
    "code" : "BR0370120",
    "display" : "Artesunato 100mg + Cloridrato de Mefloquina 220mg comprimido revestido"
  },
  {
    "code" : "BR0370120-1",
    "display" : "Artesunato 100mg + Cloridrato de Mefloquina 220mg comprimido revestido"
  },
  {
    "code" : "BR0370120-2",
    "display" : "Artesunato 100mg + Cloridrato de Mefloquina 220mg comprimido revestido"
  },
  {
    "code" : "BR0370525",
    "display" : "Valsartana 160mg + Hidroclorotiazida 25mg comprimido revestido"
  },
  {
    "code" : "BR0370560",
    "display" : "Alfa1antitripsina 1.000mg/50mL Solução para infusão; frasco-ampola"
  },
  {
    "code" : "BR0371273-2",
    "display" : "Cloreto de Sódio 0,9%  solução para injeção 125 ml ; frasco"
  },
  {
    "code" : "BR0372204",
    "display" : "Dutasterida 0,5mg Cápsula"
  },
  {
    "code" : "BR0372372",
    "display" : "Sulfato de Gentamicina 5mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0373165",
    "display" : "Sulfato de Capreomicina 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0373415",
    "display" : "Daptomicina 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0373792",
    "display" : "Ibuprofeno 400mg/3g + Arginina 370mg/3g granulado; envelope"
  },
  {
    "code" : "BR0373909-1",
    "display" : "Hipromelose 3mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0373909-2",
    "display" : "Hipromelose 3mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0373909-3",
    "display" : "Hipromelose 3mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0373909-4",
    "display" : "Hipromelose 0,2mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0373910-1",
    "display" : "Hipromelose 2mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0373910-2",
    "display" : "Hipromelose 2mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0373910-3",
    "display" : "Hipromelose 2mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0373949",
    "display" : "Pindolol 10mg Comprimido"
  },
  {
    "code" : "BR0374155",
    "display" : "Isoniazida 75mg + Rifampicina 150mg comprimido"
  },
  {
    "code" : "BR0374313",
    "display" : "Ácido Paraminossalicílico 4g granulado de liberação retardada; envelope"
  },
  {
    "code" : "BR0374816",
    "display" : "Cipionato de Testosterona 200mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0374967",
    "display" : "Cloridrato de Nilotinibe Monoidratado  200mg Cápsula"
  },
  {
    "code" : "BR0375387-1",
    "display" : "Macrogol 4mg/1mL + Hidroxipropilguar 1,8mg/1mL + Propilenoglicol 3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0375387-2",
    "display" : "Macrogol 4mg/1mL + Hidroxipropilguar 1,8mg/1mL + Propilenoglicol 3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0375387-3",
    "display" : "Macrogol 4mg/1mL + Hidroxipropilguar 1,8mg/1mL + Propilenoglicol 3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0375474-1",
    "display" : "Cloreto de Sódio 9mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0375474-2",
    "display" : "Cloreto de Sódio 9mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0375474-3",
    "display" : "Cloreto de Sódio 9mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0376105",
    "display" : "Nicotina 7mg Adesivo Transdérmico"
  },
  {
    "code" : "BR0376106",
    "display" : "Nicotina 14mg Adesivo Transdérmico"
  },
  {
    "code" : "BR0376107",
    "display" : "Nicotina 21mg Adesivo Transdérmico"
  },
  {
    "code" : "BR0376357",
    "display" : "Valsartana 40mg comprimido revestido"
  },
  {
    "code" : "BR0376502",
    "display" : "Ranelato de Estrôncio 2g granulado"
  },
  {
    "code" : "BR0376502-1",
    "display" : "Ranelato de Estrôncio 2g granulado"
  },
  {
    "code" : "BR0376695",
    "display" : "Piridoxina 50mg comprimido"
  },
  {
    "code" : "BR0377008",
    "display" : "Zanamivir 5mg Pó para inalação; inalador"
  },
  {
    "code" : "BR0377422",
    "display" : "Ácido Fusídico 20mg/1g + Valerato de Betametasona 1mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0377899",
    "display" : "Valeriana Officinalis L. 50mg cápsula"
  },
  {
    "code" : "BR0378055",
    "display" : "Fosfomicina 5,631g granulado; envelope"
  },
  {
    "code" : "BR0379002",
    "display" : "Anidulafungina 100mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0379469-1",
    "display" : "Hidrato de Cloral 100mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0379469-2",
    "display" : "Hidrato de Cloral 100mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0379902",
    "display" : "Fosfato de Oseltamivir 30mg cápsula"
  },
  {
    "code" : "BR0379962",
    "display" : "Fosfato de Oseltamivir 45mg cápsula"
  },
  {
    "code" : "BR0380017",
    "display" : "Insulina Glulisina 300UI/3mL Solução para injeção; carpule"
  },
  {
    "code" : "BR0380419",
    "display" : "Bimatoprosta 0,3mg/1mL + Maleato de Timolol 5mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0380545",
    "display" : "Ritonavir 25mg + Lopinavir 100mg comprimido revestido"
  },
  {
    "code" : "BR0380823",
    "display" : "Paliperidona 6mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0380855",
    "display" : "Diclofenaco Dietilamônio 11,6mg/1g Solução aerossol; frasco"
  },
  {
    "code" : "BR0381063",
    "display" : "Sitagliptina 50mg + Metformina 500mg comprimido revestido"
  },
  {
    "code" : "BR0381066",
    "display" : "Besilato de Anlodipino 5mg + Ramipril 10mg Cápsula"
  },
  {
    "code" : "BR0381288",
    "display" : "Rifabutina 150mg cápsula"
  },
  {
    "code" : "BR0381879",
    "display" : "Omeprazol Magnésico 10mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0381880",
    "display" : "Omeprazol Magnésico 20mg comprimido revestido"
  },
  {
    "code" : "BR0381881",
    "display" : "Omeprazol Magnésico 40mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0382197",
    "display" : "Dicloridrato de Trimetazidina 35mg comprimido revestido"
  },
  {
    "code" : "BR0382939",
    "display" : "Decitabina 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383409",
    "display" : "Carmelose Sódica 5mg/1mL + Glicerol 9mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0383409-3",
    "display" : "Carmelose Sódica 5mg/1mL + Glicerol 9mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0383417",
    "display" : "Ciclesonida 160micrograma solução para inalação; dispositivo"
  },
  {
    "code" : "BR0383436",
    "display" : "Azacitidina 100mg Pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383660",
    "display" : "Brometo de Tiotrópio 2,5micrograma/1dose solução para inalação; dispositivo"
  },
  {
    "code" : "BR0383688",
    "display" : "Insulina Asparte bifásica (30/70) 100unidades/mL suspensão para injeção 3 mL; carpule"
  },
  {
    "code" : "BR0383688-1",
    "display" : "Insulina Asparte bifásica (30/70) 100unidades/mL suspensão para injeção 3 mL; dispositivo para injeção"
  },
  {
    "code" : "BR0383786",
    "display" : "Tartarato de Vinorelbina 10mg/1mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383786-1",
    "display" : "Tartarato de Vinorelbina 50mg/5mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0383788",
    "display" : "Tartarato de Vinorelbina 20mg cápsula"
  },
  {
    "code" : "BR0383790",
    "display" : "Tartarato de Vinorelbina 30mg cápsula"
  },
  {
    "code" : "BR0383791",
    "display" : "Ácido Alendrônico 70mg + Colecalciferol 2.800 unidades internacionais comprimido"
  },
  {
    "code" : "BR0384297",
    "display" : "Mercaptamina 5mg/1mL Solução oftálmica"
  },
  {
    "code" : "BR0384298",
    "display" : "Hidrocortisona 10mg comprimido"
  },
  {
    "code" : "BR0384467",
    "display" : "Nepafenaco 1mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0384537",
    "display" : "Peróxido de Benzoíla 25mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0384537-2",
    "display" : "Peróxido de Benzoíla 25mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0384830",
    "display" : "Ácido Tranexâmico 500mg comprimido"
  },
  {
    "code" : "BR0384894",
    "display" : "Cloridrato de Propafenona 150mg comprimido revestido"
  },
  {
    "code" : "BR0385153",
    "display" : "Trometamol Cetorolaco 10mg comprimido sublingual"
  },
  {
    "code" : "BR0385435",
    "display" : "Betametasona 0,5mg Comprimido"
  },
  {
    "code" : "BR0385436",
    "display" : "Betametasona 2mg Comprimido"
  },
  {
    "code" : "BR0385446",
    "display" : "Betametasona 0,5mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0385450",
    "display" : "Hidroquinona 40mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0386041",
    "display" : "Hidroxicloroquina 200mg comprimido"
  },
  {
    "code" : "BR0386396",
    "display" : "Amoxicilina 80mg + Clavulanato de Potássio 11,4mg pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0386846",
    "display" : "Policarbofila Cálcica 625mg comprimido revestido"
  },
  {
    "code" : "BR0386959",
    "display" : "Paracetamol 32mg/mL suspensão oral"
  },
  {
    "code" : "BR038719",
    "display" : "Acitretina 10mg cápsula"
  },
  {
    "code" : "BR0387341",
    "display" : "Fumarato de Formoterol Di-Hidratado 6micrograma + Budesonida 200micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0387341E",
    "display" : "Fumarato de Formoterol Di-Hidratado 6micrograma + Budesonida 200micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0387359-1",
    "display" : "Papaína 2% gel; frasco"
  },
  {
    "code" : "BR0387438",
    "display" : "Cafeína 5mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0387981",
    "display" : "Risperidona 25mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0387982",
    "display" : "Risperidona 37,5mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0387983",
    "display" : "Risperidona 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0387985",
    "display" : "Dicloridrato de Zuclopentixol 25mg comprimido revestido"
  },
  {
    "code" : "BR0388383-1",
    "display" : "Tocilizumabe 80mg/4mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0388383-2",
    "display" : "Tocilizumabe 200mg/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0388383E",
    "display" : "Tocilizumabe 80mg/4mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0388387",
    "display" : "Levodopa 50mg + Carbidopa 12,5mg + Entacapona 200mg comprimido revestido"
  },
  {
    "code" : "BR0388392",
    "display" : "Rosuvastatina Cálcica 40mg comprimido revestido"
  },
  {
    "code" : "BR0388399",
    "display" : "Olmesartana 20mg + Anlodipino 5mg comprimido revestido"
  },
  {
    "code" : "BR0388401",
    "display" : "Olmesartana 40mg + Anlodipino 5mg comprimido revestido"
  },
  {
    "code" : "BR0388402",
    "display" : "Olmesartana 40mg + Besilato de Anlodipino 10mg comprimido revestido"
  },
  {
    "code" : "BR0388403",
    "display" : "Glimepirida 3mg Comprimido"
  },
  {
    "code" : "BR0388555",
    "display" : "Aspartato de Ornitina 5g/10mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0388569",
    "display" : "Ibandronato de Sódio Monoidratado 150mg comprimido"
  },
  {
    "code" : "BR0388712",
    "display" : "Pregabalina 75mg cápsula"
  },
  {
    "code" : "BR0388796",
    "display" : "Cloridrato de Metformina 500mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0388797",
    "display" : "Cloridrato de Metformina 750mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0388866",
    "display" : "Alentuzumabe 30mg/ 1 mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0389398",
    "display" : "Trióxido de Arsênio 10mg/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0389480",
    "display" : "Tobramicina 60mg/1mL solução para inalação; ampola"
  },
  {
    "code" : "BR0389637-2",
    "display" : "Cloridrato de Fexofenadina 6mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0389710",
    "display" : "Adapaleno 3mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0389802",
    "display" : "Etinilestradiol 0.015mg + Gestodeno 0.06mg comprimido revestido"
  },
  {
    "code" : "BR0389863-1",
    "display" : "Sugamadex Sódico 500mg/5mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0389957-1",
    "display" : "Dipirona 300mg + Butilbrometo de Escopolamina 6,5micrograma + Bromidrato de Hiosciamina 104micrograma + Metilbrometo de Homatropina 1mg comprimido"
  },
  {
    "code" : "BR0389957-2",
    "display" : "Dipirona Monoidratada 300mg/1mL + Bromidrato de Homatropina 1mg/1mL + Butilbrometo de Escopolamina 6,5micrograma/1mL + Bromidrato de Hiosciamina 104micrograma/1mL solução oral; frasco"
  },
  {
    "code" : "BR0390005",
    "display" : "Hemifumarato de Quetiapina 50mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0390006",
    "display" : "Hemifumarato de Quetiapina 300mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0390006E",
    "display" : "Hemifumarato de Quetiapina 300mg comprimido revestido"
  },
  {
    "code" : "BR0390007",
    "display" : "Hemifumarato de Quetiapina 200mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0390008-2",
    "display" : "Cetuximabe 100mg/20mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390008-4",
    "display" : "Cetuximabe 500mg/100mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390333",
    "display" : "Tipranavir 100mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0390354",
    "display" : "Fosamprenavir Cálcico 50mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0390440-1",
    "display" : "Exenatida 300micrograma/1,2mL solução para injeção; dispositivo de injeção pré-carregado"
  },
  {
    "code" : "BR0390440-2",
    "display" : "Exenatida 600micrograma/2,4mL solução para injeção; dispositivo de injeção pré-carregado"
  },
  {
    "code" : "BR0390441-1",
    "display" : "Carbômer 0.3% gel oftálmico"
  },
  {
    "code" : "BR0390441-2",
    "display" : "Carbômer 0.3% gel oftálmico"
  },
  {
    "code" : "BR0390598-2",
    "display" : "Fator VIII de Coagulação (Recombinante) 500UI Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0390643",
    "display" : "Tensirolimo 30mg/1,2mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0391324",
    "display" : "Hidroquinona 40mg/1g + Fluocinolona Acetonida 0,1mg/1g + Tretinoína 0,5mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0391336",
    "display" : "Alfataliglicerase 200unidade pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0391336E",
    "display" : "Alfataliglicerase 200unidade pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0391938",
    "display" : "Colecalciferol 3.300UI/1mL solução oral; frasco"
  },
  {
    "code" : "BR0392111",
    "display" : "Pregabalina 150mg Cápsula"
  },
  {
    "code" : "BR0392113",
    "display" : "Risperidona 0,25mg comprimido revestido"
  },
  {
    "code" : "BR0392113/00111",
    "display" : "Risperidona 0,25mg comprimido revestido"
  },
  {
    "code" : "BR0392114",
    "display" : "Risperidona 0,5mg comprimido revestido"
  },
  {
    "code" : "BR0392118-1",
    "display" : "Simeticona 75mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0392118-2",
    "display" : "Simeticona 75mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0392118-3",
    "display" : "Simeticona 75mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0392118-4",
    "display" : "Simeticona 75mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0392264",
    "display" : "Carbamazepina 20mg/1mL Xarope"
  },
  {
    "code" : "BR0392403",
    "display" : "Tartarato de Brimonidina 1mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0392423",
    "display" : "Dexpantenol 50mg/g pomada"
  },
  {
    "code" : "BR0392593",
    "display" : "Hidróxido de Alumínio 178mg + Hidróxido de Magnésio 185mg + Carbonato de Cálcio 231,5mg pastilha"
  },
  {
    "code" : "BR0392617",
    "display" : "Tianfenicol 500mg comprimido"
  },
  {
    "code" : "BR0392662",
    "display" : "Cetoprofeno 160mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0392663",
    "display" : "Cetoprofeno 320mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0392708",
    "display" : "Sitagliptina 50mg + Metformina 850mg comprimido revestido"
  },
  {
    "code" : "BR0392714",
    "display" : "Óxido de Zinco 200mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0392760",
    "display" : "Propionato de Fluticasona 250micrograma/1dose suspensão aerossol; inalador"
  },
  {
    "code" : "BR0393034",
    "display" : "Saxagliptina 5mg comprimido revestido"
  },
  {
    "code" : "BR0393138",
    "display" : "Everolimo 5mg Comprimido"
  },
  {
    "code" : "BR0393139",
    "display" : "Everolimo 10mg comprimido"
  },
  {
    "code" : "BR0393161",
    "display" : "Levotiroxina Sódica 38micrograma comprimido"
  },
  {
    "code" : "BR0393327",
    "display" : "Cloridrato de Ciprofloxacino 2mg/1mL + Hidrocortisona 10mg/1mL Suspensão otológica; frasco"
  },
  {
    "code" : "BR0393328",
    "display" : "Cloreto de Potássio 60mg/1mL Xarope"
  },
  {
    "code" : "BR0393331",
    "display" : "Desogestrel 0,15mg + Etinilestradiol 0,03mg Comprimido"
  },
  {
    "code" : "BR0393342-1",
    "display" : "Pelargonium Sidoides Dc. 825mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0393342-2",
    "display" : "Pelargonium Sidoides Dc. 825mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0393493",
    "display" : "Sulfato de Tuaminoeptano 5mg/1mL + Acetilcisteína 10mg/1mL Solução nasal; frasco"
  },
  {
    "code" : "BR0393565",
    "display" : "Furazolidona 200mg comprimido"
  },
  {
    "code" : "BR0393705",
    "display" : "Silimarina 140mg cápsula"
  },
  {
    "code" : "BR0393729",
    "display" : "Cloridrato de Oxicodona 10mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0393730",
    "display" : "Cloridrato de Oxicodona 20mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0393731",
    "display" : "Cloridrato de Oxicodona 40mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0393740",
    "display" : "Levonorgestrel 0,1mg + Etinilestradiol 0,02mg comprimido revestido"
  },
  {
    "code" : "BR0393779",
    "display" : "Darunavir 75mg comprimido revestido"
  },
  {
    "code" : "BR0393780",
    "display" : "Darunavir 600mg comprimido revestido"
  },
  {
    "code" : "BR0393781",
    "display" : "Darunavir 150mg comprimido revestido"
  },
  {
    "code" : "BR0393803",
    "display" : "Ácido Fólico 5mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0393808",
    "display" : "Valsartana 160mg + Besilato de Anlodipino 10mg comprimido revestido"
  },
  {
    "code" : "BR0393831",
    "display" : "Cloridrato de Ciclobenzaprina 5mg + Clonixinato de Lisina 125mg comprimido revestido"
  },
  {
    "code" : "BR0393886",
    "display" : "Enfuvirtida 180mg/2mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0393920",
    "display" : "Etonogestrel 68mg implante; dispositivo"
  },
  {
    "code" : "BR0393953",
    "display" : "Temozolomida 140mg Cápsula"
  },
  {
    "code" : "BR0393999",
    "display" : "Benzoato de Sódio 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0394026",
    "display" : "Cloridrato de Levobupivacaína 50mg/20mL + Hemitartarato de Epinefrina 0,182mg/20mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394103",
    "display" : "Rivaroxabana 10mg comprimido revestido"
  },
  {
    "code" : "BR0394258",
    "display" : "Ferripolimaltose 50mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0394263-1",
    "display" : "Hidroxizina 2mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0394263-2",
    "display" : "Cloridrato de Hidroxizina 2mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0394310",
    "display" : "Betainterferona 1a Recombinante 22micrograma/0,5mL Solução para injeção"
  },
  {
    "code" : "BR0394311",
    "display" : "Betainterferona 1a Recombinante 44micrograma/0,5mL solução para injeção"
  },
  {
    "code" : "BR0394314",
    "display" : "Betainterferona 1a 30micrograma/0,5mL Solução para injeção"
  },
  {
    "code" : "BR0394662",
    "display" : "Sulfato de Neomicina 5mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0394667",
    "display" : "Nifedipino 60mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0394675-1",
    "display" : "Cloreto de Sódio 6,371mg/mL + Acetato de Sódio 3,95 mg/mL + Cloreto de Potássio 0,746 mg/mL + Cloreto de Cálcio 0,515 mg/mL + Cloreto de Magnésio 0,305 mg/mL + Citrato de Sódio 1,67 mg/mL solução oftálmica 250 mL; bolsa"
  },
  {
    "code" : "BR0394675-2",
    "display" : "Cloreto de Sódio 6,371mg/mL + Acetato de Sódio 3,95 mg/mL + Cloreto de Potássio 0,746 mg/mL + Cloreto de Cálcio 0,515 mg/mL + Cloreto de Magnésio 0,305 mg/mL + Citrato de Sódio 1,67 mg/mL solução oftálmica 500 mL; bolsa"
  },
  {
    "code" : "BR0394677E",
    "display" : "Alfavelaglicerase 200UI pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394678E",
    "display" : "Alfavelaglicerase 400unidade pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394681",
    "display" : "Fibrinogênio 1g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394754",
    "display" : "Cetrimida 0,1mg/1mL + Hipromelose 3,2mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0394789",
    "display" : "Itraconazol 10mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0394789-1",
    "display" : "Itraconazol 10mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0394804",
    "display" : "Paclitaxel 100mg/16,7mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394804-4",
    "display" : "Paclitaxel 300mg/50mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0394865",
    "display" : "Ácido Tióctico 600mg comprimido revestido"
  },
  {
    "code" : "BR0394910",
    "display" : "Cloreto de Sódio 4,5mg/1g gel; frasco"
  },
  {
    "code" : "BR0394910-1",
    "display" : "Cloreto de Sódio 4,5mg/1g gel; frasco"
  },
  {
    "code" : "BR0394915",
    "display" : "Besilato de Anlodipino 2,5mg + Cloridrato de Benazepril 10mg Cápsula"
  },
  {
    "code" : "BR0394916",
    "display" : "Besilato de Anlodipino 5mg + Cloridrato de Benazepril 10mg Cápsula"
  },
  {
    "code" : "BR0395144",
    "display" : "Dicloridrato de Flufenazina 5mg comprimido revestido"
  },
  {
    "code" : "BR0395146",
    "display" : "Cobamamida 5mg comprimido mastigável"
  },
  {
    "code" : "BR0395147",
    "display" : "Diazepam 10mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0395156",
    "display" : "Maleato de Pimetixeno 0,1mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0395161",
    "display" : "Piribedil 50mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0395162",
    "display" : "Valsartana 320mg + Hidroclorotiazida 25mg comprimido revestido"
  },
  {
    "code" : "BR0395437",
    "display" : "Vildagliptina 50mg + Metformina 1.000mg comprimido revestido"
  },
  {
    "code" : "BR0395438",
    "display" : "Cloridrato de Nafazolina 1mg/1mL + Pantenol 5mg/1mL + Maleato de Mepiramina 0,2mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0395438-1",
    "display" : "Cloridrato de Nafazolina 1mg/1mL + Pantenol 5mg/1mL + Maleato de Mepiramina 0,2mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0395439",
    "display" : "Furoato de Fluticasona 27,5micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0395465",
    "display" : "Ácido Nicotínico 1g Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0395518",
    "display" : "Paracetamol 500mg + Fosfato de Codeína 15mg cápsula"
  },
  {
    "code" : "BR0395519",
    "display" : "Ibuprofeno 400mg + Paracetamol 400mg + Carisoprodol 200mg + Piridoxina 50mg cápsula"
  },
  {
    "code" : "BR0395520",
    "display" : "Aspartato de Magnésio 50mg + Ranitidina 150mg + Carbonato de Cálcio 500mg + Colecalciferol 400UI cápsula"
  },
  {
    "code" : "BR0395558",
    "display" : "Ácido Salicílico 50mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0395601",
    "display" : "Ácido Nicotínico 250mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0395601E",
    "display" : "Ácido Nicotínico 250mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0395602",
    "display" : "Ácido Gamaminobutírico 100mg/1mL + Pantotenato de Cálcio 8mg/1mL + Lisina 100mg/1mL + Tiamina 4mg/1mL + Cloridrato de Piridoxina 8mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0395608",
    "display" : "Brometo de Pinavério 50mg comprimido revestido"
  },
  {
    "code" : "BR0395609",
    "display" : "Citrato de Zinco 10mg + Ácido Ascórbico 1.000mg Comprimido efervescente"
  },
  {
    "code" : "BR0395620",
    "display" : "Glycine Max (L.) Merr. 150mg cápsula"
  },
  {
    "code" : "BR0395627",
    "display" : "Polimixina B 10.000UI/1mL + Lidocaína 40mg/1mL + Neomicina 10mg/1mL + Fludrocortisona 1mg/1mL solução otológica; frasco"
  },
  {
    "code" : "BR0395631-1",
    "display" : "Mikania Glomerata Spreng. 0,05mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0395631-2",
    "display" : "Mikania Glomerata Spreng. 0,05mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0395716-3",
    "display" : "Schinus Terebinthifolia Raddi 10% gel vaginal; bisnaga"
  },
  {
    "code" : "BR0395718",
    "display" : "Sildenafila 12,5mg Cápsula"
  },
  {
    "code" : "BR0395719",
    "display" : "Fluoxetina 60mg cápsula;"
  },
  {
    "code" : "BR0395720",
    "display" : "Carnitina 1g Cápsula"
  },
  {
    "code" : "BR0395726-1",
    "display" : "Oxomemazina 0,332mg/1mL + Paracetamol 6,66mg/1mL + Guaifenesina 6,66mg/1mL + Benzoato de Sódio 6,66mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0395726-2",
    "display" : "Oxomemazina 0,332mg/1mL + Paracetamol 6,66mg/1mL + Guaifenesina 6,66mg/1mL + Benzoato de Sódio 6,66mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0395730-1",
    "display" : "Hidróxido de Alumínio 60mg/1mL + Hidróxido de Magnésio 40mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0395730-2",
    "display" : "Hidróxido de Alumínio 60mg/1mL + Hidróxido de Magnésio 40mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0395730-3",
    "display" : "Hidróxido de Alumínio 60mg/1mL + Hidróxido de Magnésio 40mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0395797",
    "display" : "Levonorgestrel 0,05mg + Etinilestradiol 0,03 mg comprimido e Levonorgestrel 0,075 mg + Etinilestradiol 0,04 mg comprimido e Levonorgestrel 0,125 mg + Etinilestradiol 0,03 mg comprimido"
  },
  {
    "code" : "BR0395807",
    "display" : "Maleato de Timolol 5mg/1mL + Brinzolamida 10mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0395836",
    "display" : "Metronidazol 250mg/1g + Cloreto de Benzalcônio 1,25mg/1g + Nistatina 100.000UI/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0395837",
    "display" : "Alcatrão Mineral 1% Pomada; bisnaga"
  },
  {
    "code" : "BR0395845",
    "display" : "Ureia 50mg/1g Creme"
  },
  {
    "code" : "BR0395847",
    "display" : "Aloe Vera (L.) Burman F. 5% pomada; bisnaga"
  },
  {
    "code" : "BR0395886",
    "display" : "Triclosana 1% sabonete"
  },
  {
    "code" : "BR0395908",
    "display" : "Losartana Potássica 50mg + Anlodipino 5mg comprimido revestido"
  },
  {
    "code" : "BR0395910",
    "display" : "Hidroclorotiazida 12,5mg + Valsartana 320mg comprimido revestido"
  },
  {
    "code" : "BR0395947",
    "display" : "Ácido Cítrico 70mg/1mL + Citrato de Potássio 108mg/1mL + Citrato de Sódio 98mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0395949",
    "display" : "Risedronato Sódico 150mg comprimido revestido"
  },
  {
    "code" : "BR0395952",
    "display" : "Lactase 3.000UI cápsula"
  },
  {
    "code" : "BR0396029",
    "display" : "Hialuronidase 150UTR/1g + Valerato de Betametasona 2mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0396047",
    "display" : "Cloridrato de Prometazina 0,565mg/1mL + Sulfoguaiacol 9mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0396051",
    "display" : "Insulina Asparte 300unidade/3mL solução para injeção; dispositivo de injeção pré-carregado"
  },
  {
    "code" : "BR0396081",
    "display" : "Amissulprida 50mg comprimido"
  },
  {
    "code" : "BR0396087",
    "display" : "Aminaftona 75mg comprimido"
  },
  {
    "code" : "BR0396379",
    "display" : "Fosfato Sódico de Prednisolona 11mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0396450",
    "display" : "Maytenus Ilicifolia Mart. Ex Reissek 380mg Cápsula"
  },
  {
    "code" : "BR0396555",
    "display" : "Betametasona 0,1mg/1mL Elixir"
  },
  {
    "code" : "BR0396557",
    "display" : "Valsartana 160mg + Hidroclorotiazida 12,5mg + Besilato de Anlodipino 5mg comprimido revestido"
  },
  {
    "code" : "BR0396558",
    "display" : "Besilato de Anlodipino 5mg + Hidroclorotiazida 25mg + Valsartana 160mg comprimido revestido"
  },
  {
    "code" : "BR0396561",
    "display" : "Cloridrato de Hidromorfona 16mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0396668",
    "display" : "Mesilato de Codergocrina 6mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0396702",
    "display" : "Cloridrato de Nebivolol 5mg Comprimido"
  },
  {
    "code" : "BR0396703",
    "display" : "Nimesulida Betaciclodextrina 400mg comprimido"
  },
  {
    "code" : "BR039680-1",
    "display" : "Papaína 10% gel; frasco"
  },
  {
    "code" : "BR039680-3",
    "display" : "Papaína 10% gel; frasco"
  },
  {
    "code" : "BR0396853-1",
    "display" : "Cloridrato de Fenilefrina 1mg/1mL + Cloridrato de Tetracaína 10mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0396853-2",
    "display" : "Cloridrato de Fenilefrina 1mg/1mL + Cloridrato de Tetracaína 10mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0396947",
    "display" : "Sulfato Ferroso Heptaidratado 50mg/1mL (Ferro 10 mg/mL) xarope; frasco"
  },
  {
    "code" : "BR0397074",
    "display" : "Cloreto de Benzalcônio 1,33mg/1mL + Cloridrato de Lidocaína 21mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0397333",
    "display" : "Brometo de Otilônio 40mg comprimido revestido"
  },
  {
    "code" : "BR0397438",
    "display" : "Glimepirida 6mg Comprimido"
  },
  {
    "code" : "BR0397450",
    "display" : "Modafinila 100mg Comprimido"
  },
  {
    "code" : "BR0397451",
    "display" : "Modafinila 200mg comprimido"
  },
  {
    "code" : "BR0397462-1",
    "display" : "Carbômer 2mg/1g + Sorbitol 48,5mg/1g Gel oftálmico"
  },
  {
    "code" : "BR0397462-2",
    "display" : "Carbômer 2mg/1g + Sorbitol 48,5mg/1g Gel oftálmico"
  },
  {
    "code" : "BR0397475",
    "display" : "Metildigoxina 0,1mg Comprimido"
  },
  {
    "code" : "BR0397542",
    "display" : "Alfafolitropina 300UI/0,5mL Solução para injeção"
  },
  {
    "code" : "BR0397544",
    "display" : "Alfafolitropina 900UI/1,5mL Solução para injeção"
  },
  {
    "code" : "BR0397549",
    "display" : "Menotropina 75UI Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0397566",
    "display" : "Cefalexina Monoidratada 100mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0397600",
    "display" : "Sitagliptina 50mg + Metformina 1000 mg comprimido revestido"
  },
  {
    "code" : "BR0397872",
    "display" : "Hidróxido de Magnésio 85mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0397910",
    "display" : "Cistina 20mg + Nitrato de Tiamina 60mg + Pantotenato de Cálcio 60mg + Ácido Paraminobenzoico 20mg + Queratina 20mg + Levedura 100mg cápsula"
  },
  {
    "code" : "BR0397912",
    "display" : "Agomelatina 25mg comprimido revestido"
  },
  {
    "code" : "BR0398187",
    "display" : "Retinol 50.000UI/1mL + Colecalciferol 10.000UI/1mL solução oral; frasco"
  },
  {
    "code" : "BR0398268",
    "display" : "Valsartana 320mg + Besilato de Anlodipino 10mg comprimido revestido"
  },
  {
    "code" : "BR0398382",
    "display" : "Ciclesonida 50micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0398382-1",
    "display" : "Ciclesonida 50micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0398689",
    "display" : "Cloridrato de Benserazida 25mg + Levodopa 100mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0398702U0005",
    "display" : "Acetato de Medroxiprogesterona 150mg/1mL suspensão para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0398707",
    "display" : "Sulfato de Bleomicina 15UI Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0398711",
    "display" : "Propionato de Fluticasona 125micrograma/1dose + Xinafoato de Salmeterol 25micrograma/1dose suspensão aerossol; frasco"
  },
  {
    "code" : "BR0398939",
    "display" : "Ibandronato de Sódio Monoidratado 3mg/3mL Solução para injeção"
  },
  {
    "code" : "BR0399052",
    "display" : "Bicarbonato de Sódio 63,7mg + Carbonato Básico de Bismuto 3,3mg + Carbonato de Cálcio 521mg + Carbonato de Magnésio 67mg pastilha"
  },
  {
    "code" : "BR0399065",
    "display" : "Cloridrato de Triexifenidil 2mg comprimido"
  },
  {
    "code" : "BR0399161",
    "display" : "Clemastina 1mg/1g + Dexametasona 0,5mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0399410",
    "display" : "Harpagophytum Procumbens Dc. Ex Meissn. 500mg cápsula"
  },
  {
    "code" : "BR0399412",
    "display" : "Maytenus Ilicifolia Mart. Ex Reissek 500mg cápsula"
  },
  {
    "code" : "BR0399413",
    "display" : "Rhamnus Purshiana 500mg cápsula"
  },
  {
    "code" : "BR0399415",
    "display" : "Melilotus Officinalis 26.7mg comprimido revestido"
  },
  {
    "code" : "BR0399441",
    "display" : "Uncaria Tomentosa (Willd. Ex Roem. & Schult.) Dc. 50mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0399597",
    "display" : "Diazóxido 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0399636",
    "display" : "Rhamnus Purshiana 75mg cápsula"
  },
  {
    "code" : "BR0399799",
    "display" : "Sultiamo 50mg Comprimido"
  },
  {
    "code" : "BR0399988",
    "display" : "Ferripolimaltose 100mg + Ácido Fólico 0,35mg comprimido mastigável"
  },
  {
    "code" : "BR0399995",
    "display" : "Posaconazol 40mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0399996",
    "display" : "Cloridrato de Pazopanibe 400mg comprimido revestido"
  },
  {
    "code" : "BR0399997",
    "display" : "Cloridrato de Pazopanibe 200mg comprimido revestido"
  },
  {
    "code" : "BR0400002",
    "display" : "Cabazitaxel 60mg/1,5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0400091",
    "display" : "Atorvastatina 10mg + Anlodipino 5mg comprimido revestido"
  },
  {
    "code" : "BR0400390",
    "display" : "Dicloridrato de Buclizina 25mg Comprimido"
  },
  {
    "code" : "BR0400436",
    "display" : "Valproato de Sódio 500mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0400470",
    "display" : "Lisado Bacteriano E. Coli 6mg Cápsula"
  },
  {
    "code" : "BR0400476",
    "display" : "Paricalcitol 5micrograma/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0400480",
    "display" : "Drospirenona 2mg + Estradiol Hemi-Hidratado 1mg comprimido revestido"
  },
  {
    "code" : "BR0400486",
    "display" : "Bortezomibe 1mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0400563",
    "display" : "Ustequinumabe 45mg/0,5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0400564-1",
    "display" : "Arteméter 20mg + Lumefantrina 120mg comprimido"
  },
  {
    "code" : "BR0400564-2",
    "display" : "Arteméter 20mg + Lumefantrina 120mg comprimido"
  },
  {
    "code" : "BR0400564-3",
    "display" : "Arteméter 20mg + Lumefantrina 120mg comprimido"
  },
  {
    "code" : "BR0400564-4",
    "display" : "Arteméter 20mg + Lumefantrina 120mg comprimido"
  },
  {
    "code" : "BR0400579",
    "display" : "Cordia Verbenacea Dc. 5mg/1g solução aerossol"
  },
  {
    "code" : "BR0400852",
    "display" : "Ticagrelor 90mg comprimido revestido"
  },
  {
    "code" : "BR0400853",
    "display" : "Ivabradina 5mg comprimido revestido"
  },
  {
    "code" : "BR0400854",
    "display" : "Ivabradina 7,5mg comprimido revestido"
  },
  {
    "code" : "BR0400927",
    "display" : "Diosmina 900mg/5g + Hesperidina 100mg/5g granulado para suspensão; envelope"
  },
  {
    "code" : "BR0400973",
    "display" : "Glicinato Férrico 250mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0401321",
    "display" : "Amissulprida 200mg comprimido"
  },
  {
    "code" : "BR0401324",
    "display" : "Insulina Lispro 150UI/3mL + Insulina Lispro Protamina 150UI/3mL Suspensão para injeção"
  },
  {
    "code" : "BR0401411",
    "display" : "Óxido de Zinco 100mg/1g + Colecalciferol 1.000UI/1g + Retinol 400UI/1g pomada; bisnaga"
  },
  {
    "code" : "BR0401579",
    "display" : "Brosimum gaudichaudii 200mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0401579-1",
    "display" : "Brosimum gaudichaudii 200mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0402195",
    "display" : "Drospirenona 3mg + Etinilestradiol 0,02mg comprimido revestido"
  },
  {
    "code" : "BR0402259",
    "display" : "Mesilato de Etexilato de Dabigatrana 150mg Cápsula"
  },
  {
    "code" : "BR0402531",
    "display" : "Betafolitropina 300UI/0,48mL Solução para injeção; carpule"
  },
  {
    "code" : "BR0402625",
    "display" : "Minociclina 100mg cápsula"
  },
  {
    "code" : "BR0402991",
    "display" : "Saxagliptina 2,5mg comprimido revestido"
  },
  {
    "code" : "BR0403023",
    "display" : "Sulfato de Salbutamol 1mg/1mL solução para inalação; ampola"
  },
  {
    "code" : "BR0403033",
    "display" : "Panitumumabe 100mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0403359-2",
    "display" : "Insulina Glulisina 1.000UI/10mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0403473",
    "display" : "Palmitato de Retinol 10mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0403990",
    "display" : "Roflumilaste 500 micrograma comprimido revestido"
  },
  {
    "code" : "BR0403991",
    "display" : "Dipropionato de Betametasona 20mg/1mL + Ácido Salicílico 0,5mg/1mL solução cutânea; frasco"
  },
  {
    "code" : "BR0404151",
    "display" : "Papaína 6% Gel; frasco"
  },
  {
    "code" : "BR0404174",
    "display" : "Hidroxibenzoato de Viminol 70mg Cápsula"
  },
  {
    "code" : "BR0404346",
    "display" : "Maleato de Indacaterol 150micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0404403",
    "display" : "Cloridrato de Delapril 30mg + Dicloridrato de Manidipino 10mg Comprimido"
  },
  {
    "code" : "BR0404404",
    "display" : "Hypericum Perforatum 300mg Cápsula"
  },
  {
    "code" : "BR0404405",
    "display" : "Passiflora Incarnata 360mg comprimido revestido"
  },
  {
    "code" : "BR0404406",
    "display" : "Silybum Marianum (L.) Gaertn. 100mg comprimido revestido"
  },
  {
    "code" : "BR0404421-1",
    "display" : "Stryphnodendron barbatiman 60mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0404421-2",
    "display" : "Stryphnodendron barbatiman 60mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0404425-1",
    "display" : "Benzocaína 45mg/1g + Triclosana 5mg/1g + Mentol 5mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0404425-2",
    "display" : "Benzocaína 45mg/1g + Triclosana 5mg/1g + Mentol 5mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0404429",
    "display" : "Glicinato de Magnésio 722,2mg + Cloridrato de Piridoxina 1mg comprimido revestido"
  },
  {
    "code" : "BR0404443",
    "display" : "Aspartato de Ornitina 60mg + Cloridrato de Arginina 185mg + Citrulina 5mg comprimido revestido"
  },
  {
    "code" : "BR0404448",
    "display" : "Maleato de Indacaterol 300micrograma Cápsula para inalação"
  },
  {
    "code" : "BR0404511",
    "display" : "Echinacea Purpurea (L.) Moench 40mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0404655",
    "display" : "Ambrisentana 5mg comprimido revestido"
  },
  {
    "code" : "BR0404655E",
    "display" : "Ambrisentana 5mg comprimido revestido"
  },
  {
    "code" : "BR0404656",
    "display" : "Ambrisentana 10mg comprimido revestido"
  },
  {
    "code" : "BR0404656E",
    "display" : "Ambrisentana 10mg comprimido revestido"
  },
  {
    "code" : "BR0404690",
    "display" : "Glycine Max (L.) Merr. 75mg cápsula"
  },
  {
    "code" : "BR0404790",
    "display" : "Boceprevir 200mg Cápsula"
  },
  {
    "code" : "BR0404790E",
    "display" : "Boceprevir 200mg Cápsula"
  },
  {
    "code" : "BR0405149",
    "display" : "Captopril 10mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR040521",
    "display" : "Pemetrexede Dissódico Heptaidratado 100mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0405219",
    "display" : "Candesartana 16mg + Felodipino 2,5mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0405220",
    "display" : "Candesartana 16mg + Felodipino 5mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0405899",
    "display" : "Succinato de Desvenlafaxina Monoidratado 100mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0405900",
    "display" : "Benzocaína 45mg/1g + Triclosana 5mg/1g + Mentol 5mg/1g solução aerossol; Tubo"
  },
  {
    "code" : "BR0405962",
    "display" : "Nimotuzumabe 50mg/10mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0405965",
    "display" : "Insulina Lispro Protamina 225UI/3mL + Insulina Lispro 75UI/3mL Suspensão para injeção"
  },
  {
    "code" : "BR0405997",
    "display" : "Bimatoprosta 0,1mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0405997-1",
    "display" : "Bimatoprosta 0,1mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0405998",
    "display" : "Insulina Lispro 300UI/3mL solução para injeção; dispositivo de injeção pré-carregado"
  },
  {
    "code" : "BR0406003",
    "display" : "Piper Methysticum 234mg Cápsula"
  },
  {
    "code" : "BR0406013",
    "display" : "Valerato de Estradiol 1mg comprimido revestido"
  },
  {
    "code" : "BR0406015-1",
    "display" : "Cloridrato de Oxibutinina 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0406015-2",
    "display" : "Cloridrato de Oxibutinina 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0406015-3",
    "display" : "Cloridrato de Oxibutinina 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0406081",
    "display" : "Lornoxicam 8mg comprimido revestido"
  },
  {
    "code" : "BR0406230",
    "display" : "Solifenacina 5mg comprimido revestido"
  },
  {
    "code" : "BR0406231",
    "display" : "Solifenacina 10mg comprimido revestido"
  },
  {
    "code" : "BR0406477",
    "display" : "Dexametasona 1mg + Neomicina 5mg creme; bisnaga"
  },
  {
    "code" : "BR0406485",
    "display" : "Betaepoetina Metoxipolietilenoglicol 50micrograma/0,3mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0406487",
    "display" : "Levocetirizina 5mg comprimido revestido"
  },
  {
    "code" : "BR0406518",
    "display" : "Docetaxel Tri-Hidratado 20mg/1mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406518-1",
    "display" : "Docetaxel Tri-Hidratado 80mg/4mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406520E",
    "display" : "Alfaepoetina 3.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406602",
    "display" : "Hemifumarato de Alisquireno 300mg + Hidroclorotiazida 12,5mg Comprimido"
  },
  {
    "code" : "BR0406799",
    "display" : "Sulfato Ferroso Heptaidratado 68mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0406975",
    "display" : "Ácido Valproico 1.000mg/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406975-1",
    "display" : "Ácido Valpróico 200mg/2 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0406975-3",
    "display" : "Ácido Valproico 500mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0406992",
    "display" : "Nimesulida 200mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0406994",
    "display" : "Passiflora Incarnata 300mg comprimido revestido"
  },
  {
    "code" : "BR0407013",
    "display" : "Mentol 150mg/g + Cânfora 100 mg/g + Salicilato de Metila 80 mg/g + Óleo de Eucalipto 50 mg/g pomada"
  },
  {
    "code" : "BR0407013-1",
    "display" : "Mentol 150mg/g + Cânfora 100 mg/g + Salicilato de Metila 80 mg/g + Óleo de Eucalipto 50 mg/g pomada"
  },
  {
    "code" : "BR0407030-1",
    "display" : "Sulfato de Magnésio 990mg pó para solução oral; frasco"
  },
  {
    "code" : "BR0407030-2",
    "display" : "Sulfato de Magnésio 990mg pó para solução oral; frasco"
  },
  {
    "code" : "BR0407033",
    "display" : "Valproato de Sódio 300mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0407036",
    "display" : "Valeriana Officinalis L. 250mg + Humulus Lupulus L. 60mg comprimido revestido"
  },
  {
    "code" : "BR0407039",
    "display" : "Ciproeptadina 0,8mg/1mL + Cobamamida 0,2mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0407066",
    "display" : "Cloridrato de Metformina 1.000mg + Glimepirida 4mg comprimido revestido"
  },
  {
    "code" : "BR0407075",
    "display" : "Cloridrato de Ciclobenzaprina 5mg + Cafeína 30mg comprimido revestido"
  },
  {
    "code" : "BR0407214",
    "display" : "Linagliptina 5mg comprimido revestido"
  },
  {
    "code" : "BR0407326",
    "display" : "Dimesilato de Lisdexanfetamina 70mg Cápsula"
  },
  {
    "code" : "BR0407327",
    "display" : "Dimesilato de Lisdexanfetamina 50mg cápsula"
  },
  {
    "code" : "BR0407328",
    "display" : "Dimesilato de Lisdexanfetamina 30mg Cápsula"
  },
  {
    "code" : "BR0407441",
    "display" : "Dipropionato de Beclometasona 100micrograma/1dose + Fumarato de Formoterol 6micrograma/1dose Solução aerossol"
  },
  {
    "code" : "BR0407531",
    "display" : "Liraglutida 18mg/3mL solução para injeção"
  },
  {
    "code" : "BR0407704",
    "display" : "Cloridrato de Prasugrel  5mg comprimido revestido"
  },
  {
    "code" : "BR0407705",
    "display" : "Cloridrato de Prasugrel  10mg comprimido revestido"
  },
  {
    "code" : "BR0407989",
    "display" : "Ribavirina 200mg cápsula"
  },
  {
    "code" : "BR0408470",
    "display" : "Mesalazina 1.200mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0408498",
    "display" : "Passiflora Incarnata 0,1mL/1mL + Crataegus Oxyacantha 0,7mL/1mL + Salix Alba 50mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0409539",
    "display" : "Benznidazol 12,5mg comprimido"
  },
  {
    "code" : "BR0409591",
    "display" : "Dicloridrato de Pramipexol 0,375mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0409592",
    "display" : "Dicloridrato de Pramipexol 3mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0410019",
    "display" : "Eltrombopague 25mg comprimido revestido"
  },
  {
    "code" : "BR0410020",
    "display" : "Eltrombopague 50mg comprimido revestido"
  },
  {
    "code" : "BR0410023",
    "display" : "Dipirona Monoidratada 1g Comprimido"
  },
  {
    "code" : "BR0410047",
    "display" : "Vaccinium Macrocarpon Aiton 400mg Cápsula"
  },
  {
    "code" : "BR0410714",
    "display" : "Hidrato de Cloral 160mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0410989",
    "display" : "Benfotiamina 150mg comprimido revestido"
  },
  {
    "code" : "BR0411397-3",
    "display" : "Palmitato de Paliperidona 75mg/0,75mL Suspensão para injeção"
  },
  {
    "code" : "BR0412031",
    "display" : "Dasatinibe 100mg comprimido revestido"
  },
  {
    "code" : "BR0412091",
    "display" : "Rivaroxabana 20mg comprimido revestido"
  },
  {
    "code" : "BR0412092",
    "display" : "Rivaroxabana 15mg comprimido revestido"
  },
  {
    "code" : "BR0412094",
    "display" : "Cloridrato de Fingolimode 0,5mg cápsula"
  },
  {
    "code" : "BR0412094E",
    "display" : "Cloridrato de Fingolimode 0,5mg cápsula"
  },
  {
    "code" : "BR0412122",
    "display" : "Betacaroteno 5mg cápsula"
  },
  {
    "code" : "BR0412375",
    "display" : "Fosfato de Oseltamivir 25mg Cápsula"
  },
  {
    "code" : "BR0412376",
    "display" : "Oseltamivir 20mg Cápsula"
  },
  {
    "code" : "BR0412419",
    "display" : "Oseltamivir 12mg/mL suspensão oral"
  },
  {
    "code" : "BR0412431",
    "display" : "Fumarato de Rupatadina 10mg Comprimido"
  },
  {
    "code" : "BR0412432",
    "display" : "Cloreto de Sódio 17,55% Solução para injeção; frasco"
  },
  {
    "code" : "BR0412470",
    "display" : "Telaprevir 375mg comprimido revestido"
  },
  {
    "code" : "BR0412470E",
    "display" : "Telaprevir 375mg comprimido revestido"
  },
  {
    "code" : "BR0412718",
    "display" : "Acetato de Icatibanto 30mg/3mL Solução para injeção"
  },
  {
    "code" : "BR0412776",
    "display" : "Abiraterona 250mg Comprimido"
  },
  {
    "code" : "BR0412786",
    "display" : "Ácido Fólico 4mg + Cianocobalamina 0,4mg + Cloridrato de Piridoxina 0,8mg comprimido revestido"
  },
  {
    "code" : "BR0412830",
    "display" : "Brentuximabe Vedotina 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0412833",
    "display" : "Tadalafila 5mg comprimido revestido"
  },
  {
    "code" : "BR0412840",
    "display" : "Bilastina 20mg Comprimido"
  },
  {
    "code" : "BR0412963",
    "display" : "Simeticona 40mg Comprimido"
  },
  {
    "code" : "BR0412965",
    "display" : "Simeticona 75mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0412965-1",
    "display" : "Simeticona 75mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0412965-2",
    "display" : "Simeticona 75mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0413041",
    "display" : "Plerixafor 24mg/1,2mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0413606",
    "display" : "Midodrina 5mg comprimido"
  },
  {
    "code" : "BR0413607",
    "display" : "Midodrina 2,5 comprimido"
  },
  {
    "code" : "BR0413608",
    "display" : "Midodrina 10mg comprimido"
  },
  {
    "code" : "BR0413768",
    "display" : "Cloridrato de Bupropiona 300mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0413882",
    "display" : "Colecalciferol 5.600UI + Alendronato de Sódio Tri-Hidratado 70mg Comprimido"
  },
  {
    "code" : "BR0414431",
    "display" : "Golimumabe 50mg/0,5mL Solução para injeção"
  },
  {
    "code" : "BR0414431E",
    "display" : "Golimumabe 50mg/0,5mL Solução para injeção"
  },
  {
    "code" : "BR0414435E",
    "display" : "Certolizumabe Pegol 200mg/1mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0414454",
    "display" : "Carnitina 50mg/1mL Xarope"
  },
  {
    "code" : "BR0414456",
    "display" : "Benzoato de Sódio 200mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0414456-1",
    "display" : "Benzoato de Sódio 200mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0414456-2",
    "display" : "Benzoato de Sódio 200mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0414657",
    "display" : "Tobramicina 75mg/1mL Solução para inalação"
  },
  {
    "code" : "BR0414847",
    "display" : "Carbonato de Lodenafila 80mg Comprimido"
  },
  {
    "code" : "BR0414848",
    "display" : "Terconazol 8mg/1g Creme vaginal; bisnaga"
  },
  {
    "code" : "BR0415027",
    "display" : "Podofilotoxina 20% solução cutânea"
  },
  {
    "code" : "BR0415213",
    "display" : "Colecalciferol 200UI + Alendronato de Sódio Tri-Hidratado 70mg + Carbonato de Cálcio 500mg comprimido revestido"
  },
  {
    "code" : "BR0415504",
    "display" : "Alantoína 10mg/1g + Heparina Sódica 0,4mg/1g + Alli Cepae L. 100mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0415509",
    "display" : "Tafluprosta 15micrograma/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0415778",
    "display" : "Hemifumarato de Alisquireno 150mg + Hidroclorotiazida 12,5mg comprimido revestido"
  },
  {
    "code" : "BR0416731",
    "display" : "Medroxiprogesterona 25mg/0.5mL + Estradiol 5mg/0.5mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0416784",
    "display" : "Macrogol 4000 10g Granulado para solução"
  },
  {
    "code" : "BR0417026",
    "display" : "Maleato de Asenapina 5mg Comprimido sublingual"
  },
  {
    "code" : "BR0417028",
    "display" : "Maleato de Asenapina 10mg comprimido sublingual"
  },
  {
    "code" : "BR0417032",
    "display" : "Cefalexina Monoidratada 1g comprimido revestido"
  },
  {
    "code" : "BR0417156",
    "display" : "Cloreto de Metiltionínio 20mg + Metenamina 120mg drágea"
  },
  {
    "code" : "BR0417571",
    "display" : "Trioxisaleno 10mg Cápsula"
  },
  {
    "code" : "BR0417713",
    "display" : "Gliclazida 60mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0418793",
    "display" : "Vemurafenibe 240mg comprimido revestido"
  },
  {
    "code" : "BR0420469",
    "display" : "Heparina Sódica Suína 50UI/1g + Nicotinato de Benzila 2mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0420599",
    "display" : "Sulfato de Morfina Pentaidratado 0,1mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0421223",
    "display" : "Denosumabe 60mg/1mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0421663",
    "display" : "Nitrato de Butoconazol 5mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0421665",
    "display" : "Bisglicinato Ferroso 30mg/1mL + Ácido Fólico 0,2mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0422070",
    "display" : "Ureia 20% + Ácido Salicílico 3% Creme"
  },
  {
    "code" : "BR0423916",
    "display" : "Rosuvastatina Cálcica 5mg comprimido revestido"
  },
  {
    "code" : "BR0424169",
    "display" : "Besilato de Levanlodipino 5mg Comprimido"
  },
  {
    "code" : "BR0424170",
    "display" : "Besilato de Levanlodipino 2,5mg comprimido"
  },
  {
    "code" : "BR0425182",
    "display" : "Cloridrato de Escetamina 500mg/10mL solução para injeção; ampola"
  },
  {
    "code" : "BR0425182-1",
    "display" : "Dextrocetamina 100mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0425580",
    "display" : "Hemitartarato de Zolpidem 5mg comprimido sublingual"
  },
  {
    "code" : "BR0425676",
    "display" : "Diazóxido 25mg comprimido"
  },
  {
    "code" : "BR0425719",
    "display" : "Bumetanida 1mg comprimido"
  },
  {
    "code" : "BR0425824",
    "display" : "Ubidecarenona 200mg cápsula"
  },
  {
    "code" : "BR0426071",
    "display" : "Mirtazapina 60mg cápsula"
  },
  {
    "code" : "BR0426207",
    "display" : "Lisinopril 10mg + Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0426208",
    "display" : "Besilato de Anlodipino 5mg + Telmisartana 80mg Comprimido"
  },
  {
    "code" : "BR0426668",
    "display" : "Palivizumabe 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0426668-1",
    "display" : "Palivizumabe 50mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0426759",
    "display" : "Tamarindus Indica L. 23,595mg/5g + Cassia Fistula L. 23,595mg/5g + Coriandrum Sativum L. 10,89mg/5g + Glycyrrhiza Glabra L. 4,8mg/5g + Cassia Angustifolia Vahl. 400mg/5g gel; Pote"
  },
  {
    "code" : "BR0426892",
    "display" : "Cloridrato de Tizanidina 4mg comprimido"
  },
  {
    "code" : "BR0426922",
    "display" : "Silybum Marianum (L.) Gaertn. 200mg cápsula"
  },
  {
    "code" : "BR0426931",
    "display" : "Senna Alexandrina Mill. 240mg + Coriandrum Sativum L. 5,4mg + Tamarindus Indica L. 11,7mg + Cassia Fistula L. 11,7mg cápsula"
  },
  {
    "code" : "BR0427335",
    "display" : "Tenofovir 300mg + Lamivudina 300mg + Efavirenz 600mg comprimido revestido"
  },
  {
    "code" : "BR0427409",
    "display" : "Everolimo 2,5mg comprimido"
  },
  {
    "code" : "BR0427532",
    "display" : "Pertuzumabe 420mg/14mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0427533",
    "display" : "Ipilimumabe 50mg/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0427533-1",
    "display" : "Ipilimumabe 200mg/40mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0427719",
    "display" : "Succinato de Prucaloprida 2mg comprimido revestido"
  },
  {
    "code" : "BR0428050",
    "display" : "Raltegravir 100mg comprimido"
  },
  {
    "code" : "BR0428076",
    "display" : "Fenoterol 0,05mg/1dose + Brometo de Ipratrópio 0,02mg/1dose solução aerossol; frasco"
  },
  {
    "code" : "BR0428423",
    "display" : "Fumarato de Tenofovir Desoproxila 300mg + Lamivudina 300mg comprimido revestido"
  },
  {
    "code" : "BR0428425",
    "display" : "Diosmina 900mg + Hesperidina 100mg comprimido revestido"
  },
  {
    "code" : "BR0428744-1",
    "display" : "Colecalciferol 5.600UI/1mL solução oral; frasco"
  },
  {
    "code" : "BR0428786",
    "display" : "Albumina Humana 5g/100mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0428804",
    "display" : "Bendamustina 100mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0428952",
    "display" : "Brosimum gaudichaudii 400mg comprimido"
  },
  {
    "code" : "BR0429102",
    "display" : "Fampridina 10mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0429151",
    "display" : "Ácido Gamaminobutírico 50mg + Lisina 50mg + Tiamina 2mg + Piridoxina 4mg + Pantotenato de Cálcio 4mg + comprimido"
  },
  {
    "code" : "BR0429217",
    "display" : "Fator VIII 1.000unidades internacionais + Fator von Willebrand 2.400 unidades internacionais pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0429327",
    "display" : "Piper Methysticum 20mg cápsula"
  },
  {
    "code" : "BR0429846",
    "display" : "Apixabana 5mg comprimido revestido"
  },
  {
    "code" : "BR0429847",
    "display" : "Apixabana 2,5mg comprimido revestido"
  },
  {
    "code" : "BR0429879",
    "display" : "Cloridrato de Metformina 1.000mg + Cloridrato de Saxagliptina 5mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0430050-1",
    "display" : "Arginina 250mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0430315",
    "display" : "Aflibercepte 11,12mg/0,278mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0430404",
    "display" : "Ibrutinibe 140mg cápsula"
  },
  {
    "code" : "BR0430434",
    "display" : "Colecalciferol 5.000UI comprimido revestido"
  },
  {
    "code" : "BR0431097",
    "display" : "Colecalciferol 7.000UI Cápsula"
  },
  {
    "code" : "BR0431098",
    "display" : "Colecalciferol 50.000UI Cápsula"
  },
  {
    "code" : "BR0431100",
    "display" : "Fosfato de Codeína 45mg Cápsula"
  },
  {
    "code" : "BR0431160",
    "display" : "Paracetamol 400mg + Famotidina 20mg + Tramadol 20mg cápsula"
  },
  {
    "code" : "BR0431222",
    "display" : "Ubidecarenona 300mg cápsula"
  },
  {
    "code" : "BR0431311",
    "display" : "Simeticona 5mg/1mL + Hidróxido de Alumínio 40mg/1mL + Hidróxido de Magnésio 37mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0431312",
    "display" : "Levotiroxina Sódica 137 microgramas comprimido"
  },
  {
    "code" : "BR0431314",
    "display" : "Itraconazol 20mg/1mL suspensão oral; ; frasco"
  },
  {
    "code" : "BR0431319",
    "display" : "Benzocaína 4mg/1mL + Cloreto de Cetilpiridínio 0,5mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0431569",
    "display" : "Pinus Pinaster Aiton 50mg comprimido"
  },
  {
    "code" : "BR0431570",
    "display" : "Cloridrato de Saxagliptina 2,5mg + Cloridrato de Metformina 1.000mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0431599",
    "display" : "Sofosbuvir 400mg comprimido revestido"
  },
  {
    "code" : "BR0431599E",
    "display" : "Sofosbuvir 400mg comprimido revestido"
  },
  {
    "code" : "BR0431716",
    "display" : "Esomeprazol Magnésico Tri-Hidratado 20mg + Naproxeno 500mg comprimido revestido"
  },
  {
    "code" : "BR0431717",
    "display" : "Dexametasona 0,7mg implante"
  },
  {
    "code" : "BR0431732",
    "display" : "Dicloridrato de Daclatasvir 60mg comprimido revestido"
  },
  {
    "code" : "BR0431732E",
    "display" : "Dicloridrato de Daclatasvir 60mg comprimido revestido"
  },
  {
    "code" : "BR0431752",
    "display" : "Simeprevir Sódico 150mg cápsula"
  },
  {
    "code" : "BR0431752E",
    "display" : "Simeprevir Sódico 150mg cápsula"
  },
  {
    "code" : "BR0432140",
    "display" : "Pidolato de Piridoxina 500mg comprimido revestido"
  },
  {
    "code" : "BR0432197",
    "display" : "Glycine Max (L.) Merr. 125mg comprimido revestido"
  },
  {
    "code" : "BR0432573",
    "display" : "Senna Alexandrina Mill. 50mg cápsula"
  },
  {
    "code" : "BR0432635",
    "display" : "Carboximaltose Férrica 500mg/10mL solução para injeção; ampola"
  },
  {
    "code" : "BR0432637",
    "display" : "Crizotinibe 250mg cápsula"
  },
  {
    "code" : "BR0432741",
    "display" : "Hialuronato de Sódio 1,5mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0432742",
    "display" : "Dimeticona 10mg/1mL + Magaldrato 80mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0432781",
    "display" : "Valeriana Officinalis L. 225,75mg comprimido revestido"
  },
  {
    "code" : "BR0432782",
    "display" : "Insulina Degludeca 300unidade/3mL solução para injeção; carpule"
  },
  {
    "code" : "BR0432783",
    "display" : "Pantoprazol Magnésico Di-Hidratado 40mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0432784",
    "display" : "Pertuzumabe 420mg/14mL solução para injeção; frasco-ampola + Trastuzumabe 440mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0432926",
    "display" : "Mometasona 100micrograma + Formoterol 5micrograma Suspensão aerossol"
  },
  {
    "code" : "BR0432995",
    "display" : "Mometasona 200micrograma/1dose + Formoterol 5micrograma/1dose suspensão aerossol; frasco"
  },
  {
    "code" : "BR0433019",
    "display" : "Romiplostim 250micrograma pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0433077",
    "display" : "Fenofibrato 160mg comprimido revestido"
  },
  {
    "code" : "BR0433100",
    "display" : "Furoato de Fluticasona 100micrograma/1dose + Trifenatato de Vilanterol 25micrograma/1dose Pó para inalação"
  },
  {
    "code" : "BR0433171",
    "display" : "Pitavastatina 2mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0433257",
    "display" : "Hidróxido de Alumínio 60mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0433257-1",
    "display" : "Hidróxido de Alumínio 60mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0433279",
    "display" : "Divalproato de Sódio 250mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0433428",
    "display" : "Acetato de Racealfatocoferol 300mg + Cloridrato de Piridoxina 100mg + Palmitato de Retinol 5.000UI cápsula"
  },
  {
    "code" : "BR0433494",
    "display" : "Peróxido de Ureia (carbamida) 100mg/1mL solução otológica"
  },
  {
    "code" : "BR0433514",
    "display" : "Subgalato de Bismuto 1,5mg/1g + Óxido de Zinco 45mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0433517",
    "display" : "Valerato de Estradiol 8mg + Dienogeste 5mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0433548",
    "display" : "Valsartana 320mg + Besilato de Anlodipino 10mg + Hidroclorotiazida 25mg comprimido revestido"
  },
  {
    "code" : "BR0433685",
    "display" : "Ruxolitinibe 20mg comprimido"
  },
  {
    "code" : "BR0433687",
    "display" : "Dolutegravir 5mg Comprimido para suspensão"
  },
  {
    "code" : "BR0433690",
    "display" : "Enzalutamida 40mg cápsula"
  },
  {
    "code" : "BR0433812",
    "display" : "Tranilcipromina 10mg comprimido revestido"
  },
  {
    "code" : "BR0434051",
    "display" : "Schinus Terebinthifolia Raddi 3,996mL/6g gel vaginal; bisnaga"
  },
  {
    "code" : "BR0434111",
    "display" : "Cloridrato de Amitriptilina 10mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0434125",
    "display" : "Colecalciferol 1.000UI comprimido revestido"
  },
  {
    "code" : "BR0434127",
    "display" : "Curcuma Longa L. 250mg cápsula"
  },
  {
    "code" : "BR0434128",
    "display" : "Ácido Fólico 20mg + Acetato de Racealfatocoferol 800micrograma cápsula"
  },
  {
    "code" : "BR0434130",
    "display" : "Pirenoxina Sódica 0,85mg comprimido para solução"
  },
  {
    "code" : "BR0434254",
    "display" : "Canagliflozina 300mg comprimido revestido"
  },
  {
    "code" : "BR0434765E",
    "display" : "Abatacepte 125mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0434796-1",
    "display" : "Dicloridrato de Levocetirizina 5mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0434797",
    "display" : "Hidroclorotiazida 25mg + Hemifumarato de Bisoprolol 10mg comprimido revestido"
  },
  {
    "code" : "BR0434872",
    "display" : "Tofacitinibe 5mg comprimido revestido"
  },
  {
    "code" : "BR0434945",
    "display" : "Trifolium Pratense 100mg comprimido revestido"
  },
  {
    "code" : "BR0434946",
    "display" : "Colecalciferol 1.600UI/1mL + Palmitato de Retinol 20.000UI/1mL + Acetato de Racealfatocoferol 30mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0435101",
    "display" : "Paracetamol 500mg + Amitriptilina 25mg + Meloxicam 7,5mg cápsula"
  },
  {
    "code" : "BR0435102",
    "display" : "Paracetamol 500mg + Amitriptilina 25mg + Ciclobenzaprina 5mg + Meloxicam 7,5mg Cápsula"
  },
  {
    "code" : "BR0435105",
    "display" : "Polypodium Leucatomos Poir. 250mg Cápsula"
  },
  {
    "code" : "BR0435186",
    "display" : "Metoxisaleno 1mg/1g (0,1%) creme"
  },
  {
    "code" : "BR0435187",
    "display" : "Metoxisaleno 2mg/1g (0,2%) creme"
  },
  {
    "code" : "BR0435189",
    "display" : "Paracetamol 500mg + Meloxicam 15mg + Ciclobenzaprina 5mg cápsula"
  },
  {
    "code" : "BR0435285",
    "display" : "Hialuronato de Sódio 1,6% solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0435334/0003E",
    "display" : "Dicloridrato de Daclatasvir 30mg comprimido revestido"
  },
  {
    "code" : "BR0435442",
    "display" : "Idebenona 150mg cápsula"
  },
  {
    "code" : "BR0435539",
    "display" : "Lacosamida 50mg comprimido revestido"
  },
  {
    "code" : "BR0435950",
    "display" : "Besilato de Anlodipino 5mg + Telmisartana 40mg comprimido"
  },
  {
    "code" : "BR0436169",
    "display" : "Benzoato de Alogliptina 25mg  comprimido revestido"
  },
  {
    "code" : "BR0436234",
    "display" : "Oxalato de Escitalopram 20mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0436234-1",
    "display" : "Oxalato de Escitalopram 20mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0436345",
    "display" : "Esilato de Nintedanibe 150mg cápsula"
  },
  {
    "code" : "BR0436433",
    "display" : "Nitrato de Fenticonazol 20mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0436480",
    "display" : "Furoato de Fluticasona 200micrograma/1dose + Trifenatato de Vilanterol 25micrograma/1dose pó para inalação; dispositivo"
  },
  {
    "code" : "BR0436500",
    "display" : "Besilato de Anlodipino 10mg + Ramipril 10mg cápsula"
  },
  {
    "code" : "BR0436508",
    "display" : "Alfaestradiol 0,25mg/1mL solução cutânea; frasco"
  },
  {
    "code" : "BR0436550",
    "display" : "Simeticona 125mg cápsula"
  },
  {
    "code" : "BR0436703",
    "display" : "Acetato de Prednisolona 10mg/1mL + Gatifloxacino 3mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0436705-1",
    "display" : "Buprenorfina 5mg adesivo transdérmico; envelope"
  },
  {
    "code" : "BR0436705-2",
    "display" : "Buprenorfina 10mg adesivo transdérmico; envelope"
  },
  {
    "code" : "BR0436705-3",
    "display" : "Buprenorfina 20mg adesivo transdérmico; envelope"
  },
  {
    "code" : "BR0436711",
    "display" : "Etravirina 200mg comprimido"
  },
  {
    "code" : "BR0436769",
    "display" : "Vortioxetina 10mg comprimido revestido"
  },
  {
    "code" : "BR0437051",
    "display" : "Lacosamida 10mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0437078",
    "display" : "Empagliflozina 10mg comprimido revestido"
  },
  {
    "code" : "BR0437284",
    "display" : "Levetiracetam 750mg comprimido revestido"
  },
  {
    "code" : "BR0437357",
    "display" : "Rotigotina 6mg/24 horas (13,5mg) adesivo transdérmico"
  },
  {
    "code" : "BR0437374",
    "display" : "Levotiroxina Sódica 37,5micrograma comprimido"
  },
  {
    "code" : "BR0437989",
    "display" : "Indacaterol 110 microgramas + Glicopirrônio 50 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "BR0437993",
    "display" : "Trifenatato de Vilanterol 25micrograma/1dose + Brometo de Umeclidínio 62,5micrograma/1dose pó para inalação"
  },
  {
    "code" : "BR0437994",
    "display" : "Lacosamida 150mg comprimido revestido"
  },
  {
    "code" : "BR0438039",
    "display" : "Benzoato de Alogliptina 12.5mg  comprimido revestido"
  },
  {
    "code" : "BR0438041",
    "display" : "Benzoato de Alogliptina  6.25mg  comprimido revestido"
  },
  {
    "code" : "BR0438280",
    "display" : "Levotiroxina Sódica 62,5micrograma comprimido"
  },
  {
    "code" : "BR427335",
    "display" : "Tenofovir 300mg + Lamivudina 300mg + Efavirenz 600mg comprimido revestido"
  },
  {
    "code" : "BR0465425",
    "display" : "Cloridrato de Metformina 850mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0266701U0109",
    "display" : "Budesonida 50micrograma/1dose suspensão nasal; frasco"
  },
  {
    "code" : "BR0267613U0042",
    "display" : "Captopril 25mg Comprimido"
  },
  {
    "code" : "BR0270130U0042",
    "display" : "Levodopa 250mg + Carbidopa 25 mg comprimido"
  },
  {
    "code" : "BR0270128U0042",
    "display" : "Levodopa 100mg + Cloridrato de Benserazida 25mg comprimido"
  },
  {
    "code" : "BR0267691U0042",
    "display" : "Cloridrato de Metformina 850mg comprimido revestido"
  },
  {
    "code" : "BR0267772U0042",
    "display" : "Cloridrato de Propranolol 40mg Comprimido"
  },
  {
    "code" : "BR0267587U0061",
    "display" : "Dipropionato de Beclometasona 200micrograma/1dose Pó para inalação; inalador"
  },
  {
    "code" : "BR0267586U0041",
    "display" : "Dipropionato de Beclometasona 200micrograma/NaN pó para inalação"
  },
  {
    "code" : "BR0267582U0084",
    "display" : "Dipropionato de Beclometasona 50micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0346586U0084",
    "display" : "Dipropionato de Beclometasona 50micrograma/1dose solução aerossol; dispositivo"
  },
  {
    "code" : "BR0270846U0005",
    "display" : "Valerato de Estradiol 5mg/1mL + Enantato de Noretisterona 50mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267671U0042",
    "display" : "Glibenclamida 5mg Comprimido"
  },
  {
    "code" : "BR0267674U0042",
    "display" : "Hidroclorotiazida 25mg Comprimido"
  },
  {
    "code" : "BR0272789U0042",
    "display" : "Levonorgestrel 0,15mg + Etinilestradiol 0,03mg comprimido revestido"
  },
  {
    "code" : "BR0268856U0042",
    "display" : "Losartana Potássica 50mg comprimido revestido"
  },
  {
    "code" : "BR0272581U0106",
    "display" : "Maleato de Timolol 5mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0272582U0106",
    "display" : "Maleato de Timolol 2,5mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0267651U0042",
    "display" : "Maleato de Enalapril 10mg Comprimido"
  },
  {
    "code" : "BR0267733U0042",
    "display" : "Noretisterona 0,35mg Comprimido"
  },
  {
    "code" : "BR0267746U0042",
    "display" : "Sinvastatina 10mg comprimido revestido"
  },
  {
    "code" : "BR0267747U0042",
    "display" : "Sinvastatina 20mg comprimido revestido"
  },
  {
    "code" : "BR0267745U0042",
    "display" : "Sinvastatina 40mg comprimido revestido"
  },
  {
    "code" : "BR0268303U0063",
    "display" : "Sulfato de Salbutamol 5mg/1mL Solução para inalação; frasco"
  },
  {
    "code" : "BR0294887U0084",
    "display" : "Sulfato de Salbutamol 100micrograma/1dose suspensão aerossol; dispositivo"
  },
  {
    "code" : "BR0271154U0063",
    "display" : "Insulina Humana Regular 1.000UI/10mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271157U0063",
    "display" : "Insulina Humana NPH 100unidades internacionais/mL suspensão para injeção 10 mL; frasco-ampola"
  },
  {
    "code" : "BR0271157U0137",
    "display" : "Insulina Humana 100UI/1mL Suspensão para injeção; carpule"
  },
  {
    "code" : "BR0368922-1",
    "display" : "Ácido Acético 2% solução cutânea; frasco"
  },
  {
    "code" : "BR0368922-2",
    "display" : "Ácido Acético 2% solução cutânea; frasco"
  },
  {
    "code" : "BR0368922",
    "display" : "Ácido Acético 2% solução cutânea; frasco"
  },
  {
    "code" : "BR0368921-3",
    "display" : "Ácido Acético 3% solução cutânea; frasco"
  },
  {
    "code" : "BR0368921",
    "display" : "Ácido Acético 3% solução cutânea; frasco"
  },
  {
    "code" : "BR0368919-2",
    "display" : "Ácido Acético 5% solução cutânea; frasco"
  },
  {
    "code" : "BR0368919-4",
    "display" : "Ácido Acético 5% solução cutânea; frasco"
  },
  {
    "code" : "BR0368919-3",
    "display" : "Ácido Acético 5% solução cutânea; frasco"
  },
  {
    "code" : "BR0368919-1",
    "display" : "Ácido Acético 5% solução cutânea; frasco"
  },
  {
    "code" : "BR0368919",
    "display" : "Ácido Acético 5% solução cutânea; frasco"
  },
  {
    "code" : "BR0430292",
    "display" : "Ácido Ascórbico 45mg + Retinol 400micrograma + Acetato de Racealfatocoferol 4,4mg + Citrato de Zinco 3,75mg + Óxido de Selênio 17,5micrograma comprimido"
  },
  {
    "code" : "BR0268289",
    "display" : "Ácido Bórico 2% solução oftálmica; frasco"
  },
  {
    "code" : "BR0268290",
    "display" : "Ácido Bórico 3% solução oftálmica; frasco"
  },
  {
    "code" : "BR0381060",
    "display" : "Ácidos Graxos Poliinsaturados Marinhos 1.000mg cápsula"
  },
  {
    "code" : "BR0269068-1",
    "display" : "Ácido Tricloroacético 50% solução cutânea; frasco"
  },
  {
    "code" : "BR0269068-2",
    "display" : "Ácido Tricloroacético 50% solução cutânea; frasco"
  },
  {
    "code" : "BR0269068-3",
    "display" : "Ácido Tricloroacético 50% solução cutânea; frasco"
  },
  {
    "code" : "BR0269068",
    "display" : "Ácido Tricloroacético 50% solução cutânea; frasco"
  },
  {
    "code" : "BR0269072",
    "display" : "Ácido Tricloroacético 75% solução cutânea; frasco"
  },
  {
    "code" : "BR0269072-1",
    "display" : "Ácido Tricloroacético 75% solução cutânea; frasco"
  },
  {
    "code" : "BR0269073-1",
    "display" : "Ácido Tricloroacético 80% solução cutânea; frasco"
  },
  {
    "code" : "BR0269073-3",
    "display" : "Ácido Tricloroacético 80% solução cutânea; frasco"
  },
  {
    "code" : "BR0269073-2",
    "display" : "Ácido Tricloroacético 80% solução cutânea; frasco"
  },
  {
    "code" : "BR0269073",
    "display" : "Ácido Tricloroacético 80% solução cutânea; frasco"
  },
  {
    "code" : "BR0269069",
    "display" : "Ácido Tricloroacético 90% solução cutânea; frasco"
  },
  {
    "code" : "BR0269069-1",
    "display" : "Ácido Tricloroacético 90% solução cutânea; frasco"
  },
  {
    "code" : "BR0269069-2",
    "display" : "Ácido Tricloroacético 90% solução cutânea; frasco"
  },
  {
    "code" : "BR0269943-3",
    "display" : "Álcool Etílico 70% Gel"
  },
  {
    "code" : "BR0269941-1",
    "display" : "Álcool Etílico 70% Solução"
  },
  {
    "code" : "BR0269941",
    "display" : "Álcool Etílico 70% Solução"
  },
  {
    "code" : "BR0269943-4",
    "display" : "Álcool Etílico 70% Gel"
  },
  {
    "code" : "BR0269943-1",
    "display" : "Álcool Etílico 70% Gel"
  },
  {
    "code" : "BR0269943-2",
    "display" : "Álcool Etílico 70% Gel"
  },
  {
    "code" : "BR0328596",
    "display" : "Álcool Etílico 99% solução para injeção; ampola"
  },
  {
    "code" : "BR0357239",
    "display" : "Álcool Etílico 99,5% solução cutânea; frasco"
  },
  {
    "code" : "BR0266628",
    "display" : "Alfaepoetina 2.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271356-1",
    "display" : "Alprazolam 1mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0436416",
    "display" : "Alteplase 10mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0437387",
    "display" : "Amburana Cearensis 5% xarope; frasco"
  },
  {
    "code" : "BR0271100",
    "display" : "Amoxicilina Sódica 1g + Clavulanato de Potássio 200mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0437411",
    "display" : "Arginina 0,25mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0400564",
    "display" : "Arteméter 20mg + Lumefantrina 120mg comprimido"
  },
  {
    "code" : "BR0277529",
    "display" : "Azul de Metileno 1% solução para injeção; ampola"
  },
  {
    "code" : "BR0404137",
    "display" : "Azul de Metileno 2% solução cutânea; frasco"
  },
  {
    "code" : "BR0363099",
    "display" : "Azul de Trypan 0,1% Solução oftálmica; ampola"
  },
  {
    "code" : "BR0327563",
    "display" : "Azul de Trypan 0,1% Solução para injeção; ampola"
  },
  {
    "code" : "BR0267590",
    "display" : "Dipropionato de Beclometasona 250micrograma/1dose solução aerossol; frasco"
  },
  {
    "code" : "BR0293327",
    "display" : "Tintura de Benjoim 20% tintura; frasco"
  },
  {
    "code" : "BR0272150",
    "display" : "Benzocaína 45mg/1g + Mentol 5mg/1g + Benzoxiquina 12mg/1g + Cloreto de Benzetônio 1mg/1g Solução aerossol"
  },
  {
    "code" : "BR0394316",
    "display" : "Betainterferona 1b 9.600.000UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271052",
    "display" : "Bicarbonato de Sódio 50g pó para solução oral; envelope"
  },
  {
    "code" : "BR0432846",
    "display" : "Bryophyllum Calycinum 959mg/1mL Solução oral"
  },
  {
    "code" : "BR0266705-2",
    "display" : "Budesonida 100micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0266705-3",
    "display" : "Budesonida 100micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0266705-4",
    "display" : "Budesonida 100micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0266706",
    "display" : "Budesonida 32micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0266699-2",
    "display" : "Budesonida 50micrograma/1dose Suspensão aerossol; frasco"
  },
  {
    "code" : "BR0266701-2",
    "display" : "Budesonida 50micrograma/1dose Suspensão nasal; frasco"
  },
  {
    "code" : "BR0404075",
    "display" : "Glicinato de Cálcio 250mg Pó para suspensão oral"
  },
  {
    "code" : "BR0433021",
    "display" : "Carbonato de Cálcio 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0436788",
    "display" : "Fosfato de Cálcio Tribásico 10mg/1mL + Cianocobalamina 12micrograma/1mL + Colecalciferol 0,25micrograma/1mL solução oral; frasco"
  },
  {
    "code" : "BR0327766-2",
    "display" : "Carbonato de Cálcio 600mg + Colecalciferol 200UI comprimido efervescente"
  },
  {
    "code" : "BR0395721-6",
    "display" : "Carvão Vegetal Ativado 10g pó para solução oral; Sachê"
  },
  {
    "code" : "BR0395721-7",
    "display" : "Carvão Vegetal Ativado 15g pó para solução oral; Sachê"
  },
  {
    "code" : "BR0434505",
    "display" : "Carvão Vegetal Ativado 250mg comprimido"
  },
  {
    "code" : "BR0397674",
    "display" : "Celulose 500mg pó para inalação"
  },
  {
    "code" : "BR0434084",
    "display" : "Matricaria Chamomilla L. 100mg/1 g pomada"
  },
  {
    "code" : "BR0428744-3",
    "display" : "Colecalciferol 2.000UI comprimido"
  },
  {
    "code" : "BR0436839",
    "display" : "Tiamina 7,5mg + Riboflavina 0,825mg + Piridoxina 2,5mg + Nicotinamida 12,5mg cápsula"
  },
  {
    "code" : "BR0276665-2",
    "display" : "Iobitridol 35g/100mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0276665-3",
    "display" : "Iobitridol 175g/500mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0305236",
    "display" : "Iodo 15g/50mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0310452",
    "display" : "Ésteres Etílicos Dos Ácidos Graxos Do Óleo de Papoula Iodados 4,8g/10mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0276662-2",
    "display" : "Sulfato de Bário 1g/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0316334-3",
    "display" : "Iodo 35g/100mL solução para injeção; frasco"
  },
  {
    "code" : "BR0340320",
    "display" : "Ioversol 63,62g/125mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0340319",
    "display" : "Ioversol 67,8g/100mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0407485",
    "display" : "Diazóxido 100mg cápsula"
  },
  {
    "code" : "BR0299247",
    "display" : "Didanosina 2g pó para suspensão oral; Sachê"
  },
  {
    "code" : "BR0299248",
    "display" : "Didanosina 4g pó para suspensão oral; Sachê"
  },
  {
    "code" : "BR0323260",
    "display" : "Cloridrato de Doxorrubicina 10mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0278430",
    "display" : "Papaver Somniferum L. 0,05mL/1mL elixir; frasco"
  },
  {
    "code" : "BR0268961",
    "display" : "Estreptoquinase 1.500.000UI Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0368190",
    "display" : "Polivitamínico (Combiron Fólico) comprimido revestido"
  },
  {
    "code" : "BR0270503-1",
    "display" : "Cloranfenicol 10mg/1g + Desoxirribonuclease 666unidade/1g + Fibrinolisina 1unidade/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0270503-2",
    "display" : "Cloranfenicol 10mg/1g + Desoxirribonuclease 666unidade/1g + Fibrinolisina 1unidade/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0392653",
    "display" : "Propionato de Fluticasona 50 microgramas/dose pó para inalação; inalador"
  },
  {
    "code" : "BR0437379",
    "display" : "Garcinia Cambogia Desr. 500mg cápsula"
  },
  {
    "code" : "BR0353564",
    "display" : "Glicose 50% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "BR0432197-1",
    "display" : "Glycine Max (L.) Merr. 100mg comprimido revestido"
  },
  {
    "code" : "BR0268109",
    "display" : "Acetato de Gosserrelina 3,6mg implante; Seringa preenchida"
  },
  {
    "code" : "BR0270472",
    "display" : "Isetionato de Hexamidina 1mg/1mL + Cloridrato de Tetracaína 0,5mg/1mL Colutório spray; frasco"
  },
  {
    "code" : "BR0393846",
    "display" : "Hidroxietilamido 6% solução para injeção; bolsa"
  },
  {
    "code" : "BR0353641",
    "display" : "Hilano G-F 20 16mg/2mL Solução para injeção"
  },
  {
    "code" : "BR0392108",
    "display" : "Imunoglobulina Humana 10g/100mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266823",
    "display" : "Imunoglobulina Humana 10g/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266824",
    "display" : "Imunoglobulina Humana 180.000mg/60mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342445",
    "display" : "Insulina Isofana 700UI/10mL + Insulina Humana Regular 300UI/10mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342445-1",
    "display" : "Insulina Isofana 210UI/3mL + Insulina Humana Regular 90UI/3mL suspensão para injeção; carpule"
  },
  {
    "code" : "BR0279285-1",
    "display" : "Iodo 2% Tintura; frasco"
  },
  {
    "code" : "BR0268332",
    "display" : "Brometo de Ipratrópio 20micrograma/1dose solução aerossol; frasco"
  },
  {
    "code" : "BR0268331-1",
    "display" : "Brometo de Ipratrópio 0,25mg/1mL Solução para inalação; frasco"
  },
  {
    "code" : "BR0268331-2",
    "display" : "Brometo de Ipratrópio 0,25mg/1mL Solução para inalação; frasco"
  },
  {
    "code" : "BR0404606",
    "display" : "Acetato de Lanreotida 120mg/0,5mL solução para injeção de liberação prolongada; Seringa preenchida"
  },
  {
    "code" : "BR0269852-2",
    "display" : "Cloridrato de Lidocaína 400mg/20mL + Hemitartarato de Epinefrina 182micrograma/20mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0397428-2",
    "display" : "Cloridrato de Lidocaína 400mg/20mL + Hemitartarato de Epinefrina 182micrograma/20mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342616",
    "display" : "Lidocaína 16mg/1.8 mL + Fenilefrina 0.72 mg/1.8 mL solução para injeção"
  },
  {
    "code" : "BR0287061",
    "display" : "Lidocaína 54mg/1,8mL + Norepinefrina 0,072mg/1,8mL solução para injeção; carpule"
  },
  {
    "code" : "BR0437403",
    "display" : "Lippia Sidoides Cham. 20% tintura; frasco"
  },
  {
    "code" : "BR0434050",
    "display" : "Malva Sylvestris L. 20% Tintura; frasco"
  },
  {
    "code" : "BR0292228",
    "display" : "Acetato de Medroxiprogesterona 150mg/1mL Suspensão para injeção; ampola"
  },
  {
    "code" : "BR0364660",
    "display" : "Antimoniato de Meglumina 1.500mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269888",
    "display" : "Cloridrato de Mepivacaína 36mg/1.8mL + Epinefrina 18micrograma/1.8mL solução para injeção; carpule"
  },
  {
    "code" : "BR0292241",
    "display" : "Mesalazina 2g granulado de liberação prolongada; envelope"
  },
  {
    "code" : "BR0273694-1",
    "display" : "Metilcelulose 2% solução oftálmica; frasco"
  },
  {
    "code" : "BR0267310",
    "display" : "Cloridrato de Metoclopramida 10mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0432638",
    "display" : "Metoprolol 10mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0407034",
    "display" : "Polivitamínico (Organoneuro Cerebral)  comprimido revestido"
  },
  {
    "code" : "BR0425364",
    "display" : "Polivitamínico (Matersupre) comprimido revestido"
  },
  {
    "code" : "BR0437384",
    "display" : "Myracrodruon urundeuva 15% creme vaginal; bisnaga"
  },
  {
    "code" : "BR0437385",
    "display" : "Myracrodruon urundeuva 7% elixir; frasco"
  },
  {
    "code" : "BR0349666",
    "display" : "Nitrato de Prata 5g bastão"
  },
  {
    "code" : "BR0423946",
    "display" : "Acetato de Noretisterona 2mg + Etinilestradiol 0,01mg comprimido"
  },
  {
    "code" : "BR0342980-1",
    "display" : "Acetato de Octreotida 20mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0430482",
    "display" : "triglicerídeos de ácidos graxos ômega-3 1.000mg cápsula"
  },
  {
    "code" : "BR0429010",
    "display" : "triglicerídeos de ácidos graxos ômega-3 1.100mg cápsula"
  },
  {
    "code" : "BR0305738",
    "display" : "Oenothera Biennis L. 500mg cápsula"
  },
  {
    "code" : "BR0406015-4",
    "display" : "Cloridrato de Oxibutinina 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0401411-1",
    "display" : "Óxido de Zinco 100mg/1g + Colecalciferol 1.000UI/1g + Retinol 400UI/1g pomada; bisnaga"
  },
  {
    "code" : "BR0404508",
    "display" : "Polivitamínico (Gerovital) cápsula"
  },
  {
    "code" : "BR0436202",
    "display" : "Paroxetina 60mg Cápsula"
  },
  {
    "code" : "BR0437383",
    "display" : "Passiflora Edulis Sims 200mg cápsula"
  },
  {
    "code" : "BR0433657",
    "display" : "Passiflora Incarnata 600mg comprimido revestido"
  },
  {
    "code" : "BR0396414-4",
    "display" : "Plantago Ovata Forssk.   3,26g/5,8g pó para solução oral; envelope"
  },
  {
    "code" : "BR0398578",
    "display" : "Plantago Ovata Forssk.   520mg/1g + Senna Alexandrina Mill. 99,4mg/1g Granulado"
  },
  {
    "code" : "BR0417266",
    "display" : "Poliestirenossulfonato de Sódio 454g granulado para suspensão; Sachê"
  },
  {
    "code" : "BR0393341",
    "display" : "Riboflavina 200mg cápsula"
  },
  {
    "code" : "BR0282889",
    "display" : "Senna Alexandrina Mill. 28,9mg + Cassia Fistula L. 19,5mg cápsula"
  },
  {
    "code" : "BR0282889-1",
    "display" : "Senna Alexandrina Mill. 4.878mg/1g + Cassia Fistula L. 4.719mg/1g Gel; frasco"
  },
  {
    "code" : "BR0436201",
    "display" : "Sertralina 150mg cápsula"
  },
  {
    "code" : "BR0437604",
    "display" : "Sildenafila 20mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0404406-1",
    "display" : "Silybum Marianum (L.) Gaertn. 64mg/5mL suspensão oral; frasco"
  },
  {
    "code" : "BR0375387",
    "display" : "Macrogol 4mg/1mL + Hidroxipropilguar 1,8mg/1mL + Propilenoglicol 3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0318989",
    "display" : "Somatropina 16UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0318990",
    "display" : "Somatropina 36UI pó e diluente para solução para injeção; dispositivo"
  },
  {
    "code" : "BR0348663",
    "display" : "Soro Antiaracnídico"
  },
  {
    "code" : "BR0348672",
    "display" : "Soro Antibotrópico (Pentavalente)"
  },
  {
    "code" : "BR0394810",
    "display" : "Soro Antibotrópico (Pentavalente) E Anticrotálico"
  },
  {
    "code" : "BR0394811",
    "display" : "Soro Antibotrópico (Pentavalente) E Antilaquético"
  },
  {
    "code" : "BR0348669",
    "display" : "Soro Antielapídico"
  },
  {
    "code" : "BR0348664",
    "display" : "Soro Antiescorpiônico"
  },
  {
    "code" : "BR0348660",
    "display" : "Soro Antirrábico"
  },
  {
    "code" : "BR0434045-2",
    "display" : "Symphytum Officinale L. 350mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0338288-2",
    "display" : "Undecilato de Testosterona 1g/4mL solução para injeção; ampola"
  },
  {
    "code" : "BR0267421",
    "display" : "Tianfenicol 2,5g granulado; envelope"
  },
  {
    "code" : "BR0430402",
    "display" : "Trastuzumabe Entansina 160mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292155",
    "display" : "Triancinolona Acetonida 55micrograma/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0399442-1",
    "display" : "Uncaria Tomentosa (Willd. Ex Roem. & Schult.) Dc. 300mg cápsula"
  },
  {
    "code" : "BR0420463",
    "display" : "Ureia 3% + Óleo de semente de uva 5% creme; frasco"
  },
  {
    "code" : "BR0431301-1",
    "display" : "Petrolato Líquido 1mL/1mL líquido; frasco"
  },
  {
    "code" : "BR0269568",
    "display" : "Brometo de Vecurônio 4mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0435190",
    "display" : "Cloreto de Metilrosanilínio 2% solução cutânea; frasco"
  },
  {
    "code" : "BR0308890",
    "display" : "Zidovudina 10mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0400982",
    "display" : "Sulfato de Zinco 2,5mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0433249",
    "display" : "Sulfato de Zinco 4mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0268958",
    "display" : "Colagenase 0,6UI/1g Pomada"
  },
  {
    "code" : "BR0442729",
    "display" : "Colecalciferol 2.000UI comprimido"
  },
  {
    "code" : "BR0292236U0042",
    "display" : "Mesalazina 500mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0300745U0041",
    "display" : "Pancreatina 25.000UI cápsula de liberação retardada"
  },
  {
    "code" : "BR0386482U0042",
    "display" : "Colecalciferol 400UI + Fosfato de Cálcio Tribásico 600 mg comprimido revestido"
  },
  {
    "code" : "BR0478272",
    "display" : "Semaglutida 3mg Comprimido"
  },
  {
    "code" : "BR0268427U0046",
    "display" : "Ciclofosfamida 50mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0268410U0118",
    "display" : "Cefotaxima Sódica 500mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0451578",
    "display" : "Rhamnus Purshiana 400mg cápsula"
  },
  {
    "code" : "BR0464982",
    "display" : "Trifluridina 20mg + Tipiracila 8.19 mg comprimido revestido"
  },
  {
    "code" : "BR0343632",
    "display" : "Polidocanol 3,2mg/1g + Cloridrato de Lidocaína 3,4mg/1g + Extrato de Camomila 150mg/1g solução oral; frasco"
  },
  {
    "code" : "BR0273820U0042",
    "display" : "Sildenafila 25mg comprimido revestido"
  },
  {
    "code" : "BR0267777U0063",
    "display" : "Paracetamol 200mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0327699U0042",
    "display" : "Permanganato de Potássio 100mg Comprimido; comprimido"
  },
  {
    "code" : "BR0363597U0110",
    "display" : "Permetrina 50mg/1mL Loção; frasco"
  },
  {
    "code" : "BR0384537U0030",
    "display" : "Peróxido de Benzoíla 25mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0399409U0041",
    "display" : "Rhamnus Purshiana 150mg Cápsula; cápsula"
  },
  {
    "code" : "BR0600080",
    "display" : "Racemetionina 100mg + Cloreto de Colina 20mg comprimido revestido"
  },
  {
    "code" : "BR0435231",
    "display" : "ACETATO DE DEGARELIX 80mg/4mL Pó para solução para injeção"
  },
  {
    "code" : "BR0444051U0060",
    "display" : "Clorexidina 2% solução cutânea; frasco"
  },
  {
    "code" : "BR0603480",
    "display" : "Cannabis Sativa 34,36mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0273892U0391",
    "display" : "Budesonida 0,5mg/1mL suspensão para inalação; frasco"
  },
  {
    "code" : "BR0385424U0042",
    "display" : "Cynara Scolymus L. 200mg comprimido"
  },
  {
    "code" : "BR0367808U0042",
    "display" : "Paracetamol 500mg + Pseudoefedrina 30mg comprimido revestido"
  },
  {
    "code" : "BR0485177",
    "display" : "Vortioxetina 20mg comprimido revestido"
  },
  {
    "code" : "BR0432573U0041",
    "display" : "Senna Alexandrina Mill. 28,9mg + Cassia Fistula L. 19,5mg cápsula"
  },
  {
    "code" : "BR0465439",
    "display" : "Avelumabe 200mg/10mL solução para infusão; frasco-ampola"
  },
  {
    "code" : "BR0404603",
    "display" : "Acetato de Lanreotida 60mg/0,5mL solução para injeção de liberação prolongada"
  },
  {
    "code" : "BR0404846U0005",
    "display" : "Somatropina 12UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0485131",
    "display" : "Pasireotida 40mg pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0457612U0548",
    "display" : "Senna Alexandrina Mill. 4.878mg/1g + Cassia Fistula L. 4.719mg/1g Gel; frasco"
  },
  {
    "code" : "BR0433687U0042",
    "display" : "Dolutegravir 50mg comprimido revestido"
  },
  {
    "code" : "BR0348359U0074",
    "display" : "Brometo de Propantelina 5mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0441621U0042",
    "display" : "Dapagliflozina 5mg + Metformina 1 g comprimido de liberação prolongada"
  },
  {
    "code" : "BR0445431U0041",
    "display" : "Sacubitril Valsartana Sódica Hidratada 100mg comprimido revestido"
  },
  {
    "code" : "BR0285081U0041",
    "display" : "Cloridrato de Tansulosina 0,4mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0270837",
    "display" : "Estradiol 100 microgramas/24 horas adesivo transdérmico"
  },
  {
    "code" : "BR0434252U0041",
    "display" : "Pirfenidona 267mg cápsula"
  },
  {
    "code" : "BR0449866",
    "display" : "Atezolizumabe 1.200mg/20mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268151U0062",
    "display" : "Prednisolona 1mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267769U0009",
    "display" : "Cloridrato de Prometazina 50mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268236U0039",
    "display" : "Cloreto de Sódio 0,9% solução para injeção 500 mL; bolsa"
  },
  {
    "code" : "BR0272412U0042",
    "display" : "Cloridrato de Propafenona 300mg comprimido revestido"
  },
  {
    "code" : "BR0292237U0042",
    "display" : "Mesalazina 400mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0267736U0042",
    "display" : "Ranitidina 150mg comprimido revestido"
  },
  {
    "code" : "BR0292264U0041",
    "display" : "Sulfato de Morfina Pentaidratado 60mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0272565U0086",
    "display" : "Retinol 150.000UI/1mL Solução oral"
  },
  {
    "code" : "BR0292263U0041",
    "display" : "Sulfato de Morfina Pentaidratado 30mg Cápsula de liberação prolongada"
  },
  {
    "code" : "BR0367664U0075",
    "display" : "Natalizumabe 300mg/15mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0286740U0067",
    "display" : "Cloperastina 3,54mg/mL xarope"
  },
  {
    "code" : "BR0268390U0052",
    "display" : "Glicose 20g + Cloreto de Potássio 1,5g + Cloreto de Sódio 3,5g + Citrato de Sódio 2,9g Pó para solução oral"
  },
  {
    "code" : "BR0393339U0042",
    "display" : "Harpagophytum Procumbens Dc. Ex Meissn. 400mg comprimido revestido"
  },
  {
    "code" : "BR0268303U0106",
    "display" : "Sulfato de Salbutamol 5mg/1mL Solução para inalação; frasco"
  },
  {
    "code" : "BR0272089U0023",
    "display" : "Sulfadiazina de Prata 10mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0308882U0042",
    "display" : "Trimetoprima 80mg + Sulfametoxazol 400mg Comprimido"
  },
  {
    "code" : "BR0292345U0097",
    "display" : "Sulfato Ferroso Heptaidratado 25mg/1mL (Ferro 5 mg/mL) solução oral; frasco"
  },
  {
    "code" : "BR0268370U0042",
    "display" : "Aciclovir 200mg Comprimido"
  },
  {
    "code" : "BR0278489U0097",
    "display" : "Ácido Fólico 0,2mg/1mL Solução oral"
  },
  {
    "code" : "BR0308732U0062",
    "display" : "Valproato de Sódio 50mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0271111U0115",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0271217U0042",
    "display" : "Amoxicilina 500mg + Clavulanato de Potássio 125mg comprimido revestido"
  },
  {
    "code" : "BR0314517U0108",
    "display" : "Azitromicina 40mg/1mL Pó para suspensão oral"
  },
  {
    "code" : "BR0314517U0155",
    "display" : "Azitromicina 40mg/1mL Pó para suspensão oral"
  },
  {
    "code" : "BR0346586U0573",
    "display" : "Dipropionato de Beclometasona 50micrograma/1dose solução aerossol; dispositivo"
  },
  {
    "code" : "BR0270613U0118",
    "display" : "Benzilpenicilina Benzatina 600.000UI pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270614U0118",
    "display" : "Benzilpenicilina Potássica 100.000UI + Benzilpenicilina Procaína 300.000UI Pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267621U0042",
    "display" : "Carbonato de Lítio 300mg Comprimido"
  },
  {
    "code" : "BR0267625U0041",
    "display" : "Cefalexina Monoidratada 500mg Cápsula"
  },
  {
    "code" : "BR0331555U0062",
    "display" : "Cefalexina Monoidratada 50mg/1mL Suspensão oral"
  },
  {
    "code" : "BR0267522U0042",
    "display" : "Cloridrato de Clomipramina 25mg comprimido revestido"
  },
  {
    "code" : "BR0437160U0097",
    "display" : "Cloreto de Sódio 9mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0340207U0086",
    "display" : "Cloridrato de Clorpromazina 40mg/1mL Solução oral; Solução"
  },
  {
    "code" : "BR0367692U0042",
    "display" : "Ácido Nicotínico 500mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0374967U0041",
    "display" : "Cloridrato de Nilotinibe Monoidratado  200mg Cápsula"
  },
  {
    "code" : "BR0395721U0123",
    "display" : "Carvão Vegetal Ativado 500g pó para solução oral; Sachê"
  },
  {
    "code" : "BR0413681U0067",
    "display" : "Mikania Glomerata Spreng. 81,5mg/1mL Solução oral"
  },
  {
    "code" : "BR0394804U0091",
    "display" : "Paclitaxel 6mg/1mL Solução para injeção"
  },
  {
    "code" : "BR0336708",
    "display" : "Tacrolimo 5mg/1 mL solução para injeção; ampola"
  },
  {
    "code" : "BR0277311U0042",
    "display" : "Ácido Aminocaproico 500mg Comprimido"
  },
  {
    "code" : "BR0437081U0042",
    "display" : "Riociguate 1mg comprimido revestido"
  },
  {
    "code" : "BR0444570",
    "display" : "Formoterol 12 microgramas + Propionato de Fluticasona 250 microgramas cápsula para inalação; inalador"
  },
  {
    "code" : "BR0436601U0042",
    "display" : "Felodipino 5mg + Metoprolol 50 mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0385423",
    "display" : "Cefaclor 75mg/mL suspensão oral"
  },
  {
    "code" : "BR0432367",
    "display" : "Hialuronato de Sódio 2mg/1 mL solução oftálmica"
  },
  {
    "code" : "BR0439342U0042",
    "display" : "Hemifumarato de Cobimetinibe 20mg comprimido revestido"
  },
  {
    "code" : "BR0465388U0042",
    "display" : "Selexipague 200 micrograma comprimido revestido"
  },
  {
    "code" : "BR0429928",
    "display" : "Cloridrato de Doxorrubicina 20mg/10mL Suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0439611",
    "display" : "Rotigotina 8mg/24 (18mg) horas adesivo transdérmico"
  },
  {
    "code" : "BR0480013",
    "display" : "Selumetinibe 25mg cápsula"
  },
  {
    "code" : "BR0284458U0023",
    "display" : "Propionato de Clobetasol 0,5mg/1g Creme"
  },
  {
    "code" : "BR0272045U0042",
    "display" : "Bissulfato de Clopidogrel 75mg comprimido revestido"
  },
  {
    "code" : "BR0298454U0062",
    "display" : "Maleato de Dexclorfeniramina 0,4mg/1mL Xarope"
  },
  {
    "code" : "BR0267648U0110",
    "display" : "Digoxina 0,05mg/1mL Elixir"
  },
  {
    "code" : "BR0267650U0042",
    "display" : "Maleato de Enalapril 5mg Comprimido"
  },
  {
    "code" : "BR0267208U0029",
    "display" : "Estriol 1mg/1g Creme vaginal"
  },
  {
    "code" : "BR0271435U0019",
    "display" : "Estrogênios Conjugados 0,625mg/1g Creme vaginal"
  },
  {
    "code" : "BR0300723U0086",
    "display" : "Fenobarbital 40mg/1mL Solução oral"
  },
  {
    "code" : "BR0273009U0041",
    "display" : "Cloridrato de Fluoxetina 20mg Cápsula"
  },
  {
    "code" : "BR0269622U0060",
    "display" : "Glicerol 120mg/1mL Solução retal; frasco"
  },
  {
    "code" : "BR0292194U0005",
    "display" : "Decanoato de Haloperidol 50mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0345240U0017",
    "display" : "Acetato de Hidrocortisona 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0267544U0037",
    "display" : "Glicose 10% solução para injeção 250 mL; bolsa"
  },
  {
    "code" : "BR0342134U0118",
    "display" : "Succinato Sódico de Hidrocortisona 500mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0443955",
    "display" : "Betametasona 1mg/mL + Clorfenesina 10 mg/mL + Tetracaína 5 mg/mL solução otológica"
  },
  {
    "code" : "BR0478939U0115",
    "display" : "Risdiplam 0.75mg/1 mL pó para solução oral"
  },
  {
    "code" : "BR0278264U0041",
    "display" : "Trientina 250mg Cápsula"
  },
  {
    "code" : "BR0434125U0041",
    "display" : "Colecalciferol 1.000UI Cápsula"
  },
  {
    "code" : "BR0457718-1",
    "display" : "Emicizumabe 150mg/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0435176",
    "display" : "Alginato de Sódio 100mg/mL + Bicarbonato de Potássio 20 mg/mL suspensão oral"
  },
  {
    "code" : "BR0418667",
    "display" : "Rufinamida 200mg comprimido revestido"
  },
  {
    "code" : "BR0441769",
    "display" : "Sitagliptina 100mg + Metformina 1g comprimido de liberação prolongada"
  },
  {
    "code" : "BR0441571",
    "display" : "Blinatumomabe 38.5mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266823U0118",
    "display" : "Imunoglobulina Humana 10g/10mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268378U0004",
    "display" : "Cloridrato de Alfentanila 5,44mg/10mL Solução para injeção"
  },
  {
    "code" : "BR0614332",
    "display" : "Propionato de Fluticasona 50micrograma/1dose + Cloridrato de Azelastina 137mg/1dose suspensão spray; frasco"
  },
  {
    "code" : "BR0271848U0098",
    "display" : "Bimatoprosta 0,3mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0603198",
    "display" : "Citrato de Potássio 1.620mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0446772U0041",
    "display" : "Palbociclibe 125mg Cápsula"
  },
  {
    "code" : "BR0397280U0074",
    "display" : "Mikania Glomerata Spreng. 0,1mg/1mL xarope; ; frasco"
  },
  {
    "code" : "BR0387488U0042",
    "display" : "Isoniazida 300mg Comprimido"
  },
  {
    "code" : "BR0447820U0041",
    "display" : "Glycine Max (L.) Merr. 500mg Cápsula"
  },
  {
    "code" : "BR0268573U0042",
    "display" : "Acetato de Desmopressina 0,1mg Comprimido"
  },
  {
    "code" : "BR0429303U0062",
    "display" : "Cynara Scolymus L. 1,5mg/1mL Tintura"
  },
  {
    "code" : "BR0427442U0045",
    "display" : "Hidroxocobalamina 5.000mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0279269U0042",
    "display" : "Varfarina Sódica 5mg Comprimido"
  },
  {
    "code" : "BR0270141U0042",
    "display" : "Cloridrato de Biperideno 4mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0397280U0062",
    "display" : "Mikania Glomerata Spreng. 0,1mg/1mL xarope; ; frasco"
  },
  {
    "code" : "BR0428080U0042",
    "display" : "Raltegravir Potássico 100mg comprimido mastigável"
  },
  {
    "code" : "BR0287825",
    "display" : "Cloreto de Sódio 10% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0275963U0042",
    "display" : "Finasterida 5mg comprimido revestido"
  },
  {
    "code" : "BR0270814U0118",
    "display" : "Dexametasona 4mg/2mL + Piridoxina 100mg/1mL + Cianocobalamina 5mg/2mL + Tiamina 100mg/1mL solução para injeção"
  },
  {
    "code" : "BR0308874U0118",
    "display" : "Isetionato de Pentamidina 300mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0395558U0285",
    "display" : "Ácido Salicílico 50mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0268297U0042",
    "display" : "Ofloxacino 400mg comprimido revestido"
  },
  {
    "code" : "BR0348659U0004",
    "display" : "Soro Antidiftérico 10.000UI/10mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0348659U0013",
    "display" : "Soro Antidiftérico 5.000UI/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0341174U0062",
    "display" : "Clorexidina 0,12% colutório; frasco"
  },
  {
    "code" : "BR0267518U0042",
    "display" : "Atenolol 100mg Comprimido"
  },
  {
    "code" : "BR0294096U0118",
    "display" : "Ceftriaxona Sódica 250mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0351478",
    "display" : "Etodolaco 500mg comprimido revestido"
  },
  {
    "code" : "BR0268112U0046",
    "display" : "Hidralazina 50mg drágea"
  },
  {
    "code" : "BR0332987U0042",
    "display" : "Levofloxacino 250mg comprimido revestido"
  },
  {
    "code" : "BR0268575U0005",
    "display" : "Acetato de Desmopressina 4micrograma/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0272837U0041",
    "display" : "Rifampicina 300mg Cápsula"
  },
  {
    "code" : "BR0268830U0042",
    "display" : "Ritonavir 100mg comprimido revestido"
  },
  {
    "code" : "BR0272796U0106",
    "display" : "Heparina Sódica 25.000UI/5mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267424U0009",
    "display" : "Cloridrato de Verapamil 5mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268158U0042",
    "display" : "Pirimetamina 25mg Comprimido"
  },
  {
    "code" : "BR0267194U0009",
    "display" : "Diazepam 10mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0273450U0042",
    "display" : "Moxifloxacino 400mg comprimido revestido"
  },
  {
    "code" : "BR0268510U0013",
    "display" : "Flumazenil 0,5mg/5mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0267778-1",
    "display" : "Paracetamol 500mg pó para solução oral; Sachê"
  },
  {
    "code" : "BR0450888",
    "display" : "Ocrelizumabe 300mg/10mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0427719U0042",
    "display" : "Succinato de Prucaloprida 1mg comprimido revestido"
  },
  {
    "code" : "BR0267162U0004",
    "display" : "Cloreto de Potássio 19,1% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0438093",
    "display" : "Colecalciferol 200UI cápsula"
  },
  {
    "code" : "BR0450762U0041",
    "display" : "Ixazomibe 4mg cápsula"
  },
  {
    "code" : "BR0477861",
    "display" : "Fluticasona 100micrograma/1dose + Vilanterol 25micrograma/1dose + Umeclidínio 62,5micrograma/1dose pó para inalação; dispositivo"
  },
  {
    "code" : "BR0269846U0015",
    "display" : "Cloridrato de Lidocaína 20mg/1g gel; Seringa preenchida"
  },
  {
    "code" : "BR0433218U0098",
    "display" : "Insulina Degludeca 100UI/1mL Solução para injeção"
  },
  {
    "code" : "BR0452628",
    "display" : "Palbociclibe 100mg Cápsula"
  },
  {
    "code" : "BR0480346",
    "display" : "Lorlatinibe 100mg comprimido revestido"
  },
  {
    "code" : "BR0480136",
    "display" : "Toxina Botulínica A 300 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0429678U0042",
    "display" : "Levetiracetam 1000mg comprimido revestido"
  },
  {
    "code" : "BR0406994U0041",
    "display" : "Passiflora Incarnata 857mg comprimido revestido"
  },
  {
    "code" : "BR0473091",
    "display" : "Baricitinibe 2mg comprimido revestido"
  },
  {
    "code" : "BR0602807",
    "display" : "Bisoprolol 10mg + Anlodipino 5mg comprimido"
  },
  {
    "code" : "BR0268084U0046",
    "display" : "Cabergolina 0,5mg comprimido"
  },
  {
    "code" : "BR0485276",
    "display" : "Montelucaste de Sódio 10mg + Levocetirizina 5mg comprimido revestido"
  },
  {
    "code" : "BR0443165U0042",
    "display" : "Harpagophytum Procumbens Dc. Ex Meissn. 450mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0483555",
    "display" : "Harpagophytum Procumbens Dc. Ex Meissn. 250mg comprimido"
  },
  {
    "code" : "BR0269998U0110",
    "display" : "Estolato de Eritromicina 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0269848U0009",
    "display" : "Glicose 150mg/2mL + Cloridrato de Lidocaína 100mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0412966",
    "display" : "Simeticona 75mg/mL emulsão oral"
  },
  {
    "code" : "BR0451597U0023",
    "display" : "Aloe Vera (L.) Burman F. 10% gel; Tubo"
  },
  {
    "code" : "BR0419745",
    "display" : "Carnitina 100mg/1mL Solução oral"
  },
  {
    "code" : "BR0606841U0042",
    "display" : "Rifapentina 300mg + Isoniazida 300mg Comprimido"
  },
  {
    "code" : "BR0272898",
    "display" : "Betametasona 0,25mg/1mL + Maleato de Dexclorfeniramina 2mg/1mL Solução oral"
  },
  {
    "code" : "BR0292205U0062",
    "display" : "Isoniazida 20mg/1 mL suspensão oral"
  },
  {
    "code" : "BR0607364",
    "display" : "Naproxeno Sódico 500mg + Succinato de Sumatriptana 85mg comprimido revestido"
  },
  {
    "code" : "BR0440396",
    "display" : "Fosaprepitanto Dimeglumina 150mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0483737",
    "display" : "Deutetrabenazina 6mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0442877",
    "display" : "Olaparibe 50mg cápsula"
  },
  {
    "code" : "BR0272369U0042",
    "display" : "Cloridrato de Valaciclovir 500mg comprimido revestido"
  },
  {
    "code" : "BR0448838U0067",
    "display" : "Acebrofilina 5mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0445952",
    "display" : "Pioglitazona 15mg + Alogliptina 25 mg comprimido revestido"
  },
  {
    "code" : "BR0433074",
    "display" : "Atalureno 125mg granulado para suspensão; envelope"
  },
  {
    "code" : "BR0270138U0005",
    "display" : "Lactato de Biperideno 5mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0340783U0062",
    "display" : "Hidróxido de Alumínio 61,5mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0322441U0046",
    "display" : "Glicosamina 1g cápsula"
  },
  {
    "code" : "BR0450785",
    "display" : "Venetoclax 100mg comprimido revestido"
  },
  {
    "code" : "BR0268820U0041",
    "display" : "Sulfato de Atazanavir 200mg Cápsula"
  },
  {
    "code" : "BR0384830U0042",
    "display" : "Ácido Tranexâmico 500mg comprimido"
  },
  {
    "code" : "BR0435700U0032",
    "display" : "Ombitasvir 12,5mg + Dasabuvir 250mg + Veruprevir 75mg + Ritonavir 50mg Comprimido"
  },
  {
    "code" : "BR0292196U0005",
    "display" : "Haloperidol 5mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0269388U0006",
    "display" : "Fosfato Dissódico de Dexametasona 4mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0419942U0118",
    "display" : "Meropeném 2g pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0271913U0041",
    "display" : "Retinol 50.000UI cápsula"
  },
  {
    "code" : "BR0342270U0106",
    "display" : "Imunoglobulina antitimócito 25mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0446251U0541",
    "display" : "Carvão Vegetal Ativado 5g pó para solução oral; Sachê"
  },
  {
    "code" : "BR0268292U0042",
    "display" : "Folinato de Cálcio 15mg Comprimido"
  },
  {
    "code" : "BR0270813U0042",
    "display" : "Cianocobalamina 5mg + Tiamina 100mg + Piridoxina 100mg comprimido revestido"
  },
  {
    "code" : "BR0474742U0042",
    "display" : "Ácido Ascórbico 1g comprimido revestido"
  },
  {
    "code" : "BR0395601U0042",
    "display" : "Ácido Nicotínico 250mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0367693U0042",
    "display" : "Ácido Nicotínico 750mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0268352U0106",
    "display" : "Tartarato de Brimonidina 2mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0271866U0106",
    "display" : "Brinzolamida 10mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0267544U0034",
    "display" : "Glicose 10% solução para injeção 100 mL; bolsa"
  },
  {
    "code" : "BR0287252U0120",
    "display" : "Nicotina 2mg pastilha"
  },
  {
    "code" : "BR0306947U0041",
    "display" : "Fosfato de Oseltamivir 75mg Cápsula"
  },
  {
    "code" : "BR0270220U0118",
    "display" : "Succinato Sódico de Hidrocortisona 100mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270616U0118",
    "display" : "Benzilpenicilina Potássica 5.000.000UI Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292205U0042",
    "display" : "Isoniazida 100mg Comprimido"
  },
  {
    "code" : "BR0437695",
    "display" : "Acetato de Racealfatocoferol 400UI cápsula"
  },
  {
    "code" : "BR0392113U0042",
    "display" : "Risperidona 0,25mg comprimido revestido"
  },
  {
    "code" : "BR0284106U0097",
    "display" : "Risperidona 1mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0395618U0041",
    "display" : "Cynara Scolymus L. 300mg cápsula"
  },
  {
    "code" : "BR0395716U0030",
    "display" : "Schinus Terebinthifolia Raddi 0,67mL/1g creme; bisnaga"
  },
  {
    "code" : "BR0332849U0023",
    "display" : "Calcipotriol 50micrograma/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0414435U0135",
    "display" : "Certolizumabe Pegol 200mg/1mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0284460U0104",
    "display" : "Propionato de Clobetasol 0,5mg/1g solução cutânea; frasco"
  },
  {
    "code" : "BR0414431U0135",
    "display" : "Golimumabe 50mg/0,5mL Solução para injeção"
  },
  {
    "code" : "BR0268520U0105",
    "display" : "Rituximabe 500mg/50mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266701U0061",
    "display" : "Budesonida 50micrograma/1dose suspensão nasal; frasco"
  },
  {
    "code" : "BR0472278",
    "display" : "Baricitinibe 4mg comprimido revestido"
  },
  {
    "code" : "BR038566",
    "display" : "Clorexidina 2% gel; Tubo"
  },
  {
    "code" : "BR0368779U0067",
    "display" : "Mikania Glomerata Spreng. 117,6mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0608060",
    "display" : "Beclometasona 200micrograma/1dose + Formoterol 6micrograma/1dose solução para inalação; dispositivo"
  },
  {
    "code" : "BR0271028U0063",
    "display" : "Diclofenaco Resinato 15mg/1mL suspensão; frasco"
  },
  {
    "code" : "BR0271028U0086",
    "display" : "Diclofenaco Resinato 15mg/1mL suspensão; frasco"
  },
  {
    "code" : "BR0450768",
    "display" : "Elotuzumabe 300mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0465391U0042",
    "display" : "Selexipague 1mg comprimido revestido"
  },
  {
    "code" : "BR0445431U0042",
    "display" : "Sacubitril Valsartana Sódica Hidratada 50mg comprimido revestido"
  },
  {
    "code" : "BR0485127U0042",
    "display" : "Ezetimiba 10mg + Rosuvastatina 40mg comprimido revestido"
  },
  {
    "code" : "BR0604578",
    "display" : "Aspartato de Ornitina 3.000mg/5g granulado para solução; envelope"
  },
  {
    "code" : "BR0419549U0041",
    "display" : "Biotina 10mg cápsula"
  },
  {
    "code" : "BR0480862U0042",
    "display" : "Dolutegravir 5mg Comprimido para suspensão"
  },
  {
    "code" : "BR0267506U0042",
    "display" : "Albendazol 400mg comprimido mastigável"
  },
  {
    "code" : "BR0271606U0041",
    "display" : "Cloridrato de Nortriptilina 25mg Cápsula"
  },
  {
    "code" : "BR0271610U0041",
    "display" : "Cloridrato de Nortriptilina 50mg Cápsula"
  },
  {
    "code" : "BR0457206",
    "display" : "Apalutamida 60mg comprimido revestido"
  },
  {
    "code" : "BR0233632U0062",
    "display" : "Óleo Mineral 1mg/1mL solução oral; ; frasco"
  },
  {
    "code" : "BR0233632U0067",
    "display" : "Óleo Mineral 1mg/1mL solução oral; ; frasco"
  },
  {
    "code" : "BR0233632U0103",
    "display" : "Óleo Mineral 1mg/1mL solução oral; ; frasco"
  },
  {
    "code" : "BR0398178-1",
    "display" : "Colecalciferol 200UI solução oral; frasco"
  },
  {
    "code" : "BR0443375U0041",
    "display" : "Passiflora Incarnata 500mg comprimido revestido"
  },
  {
    "code" : "BR0267712U0041",
    "display" : "Omeprazol 20mg Cápsula de liberação retardada"
  },
  {
    "code" : "BR0437080U0042",
    "display" : "Riociguate 2,5mg comprimido revestido"
  },
  {
    "code" : "BR0452496",
    "display" : "Mesilato de Dabrafenibe 75mg Cápsula"
  },
  {
    "code" : "BR0267778U0042",
    "display" : "Paracetamol 500mg Comprimido"
  },
  {
    "code" : "BR0267777U0075",
    "display" : "Paracetamol 200mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0468963",
    "display" : "Paliperidona 200mg/1mL Suspensão para injeção"
  },
  {
    "code" : "BR0267773U0110",
    "display" : "Permetrina 10mg/1mL Loção; frasco"
  },
  {
    "code" : "BR0267773U0062",
    "display" : "Permetrina 10mg/1mL Loção; frasco"
  },
  {
    "code" : "BR0405898",
    "display" : "Succinato de Desvenlafaxina Monoidratado 50mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0363597U0062",
    "display" : "Permetrina 50mg/1mL Loção; frasco"
  },
  {
    "code" : "BR0434125-1",
    "display" : "Colecalciferol 500UI solução oral; frasco"
  },
  {
    "code" : "BR0442717",
    "display" : "Fluocortolona 1mg/g + Lidocaína 20 mg/g creme"
  },
  {
    "code" : "BR0366861U0030",
    "display" : "Peróxido de Benzoíla 50mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0475935",
    "display" : "Bedaquilina 100mg comprimido"
  },
  {
    "code" : "BR0420857U0085",
    "display" : "Acetato de Hidrocortisona 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0400563U0164",
    "display" : "Ustequinumabe 90mg/1mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0432448",
    "display" : "Linagliptina 2.5mg + Metformina 500 mg comprimido revestido"
  },
  {
    "code" : "BR0484664",
    "display" : "Curcuma Longa L. 250mg cápsula"
  },
  {
    "code" : "BR0453600U0041",
    "display" : "Itraconazol 25mg cápsula"
  },
  {
    "code" : "BR0271353U0106",
    "display" : "Cloridrato de Pilocarpina 20mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0376695U0042",
    "display" : "Piridoxina 50mg comprimido"
  },
  {
    "code" : "BR0267741U0042",
    "display" : "Prednisona 5mg Comprimido"
  },
  {
    "code" : "BR0267743U0042",
    "display" : "Prednisona 20mg Comprimido"
  },
  {
    "code" : "BR0273589U0042",
    "display" : "Propiltiouracila 100mg Comprimido"
  },
  {
    "code" : "BR0267771U0042",
    "display" : "Cloridrato de Propranolol 10mg Comprimido"
  },
  {
    "code" : "BR0267765U0042",
    "display" : "Sulfadiazina 500mg Comprimido"
  },
  {
    "code" : "BR0272089U0121",
    "display" : "Sulfadiazina de Prata 1% Pasta"
  },
  {
    "code" : "BR0272089U0146",
    "display" : "Sulfadiazina de Prata 1% Pasta"
  },
  {
    "code" : "BR0266707U0066",
    "display" : "Budesonida 64micrograma/1dose suspensão spray"
  },
  {
    "code" : "BR0332468U0062",
    "display" : "Sulfato Ferroso Heptaidratado 25mg/1mL (Ferro 5 mg/mL) xarope; frasco"
  },
  {
    "code" : "BR0272341U0042",
    "display" : "Tiamina 300mg comprimido revestido"
  },
  {
    "code" : "BR0278283U0042",
    "display" : "Acetazolamida 250mg Comprimido"
  },
  {
    "code" : "BR0267504U0041",
    "display" : "Ácido Valproico 250mg Cápsula"
  },
  {
    "code" : "BR0274648U0031",
    "display" : "Óxido de Zinco 250mg/1g + Mentol 5mg/1g Pasta; bisnaga"
  },
  {
    "code" : "BR0267504U0042",
    "display" : "Ácido Valproico 250mg Comprimido"
  },
  {
    "code" : "BR0267505U0042",
    "display" : "Valproato de Sódio 500mg Comprimido de liberação retardada"
  },
  {
    "code" : "BR0267507U0063",
    "display" : "Albendazol 40mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0267509U0042",
    "display" : "Alopurinol 300mg Comprimido"
  },
  {
    "code" : "BR0267510U0042",
    "display" : "Cloridrato de Amiodarona 200mg comprimido"
  },
  {
    "code" : "BR0267512U0042",
    "display" : "Cloridrato de Amitriptilina 25mg comprimido revestido"
  },
  {
    "code" : "BR0271089U0041",
    "display" : "Amoxicilina Tri-Hidratada 500mg Cápsula"
  },
  {
    "code" : "BR0271089U0042",
    "display" : "Amoxicilina Tri-Hidratada 500mg Comprimido"
  },
  {
    "code" : "BR0443164U0042",
    "display" : "Glycine Max (L.) Merr. 60mg Comprimido"
  },
  {
    "code" : "BR0450166",
    "display" : "Lurasidona 40mg comprimido revestido"
  },
  {
    "code" : "BR0340758U0042",
    "display" : "Dipirona 250mg + Cafeína 30mg e Dipirona 250mg + Maleato de Clorfeniramina 2mg comprimido revestido"
  },
  {
    "code" : "BR0448702U0118",
    "display" : "Etanercepte 50mg/1 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0451638U0106",
    "display" : "Alfavestronidase 10mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0282299U0041",
    "display" : "Sulpirida 50mg cápsula"
  },
  {
    "code" : "BR0400563U0238",
    "display" : "Ustequinumabe 45mg/0,5 mL solução para injeção; seringa preenchida"
  },
  {
    "code" : "BR0305936U0007",
    "display" : "Propofol 400mg/20 mL emulsão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270909",
    "display" : "Paracetamol 500mg + Cafeína 65mg comprimido revestido"
  },
  {
    "code" : "BR0449681",
    "display" : "Colecalciferol 10.000UI cápsula"
  },
  {
    "code" : "BR0602271",
    "display" : "Flurbiprofeno 40mg adesivo transdérmico"
  },
  {
    "code" : "BR0486368U0042",
    "display" : "Lamivudina 300mg + Dolutegravir Sódico 50mg comprimido revestido"
  },
  {
    "code" : "BR0436603",
    "display" : "Adapaleno 1mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0478931U0062",
    "display" : "Cloridrato de Dexmedetomidina 400micrograma/100mL solução para injeção; bolsa"
  },
  {
    "code" : "BR0604745",
    "display" : "Hedera Helix 15mg/1mL Xarope; frasco"
  },
  {
    "code" : "BR0296302U0042",
    "display" : "Cloridrato de Paroxetina 25mg comprimido revestido"
  },
  {
    "code" : "BR0367576",
    "display" : "Captopril 1mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0436256",
    "display" : "Bisoprolol 5mg + Hidroclorotiazida 12,5mg comprimido revestido"
  },
  {
    "code" : "BR0337862U0170",
    "display" : "Vacina Hepatite B (Recombinante) 10micrograma/0,5mL Suspensão para injeção"
  },
  {
    "code" : "BR0271111U0074",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0372335U0029",
    "display" : "Metronidazol 100mg/1g Gel vaginal; bisnaga"
  },
  {
    "code" : "BR0432197U0042",
    "display" : "Glycine Max (L.) Merr. 125mg comprimido revestido"
  },
  {
    "code" : "BR0432210U0041",
    "display" : "Uncaria Tomentosa (Willd. Ex Roem. & Schult.) Dc. 450mg Cápsula"
  },
  {
    "code" : "BR0273702U0042",
    "display" : "Naproxeno 250mg Comprimido"
  },
  {
    "code" : "BR0268005U0081",
    "display" : "Travoprosta 0,04mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0281135U0113",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL + Clavulanato de Potássio 12,5mg/1mL Pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0281135U0062",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL + Clavulanato de Potássio 12,5mg/1mL Pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0272434U0042",
    "display" : "Besilato de Anlodipino 5mg Comprimido"
  },
  {
    "code" : "BR0268896U0042",
    "display" : "Besilato de Anlodipino 10mg Comprimido"
  },
  {
    "code" : "BR0314517U0117",
    "display" : "Azitromicina Di-Hidratada 900mg Pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0345240U0018",
    "display" : "Acetato de Hidrocortisona 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0326010U0015",
    "display" : "Triancinolona Acetonida 1mg/1g Pomada; bisnaga"
  },
  {
    "code" : "BR0267140U0042",
    "display" : "Azitromicina Di-Hidratada 500mg comprimido revestido"
  },
  {
    "code" : "BR0396414U0243",
    "display" : "Plantago Ovata Forssk.   3,5g/5g pó para solução oral; envelope"
  },
  {
    "code" : "BR0270612U0118",
    "display" : "Benzilpenicilina Benzatina 1.200.000UI Pó para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0270140U0042",
    "display" : "Cloridrato de Biperideno 2mg Comprimido"
  },
  {
    "code" : "BR0440867U0067",
    "display" : "Carbamazepina 20mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0267565U0042",
    "display" : "Carvedilol 6,25mg Comprimido"
  },
  {
    "code" : "BR0267567U0042",
    "display" : "Carvedilol 25mg Comprimido"
  },
  {
    "code" : "BR0271103U0062",
    "display" : "Cetoconazol 20mg/1mL Xampu; frasco"
  },
  {
    "code" : "BR0267632U0042",
    "display" : "Cloridrato de Ciprofloxacino 500mg comprimido revestido"
  },
  {
    "code" : "BR0269986U0042",
    "display" : "Claritromicina 250mg Comprimido"
  },
  {
    "code" : "BR0268436U0041",
    "display" : "Cloridrato de Clindamicina 300mg Cápsula"
  },
  {
    "code" : "BR0270120U0086",
    "display" : "Clonazepam 2,5mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0267638U0042",
    "display" : "Clorpromazina 100mg comprimido revestido"
  },
  {
    "code" : "BR0269388U0042",
    "display" : "Dexametasona 4mg Comprimido"
  },
  {
    "code" : "BR0268243U0062",
    "display" : "Dexametasona 0,1mg/1mL Elixir; frasco"
  },
  {
    "code" : "BR0267187U0106",
    "display" : "Dexametasona 1mg/1mL suspensão oftálmica; frasco"
  },
  {
    "code" : "BR0267471U0118",
    "display" : "Alfapeginterferona 2b 177,6micrograma pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268079U0042",
    "display" : "Cloridrato de Amantadina 100mg Comprimido"
  },
  {
    "code" : "BR0342501U0041",
    "display" : "Fenofibrato 250mg Cápsula de liberação retardada"
  },
  {
    "code" : "BR0270785U0084",
    "display" : "Bromidrato de Fenoterol 100micrograma/1dose Solução aerossol; frasco"
  },
  {
    "code" : "BR0266809U0109",
    "display" : "Xinafoato de Salmeterol 50micrograma/1dose Pó para inalação; frasco"
  },
  {
    "code" : "BR0440863U0074",
    "display" : "Maleato de Dexclorfeniramina 0,4mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267195U0042",
    "display" : "Diazepam 5mg Comprimido"
  },
  {
    "code" : "BR0267647U0042",
    "display" : "Digoxina 0,25mg Comprimido"
  },
  {
    "code" : "BR0267205U0063",
    "display" : "Dipirona Monoidratada 500mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0267205U0086",
    "display" : "Dipirona Monoidratada 500mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0354633U0081",
    "display" : "Cloridrato de Olopatadina 2mg/1mL Solução oftálmica; frasco"
  },
  {
    "code" : "BR0267653U0042",
    "display" : "Espironolactona 25mg Comprimido"
  },
  {
    "code" : "BR0267654U0042",
    "display" : "Espironolactona 100mg Comprimido"
  },
  {
    "code" : "BR0356602U0042",
    "display" : "Estrogênios Conjugados 0,3mg drágea"
  },
  {
    "code" : "BR0267660U0042",
    "display" : "Fenobarbital 100mg Comprimido"
  },
  {
    "code" : "BR0267661U0041",
    "display" : "Fluconazol 100mg cápsula"
  },
  {
    "code" : "BR0267662U0041",
    "display" : "Fluconazol 150mg Cápsula"
  },
  {
    "code" : "BR0273009U0042",
    "display" : "Cloridrato de Fluoxetina 20mg comprimido revestido"
  },
  {
    "code" : "BR0269622U0090",
    "display" : "Glicerol 120mg/1mL Solução retal; frasco"
  },
  {
    "code" : "BR0273115U0042",
    "display" : "Gliclazida 80mg Comprimido"
  },
  {
    "code" : "BR0267669U0042",
    "display" : "Haloperidol 5mg Comprimido"
  },
  {
    "code" : "BR0268111U0046",
    "display" : "Cloridrato de Hidralazina 25mg drágea"
  },
  {
    "code" : "BR0345240U0023",
    "display" : "Acetato de Hidrocortisona 10mg/1g Creme; bisnaga"
  },
  {
    "code" : "BR0294648U0042",
    "display" : "Ibuprofeno 200mg Comprimido"
  },
  {
    "code" : "BR0267677U0042",
    "display" : "Ibuprofeno 300mg Comprimido"
  },
  {
    "code" : "BR0273401U0042",
    "display" : "Mononitrato de Isossorbida 40mg Comprimido"
  },
  {
    "code" : "BR0268861U0041",
    "display" : "Itraconazol 100mg Cápsula"
  },
  {
    "code" : "BR0273328U0042",
    "display" : "Ivermectina 6mg Comprimido"
  },
  {
    "code" : "BR0295853U0042",
    "display" : "Levonorgestrel 1,5mg comprimido"
  },
  {
    "code" : "BR0268124U0042",
    "display" : "Levotiroxina Sódica 25micrograma Comprimido"
  },
  {
    "code" : "BR0268123U0042",
    "display" : "Levotiroxina Sódica 50micrograma Comprimido"
  },
  {
    "code" : "BR0268125U0042",
    "display" : "Levotiroxina Sódica 100micrograma Comprimido"
  },
  {
    "code" : "BR0269846U0023",
    "display" : "Cloridrato de Lidocaína 20mg/1g Gel; bisnaga"
  },
  {
    "code" : "BR0269845U0105",
    "display" : "Lidocaína 100mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0295040U0042",
    "display" : "Lamotrigina 25mg Comprimido para suspensão"
  },
  {
    "code" : "BR0272809U0042",
    "display" : "Lamotrigina 100mg Comprimido"
  },
  {
    "code" : "BR0271710U0010",
    "display" : "Cloridrato de Amiodarona 150mg/3mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0267574U0004",
    "display" : "Cloreto de Sódio 20% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0272846U0042",
    "display" : "Talidomida 100mg Comprimido"
  },
  {
    "code" : "BR0267541U0004",
    "display" : "Glicose 50% solução para injeção 10 mL; ampola"
  },
  {
    "code" : "BR0267393U0041",
    "display" : "Tetraciclina 500mg Comprimido"
  },
  {
    "code" : "BR0268151U0110",
    "display" : "Prednisolona 1mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0268395U0118",
    "display" : "Anfotericina B 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0287559U0321",
    "display" : "Estavudina 1mg/1mL Pó para solução oral; frasco"
  },
  {
    "code" : "BR0271052U0444",
    "display" : "Bicarbonato de Sódio 50g pó para solução oral; envelope"
  },
  {
    "code" : "BR0417713U0042",
    "display" : "Gliclazida 60mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0373165U0118",
    "display" : "Sulfato de Capreomicina 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268415U0118",
    "display" : "Ceftriaxona Sódica 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0280115U0042",
    "display" : "Bosentana Monoidratada 125mg comprimido revestido"
  },
  {
    "code" : "BR0411397-5",
    "display" : "Palmitato de Paliperidona 150mg/1,5mL suspensão para injeção de liberação prolongada; Seringa preenchida"
  },
  {
    "code" : "BR0273821U0042",
    "display" : "Citrato de Sildenafila 50mg comprimido revestido"
  },
  {
    "code" : "BR0388383U0162",
    "display" : "Tocilizumabe 80mg/4mL Solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268353U0042",
    "display" : "Nevirapina 200mg Comprimido"
  },
  {
    "code" : "BR0272737U0013",
    "display" : "Antimoniato de Meglumina 1.500mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268255U0005",
    "display" : "Epinefrina 1mg/1mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268956U0042",
    "display" : "Levonorgestrel 0,75mg Comprimido"
  },
  {
    "code" : "BR0273400U0042",
    "display" : "Mononitrato de Isossorbida 20mg Comprimido"
  },
  {
    "code" : "BR0268150U0110",
    "display" : "Fosfato Sódico de Prednisolona 3mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0299766U0042",
    "display" : "Cloridrato de Etambutol 400mg comprimido revestido"
  },
  {
    "code" : "BR0269996U0042",
    "display" : "Estolato de Eritromicina 500mg Comprimido"
  },
  {
    "code" : "BR0395837U0018",
    "display" : "Alcatrão Mineral 1% Pomada; bisnaga"
  },
  {
    "code" : "BR0287481U0140",
    "display" : "Nicotina 2mg Goma de mascar"
  },
  {
    "code" : "BR0364037U0042",
    "display" : "Rifampicina 150mg + Etambutol 275mg + Isoniazida 75mg + Pirazinamida 400mg comprimido revestido"
  },
  {
    "code" : "BR0268446U0007",
    "display" : "Cloridrato de Dobutamina 250mg/20mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268960U0004",
    "display" : "Cloridrato de Dopamina 50mg/10mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0268414U0118",
    "display" : "Ceftriaxona Sódica 1g Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268236U0034",
    "display" : "Cloreto de Sódio 0,9%  solução para injeção 100 ml; bolsa"
  },
  {
    "code" : "BR0308884U0062",
    "display" : "Trimetoprima 8mg/1mL + Sulfametoxazol 40mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0267617U0042",
    "display" : "Carbamazepina 400mg comprimido"
  },
  {
    "code" : "BR0270597U0005",
    "display" : "Acetato de Betametasona 3mg/1mL + Fosfato Dissódico de Betametasona 3mg/1mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0292419U0011",
    "display" : "Fosfato de Clindamicina 600mg/4mL solução para injeção; ampola"
  },
  {
    "code" : "BR0270992U0042",
    "display" : "Diclofenaco Potássico 50mg comprimido revestido"
  },
  {
    "code" : "BR0440864U0041",
    "display" : "Claritromicina 500mg cápsula"
  },
  {
    "code" : "BR0267631U0042",
    "display" : "Cloridrato de Ciprofloxacino 250mg comprimido revestido"
  },
  {
    "code" : "BR0429853U0041",
    "display" : "Mentha Piperita 300mg cápsula"
  },
  {
    "code" : "BR0400564U0042",
    "display" : "Arteméter 20mg + Lumefantrina 120mg comprimido"
  },
  {
    "code" : "BR0269963U0085",
    "display" : "Domperidona 1mg/1mL Suspensão oral; frasco"
  },
  {
    "code" : "BR0267777U0086",
    "display" : "Paracetamol 200mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0271353U0063",
    "display" : "Cloridrato de Pilocarpina 20mg/1mL solução oftálmica; frasco"
  },
  {
    "code" : "BR0395631U0062",
    "display" : "Mikania Glomerata Spreng. 0,05mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0272337U0042",
    "display" : "Cloridrato de Piridoxina 100mg comprimido"
  },
  {
    "code" : "BR0332754U0097",
    "display" : "Ibuprofeno 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0268417U0118",
    "display" : "Ceftriaxona Dissódica Hemieptaidratada 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0329507U0041",
    "display" : "Palmitato de Retinol 100.000UI cápsula"
  },
  {
    "code" : "BR0268151U0067",
    "display" : "Prednisolona 1mg/1mL Solução oral; frasco"
  },
  {
    "code" : "BR0268439U0042",
    "display" : "Claritromicina 500mg comprimido revestido"
  },
  {
    "code" : "BR0293892U0067",
    "display" : "Acebrofilina 10mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0271036U0042",
    "display" : "Doxiciclina 100mg comprimido revestido"
  },
  {
    "code" : "BR0305247U0067",
    "display" : "Lactulose 667mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0267774U0042",
    "display" : "Piridoxina 40mg comprimido revestido"
  },
  {
    "code" : "BR0433940U0074",
    "display" : "Mikania Glomerata Spreng. 35mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0267508U0042",
    "display" : "Alopurinol 100mg comprimido"
  },
  {
    "code" : "BR0303292U0033",
    "display" : "Solução de Ringer + Lactato; frasco-ampola"
  },
  {
    "code" : "BR0341174U0090",
    "display" : "Clorexidina 0,12% colutório; frasco"
  },
  {
    "code" : "BR0333569U0015",
    "display" : "Tacrolimo Monoidratado 1mg/1g pomada; bisnaga"
  },
  {
    "code" : "BR0288275U0031",
    "display" : "Nitrato de Miconazol 20mg/1g + Tinidazol 30mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0268252U0009",
    "display" : "Dipirona Monoidratada 1g/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0268954U0042",
    "display" : "Praziquantel 600mg comprimido"
  },
  {
    "code" : "BR0267564U0042",
    "display" : "Carvedilol 12,5mg comprimido"
  },
  {
    "code" : "BR0332764U0042",
    "display" : "Darunavir 300mg comprimido revestido"
  },
  {
    "code" : "BR0267589U0061",
    "display" : "Dipropionato de Beclometasona 400micrograma/1dose pó para inalação; dispositivo"
  },
  {
    "code" : "BR0284114U0023",
    "display" : "Cetoconazol 20mg/1g + Dipropionato de Betametasona 0,5mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0267378U0067",
    "display" : "Nistatina 100.000UI/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0292380U0063",
    "display" : "Cloridrato de Tramadol 100mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0393780U0042",
    "display" : "Darunavir 600mg comprimido revestido"
  },
  {
    "code" : "BR0308802U0149",
    "display" : "Fator VIII de Coagulação 500UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0409539U0042",
    "display" : "Benznidazol 12,5mg comprimido"
  },
  {
    "code" : "BR0308805U0118",
    "display" : "Fator Ix de Coagulação 500UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0437668U0067",
    "display" : "Mikania Glomerata Spreng. 60mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0269998U0105",
    "display" : "Estolato de Eritromicina 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0404655U0042",
    "display" : "Ambrisentana 5mg comprimido revestido"
  },
  {
    "code" : "BR0404656U0042",
    "display" : "Ambrisentana 10mg comprimido revestido"
  },
  {
    "code" : "BR0271116U0062",
    "display" : "Fluconazol 200mg/100mL solução para injeção; bolsa"
  },
  {
    "code" : "BR0266629U0118",
    "display" : "Alfaepoetina 4.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0288641U0042",
    "display" : "Micofenolato de Sódio 360mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0343607U0118",
    "display" : "Etanercepte 25mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268143U0042",
    "display" : "Micofenolato de Mofetila 500mg comprimido revestido"
  },
  {
    "code" : "BR0267895U0041",
    "display" : "Hemitartarato de Rivastigmina 6mg cápsula"
  },
  {
    "code" : "BR0272083U0042",
    "display" : "Sevelâmer 800mg comprimido revestido"
  },
  {
    "code" : "BR0292242U0052",
    "display" : "Mesalazina 3g pó para solução oral/retal; frasco"
  },
  {
    "code" : "BR0268107U0041",
    "display" : "Gabapentina 300mg cápsula"
  },
  {
    "code" : "BR0271391U0042",
    "display" : "Sulfato de Morfina 30mg comprimido"
  },
  {
    "code" : "BR0379902U0041",
    "display" : "Fosfato de Oseltamivir 30mg cápsula"
  },
  {
    "code" : "BR0379962U0041",
    "display" : "Fosfato de Oseltamivir 45mg cápsula"
  },
  {
    "code" : "BR0395631U0074",
    "display" : "Mikania Glomerata Spreng. 0,05mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0354627U0042",
    "display" : "Hidróxido de Alumínio 230mg comprimido mastigável"
  },
  {
    "code" : "BR0406520U0118",
    "display" : "Alfaepoetina 3.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292372U0118",
    "display" : "Toxina Botulínica A 100 unidades pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308719U0041",
    "display" : "Acitretina 10mg cápsula"
  },
  {
    "code" : "BR0342320U0041",
    "display" : "Cloridrato de Ziprasidona Monoidratado 80mg cápsula"
  },
  {
    "code" : "BR0319883U0042",
    "display" : "Citrato de Sildenafila 20mg comprimido revestido"
  },
  {
    "code" : "BR0270143U0042",
    "display" : "Mesilato de Bromocriptina 2,5mg comprimido"
  },
  {
    "code" : "BR0276333U0042",
    "display" : "Cloridrato de Amitriptilina 75mg comprimido revestido"
  },
  {
    "code" : "BR0368921U0090",
    "display" : "Ácido Acético 3% solução cutânea; frasco"
  },
  {
    "code" : "BR0324358U0086",
    "display" : "Anfotericina B 100mg/20mL suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268816U0062",
    "display" : "Nevirapina Hemi-Hidratada 10mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0431732U0042",
    "display" : "Dicloridrato de Daclatasvir 60mg comprimido revestido"
  },
  {
    "code" : "BR0292345U0110",
    "display" : "Sulfato Ferroso Heptaidratado 25mg/1mL (Ferro 5 mg/mL) solução oral; frasco"
  },
  {
    "code" : "BR0399411U0062",
    "display" : "Maytenus Ilicifolia Mart. Ex Reissek 12mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0269878U0060",
    "display" : "Clorexidina 0,5% solução cutânea; frasco"
  },
  {
    "code" : "BR0395847U0031",
    "display" : "Aloe Vera (L.) Burman F. 5% pomada; bisnaga"
  },
  {
    "code" : "BR0431752U0041",
    "display" : "Simeprevir Sódico 150mg cápsula"
  },
  {
    "code" : "BR0269880U0103",
    "display" : "Clorexidina 2% solução cutânea; frasco"
  },
  {
    "code" : "BR0271111U0062",
    "display" : "Amoxicilina Tri-Hidratada 50mg/1mL pó para suspensão oral; frasco"
  },
  {
    "code" : "BR0267666U0009",
    "display" : "Furosemida 20mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0429325U0041",
    "display" : "Cynara Scolymus L. 250mg cápsula"
  },
  {
    "code" : "BR0428423U0042",
    "display" : "Fumarato de Tenofovir Desoproxila 300mg + Lamivudina 300mg comprimido revestido"
  },
  {
    "code" : "BR0395620U0041",
    "display" : "Glycine Max (L.) Merr. 150mg cápsula"
  },
  {
    "code" : "BR0437160U0063",
    "display" : "Cloreto de Sódio 9mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0268162U0030",
    "display" : "Nitrato de Miconazol 20mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0288275U0028",
    "display" : "Nitrato de Miconazol 20mg/1g + Tinidazol 30mg/1g creme vaginal; bisnaga"
  },
  {
    "code" : "BR0427335U0042",
    "display" : "Tenofovir 300mg + Lamivudina 300mg + Efavirenz 600mg comprimido revestido"
  },
  {
    "code" : "BR0332468U0110",
    "display" : "Sulfato Ferroso Heptaidratado 25mg/1mL (Ferro 5 mg/mL) xarope; frasco"
  },
  {
    "code" : "BR0394650U0042",
    "display" : "Tartarato de Metoprolol 100mg comprimido revestido"
  },
  {
    "code" : "BR0268286U0023",
    "display" : "Nitrato de Miconazol 20mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0367515U0041",
    "display" : "Cynara Scolymus L. 200mg cápsula"
  },
  {
    "code" : "BR0412094U0041",
    "display" : "Cloridrato de Fingolimode 0,5mg cápsula"
  },
  {
    "code" : "BR0367514U0042",
    "display" : "Hidróxido de Alumínio 230mg comprimido"
  },
  {
    "code" : "BR0280116U0042",
    "display" : "Bosentana Monoidratada 62,5mg comprimido revestido"
  },
  {
    "code" : "BR0273668U0118",
    "display" : "Mesilato de Pralidoxima 200mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267735U0009",
    "display" : "Cloridrato de Ranitidina 50mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR0272913",
    "display" : "Benzocaína 200mg/1g gel; Pote"
  },
  {
    "code" : "BR0266627U0118",
    "display" : "Alfaepoetina 1.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0272472U0041",
    "display" : "Danazol 200mg cápsula"
  },
  {
    "code" : "BR0266630U0118",
    "display" : "Alfaepoetina 10.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266628U0118",
    "display" : "Alfaepoetina 2.000UI/1mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0325838U0042",
    "display" : "Deferasirox 125mg comprimido para suspensão"
  },
  {
    "code" : "BR0361382U0042",
    "display" : "Deferiprona 500mg comprimido revestido"
  },
  {
    "code" : "BR0267092U0042",
    "display" : "Lovastatina 40mg comprimido"
  },
  {
    "code" : "BR0267473U0118",
    "display" : "Alfapeginterferona 2b 148micrograma pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268148U0042",
    "display" : "Pravastatina Sódica 20mg comprimido"
  },
  {
    "code" : "BR0315088U0042",
    "display" : "Entecavir 0,5mg comprimido revestido"
  },
  {
    "code" : "BR0278482U0042",
    "display" : "Primidona 250mg comprimido"
  },
  {
    "code" : "BR0272831U0042",
    "display" : "Hemifumarato de Quetiapina 25mg comprimido revestido"
  },
  {
    "code" : "BR0387438/0006",
    "display" : "Cafeína 5mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0330115U0118",
    "display" : "Ganciclovir Sódico 500mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0269998U0062",
    "display" : "Estolato de Eritromicina 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0394789U0074",
    "display" : "Itraconazol 10mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0268081U0042",
    "display" : "Atorvastatina Cálcica 20mg comprimido revestido"
  },
  {
    "code" : "BR0369179U0042",
    "display" : "Everolimo 1mg Comprimido"
  },
  {
    "code" : "BR0292240U0136",
    "display" : "Mesalazina 1g supositório"
  },
  {
    "code" : "BR0267081U0041",
    "display" : "Fenofibrato 200mg Cápsula"
  },
  {
    "code" : "BR0284105U0042",
    "display" : "Risperidona 3mg comprimido revestido"
  },
  {
    "code" : "BR0292239U0136",
    "display" : "Mesalazina 250mg supositório"
  },
  {
    "code" : "BR0267897U0041",
    "display" : "Hemitartarato de Rivastigmina 4,5mg cápsula"
  },
  {
    "code" : "BR0268073U0042",
    "display" : "Cloridrato de Selegilina 10mg comprimido"
  },
  {
    "code" : "BR0285818U0046",
    "display" : "Sirolimo 2mg drágea"
  },
  {
    "code" : "BR0308729U0042",
    "display" : "Bezafibrato 400mg Comprimido de liberação prolongada"
  },
  {
    "code" : "BR0338883U0391",
    "display" : "Calcitonina Sintética de Salmão 200UI/1dose solução nasal; frasco"
  },
  {
    "code" : "BR0271620U0042",
    "display" : "Olanzapina 5mg comprimido revestido"
  },
  {
    "code" : "BR0268109U0135",
    "display" : "Acetato de Gosserrelina 3,6mg implante; Seringa preenchida"
  },
  {
    "code" : "BR0292344U0042",
    "display" : "Sulfato Ferroso 40mg comprimido revestido"
  },
  {
    "code" : "BR0269878",
    "display" : "Clorexidina 0,5% solução cutânea; frasco"
  },
  {
    "code" : "BR0437668U0062",
    "display" : "Mikania Glomerata Spreng. 60mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0271570U0022",
    "display" : "Dexametasona 1mg/1g pomada oftálmica; bisnaga"
  },
  {
    "code" : "BR0433249U0062",
    "display" : "Sulfato de Zinco 4mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0270431",
    "display" : "Cloridrato de Gencitabina 200mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0353641-1",
    "display" : "Hilano G-F 20 48mg/6mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0399412U0041",
    "display" : "Maytenus Ilicifolia Mart. Ex Reissek 500mg cápsula"
  },
  {
    "code" : "BR0343608U0118",
    "display" : "Etanercepte 50mg Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0364324U0042",
    "display" : "Hidroclorotiazida 12,5mg comprimido"
  },
  {
    "code" : "BR0268443U0009",
    "display" : "Fosfato de Codeína 60mg/2mL Solução para injeção; ampola"
  },
  {
    "code" : "BR0292400U0041",
    "display" : "Alfacalcidol 0,25 microgramas cápsula"
  },
  {
    "code" : "BR0268994U0042",
    "display" : "Bupropiona 150mg comprimido de liberação prolongada"
  },
  {
    "code" : "BR0435334U0042",
    "display" : "Dicloridrato de Daclatasvir 60mg comprimido revestido"
  },
  {
    "code" : "BR0272429U0042",
    "display" : "Clozapina 25mg comprimido"
  },
  {
    "code" : "BR0272784U0067",
    "display" : "Fosfato de Codeína 3mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0266736U0118",
    "display" : "Mesilato de Desferroxamina 500mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0266767U0118",
    "display" : "Alfainterferona 2b 3.000.000UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268074U0081",
    "display" : "Acetato de Desmopressina 0,1mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0267470U0118",
    "display" : "Alfapeginterferona 2a 180micrograma/0,5mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0271394U0110",
    "display" : "Sulfato de Morfina Pentaidratado 10mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0416731U0229",
    "display" : "Medroxiprogesterona 25mg/0.5mL + Estradiol 5mg/0.5mL suspensão para injeção; ampola"
  },
  {
    "code" : "BR0396414U0334",
    "display" : "Plantago Ovata Forssk.   3,26g/5,8g pó para solução oral; envelope"
  },
  {
    "code" : "BR0433940U0062",
    "display" : "Mikania Glomerata Spreng. 35mg/1mL xarope; frasco"
  },
  {
    "code" : "BR0426292U0041",
    "display" : "Rhamnus Purshiana 380mg cápsula"
  },
  {
    "code" : "BR0305725U0005",
    "display" : "Octreotida 0,1mg/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0342981U0118",
    "display" : "Acetato de Octreotida 30mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0342980U0118",
    "display" : "Acetato de Octreotida 20mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0267077U0042",
    "display" : "Bezafibrato 200mg comprimido revestido"
  },
  {
    "code" : "BR0268084U0042",
    "display" : "Cabergolina 0,5mg comprimido"
  },
  {
    "code" : "BR0271373U0041",
    "display" : "Fumarato de Formoterol 12micrograma cápsula para inalação"
  },
  {
    "code" : "BR0268581U0118",
    "display" : "Pamidronato Dissódico 60mg pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0285817U0046",
    "display" : "Sirolimo 1mg drágea"
  },
  {
    "code" : "BR0268098U0041",
    "display" : "Tacrolimo 1mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0272847U0042",
    "display" : "Tolcapona 100mg comprimido revestido"
  },
  {
    "code" : "BR0272850U0042",
    "display" : "Topiramato 50mg comprimido revestido"
  },
  {
    "code" : "BR0272852U0042",
    "display" : "Cloridrato de Triexifenidil 5mg comprimido"
  },
  {
    "code" : "BR0276388U0041",
    "display" : "Bromidrato de Galantamina 8mg cápsula de liberação prolongada"
  },
  {
    "code" : "BR0268108U0135",
    "display" : "Acetato de Gosserrelina 10,8mg implante; Seringa preenchida"
  },
  {
    "code" : "BR0268110U0041",
    "display" : "Hidroxiureia 500mg cápsula"
  },
  {
    "code" : "BR0294881U0005",
    "display" : "Iloprosta 10micrograma/1mL solução para inalação; ampola"
  },
  {
    "code" : "BR0273567U0010",
    "display" : "Imunoglobulina Humana Anti-Hepatite B 1.800mg/3mL solução para injeção; ampola"
  },
  {
    "code" : "BR0266824U0118",
    "display" : "Imunoglobulina Humana 180.000mg/60mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0292416U0005",
    "display" : "Calcitriol 1micrograma/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0271107U0041",
    "display" : "Ciclosporina 100mg Cápsula"
  },
  {
    "code" : "BR0271104U0041",
    "display" : "Ciclosporina 25mg cápsula"
  },
  {
    "code" : "BR0271106U0041",
    "display" : "Ciclosporina 50mg cápsula"
  },
  {
    "code" : "BR0272780U0042",
    "display" : "Cloroquina 150mg comprimido"
  },
  {
    "code" : "BR0395716U0023",
    "display" : "Schinus Terebinthifolia Raddi 3,996mL/6g gel vaginal; bisnaga"
  },
  {
    "code" : "BR0269573U0086",
    "display" : "Cloridrato de Bupivacaína 50mg/20mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0399442U0041",
    "display" : "Uncaria Tomentosa (Willd. Ex Roem. & Schult.) Dc. 100mg cápsula"
  },
  {
    "code" : "BR0272131U0042",
    "display" : "Sulfato de Quinina 500mg comprimido"
  },
  {
    "code" : "BR0325837U0042",
    "display" : "Deferasirox 500mg Comprimido para suspensão"
  },
  {
    "code" : "BR0266766U0118",
    "display" : "Alfainterferona 2b 10.000.000UI pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268580U0118",
    "display" : "Pamidronato Dissódico Pentaidratado 30mg pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0268114U0042",
    "display" : "Leflunomida 20mg comprimido revestido"
  },
  {
    "code" : "BR0305260U0118",
    "display" : "Acetato de Leuprorrelina 11,25mg pó e diluente para suspensão para injeção; frasco-ampola"
  },
  {
    "code" : "BR0304788U0042",
    "display" : "Cloridrato de Cinacalcete 30mg comprimido revestido"
  },
  {
    "code" : "BR0448608",
    "display" : "Carbonato de Cálcio 600mg + Colecalciferol 400UI comprimido revestido"
  },
  {
    "code" : "BR0292343",
    "display" : "Sulfadiazina de Prata 10mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0437869U0042",
    "display" : "Fumarato de Dimetila 120mg cápsula de liberação retardada"
  },
  {
    "code" : "BR0337472-1",
    "display" : "Insulina Detemir 300UI/3mL solução para injeção; dispositivo de injeção pré-carregado"
  },
  {
    "code" : "BR0391938U0086",
    "display" : "Colecalciferol 3.300UI/1mL solução oral; frasco"
  },
  {
    "code" : "BR0466603",
    "display" : "Fosfato de Clindamicina 10mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0437993U0269",
    "display" : "Trifenatato de Vilanterol 25micrograma/1dose + Brometo de Umeclidínio 62,5micrograma/1dose pó para inalação"
  },
  {
    "code" : "BR0466366U0109",
    "display" : "Brometo de Tiotrópio 2,5micrograma/1dose + Cloridrato de Olodaterol 2,5micrograma/1dose solução para inalação; dispositivo"
  },
  {
    "code" : "BR0399486",
    "display" : "Perindopril Arginina 7mg + Besilato de Anlodipino 5mg comprimido"
  },
  {
    "code" : "BR0480352",
    "display" : "Ácido Azelaico 150mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0436722",
    "display" : "Harpagophytum Procumbens Dc. Ex Meissn. 300mg comprimido de liberação retardada"
  },
  {
    "code" : "BR0400563U0170",
    "display" : "Ustequinumabe 90mg/1mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0270633U0063",
    "display" : "Cafeína 30mg/1mL + Cloridrato de Isometepteno 50mg/1mL + Dipirona 300mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0606368",
    "display" : "Mesilato de Safinamida 50mg comprimido revestido"
  },
  {
    "code" : "BR0294643",
    "display" : "Ibuprofeno 50mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0362057U0316",
    "display" : "Hidrogenotartrato de rivastigmina (9mg) 4,6mg/24hora adesivo transdérmico"
  },
  {
    "code" : "BR0410020U0042",
    "display" : "Eltrombopague 50mg comprimido revestido"
  },
  {
    "code" : "BR0615716",
    "display" : "Betaína 1g/1g pó para solução oral; frasco"
  },
  {
    "code" : "BR0271110U0042",
    "display" : "Ciproterona 2mg + Etinilestradiol 0,035mg comprimido revestido"
  },
  {
    "code" : "BR390598-3",
    "display" : "Fator VIII de Coagulação (Recombinante) 500UI Pó para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0439450U0041",
    "display" : "Biotina 2,5mg cápsula"
  },
  {
    "code" : "BR0420857U0090",
    "display" : "Acetato de Hidrocortisona 1mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR040442-1",
    "display" : "Stryphnodendron barbatiman 10% creme; bisnaga"
  },
  {
    "code" : "BR0268286U0018",
    "display" : "Nitrato de Miconazol 20mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0406994U0042",
    "display" : "Passiflora Incarnata 315mg comprimido revestido"
  },
  {
    "code" : "BR0320796U0005",
    "display" : "Acetato de Desmopressina 15micrograma/1mL solução para injeção; ampola"
  },
  {
    "code" : "BR0332383U0118",
    "display" : "Idursulfase 6mg/3mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0297697U0165",
    "display" : "Epinefrina 18micrograma/1,8mL + Cloridrato de Articaína 72mg/1,8mL solução para injeção; carpule"
  },
  {
    "code" : "BR0399486U0042",
    "display" : "Perindopril Arginina 3,5mg + Besilato de Anlodipino 2,5mg comprimido"
  },
  {
    "code" : "BR0386022",
    "display" : "Minoxidil 50mg/1mL solução spray; frasco"
  },
  {
    "code" : "BR0377899U0042",
    "display" : "Valeriana Officinalis L. 50mg comprimido revestido"
  },
  {
    "code" : "BR0439128",
    "display" : "Passiflora Incarnata 260mg comprimido revestido"
  },
  {
    "code" : "BR0367673U0105",
    "display" : "Indometacina 1mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0448289",
    "display" : "Cloridrato de Ponatinibe 15mg comprimido revestido"
  },
  {
    "code" : "BR0438851",
    "display" : "Citrato de Fentanila 0,157mg/2mL + Droperidol 5mg/2mL solução para injeção; ampola"
  },
  {
    "code" : "BR040442",
    "display" : "Stryphnodendron barbatiman 10% creme; bisnaga"
  },
  {
    "code" : "BR0366860",
    "display" : "Peróxido de Benzoíla 100mg/1g gel; bisnaga"
  },
  {
    "code" : "BR0436600",
    "display" : "Perindopril Arginina 10mg comprimido revestido"
  },
  {
    "code" : "BR0310761U0118",
    "display" : "Laronidase 2,9mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0285965U0042",
    "display" : "Levetiracetam 250mg comprimido revestido"
  },
  {
    "code" : "BR0273328U0041",
    "display" : "Ivermectina 6mg cápsula"
  },
  {
    "code" : "BR0467108",
    "display" : "Tenofovir Alafenamida 25mg comprimido revestido"
  },
  {
    "code" : "BR0448290U0042",
    "display" : "Ivacaftor 150mg comprimido revestido"
  },
  {
    "code" : "BR0438355U0587",
    "display" : "Rituximabe 1.400mg/11,7mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0395620U0042",
    "display" : "Glycine Max (L.) Merr. 150mg comprimido revestido"
  },
  {
    "code" : "BR0270587U0023",
    "display" : "Dipropionato de Betametasona 0,64mg/1g creme; bisnaga"
  },
  {
    "code" : "BR0448601",
    "display" : "Bisglicinato Ferroso 150mg + Ácido Fólico 5mg cápsula"
  },
  {
    "code" : "BR0448042",
    "display" : "Pamoato de Pirvínio 10mg/1mL suspensão oral; frasco"
  },
  {
    "code" : "BR0483776",
    "display" : "Paracetamol 1.000mg/100mL solução para injeção; bolsa"
  },
  {
    "code" : "BR0477937",
    "display" : "Besilato de Cisatracúrio 10mg/5mL solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0467651U0234",
    "display" : "Galcanezumabe 120mg/1mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0278650U0042",
    "display" : "Cloridrato de Tiamina 50mg + Dipirona Monoidratada 250mg + Cloridrato de Piridoxina 100mg + Carisoprodol 250mg + Cianocobalamina 1mg comprimido revestido"
  },
  {
    "code" : "BR0414435",
    "display" : "Certolizumabe Pegol 200mg/1mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0407030U0053",
    "display" : "Sulfato de Magnésio 990mg pó para solução oral; frasco"
  },
  {
    "code" : "BR0417285U0041",
    "display" : "Harpagophytum Procumbens Dc. Ex Meissn. 200mg cápsula"
  },
  {
    "code" : "BR0442828",
    "display" : "Citrato de Cálcio 250mg + Colecalciferol 200UI comprimido revestido"
  },
  {
    "code" : "BR0442012U0137",
    "display" : "Insulina Humana NPH 300UI/3mL suspensão para injeção; dispositivo"
  },
  {
    "code" : "BR0606917",
    "display" : "Carbonato de Cálcio 500mg + Colecalciferol 1.000UI comprimido revestido"
  },
  {
    "code" : "BR0437160U0068",
    "display" : "Cloreto de Sódio 9mg/1mL solução nasal; frasco"
  },
  {
    "code" : "BR0443373U0124",
    "display" : "Calendula Officinalis 10% gel; Tubo"
  },
  {
    "code" : "BR0284461",
    "display" : "Propionato de Clobetasol 0,5mg/1mL xampu; frasco"
  },
  {
    "code" : "BR0345794",
    "display" : "Sulfeto de Selênio 25mg/1mL xampu; frasco"
  },
  {
    "code" : "BR0269843U0165",
    "display" : "Cloridrato de Lidocaína 36mg/1,8mL solução para injeção; carpule"
  },
  {
    "code" : "BR0291231U0118",
    "display" : "Sulfato de Estreptomicina 1g pó e diluente para solução para injeção; frasco-ampola"
  },
  {
    "code" : "BR0308718U0041",
    "display" : "Acitretina 25mg cápsula"
  },
  {
    "code" : "BR0272431U0042",
    "display" : "Clozapina 100mg comprimido"
  },
  {
    "code" : "BR0292401U0041",
    "display" : "Alfacalcidol 1micrograma cápsula"
  },
  {
    "code" : "BR0437908",
    "display" : "Passiflora Alata Curtis 400mg cápsula"
  },
  {
    "code" : "BR0374313U0237",
    "display" : "Ácido Paraminossalicílico 4g granulado de liberação retardada; envelope"
  },
  {
    "code" : "BR0452302U0063",
    "display" : "Canabidiol 50mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0448121",
    "display" : "Cocculus Indicus 210mg + Petroleum 30mg + Conium Maculatum 30mg + Ambra Grisea 30mg comprimido sublingual"
  },
  {
    "code" : "BR0290058U0135B0127",
    "display" : "Adalimumabe 40mg/0,8mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0290058U0135B0135",
    "display" : "Adalimumabe 40mg/0,4mL solução para injeção; Seringa preenchida"
  },
  {
    "code" : "BR0434357",
    "display" : "Passiflora Incarnata 90mg/1mL solução oral; frasco"
  },
  {
    "code" : "BR0607789",
    "display" : "Inositol 2g + Ácido Fólico 200micrograma pó para solução oral; Sachê"
  },
  {
    "code" : "BR0458417",
    "display" : "Aceponato de Metilprednisolona 1mg/1mL solução cutânea; frasco"
  },
  {
    "code" : "BR0318291",
    "display" : "Ácido Salicílico 100mg/1mL solução cutânea"
  },
  {
    "code" : "BR0470184",
    "display" : "Rifapentina 150mg comprimido"
  },
  {
    "code" : "BR0485309",
    "display" : "Pregabalina 75mg comprimido"
  },
  {
    "code" : "BR0362268",
    "display" : "Aprepitanto 125mg Cápsula"
  },
  {
    "code" : "BR0443476",
    "display" : "Hidrosmina 200mg cápsula"
  },
  {
    "code" : "BR0443476U0041",
    "display" : "Hidrosmina 200mg cápsula"
  }]
}

```
