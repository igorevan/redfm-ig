# BR Core Composition - Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS v1.0.0-release

## Resource Profile: BR Core Composition 

 
Este perfil representa as restrições aplicadas ao recurso br-core-composition 

**Usos:**

* Derivado deste Perfil: [Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM)](StructureDefinition-RNDSRegistroEletronicoDispensacaoFornecimentoMedicamento.md)
* Refere a este Perfil: [BR Core Composition](StructureDefinition-br-core-composition.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/br.gov.saude.redfm.fhir|current/StructureDefinition/StructureDefinition-br-core-composition.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-br-core-composition.csv), [Excel](../StructureDefinition-br-core-composition.xlsx), [Schematron](../StructureDefinition-br-core-composition.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "br-core-composition",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/redfm/1.0.0/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/redfm/1.0.0/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-composition",
  "version" : "1.0.0-release",
  "name" : "BRCoreComposition",
  "title" : "BR Core Composition",
  "status" : "active",
  "date" : "2026-06-30T10:02:10-03:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Este perfil representa as restrições aplicadas ao recurso br-core-composition",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "fhirdocumentreference",
    "uri" : "http://hl7.org/fhir/documentreference",
    "name" : "FHIR DocumentReference"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Composition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Composition",
      "path" : "Composition"
    },
    {
      "id" : "Composition.id",
      "path" : "Composition.id",
      "short" : "ID lógico deste artefato",
      "definition" : "ID lógico deste artefato"
    },
    {
      "id" : "Composition.meta",
      "path" : "Composition.meta",
      "short" : "ID lógico deste artefato",
      "definition" : "ID lógico deste artefato"
    },
    {
      "id" : "Composition.implicitRules",
      "path" : "Composition.implicitRules",
      "short" : "Conjunto de regras utilizadas para a elaboração deste conteúdo",
      "definition" : "Conjunto de regras utilizadas para a elaboração deste conteúdo"
    },
    {
      "id" : "Composition.language",
      "path" : "Composition.language",
      "short" : "Idioma do conteúdo do recurso",
      "definition" : "Idioma do conteúdo do recurso"
    },
    {
      "id" : "Composition.text",
      "path" : "Composition.text",
      "short" : "Resumo do recurso para interpretação humana",
      "definition" : "Resumo do recurso para interpretação humana"
    },
    {
      "id" : "Composition.contained",
      "path" : "Composition.contained",
      "short" : "Recursos contidos",
      "definition" : "Recursos contidos neste artefato"
    },
    {
      "id" : "Composition.modifierExtension",
      "path" : "Composition.modifierExtension",
      "short" : "Extensões que não podem ser ignoradas",
      "definition" : "Extensões que não podem ser ignoradas"
    },
    {
      "id" : "Composition.identifier",
      "path" : "Composition.identifier",
      "short" : "Identificador independente da versão da Composition",
      "definition" : "Identificador independente da versão da Composition"
    },
    {
      "id" : "Composition.status",
      "path" : "Composition.status",
      "short" : "Status/Situação da Composition",
      "definition" : "Status/Situação da Composition: preliminar, definitivo, alterado, inserido com erro",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/composition-status"
      }
    },
    {
      "id" : "Composition.type",
      "path" : "Composition.type",
      "short" : "Tipo da Composition",
      "definition" : "Tipo da Composition (fixo em 'Sumário Internacional do Paciente)",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://hl7.org/fhir/ValueSet/doc-typecodes"
      }
    },
    {
      "id" : "Composition.type.id",
      "path" : "Composition.type.id",
      "short" : "ID exclusivo para referência entre elementos",
      "definition" : "ID exclusivo para referência entre elementos"
    },
    {
      "id" : "Composition.type.extension",
      "path" : "Composition.type.extension",
      "short" : "Conteúdo adicional definido por implementações",
      "definition" : "Conteúdo adicional definido por implementações"
    },
    {
      "id" : "Composition.type.coding",
      "path" : "Composition.type.coding",
      "short" : "Código definido por uma terminologia",
      "definition" : "Código definido por uma terminologia"
    },
    {
      "id" : "Composition.type.coding.id",
      "path" : "Composition.type.coding.id",
      "short" : "ID exclusivo para referência entre elementos",
      "definition" : "ID exclusivo para referência entre elementos"
    },
    {
      "id" : "Composition.type.coding.extension",
      "path" : "Composition.type.coding.extension",
      "short" : "Conteúdo adicional definido por implementações",
      "definition" : "Conteúdo adicional definido por implementações"
    },
    {
      "id" : "Composition.type.coding.system",
      "path" : "Composition.type.coding.system",
      "short" : "Identificador do sistema de terminologia",
      "definition" : "Identidficador do sistema de terminologia."
    },
    {
      "id" : "Composition.type.coding.version",
      "path" : "Composition.type.coding.version",
      "short" : "Versão da terminologia LOINC",
      "definition" : "Versão da terminologia LOINC - se relevante"
    },
    {
      "id" : "Composition.type.coding.code",
      "path" : "Composition.type.coding.code",
      "short" : "Código conforme terminologia",
      "definition" : "Código conforme terminologia."
    },
    {
      "id" : "Composition.type.coding.display",
      "path" : "Composition.type.coding.display",
      "short" : "Descrição conforme definição da terminologia LOINC",
      "definition" : "Descrição conforme definição da terminologia LOINC"
    },
    {
      "id" : "Composition.type.coding.userSelected",
      "path" : "Composition.type.coding.userSelected",
      "short" : "Se esta codificação foi escolhida diretamente pelo usuário",
      "definition" : "Se esta codificação foi escolhida diretamente pelo usuário"
    },
    {
      "id" : "Composition.type.text",
      "path" : "Composition.type.text",
      "short" : "Representação em texto livre do conceito",
      "definition" : "Representação em texto livre do conceito"
    },
    {
      "id" : "Composition.category",
      "path" : "Composition.category",
      "short" : "Categorização da Composition",
      "definition" : "Categorização da Composition",
      "binding" : {
        "strength" : "example",
        "valueSet" : "http://hl7.org/fhir/ValueSet/document-classcodes"
      }
    },
    {
      "id" : "Composition.subject",
      "path" : "Composition.subject",
      "short" : "Sobre quem e/ou sobre o que é a Composition",
      "definition" : "Sobre quem e/ou sobre o que é a Composition",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-patient"]
      }]
    },
    {
      "id" : "Composition.subject.id",
      "path" : "Composition.subject.id",
      "short" : "ID exclusivo para referência entre elementos",
      "definition" : "ID exclusivo para referência entre elementos"
    },
    {
      "id" : "Composition.subject.extension",
      "path" : "Composition.subject.extension",
      "short" : "Conteúdo adicional definido por implementações",
      "definition" : "Conteúdo adicional definido por implementações"
    },
    {
      "id" : "Composition.subject.reference",
      "path" : "Composition.subject.reference",
      "short" : "Referência literal, URL relativa, interna ou absoluta",
      "definition" : "Referência literal, URL relativa, interna ou absoluta"
    },
    {
      "id" : "Composition.subject.type",
      "path" : "Composition.subject.type",
      "short" : "Tipo ao qual a referência se refere",
      "definition" : "Tipo ao qual a referência se refere (por exemplo,'Paciente')"
    },
    {
      "id" : "Composition.subject.identifier",
      "path" : "Composition.subject.identifier",
      "short" : "Referência lógica, quando a referência literal não é conhecida",
      "definition" : "Referência lógica, quando a referência literal não é conhecida"
    },
    {
      "id" : "Composition.subject.display",
      "path" : "Composition.subject.display",
      "short" : "Texto alternativo para o recurso",
      "definition" : "Texto alternativo para o recurso"
    },
    {
      "id" : "Composition.encounter",
      "path" : "Composition.encounter",
      "short" : "Contato assistencial descrito nesta Composition",
      "definition" : "Contato assistencial descrito nesta Composition",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-encounter"]
      }]
    },
    {
      "id" : "Composition.date",
      "path" : "Composition.date",
      "short" : "Data de edição da Composition",
      "definition" : "Data de edição da Composition"
    },
    {
      "id" : "Composition.author",
      "path" : "Composition.author",
      "short" : "Quem e/ou o que foi o autor desta Composition",
      "definition" : "Quem e/ou o que foi o autor desta Compositon",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-practitioner",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-practitionerrole",
        "http://hl7.org/fhir/StructureDefinition/Device",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-patient",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-relatedperson",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Composition.title",
      "path" : "Composition.title",
      "short" : "Sumário Internacional do Paciente",
      "definition" : "Sumário Internacional do Paciente"
    },
    {
      "id" : "Composition.confidentiality",
      "path" : "Composition.confidentiality",
      "short" : "Códigos que especificam o nível de confidencialidade da Composition",
      "definition" : "Códigos que especificam o nível de confidencialidade da Composition",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v3-ConfidentialityClassification"
      }
    },
    {
      "id" : "Composition.attester",
      "path" : "Composition.attester",
      "short" : "Responsável por atestar a acurácia da Composition",
      "definition" : "Responsável por atestar a acurácia da Composition"
    },
    {
      "id" : "Composition.attester.id",
      "path" : "Composition.attester.id",
      "short" : "ID exclusivo para referência entre elementos",
      "definition" : "ID exclusivo para referência entre elementos"
    },
    {
      "id" : "Composition.attester.extension",
      "path" : "Composition.attester.extension",
      "short" : "Conteúdo adicional definido por implementações",
      "definition" : "Conteúdo adicional definido por implementações"
    },
    {
      "id" : "Composition.attester.modifierExtension",
      "path" : "Composition.attester.modifierExtension",
      "short" : "Extensões que não podem ser ignoradas mesmo que não sejam reconhecidas",
      "definition" : "Extensões que não podem ser ignoradas mesmo que não sejam reconhecidas"
    },
    {
      "id" : "Composition.attester.mode",
      "path" : "Composition.attester.mode",
      "short" : "Métodolo utilizada para autenticar a Composition",
      "definition" : "Métodolo utilizada para autenticar a Composition: pessoal, profissional, legal, oficial",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/composition-attestation-mode"
      }
    },
    {
      "id" : "Composition.attester.time",
      "path" : "Composition.attester.time",
      "short" : "Quando a Composition foi atestada",
      "definition" : "Quando a Composition foi atestada"
    },
    {
      "id" : "Composition.attester.party",
      "path" : "Composition.attester.party",
      "short" : "Quem atestou a Composition",
      "definition" : "Quem atestou a Composition",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-patient",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-relatedperson",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-practitioner",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-practitionerrole",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Composition.custodian",
      "path" : "Composition.custodian",
      "short" : "Organização responsável pela custódia da Composition",
      "definition" : "Identifica a organização ou grupo responsável pela composição.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Composition.relatesTo",
      "path" : "Composition.relatesTo",
      "short" : "Relacionamentos com outras Compositions/Documents",
      "definition" : "Relações que esta composição tem com outras composições ou recursos."
    },
    {
      "id" : "Composition.relatesTo.id",
      "path" : "Composition.relatesTo.id",
      "short" : "Relacionamentos com outras composições/Documents",
      "definition" : "Relacionamentos com outras composições/Documents"
    },
    {
      "id" : "Composition.relatesTo.extension",
      "path" : "Composition.relatesTo.extension",
      "short" : "Conteúdo adicional definido por implementações",
      "definition" : "Conteúdo adicional definido por implementações"
    },
    {
      "id" : "Composition.relatesTo.modifierExtension",
      "path" : "Composition.relatesTo.modifierExtension",
      "short" : "Extensões que não podem ser ignoradas mesmo que não sejam reconhecidas",
      "definition" : "Extensões que não podem ser ignoradas mesmo que não sejam reconhecidas"
    },
    {
      "id" : "Composition.relatesTo.code",
      "path" : "Composition.relatesTo.code",
      "short" : "Alvo do relacionamento da composição",
      "definition" : "Alvo do relacionamento da composição",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/document-relationship-type"
      }
    },
    {
      "id" : "Composition.relatesTo.target[x]",
      "path" : "Composition.relatesTo.target[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "short" : "Relacionamento alvo",
      "definition" : "Relacionamento alvo"
    },
    {
      "id" : "Composition.relatesTo.target[x]:targetReference",
      "path" : "Composition.relatesTo.target[x]",
      "sliceName" : "targetReference",
      "short" : "Referencia a composition alvo",
      "definition" : "Referencia a composition alvo",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-composition"]
      }]
    },
    {
      "id" : "Composition.event",
      "path" : "Composition.event",
      "short" : "Serviços assistenciais documentados",
      "definition" : "O serviço especializado  como uma colonoscopia ou uma apendicectomia, sendo documentado."
    },
    {
      "id" : "Composition.event.id",
      "path" : "Composition.event.id",
      "short" : "ID exclusivo para referência entre elementos",
      "definition" : "Identificador  único para o elemento dentro de um recurso (para referências internas). Este pode ser qualquer valor de string que não contenha espaços."
    },
    {
      "id" : "Composition.event.extension",
      "path" : "Composition.event.extension",
      "short" : "Conteúdo adicional definido por implementações",
      "definition" : "Conteúdo adicional definido por implementações"
    },
    {
      "id" : "Composition.event.modifierExtension",
      "path" : "Composition.event.modifierExtension",
      "short" : "Extensões que não podem ser ignoradas mesmo que não sejam reconhecidas",
      "definition" : "Extensões que não podem ser ignoradas mesmo que não sejam reconhecidas"
    },
    {
      "id" : "Composition.event.code",
      "path" : "Composition.event.code",
      "short" : "Código(s) aplicável(is) aos eventos documentados",
      "definition" : "Esta lista de códigos representa os principais atos clínicos, como uma colonoscopia ou uma apendicectomia, sendo documentados. Em alguns casos, o evento é inerente ao typeCode, como um 'Histórico e Relatório Físico', no qual o procedimento documentado é necessariamente um ato de 'Histórico e Físico'.",
      "binding" : {
        "strength" : "required"
      }
    },
    {
      "id" : "Composition.event.period",
      "path" : "Composition.event.period",
      "short" : "O período de tempo coberto pela composition.",
      "definition" : "O período de tempo coberto pela composition. Não há afirmação de que a documentação seja uma representação completa para este período, apenas que documenta eventos durante esse tempo."
    },
    {
      "id" : "Composition.event.detail",
      "path" : "Composition.event.detail",
      "short" : "Referência aos eventos da Composition",
      "definition" : "Referência aos eventos da Composition"
    },
    {
      "id" : "Composition.section",
      "path" : "Composition.section",
      "short" : "A secção inicial da composition a partir da qual as demais seções são definidas",
      "definition" : "A secção inicial da composition a partir da qual as demais seções são definidas"
    },
    {
      "id" : "Composition.section.id",
      "path" : "Composition.section.id",
      "short" : "Identificador exclusivo para referência entre elemento",
      "definition" : "Identificador exclusivo para referência entre elementos"
    },
    {
      "id" : "Composition.section.extension",
      "path" : "Composition.section.extension",
      "short" : "Conteúdo adicional definido por implementações",
      "definition" : "Conteúdo adicional definido por implementações"
    },
    {
      "id" : "Composition.section.modifierExtension",
      "path" : "Composition.section.modifierExtension",
      "short" : "Extensões que não podem ser ignoradas mesmo que não sejam reconhecidas",
      "definition" : "Extensões que não podem ser ignoradas mesmo que não sejam reconhecidas"
    },
    {
      "id" : "Composition.section.title",
      "path" : "Composition.section.title",
      "short" : "Título da seção",
      "definition" : "Título da seção do Sumário Internacional do Paciente"
    },
    {
      "id" : "Composition.section.code",
      "path" : "Composition.section.code",
      "short" : "Um código que identifica o tipo de conteúdo contido dentro da seção.",
      "definition" : "Um código que identifica o tipo de conteúdo contido dentro da seção. Isso deve ser consistente com o título da seção.",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/doc-section-codes"
      }
    },
    {
      "id" : "Composition.section.author",
      "path" : "Composition.section.author",
      "short" : "Quem e/ou o que foi o autor desta seção",
      "definition" : "Identifica quem é responsável pelas informações nesta seção, não necessariamente quem a digitou.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-practitioner",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-practitionerrole",
        "http://hl7.org/fhir/StructureDefinition/Device",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-patient",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-relatedperson",
        "https://br-core.saude.gov.br/fhir/StructureDefinition/br-core-organization"]
      }]
    },
    {
      "id" : "Composition.section.focus",
      "path" : "Composition.section.focus",
      "short" : "Quem/o que é a seção",
      "definition" : "Quem/o que é a seção"
    },
    {
      "id" : "Composition.section.text",
      "path" : "Composition.section.text",
      "short" : "Resumo em texto livre da seção",
      "definition" : "Resumo em texto livre da seção"
    },
    {
      "id" : "Composition.section.mode",
      "path" : "Composition.section.mode",
      "short" : "Método de processamento da seção",
      "definition" : "Método de processamento da seção",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/list-mode"
      }
    },
    {
      "id" : "Composition.section.orderedBy",
      "path" : "Composition.section.orderedBy",
      "short" : "Especifica a ordem dos itens nas sections.entry",
      "definition" : "Especifica a ordem dos itens nas sections.entry",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://hl7.org/fhir/ValueSet/list-empty-reason"
      }
    },
    {
      "id" : "Composition.section.entry",
      "path" : "Composition.section.entry",
      "short" : "Uma referência ao recurso a partir  do qual narrativa da seção é derivada.",
      "definition" : "Uma referência ao recurso a partir  do qual narrativa da seção é derivada."
    },
    {
      "id" : "Composition.section.emptyReason",
      "path" : "Composition.section.emptyReason",
      "short" : "Explicação porquê a secção está vazia",
      "definition" : "Explicação porquê a secção está vazia"
    },
    {
      "id" : "Composition.section.section",
      "path" : "Composition.section.section",
      "short" : "Uma subseção aninhada dentro desta seção",
      "definition" : "Uma subseção aninhada dentro desta seção"
    }]
  }
}

```
