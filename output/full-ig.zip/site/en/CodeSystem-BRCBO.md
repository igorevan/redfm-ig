# Classificação Brasileira de Ocupações - CBO (CodeSystem) - Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS v1.0.0-release

## CodeSystem: Classificação Brasileira de Ocupações - CBO (CodeSystem) 

This Code system is referenced in the definition of the following value sets:

* [Classificação Brasileira de Ocupações - CBO (ValueSet)](ValueSet-BROcupacao-1.0.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRCBO",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/redfm/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/redfm/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO",
  "version" : "1.0.0-release",
  "name" : "BRCBO",
  "title" : "Classificação Brasileira de Ocupações - CBO (CodeSystem)",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-11T12:05:18.2868027+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Classifica as profissões do mercado de trabalho brasileiro.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "property" : [{
    "code" : "healthcare",
    "description" : "Se a ocupação está relacionada à área de prestação de serviço em saúde",
    "type" : "boolean"
  },
  {
    "code" : "regulated",
    "description" : "Se a ocupação está regulada",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "010105",
    "display" : "OFICIAL GENERAL DA AERONAUTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "010110",
    "display" : "OFICIAL GENERAL DO EXERCITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "010115",
    "display" : "OFICIAL GENERAL DA MARINHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "010205",
    "display" : "OFICIAL DA AERONAUTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "010210",
    "display" : "OFICIAL DO EXERCITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "010215",
    "display" : "OFICIAL DA MARINHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "010305",
    "display" : "PRACA DA AERONAUTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "010310",
    "display" : "PRACA DO EXERCITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "010315",
    "display" : "PRACA DA MARINHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "020105",
    "display" : "CORONEL DA POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "020110",
    "display" : "TENENTECORONEL DA POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "020115",
    "display" : "MAJOR DA POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "020205",
    "display" : "CAPITAO DA POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "020305",
    "display" : "PRIMEIRO TENENTE DE POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "020310",
    "display" : "SEGUNDO TENENTE DE POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "021105",
    "display" : "SUBTENENTE DA POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "021110",
    "display" : "SARGENTO DA POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "021205",
    "display" : "CABO DA POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "021210",
    "display" : "SOLDADO DA POLICIA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "030105",
    "display" : "CORONEL BOMBEIRO MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "030110",
    "display" : "MAJOR BOMBEIRO MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "030115",
    "display" : "TENENTECORONEL BOMBEIRO MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "030205",
    "display" : "CAPITAO BOMBEIRO MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "030305",
    "display" : "TENENTE DO CORPO DE BOMBEIROS MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "031105",
    "display" : "SUBTENENTE BOMBEIRO MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "031110",
    "display" : "SARGENTO BOMBEIRO MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "031205",
    "display" : "CABO BOMBEIRO MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "031210",
    "display" : "SOLDADO BOMBEIRO MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111105",
    "display" : "SENADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111110",
    "display" : "DEPUTADO FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111115",
    "display" : "DEPUTADO ESTADUAL E DISTRITAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111120",
    "display" : "VEREADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111205",
    "display" : "PRESIDENTE DA REPUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111210",
    "display" : "VICEPRESIDENTE DA REPUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111215",
    "display" : "MINISTRO DE ESTADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111220",
    "display" : "SECRETARIOEXECUTIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111225",
    "display" : "MEMBRO SUPERIOR DO PODER EXECUTIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111230",
    "display" : "GOVERNADOR DE ESTADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111235",
    "display" : "GOVERNADOR DO DISTRITO FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111240",
    "display" : "VICEGOVERNADOR DE ESTADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111245",
    "display" : "VICEGOVERNADOR DO DISTRITO FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111250",
    "display" : "PREFEITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111255",
    "display" : "VICEPREFEITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111305",
    "display" : "MINISTRO DO SUPREMO TRIBUNAL FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111310",
    "display" : "MINISTRO DO SUPERIOR TRIBUNAL DE JUSTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111315",
    "display" : "MINISTRO DO SUPERIOR TRIBUNAL MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111320",
    "display" : "MINISTRO DO SUPERIOR TRIBUNAL DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111325",
    "display" : "JUIZ DE DIREITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111330",
    "display" : "JUIZ FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111335",
    "display" : "JUIZ AUDITOR FEDERAL  JUSTICA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111340",
    "display" : "JUIZ AUDITOR ESTADUAL  JUSTICA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111345",
    "display" : "JUIZ DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111405",
    "display" : "DIRIGENTE DO SERVICO PUBLICO FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111410",
    "display" : "DIRIGENTE DO SERVICO PUBLICO ESTADUAL E DISTRITAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111415",
    "display" : "DIRIGENTE DO SERVICO PUBLICO MUNICIPAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111505",
    "display" : "ESPECIALISTA DE POLITICAS PUBLICAS E GESTAO GOVERNAMENTAL  EPPGG",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "111510",
    "display" : "ANALISTA DE PLANEJAMENTO E ORCAMENTO  APO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "113005",
    "display" : "CACIQUE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "113010",
    "display" : "LIDER DE COMUNIDADE CAICARA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "113015",
    "display" : "MEMBRO DE LIDERANCA QUILOMBOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "114105",
    "display" : "DIRIGENTE DE PARTIDO POLITICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "114205",
    "display" : "DIRIGENTES DE ENTIDADES DE TRABALHADORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "114210",
    "display" : "DIRIGENTES DE ENTIDADES PATRONAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "114305",
    "display" : "DIRIGENTE E ADMINISTRADOR DE ORGANIZACAO RELIGIOSA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "114405",
    "display" : "DIRIGENTE E ADMINISTRADOR DE ORGANIZACAO DA SOCIEDADE CIVIL SEM FINS LUCRATIVOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "121005",
    "display" : "DIRETOR DE PLANEJAMENTO ESTRATEGICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "121010",
    "display" : "DIRETOR GERAL DE EMPRESA E ORGANIZACOES (EXCETO DE INTERESSE PUBLICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122105",
    "display" : "DIRETOR DE PRODUCAO E OPERACOES EM EMPRESA AGROPECUARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122110",
    "display" : "DIRETOR DE PRODUCAO E OPERACOES EM EMPRESA AQICOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122115",
    "display" : "DIRETOR DE PRODUCAO E OPERACOES EM EMPRESA FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122120",
    "display" : "DIRETOR DE PRODUCAO E OPERACOES EM EMPRESA PESQUEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122205",
    "display" : "DIRETOR DE PRODUCAO E OPERACOES DA INDUSTRIA DE TRANSFORMACAO, EXTRACAO MINERAL E UTILIDADES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122305",
    "display" : "DIRETOR DE OPERACOES DE OBRAS PUBLICA E CIVIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122405",
    "display" : "DIRETOR DE OPERACOES COMERCIAIS (COMERCIO ATACADISTA E VAREJISTA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122505",
    "display" : "DIRETOR DE PRODUCAO E OPERACOES DE ALIMENTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122510",
    "display" : "DIRETOR DE PRODUCAO E OPERACOES DE HOTEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122515",
    "display" : "DIRETOR DE PRODUCAO E OPERACOES DE TURISMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122520",
    "display" : "TURISMOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122605",
    "display" : "DIRETOR DE OPERACOES DE CORREIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122610",
    "display" : "DIRETOR DE OPERACOES DE SERVICOS DE ARMAZENAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122615",
    "display" : "DIRETOR DE OPERACOES DE SERVICOS DE TELECOMUNICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122620",
    "display" : "DIRETOR DE OPERACOES DE SERVICOS DE TRANSPORTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122705",
    "display" : "DIRETOR COMERCIAL EM OPERACOES DE INTERMEDIACAO FINANCEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122710",
    "display" : "DIRETOR DE PRODUTOS BANCARIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122715",
    "display" : "DIRETOR DE CREDITO RURAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122720",
    "display" : "DIRETOR DE CAMBIO E COMERCIO EXTERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122725",
    "display" : "DIRETOR DE COMPLIANCE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122730",
    "display" : "DIRETOR DE CREDITO (EXCETO CREDITO IMOBILIARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122735",
    "display" : "DIRETOR DE CREDITO IMOBILIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122740",
    "display" : "DIRETOR DE LEASING",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122745",
    "display" : "DIRETOR DE MERCADO DE CAPITAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122750",
    "display" : "DIRETOR DE RECUPERACAO DE CREDITOS EM OPERACOES DE INTERMEDIACAO FINANCEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "122755",
    "display" : "DIRETOR DE RISCOS DE MERCADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123105",
    "display" : "DIRETOR ADMINISTRATIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123110",
    "display" : "DIRETOR ADMINISTRATIVO E FINANCEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123115",
    "display" : "DIRETOR FINANCEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123205",
    "display" : "DIRETOR DE RECURSOS HUMANOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123210",
    "display" : "DIRETOR DE RELACOES DE TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123305",
    "display" : "DIRETOR COMERCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123310",
    "display" : "DIRETOR DE MARKETING",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123405",
    "display" : "DIRETOR DE SUPRIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123410",
    "display" : "DIRETOR DE SUPRIMENTOS NO SERVICO PUBLICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123605",
    "display" : "DIRETOR DE SERVICOS DE INFORMATICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123705",
    "display" : "DIRETOR DE PESQUISA E DESENVOLVIMENTO (PD)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "123805",
    "display" : "DIRETOR DE MANUTENCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131105",
    "display" : "DIRETOR DE SERVICOS CULTURAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131110",
    "display" : "DIRETOR DE SERVICOS SOCIAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131115",
    "display" : "GERENTE DE SERVICOS CULTURAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131120",
    "display" : "GERENTE DE SERVICOS SOCIAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131205",
    "display" : "DIRETOR DE SERVICOS DE SAUDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "131210",
    "display" : "GERENTE DE SERVICOS DE SAUDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "131215",
    "display" : "TECNOLOGO EM GESTAO HOSPITALAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131220",
    "display" : "GERONTOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131225",
    "display" : "SANITARISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131305",
    "display" : "DIRETOR DE INSTITUICAO EDUCACIONAL DA AREA PRIVADA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131310",
    "display" : "DIRETOR DE INSTITUICAO EDUCACIONAL PUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131315",
    "display" : "GERENTE DE INSTITUICAO EDUCACIONAL DA AREA PRIVADA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "131320",
    "display" : "GERENTE DE SERVICOS EDUCACIONAIS DA AREA PUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141105",
    "display" : "GERENTE DE PRODUCAO E OPERACOES AQUICOLAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141110",
    "display" : "GERENTE DE PRODUCAO E OPERACOES FLORESTAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141115",
    "display" : "GERENTE DE PRODUCAO E OPERACOES AGROPECUARIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141120",
    "display" : "GERENTE DE PRODUCAO E OPERACOES PESQUEIRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141205",
    "display" : "GERENTE DE PRODUCAO E OPERACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141305",
    "display" : "GERENTE DE PRODUCAO E OPERACOES DA CONSTRUCAO CIVIL E OBRAS PUBLICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141405",
    "display" : "COMERCIANTE ATACADISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141410",
    "display" : "COMERCIANTE VAREJISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141415",
    "display" : "GERENTE DE LOJA E SUPERMERCADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141420",
    "display" : "GERENTE DE OPERACOES DE SERVICOS DE ASSISTENCIA TECNICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141505",
    "display" : "GERENTE DE HOTEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141510",
    "display" : "GERENTE DE RESTAURANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141515",
    "display" : "GERENTE DE BAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141520",
    "display" : "GERENTE DE PENSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141525",
    "display" : "GERENTE DE TURISMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141605",
    "display" : "GERENTE DE OPERACOES DE TRANSPORTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141610",
    "display" : "GERENTE DE OPERACOES DE CORREIOS E TELECOMUNICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141615",
    "display" : "GERENTE DE LOGISTICA (ARMAZENAGEM E DISTRIBUICAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141705",
    "display" : "GERENTE DE PRODUTOS BANCARIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141710",
    "display" : "GERENTE DE AGENCIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141715",
    "display" : "GERENTE DE CAMBIO E COMERCIO EXTERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141720",
    "display" : "GERENTE DE CREDITO E COBRANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141725",
    "display" : "GERENTE DE CREDITO IMOBILIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141730",
    "display" : "GERENTE DE CREDITO RURAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141735",
    "display" : "GERENTE DE RECUPERACAO DE CREDITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142105",
    "display" : "GERENTE ADMINISTRATIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142110",
    "display" : "GERENTE DE RISCOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142115",
    "display" : "GERENTE FINANCEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142120",
    "display" : "TECNOLOGO EM GESTAO ADMINISTRATIVO FINANCEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142205",
    "display" : "GERENTE DE RECURSOS HUMANOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142210",
    "display" : "GERENTE DE DEPARTAMENTO PESSOAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142305",
    "display" : "GERENTE COMERCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142310",
    "display" : "GERENTE DE COMUNICACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142315",
    "display" : "GERENTE DE MARKETING",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142320",
    "display" : "GERENTE DE VENDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142325",
    "display" : "RELACOES PUBLICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142330",
    "display" : "ANALISTA DE NEGOCIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142335",
    "display" : "ANALISTA DE PESQUISA DE MERCADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142340",
    "display" : "OUVIDOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142405",
    "display" : "GERENTE DE COMPRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142410",
    "display" : "GERENTE DE SUPRIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142415",
    "display" : "GERENTE DE ALMOXARIFADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142505",
    "display" : "GERENTE DE REDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142510",
    "display" : "GERENTE DE DESENVOLVIMENTO DE SISTEMAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142515",
    "display" : "GERENTE DE PRODUCAO DE TECNOLOGIA DA INFORMACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142520",
    "display" : "GERENTE DE PROJETOS DE TECNOLOGIA DA INFORMACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142525",
    "display" : "GERENTE DE SEGURANCA DE TECNOLOGIA DA INFORMACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142530",
    "display" : "GERENTE DE SUPORTE TECNICO DE TECNOLOGIA DA INFORMACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142535",
    "display" : "TECNOLOGO EM GESTAO DA TECNOLOGIA DA INFORMACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142605",
    "display" : "GERENTE DE PESQUISA E DESENVOLVIMENTO (PD)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142610",
    "display" : "ESPECIALISTA EM DESENVOLVIMENTO DE CIGARROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142705",
    "display" : "GERENTE DE PROJETOS E SERVICOS DE MANUTENCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142710",
    "display" : "TECNOLOGO EM SISTEMAS BIOMEDICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "1999A1",
    "display" : "CBO NIVEL MEDIO NAO TEM CORRESPONDENCIA CBO 2002",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "1999A2",
    "display" : "CBO NIVEL SUPERIOR NAO TEM CORRESPONDENCIA CBO 2002",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "201105",
    "display" : "BIOENGENHEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "201110",
    "display" : "BIOTECNOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "201115",
    "display" : "GENETICISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "201205",
    "display" : "PESQUISADOR EM METROLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "201210",
    "display" : "ESPECIALISTA EM CALIBRACOES METROLOGICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "201215",
    "display" : "ESPECIALISTA EM ENSAIOS METROLOGICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "201220",
    "display" : "ESPECIALISTA EM INSTRUMENTACAO METROLOGICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "201225",
    "display" : "ESPECIALISTA EM MATERIAIS DE REFERENCIA METROLOGICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "202105",
    "display" : "ENGENHEIRO MECATRONICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "202110",
    "display" : "ENGENHEIRO DE CONTROLE E AUTOMACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "202115",
    "display" : "TECNOLOGO EM MECATRONICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "202120",
    "display" : "TECNOLOGO EM AUTOMACAO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203005",
    "display" : "PESQUISADOR EM BIOLOGIA AMBIENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203010",
    "display" : "PESQUISADOR EM BIOLOGIA ANIMAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203015",
    "display" : "PESQUISADOR EM BIOLOGIA DE MICROORGANISMOS E PARASITAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203020",
    "display" : "PESQUISADOR EM BIOLOGIA HUMANA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "203025",
    "display" : "PESQUISADOR EM BIOLOGIA VEGETAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203105",
    "display" : "PESQUISADOR EM CIENCIAS DA COMPUTACAO E INFORMATICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203110",
    "display" : "PESQUISADOR EM CIENCIAS DA TERRA E MEIO AMBIENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203115",
    "display" : "PESQUISADOR EM FISICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203120",
    "display" : "PESQUISADOR EM MATEMATICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203125",
    "display" : "PESQUISADOR EM QUIMICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203205",
    "display" : "PESQUISADOR DE ENGENHARIA CIVIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203210",
    "display" : "PESQUISADOR DE ENGENHARIA E TECNOLOGIA (OUTRAS AREAS DA ENGENHARIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203215",
    "display" : "PESQUISADOR DE ENGENHARIA ELETRICA E ELETRONICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203220",
    "display" : "PESQUISADOR DE ENGENHARIA MECANICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203225",
    "display" : "PESQUISADOR DE ENGENHARIA METALURGICA, DE MINAS E DE MATERIAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203230",
    "display" : "PESQUISADOR DE ENGENHARIA QUIMICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203305",
    "display" : "PESQUISADOR DE CLINICA MEDICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203310",
    "display" : "PESQUISADOR DE MEDICINA BASICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203315",
    "display" : "PESQUISADOR EM MEDICINA VETERINARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203320",
    "display" : "PESQUISADOR EM SAUDE COLETIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203405",
    "display" : "PESQUISADOR EM CIENCIAS AGRONOMICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203410",
    "display" : "PESQUISADOR EM CIENCIAS DA PESCA E AQICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203415",
    "display" : "PESQUISADOR EM CIENCIAS DA ZOOTECNIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203420",
    "display" : "PESQUISADOR EM CIENCIAS FLORESTAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203505",
    "display" : "PESQUISADOR EM CIENCIAS SOCIAIS E HUMANAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203510",
    "display" : "PESQUISADOR EM ECONOMIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203515",
    "display" : "PESQUISADOR EM CIENCIAS DA EDUCACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203520",
    "display" : "PESQUISADOR EM HISTORIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "203525",
    "display" : "PESQUISADOR EM PSICOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "204105",
    "display" : "PERITO CRIMINAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "211105",
    "display" : "ATUARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "211110",
    "display" : "ESPECIALISTA EM PESQUISA OPERACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "211115",
    "display" : "MATEMATICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "211120",
    "display" : "MATEMATICO APLICADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "211205",
    "display" : "ESTATISTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "211210",
    "display" : "ESTATISTICO (ESTATISTICA APLICADA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "211215",
    "display" : "ESTATISTICO TEORICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212205",
    "display" : "ENGENHEIRO DE APLICATIVOS EM COMPUTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212210",
    "display" : "ENGENHEIRO DE EQUIPAMENTOS EM COMPUTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212215",
    "display" : "ENGENHEIROS DE SISTEMAS OPERACIONAIS EM COMPUTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212305",
    "display" : "ADMINISTRADOR DE BANCO DE DADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212310",
    "display" : "ADMINISTRADOR DE REDES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212315",
    "display" : "ADMINISTRADOR DE SISTEMAS OPERACIONAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212320",
    "display" : "ADMINISTRADOR EM SEGURANCA DA INFORMACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212405",
    "display" : "ANALISTA DE DESENVOLVIMENTO DE SISTEMAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212410",
    "display" : "ANALISTA DE REDES E DE COMUNICACAO DE DADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212415",
    "display" : "ANALISTA DE SISTEMAS DE AUTOMACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212420",
    "display" : "ANALISTA DE SUPORTE COMPUTACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213105",
    "display" : "FISICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213110",
    "display" : "FISICO (ACUSTICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213115",
    "display" : "FISICO (ATOMICA E MOLECULAR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213120",
    "display" : "FISICO (COSMOLOGIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213125",
    "display" : "FISICO (ESTATISTICA E MATEMATICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213130",
    "display" : "FISICO (FLUIDOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213135",
    "display" : "FISICO (INSTRUMENTACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213140",
    "display" : "FISICO (MATERIA CONDENSADA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213145",
    "display" : "FISICO (MATERIAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213150",
    "display" : "FISICO (MEDICINA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "213155",
    "display" : "FISICO (NUCLEAR E REATORES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213160",
    "display" : "FISICO (OPTICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213165",
    "display" : "FISICO (PARTICULAS E CAMPOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213170",
    "display" : "FISICO (PLASMA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213175",
    "display" : "FISICO (TERMICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213205",
    "display" : "QUIMICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213210",
    "display" : "QUIMICO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213215",
    "display" : "TECNOLOGO EM PROCESSOS QUIMICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213305",
    "display" : "ASTRONOMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213310",
    "display" : "GEOFISICO ESPACIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213315",
    "display" : "METEOROLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213405",
    "display" : "GEOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213410",
    "display" : "GEOLOGO DE ENGENHARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213415",
    "display" : "GEOFISICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213420",
    "display" : "GEOQUIMICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213425",
    "display" : "HIDROGEOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213430",
    "display" : "PALEONTOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213435",
    "display" : "PETROGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "213440",
    "display" : "OCEANOGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214005",
    "display" : "ENGENHEIRO AMBIENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214010",
    "display" : "TECNOLOGO EM MEIO AMBIENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214105",
    "display" : "ARQUITETO DE EDIFICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214110",
    "display" : "ARQUITETO DE INTERIORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214115",
    "display" : "ARQUITETO DE PATRIMONIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214120",
    "display" : "ARQUITETO PAISAGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214125",
    "display" : "ARQUITETO URBANISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214130",
    "display" : "URBANISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214205",
    "display" : "ENGENHEIRO CIVIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214210",
    "display" : "ENGENHEIRO CIVIL (AEROPORTOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214215",
    "display" : "ENGENHEIRO CIVIL (EDIFICACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214220",
    "display" : "ENGENHEIRO CIVIL (ESTRUTURAS METALICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214225",
    "display" : "ENGENHEIRO CIVIL (FERROVIAS E METROVIAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214230",
    "display" : "ENGENHEIRO CIVIL (GEOTECNIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214235",
    "display" : "ENGENHEIRO CIVIL (HIDROLOGIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214240",
    "display" : "ENGENHEIRO CIVIL (HIDRAULICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214245",
    "display" : "ENGENHEIRO CIVIL (PONTES E VIADUTOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214250",
    "display" : "ENGENHEIRO CIVIL (PORTOS E VIAS NAVEGAVEIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214255",
    "display" : "ENGENHEIRO CIVIL (RODOVIAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214260",
    "display" : "ENGENHEIRO CIVIL (SANEAMENTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214265",
    "display" : "ENGENHEIRO CIVIL (TUNEIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214270",
    "display" : "ENGENHEIRO CIVIL (TRANSPORTES E TRANSITO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214280",
    "display" : "TECNOLOGO EM CONSTRUCAO CIVIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214305",
    "display" : "ENGENHEIRO ELETRICISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214310",
    "display" : "ENGENHEIRO ELETRONICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214315",
    "display" : "ENGENHEIRO ELETRICISTA DE MANUTENCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214320",
    "display" : "ENGENHEIRO ELETRICISTA DE PROJETOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214325",
    "display" : "ENGENHEIRO ELETRONICO DE MANUTENCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214330",
    "display" : "ENGENHEIRO ELETRONICO DE PROJETOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214335",
    "display" : "ENGENHEIRO DE MANUTENCAO DE TELECOMUNICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214340",
    "display" : "ENGENHEIRO DE TELECOMUNICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214345",
    "display" : "ENGENHEIRO PROJETISTA DE TELECOMUNICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214350",
    "display" : "ENGENHEIRO DE REDES DE COMUNICACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214360",
    "display" : "TECNOLOGO EM ELETRICIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214365",
    "display" : "TECNOLOGO EM ELETRONICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214370",
    "display" : "TECNOLOGO EM TELECOMUNICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214405",
    "display" : "ENGENHEIRO MECANICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214410",
    "display" : "ENGENHEIRO MECANICO AUTOMOTIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214415",
    "display" : "ENGENHEIRO MECANICO (ENERGIA NUCLEAR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214420",
    "display" : "ENGENHEIRO MECANICO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214425",
    "display" : "ENGENHEIRO AERONAUTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214430",
    "display" : "ENGENHEIRO NAVAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214435",
    "display" : "TECNOLOGO EM FABRICACAO MECANICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214505",
    "display" : "ENGENHEIRO QUIMICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214510",
    "display" : "ENGENHEIRO QUIMICO (INDUSTRIA QUIMICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214515",
    "display" : "ENGENHEIRO QUIMICO (MINERACAO, METALURGIA, SIDERURGIA, CIMENTEIRA E CERAMICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214520",
    "display" : "ENGENHEIRO QUIMICO (PAPEL E CELULOSE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214525",
    "display" : "ENGENHEIRO QUIMICO (PETROLEO E BORRACHA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214530",
    "display" : "ENGENHEIRO QUIMICO (UTILIDADES E MEIO AMBIENTE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214535",
    "display" : "TECNOLOGO EM PRODUCAO SULCROALCOOLEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214605",
    "display" : "ENGENHEIRO DE MATERIAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214610",
    "display" : "ENGENHEIRO METALURGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214615",
    "display" : "TECNOLOGO EM METALURGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214705",
    "display" : "ENGENHEIRO DE MINAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214710",
    "display" : "ENGENHEIRO DE MINAS (BENEFICIAMENTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214715",
    "display" : "ENGENHEIRO DE MINAS (LAVRA A CEU ABERTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214720",
    "display" : "ENGENHEIRO DE MINAS (LAVRA SUBTERRANEA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214725",
    "display" : "ENGENHEIRO DE MINAS (PESQUISA MINERAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214730",
    "display" : "ENGENHEIRO DE MINAS (PLANEJAMENTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214735",
    "display" : "ENGENHEIRO DE MINAS (PROCESSO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214740",
    "display" : "ENGENHEIRO DE MINAS (PROJETO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214745",
    "display" : "TECNOLOGO EM PETROLEO E GAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214750",
    "display" : "TECNOLOGO EM ROCHAS ORNAMENTAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214805",
    "display" : "ENGENHEIRO AGRIMENSOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214810",
    "display" : "ENGENHEIRO CARTOGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214905",
    "display" : "ENGENHEIRO DE PRODUCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214910",
    "display" : "ENGENHEIRO DE CONTROLE DE QUALIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214915",
    "display" : "ENGENHEIRO DE SEGURANCA DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214920",
    "display" : "ENGENHEIRO DE RISCOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214925",
    "display" : "ENGENHEIRO DE TEMPOS E MOVIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214930",
    "display" : "TECNOLOGO EM PRODUCAO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214935",
    "display" : "TECNOLOGO EM SEGURANCA DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214940",
    "display" : "HIGIENISTA OCUPACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215105",
    "display" : "AGENTE DE MANOBRA E DOCAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215110",
    "display" : "CAPITAO DE MANOBRA DA MARINHA MERCANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215115",
    "display" : "COMANDANTE DA MARINHA MERCANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215120",
    "display" : "COORDENADOR DE OPERACOES DE COMBATE A POLUICAO NO MEIO AQUAVIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215125",
    "display" : "IMEDIATO DA MARINHA MERCANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215130",
    "display" : "INSPETOR DE TERMINAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215135",
    "display" : "INSPETOR NAVAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215140",
    "display" : "OFICIAL DE QUARTO DE NAVEGACAO DA MARINHA MERCANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215145",
    "display" : "PRATICO DE PORTOS DA MARINHA MERCANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215150",
    "display" : "VISTORIADOR NAVAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215205",
    "display" : "OFICIAL SUPERIOR DE MAQUINAS DA MARINHA MERCANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215210",
    "display" : "PRIMEIRO OFICIAL DE MAQUINAS DA MARINHA MERCANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215215",
    "display" : "SEGUNDO OFICIAL DE MAQUINAS DA MARINHA MERCANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215220",
    "display" : "SUPERINTENDENTE TECNICO NO TRANSPORTE AQUAVIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215305",
    "display" : "PILOTO DE AERONAVES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215310",
    "display" : "PILOTO DE ENSAIOS EM VOO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "215315",
    "display" : "INSTRUTOR DE VOO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "221105",
    "display" : "BIOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "221205",
    "display" : "BIOMEDICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "222105",
    "display" : "ENGENHEIRO AGRICOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "222110",
    "display" : "ENGENHEIRO AGRONOMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "222115",
    "display" : "ENGENHEIRO DE PESCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "222120",
    "display" : "ENGENHEIRO FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "222205",
    "display" : "ENGENHEIRO DE ALIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "222215",
    "display" : "TECNOLOGO EM ALIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223119",
    "display" : "MEDICO EM ELETROENCEFALOGRAFIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223150",
    "display" : "MEDICO PERITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2231A1",
    "display" : "MEDICO BRONCOESOFALOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2231A2",
    "display" : "MEDICO HANSENOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2231F8",
    "display" : "MEDICO EM MEDICINA PREVENTIVA E SOCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2231F9",
    "display" : "MEDICO RESIDENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2231G1",
    "display" : "MEDICO CARDIOLOGISTA INTERVENCIONISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223204",
    "display" : "CIRURGIAO DENTISTA  AUDITOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223208",
    "display" : "CIRURGIAO DENTISTA  CLINICO GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223212",
    "display" : "CIRURGIAO DENTISTA  ENDODONTISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223216",
    "display" : "CIRURGIAO DENTISTA  EPIDEMIOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223220",
    "display" : "CIRURGIAO DENTISTA  ESTOMATOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223224",
    "display" : "CIRURGIAO DENTISTA  IMPLANTODONTISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223228",
    "display" : "CIRURGIAO DENTISTA  ODONTOGERIATRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223232",
    "display" : "CIRURGIAO DENTISTA  ODONTOLOGISTA LEGAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223236",
    "display" : "CIRURGIAO DENTISTA  ODONTOPEDIATRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223240",
    "display" : "CIRURGIAO DENTISTA  ORTOPEDISTA E ORTODONTISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223244",
    "display" : "CIRURGIAO DENTISTA  PATOLOGISTA BUCAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223248",
    "display" : "CIRURGIAO DENTISTA  PERIODONTISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223252",
    "display" : "CIRURGIAO DENTISTA  PROTESIOLOGO BUCOMAXILOFACIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223256",
    "display" : "CIRURGIAO DENTISTA  PROTESISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223260",
    "display" : "CIRURGIAO DENTISTA  RADIOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223264",
    "display" : "CIRURGIAO DENTISTA  REABILITADOR ORAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223268",
    "display" : "CIRURGIAO DENTISTA  TRAUMATOLOGISTA BUCOMAXILOFACIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223272",
    "display" : "CIRURGIAO DENTISTA DE SAUDE COLETIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223276",
    "display" : "CIRURGIAO DENTISTA  ODONTOLOGIA DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223280",
    "display" : "CIRURGIAO DENTISTA  DENTISTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223284",
    "display" : "CIRURGIAO DENTISTA  DISFUNCAO TEMPOROMANDIBULAR E DOR OROFACIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223288",
    "display" : "CIRURGIAO DENTISTA  ODONTOLOGIA PARA PACIENTES COM NECESSIDADES ESPECIAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223293",
    "display" : "CIRURGIAO DENTISTA DA ESTRATEGIA DE SAUDE DA FAMILIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223305",
    "display" : "MEDICO VETERINARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223310",
    "display" : "ZOOTECNISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223405",
    "display" : "FARMACEUTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223415",
    "display" : "FARMACEUTICO ANALISTA CLINICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223420",
    "display" : "FARMACEUTICO DE ALIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223425",
    "display" : "FARMACEUTICO PRATICAS INTEGRATIVAS E COMPLEMENTARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223430",
    "display" : "FARMACEUTICO EM SAUDE PUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223435",
    "display" : "FARMACEUTICO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223440",
    "display" : "FARMACEUTICO TOXICOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223445",
    "display" : "FARMACEUTICO HOSPITALAR E CLINICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223505",
    "display" : "ENFERMEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223510",
    "display" : "ENFERMEIRO AUDITOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223515",
    "display" : "ENFERMEIRO DE BORDO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223520",
    "display" : "ENFERMEIRO DE CENTRO CIRURGICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223525",
    "display" : "ENFERMEIRO DE TERAPIA INTENSIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223530",
    "display" : "ENFERMEIRO DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223535",
    "display" : "ENFERMEIRO NEFROLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223540",
    "display" : "ENFERMEIRO NEONATOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223545",
    "display" : "ENFERMEIRO OBSTETRICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223550",
    "display" : "ENFERMEIRO PSIQUIATRICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223555",
    "display" : "ENFERMEIRO PUERICULTOR E PEDIATRICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223560",
    "display" : "ENFERMEIRO SANITARISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223565",
    "display" : "ENFERMEIRO DA ESTRATEGIA DE SAUDE DA FAMILIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223570",
    "display" : "PERFUSIONISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "2235C3",
    "display" : "ENFERMEIRO ESTOMATERAPEUTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223605",
    "display" : "FISIOTERAPEUTA GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223625",
    "display" : "FISIOTERAPEUTA RESPIRATORIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223630",
    "display" : "FISIOTERAPEUTA NEUROFUNCIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223635",
    "display" : "FISIOTERAPEUTA TRAUMATOORTOPEDICA FUNCIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223640",
    "display" : "FISIOTERAPEUTA OSTEOPATA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223645",
    "display" : "FISIOTERAPEUTA QUIROPRAXISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223650",
    "display" : "FISIOTERAPEUTA ACUPUNTURISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223655",
    "display" : "FISIOTERAPEUTA ESPORTIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223660",
    "display" : "FISIOTERAPEUTA DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "2236I1",
    "display" : "TECNICO EM ORIENTACAO E MOBILIDADE DE CEGOS E DEFICIENTES VISUAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223705",
    "display" : "DIETISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223710",
    "display" : "NUTRICIONISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223810",
    "display" : "FONOAUDIOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223815",
    "display" : "FONOAUDIOLOGO EDUCACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223820",
    "display" : "FONOAUDIOLOGO EM AUDIOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223825",
    "display" : "FONOAUDIOLOGO EM DISFAGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223830",
    "display" : "FONOAUDIOLOGO EM LINGUAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223835",
    "display" : "FONOAUDIOLOGO EM MOTRICIDADE OROFACIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223840",
    "display" : "FONOAUDIOLOGO EM SAUDE COLETIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223845",
    "display" : "FONOAUDIOLOGO EM VOZ",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223905",
    "display" : "TERAPEUTA OCUPACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "223910",
    "display" : "ORTOPTISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "224105",
    "display" : "AVALIADOR FISICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "224110",
    "display" : "LUDOMOTRICISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "224115",
    "display" : "PREPARADOR DE ATLETA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "224120",
    "display" : "PREPARADOR FISICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "224125",
    "display" : "TECNICO DE DESPORTO INDIVIDUAL E COLETIVO (EXCETO FUTEBOL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "224130",
    "display" : "TECNICO DE LABORATORIO E FISCALIZACAO DESPORTIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "224135",
    "display" : "TREINADOR PROFISSIONAL DE FUTEBOL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "2241E1",
    "display" : "PROFISSIONAL DE EDUCACAO FISICA NA SAUDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225103",
    "display" : "MEDICO INFECTOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225105",
    "display" : "MEDICO ACUPUNTURISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225106",
    "display" : "MEDICO LEGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225109",
    "display" : "MEDICO NEFROLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225110",
    "display" : "MEDICO ALERGISTA E IMUNOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225112",
    "display" : "MEDICO NEUROLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225115",
    "display" : "MEDICO ANGIOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225118",
    "display" : "MEDICO NUTROLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225120",
    "display" : "MEDICO CARDIOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225121",
    "display" : "MEDICO ONCOLOGISTA CLINICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225122",
    "display" : "MEDICO CANCEROLOGISTA PEDIATRICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225124",
    "display" : "MEDICO PEDIATRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225125",
    "display" : "MEDICO CLINICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225127",
    "display" : "MEDICO PNEUMOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225130",
    "display" : "MEDICO DE FAMILIA E COMUNIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225133",
    "display" : "MEDICO PSIQUIATRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225135",
    "display" : "MEDICO DERMATOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225136",
    "display" : "MEDICO REUMATOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225139",
    "display" : "MEDICO SANITARISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225140",
    "display" : "MEDICO DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225142",
    "display" : "MEDICO DA ESTRATEGIA DE SAUDE DA FAMILIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225145",
    "display" : "MEDICO EM MEDICINA DE TRAFEGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225148",
    "display" : "MEDICO ANATOMOPATOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225150",
    "display" : "MEDICO EM MEDICINA INTENSIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225151",
    "display" : "MEDICO ANESTESIOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225154",
    "display" : "MEDICO ANTROPOSOFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225155",
    "display" : "MEDICO ENDOCRINOLOGISTA E METABOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225160",
    "display" : "MEDICO FISIATRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225165",
    "display" : "MEDICO GASTROENTEROLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225170",
    "display" : "MEDICO GENERALISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225175",
    "display" : "MEDICO GENETICISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225180",
    "display" : "MEDICO GERIATRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225185",
    "display" : "MEDICO HEMATOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225195",
    "display" : "MEDICO HOMEOPATA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225203",
    "display" : "MEDICO EM CIRURGIA VASCULAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225210",
    "display" : "MEDICO CIRURGIAO CARDIOVASCULAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225215",
    "display" : "MEDICO CIRURGIAO DE CABECA E PESCOCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225220",
    "display" : "MEDICO CIRURGIAO DO APARELHO DIGESTIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225225",
    "display" : "MEDICO CIRURGIAO GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225230",
    "display" : "MEDICO CIRURGIAO PEDIATRICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225235",
    "display" : "MEDICO CIRURGIAO PLASTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225240",
    "display" : "MEDICO CIRURGIAO TORACICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225245",
    "display" : "MEDICO FONIATRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225250",
    "display" : "MEDICO GINECOLOGISTA E OBSTETRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225255",
    "display" : "MEDICO MASTOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225260",
    "display" : "MEDICO NEUROCIRURGIAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225265",
    "display" : "MEDICO OFTALMOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225270",
    "display" : "MEDICO ORTOPEDISTA E TRAUMATOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225275",
    "display" : "MEDICO OTORRINOLARINGOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225280",
    "display" : "MEDICO COLOPROCTOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225285",
    "display" : "MEDICO UROLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225290",
    "display" : "MEDICO CANCEROLOGISTA CIRURGICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225295",
    "display" : "MEDICO CIRURGIAO DA MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225305",
    "display" : "MEDICO CITOPATOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225310",
    "display" : "MEDICO EM ENDOSCOPIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225315",
    "display" : "MEDICO EM MEDICINA NUCLEAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225320",
    "display" : "MEDICO EM RADIOLOGIA E DIAGNOSTICO POR IMAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225325",
    "display" : "MEDICO PATOLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225330",
    "display" : "MEDICO RADIOTERAPEUTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225335",
    "display" : "MEDICO PATOLOGISTA CLINICO  MEDICINA LABORATORIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225340",
    "display" : "MEDICO HEMOTERAPEUTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225345",
    "display" : "MEDICO HIPERBARISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "225350",
    "display" : "MEDICO NEUROFISIOLOGISTA CLINICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "226105",
    "display" : "QUIROPRAXISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "226110",
    "display" : "OSTEOPATA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "226305",
    "display" : "MUSICOTERAPEUTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "226310",
    "display" : "ARTETERAPEUTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "226315",
    "display" : "EQUOTERAPEUTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "226320",
    "display" : "NATUROLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231105",
    "display" : "PROFESSOR DE NIVEL SUPERIOR NA EDUCACAO INFANTIL (QUATRO A SEIS ANOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231110",
    "display" : "PROFESSOR DE NIVEL SUPERIOR NA EDUCACAO INFANTIL (ZERO A TRES ANOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231205",
    "display" : "PROFESSOR DA EDUCACAO DE JOVENS E ADULTOS DO ENSINO FUNDAMENTAL (PRIMEIRA A QUARTA SERIE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231210",
    "display" : "PROFESSOR DE NIVEL SUPERIOR DO ENSINO FUNDAMENTAL (PRIMEIRA A QUARTA SERIE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231305",
    "display" : "PROFESSOR DE CIENCIAS EXATAS E NATURAIS DO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231310",
    "display" : "PROFESSOR DE EDUCACAO ARTISTICA DO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231315",
    "display" : "PROFESSOR DE EDUCACAO FISICA DO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231320",
    "display" : "PROFESSOR DE GEOGRAFIA DO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231325",
    "display" : "PROFESSOR DE HISTORIA DO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231330",
    "display" : "PROFESSOR DE LINGUA ESTRANGEIRA MODERNA DO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231335",
    "display" : "PROFESSOR DE LINGUA PORTUGUESA DO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "231340",
    "display" : "PROFESSOR DE MATEMATICA DO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232105",
    "display" : "PROFESSOR DE ARTES NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232110",
    "display" : "PROFESSOR DE BIOLOGIA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232115",
    "display" : "PROFESSOR DE DISCIPLINAS PEDAGOGICAS NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232120",
    "display" : "PROFESSOR DE EDUCACAO FISICA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "232125",
    "display" : "PROFESSOR DE FILOSOFIA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232130",
    "display" : "PROFESSOR DE FISICA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232135",
    "display" : "PROFESSOR DE GEOGRAFIA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232140",
    "display" : "PROFESSOR DE HISTORIA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232145",
    "display" : "PROFESSOR DE LINGUA E LITERATURA BRASILEIRA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232150",
    "display" : "PROFESSOR DE LINGUA ESTRANGEIRA MODERNA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232155",
    "display" : "PROFESSOR DE MATEMATICA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232160",
    "display" : "PROFESSOR DE PSICOLOGIA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232165",
    "display" : "PROFESSOR DE QUIMICA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "232170",
    "display" : "PROFESSOR DE SOCIOLOGIA NO ENSINO MEDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233105",
    "display" : "PROFESSOR DA AREA DE MEIO AMBIENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233110",
    "display" : "PROFESSOR DE DESENHO TECNICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233115",
    "display" : "PROFESSOR DE TECNICAS AGRICOLAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233120",
    "display" : "PROFESSOR DE TECNICAS COMERCIAIS E SECRETARIAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233125",
    "display" : "PROFESSOR DE TECNICAS DE ENFERMAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233130",
    "display" : "PROFESSOR DE TECNICAS INDUSTRIAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233135",
    "display" : "PROFESSOR DE TECNOLOGIA E CALCULO TECNICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233205",
    "display" : "INSTRUTOR DE APRENDIZAGEM E TREINAMENTO AGROPECUARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233210",
    "display" : "INSTRUTOR DE APRENDIZAGEM E TREINAMENTO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233215",
    "display" : "PROFESSOR DE APRENDIZAGEM E TREINAMENTO COMERCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233220",
    "display" : "PROFESSOR INSTRUTOR DE ENSINO E APRENDIZAGEM AGROFLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "233225",
    "display" : "PROFESSOR INSTRUTOR DE ENSINO E APRENDIZAGEM EM SERVICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234105",
    "display" : "PROFESSOR DE MATEMATICA APLICADA (NO ENSINO SUPERIOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234110",
    "display" : "PROFESSOR DE MATEMATICA PURA (NO ENSINO SUPERIOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234115",
    "display" : "PROFESSOR DE ESTATISTICA (NO ENSINO SUPERIOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234120",
    "display" : "PROFESSOR DE COMPUTACAO (NO ENSINO SUPERIOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234125",
    "display" : "PROFESSOR DE PESQUISA OPERACIONAL (NO ENSINO SUPERIOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234205",
    "display" : "PROFESSOR DE FISICA (ENSINO SUPERIOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234210",
    "display" : "PROFESSOR DE QUIMICA (ENSINO SUPERIOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234215",
    "display" : "PROFESSOR DE ASTRONOMIA (ENSINO SUPERIOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234305",
    "display" : "PROFESSOR DE ARQUITETURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234310",
    "display" : "PROFESSOR DE ENGENHARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234315",
    "display" : "PROFESSOR DE GEOFISICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234320",
    "display" : "PROFESSOR DE GEOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234405",
    "display" : "PROFESSOR DE CIENCIAS BIOLOGICAS DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234410",
    "display" : "PROFESSOR DE EDUCACAO FISICA NO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "234415",
    "display" : "PROFESSOR DE ENFERMAGEM DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "234420",
    "display" : "PROFESSOR DE FARMACIA E BIOQUIMICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234425",
    "display" : "PROFESSOR DE FISIOTERAPIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234430",
    "display" : "PROFESSOR DE FONOAUDIOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234435",
    "display" : "PROFESSOR DE MEDICINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234440",
    "display" : "PROFESSOR DE MEDICINA VETERINARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234445",
    "display" : "PROFESSOR DE NUTRICAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234450",
    "display" : "PROFESSOR DE ODONTOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234455",
    "display" : "PROFESSOR DE TERAPIA OCUPACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234460",
    "display" : "PROFESSOR DE ZOOTECNIA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234505",
    "display" : "PROFESSOR DE ENSINO SUPERIOR NA AREA DE DIDATICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234510",
    "display" : "PROFESSOR DE ENSINO SUPERIOR NA AREA DE ORIENTACAO EDUCACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234515",
    "display" : "PROFESSOR DE ENSINO SUPERIOR NA AREA DE PESQUISA EDUCACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234520",
    "display" : "PROFESSOR DE ENSINO SUPERIOR NA AREA DE PRATICA DE ENSINO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234604",
    "display" : "PROFESSOR DE LINGUA ALEMA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234608",
    "display" : "PROFESSOR DE LINGUA ITALIANA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234612",
    "display" : "PROFESSOR DE LINGUA FRANCESA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234616",
    "display" : "PROFESSOR DE LINGUA INGLESA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234620",
    "display" : "PROFESSOR DE LINGUA ESPANHOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234624",
    "display" : "PROFESSOR DE LINGUA PORTUGUESA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234628",
    "display" : "PROFESSOR DE LITERATURA BRASILEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234632",
    "display" : "PROFESSOR DE LITERATURA PORTUGUESA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234636",
    "display" : "PROFESSOR DE LITERATURA ALEMA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234640",
    "display" : "PROFESSOR DE LITERATURA COMPARADA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234644",
    "display" : "PROFESSOR DE LITERATURA ESPANHOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234648",
    "display" : "PROFESSOR DE LITERATURA FRANCESA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234652",
    "display" : "PROFESSOR DE LITERATURA INGLESA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234656",
    "display" : "PROFESSOR DE LITERATURA ITALIANA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234660",
    "display" : "PROFESSOR DE LITERATURA DE LINGUAS ESTRANGEIRAS MODERNAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234664",
    "display" : "PROFESSOR DE OUTRAS LINGUAS E LITERATURAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234668",
    "display" : "PROFESSOR DE LINGUAS ESTRANGEIRAS MODERNAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234672",
    "display" : "PROFESSOR DE LINGISTICA E LINGISTICA APLICADA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234676",
    "display" : "PROFESSOR DE FILOLOGIA E CRITICA TEXTUAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234680",
    "display" : "PROFESSOR DE SEMIOTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234684",
    "display" : "PROFESSOR DE TEORIA DA LITERATURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234705",
    "display" : "PROFESSOR DE ANTROPOLOGIA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234710",
    "display" : "PROFESSOR DE ARQUIVOLOGIA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234715",
    "display" : "PROFESSOR DE BIBLIOTECONOMIA DO ENSIO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234720",
    "display" : "PROFESSOR DE CIENCIA POLITICA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234725",
    "display" : "PROFESSOR DE COMUNICACAO SOCIAL DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234730",
    "display" : "PROFESSOR DE DIREITO DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234735",
    "display" : "PROFESSOR DE FILOSOFIA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234740",
    "display" : "PROFESSOR DE GEOGRAFIA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234745",
    "display" : "PROFESSOR DE HISTORIA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234750",
    "display" : "PROFESSOR DE JORNALISMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234755",
    "display" : "PROFESSOR DE MUSEOLOGIA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234760",
    "display" : "PROFESSOR DE PSICOLOGIA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234765",
    "display" : "PROFESSOR DE SERVICO SOCIAL DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234770",
    "display" : "PROFESSOR DE SOCIOLOGIA DO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234805",
    "display" : "PROFESSOR DE ECONOMIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234810",
    "display" : "PROFESSOR DE ADMINISTRACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234815",
    "display" : "PROFESSOR DE CONTABILIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234905",
    "display" : "PROFESSOR DE ARTES DO ESPETACULO NO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234910",
    "display" : "PROFESSOR DE ARTES VISUAIS NO ENSINO SUPERIOR (ARTES PLASTICAS E MULTIMIDIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "234915",
    "display" : "PROFESSOR DE MUSICA NO ENSINO SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239205",
    "display" : "PROFESSOR DE ALUNOS COM DEFICIENCIA AUDITIVA E SURDOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239210",
    "display" : "PROFESSOR DE ALUNOS COM DEFICIENCIA FISICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239215",
    "display" : "PROFESSOR DE ALUNOS COM DEFICIENCIA MENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239220",
    "display" : "PROFESSOR DE ALUNOS COM DEFICIENCIA MULTIPLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239225",
    "display" : "PROFESSOR DE ALUNOS COM DEFICIENCIA VISUAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239405",
    "display" : "COORDENADOR PEDAGOGICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239410",
    "display" : "ORIENTADOR EDUCACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239415",
    "display" : "PEDAGOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239420",
    "display" : "PROFESSOR DE TECNICAS E RECURSOS AUDIOVISUAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239425",
    "display" : "PSICOPEDAGOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239430",
    "display" : "SUPERVISOR DE ENSINO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239435",
    "display" : "DESIGNER EDUCACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241005",
    "display" : "ADVOGADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241010",
    "display" : "ADVOGADO DE EMPRESA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241015",
    "display" : "ADVOGADO (DIREITO CIVIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241020",
    "display" : "ADVOGADO (DIREITO PUBLICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241025",
    "display" : "ADVOGADO (DIREITO PENAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241030",
    "display" : "ADVOGADO (AREAS ESPECIAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241035",
    "display" : "ADVOGADO (DIREITO DO TRABALHO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241040",
    "display" : "CONSULTOR JURIDICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241205",
    "display" : "ADVOGADO DA UNIAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241210",
    "display" : "PROCURADOR AUTARQUICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241215",
    "display" : "PROCURADOR DA FAZENDA NACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241220",
    "display" : "PROCURADOR DO ESTADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241225",
    "display" : "PROCURADOR DO MUNICIPIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241230",
    "display" : "PROCURADOR FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241235",
    "display" : "PROCURADOR FUNDACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241305",
    "display" : "OFICIAL DE REGISTRO DE CONTRATOS MARITIMOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241310",
    "display" : "OFICIAL DO REGISTRO CIVIL DE PESSOAS JURIDICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241315",
    "display" : "OFICIAL DO REGISTRO CIVIL DE PESSOAS NATURAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241320",
    "display" : "OFICIAL DO REGISTRO DE DISTRIBUICOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241325",
    "display" : "OFICIAL DO REGISTRO DE IMOVEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241330",
    "display" : "OFICIAL DO REGISTRO DE TITULOS E DOCUMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241335",
    "display" : "TABELIAO DE NOTAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241340",
    "display" : "TABELIAO DE PROTESTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242205",
    "display" : "PROCURADOR DA REPUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242210",
    "display" : "PROCURADOR DE JUSTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242215",
    "display" : "PROCURADOR DE JUSTICA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242220",
    "display" : "PROCURADOR DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242225",
    "display" : "PROCURADOR REGIONAL DA REPUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242230",
    "display" : "PROCURADOR REGIONAL DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242235",
    "display" : "PROMOTOR DE JUSTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242240",
    "display" : "SUBPROCURADOR DE JUSTICA MILITAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242245",
    "display" : "SUBPROCURADORGERAL DA REPUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242250",
    "display" : "SUBPROCURADORGERAL DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242305",
    "display" : "DELEGADO DE POLICIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242405",
    "display" : "DEFENSOR PUBLICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242410",
    "display" : "PROCURADOR DA ASSISTENCIA JUDICIARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242905",
    "display" : "OFICIAL DE INTELIGENCIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "242910",
    "display" : "OFICIAL TECNICO DE INTELIGENCIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251105",
    "display" : "ANTROPOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251110",
    "display" : "ARQUEOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251115",
    "display" : "CIENTISTA POLITICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251120",
    "display" : "SOCIOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251205",
    "display" : "ECONOMISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251210",
    "display" : "ECONOMISTA AGROINDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251215",
    "display" : "ECONOMISTA FINANCEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251220",
    "display" : "ECONOMISTA INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251225",
    "display" : "ECONOMISTA DO SETOR PUBLICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251230",
    "display" : "ECONOMISTA AMBIENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251235",
    "display" : "ECONOMISTA REGIONAL E URBANO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251305",
    "display" : "GEOGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251405",
    "display" : "FILOSOFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "251505",
    "display" : "PSICOLOGO EDUCACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251510",
    "display" : "PSICOLOGO CLINICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251515",
    "display" : "PSICOLOGO DO ESPORTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251520",
    "display" : "PSICOLOGO HOSPITALAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251525",
    "display" : "PSICOLOGO JURIDICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251530",
    "display" : "PSICOLOGO SOCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251535",
    "display" : "PSICOLOGO DO TRANSITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251540",
    "display" : "PSICOLOGO DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251545",
    "display" : "NEUROPSICOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251550",
    "display" : "PSICANALISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251555",
    "display" : "PSICOLOGO ACUPUNTURISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251605",
    "display" : "ASSISTENTE SOCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "251610",
    "display" : "ECONOMISTA DOMESTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252105",
    "display" : "ADMINISTRADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252205",
    "display" : "AUDITOR (CONTADORES E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252210",
    "display" : "CONTADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252215",
    "display" : "PERITO CONTABIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252305",
    "display" : "SECRETARIA EXECUTIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252310",
    "display" : "SECRETARIO BILINGE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252315",
    "display" : "SECRETARIA TRILINGE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252320",
    "display" : "TECNOLOGO EM SECRETARIADO ESCOLAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252405",
    "display" : "ANALISTA DE RECURSOS HUMANOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252505",
    "display" : "ADMINISTRADOR DE FUNDOS E CARTEIRAS DE INVESTIMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252510",
    "display" : "ANALISTA DE CAMBIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252515",
    "display" : "ANALISTA DE COBRANCA (INSTITUICOES FINANCEIRAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252525",
    "display" : "ANALISTA DE CREDITO (INSTITUICOES FINANCEIRAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252530",
    "display" : "ANALISTA DE CREDITO RURAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252535",
    "display" : "ANALISTA DE LEASING",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252540",
    "display" : "ANALISTA DE PRODUTOS BANCARIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252545",
    "display" : "ANALISTA FINANCEIRO (INSTITUICOES FINANCEIRAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252550",
    "display" : "PROFISSIONAL DE RELACOES COM INVESTIDORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252605",
    "display" : "GESTOR EM SEGURANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253110",
    "display" : "REDATOR DE PUBLICIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253115",
    "display" : "AGENTE PUBLICITARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253130",
    "display" : "DIRETOR DE CRIACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253135",
    "display" : "DIRETOR DE CONTAS (PUBLICIDADE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253140",
    "display" : "AGENCIADOR DE PROPAGANDA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253205",
    "display" : "GERENTE DE CAPTACAO (FUNDOS E INVESTIMENTOS INSTITUCIONAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253210",
    "display" : "GERENTE DE CLIENTES ESPECIAIS (PRIVATE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253215",
    "display" : "GERENTE DE CONTAS  PESSOA FISICA E JURIDICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253220",
    "display" : "GERENTE DE GRANDES CONTAS (CORPORATE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253225",
    "display" : "OPERADOR DE NEGOCIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253305",
    "display" : "CORRETOR DE VALORES, ATIVOS FINANCEIROS, MERCADORIAS E DERIVATIVOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254105",
    "display" : "AUDITORFISCAL DA RECEITA FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254110",
    "display" : "TECNICO DA RECEITA FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254205",
    "display" : "AUDITORFISCAL DA PREVIDENCIA SOCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254305",
    "display" : "AUDITORFISCAL DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254310",
    "display" : "AGENTE DE HIGIENE E SEGURANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254405",
    "display" : "FISCAL DE TRIBUTOS ESTADUAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254410",
    "display" : "FISCAL DE TRIBUTOS MUNICIPAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254415",
    "display" : "TECNICO DE TRIBUTOS ESTADUAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254420",
    "display" : "TECNICO DE TRIBUTOS MUNICIPAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "254505",
    "display" : "FISCAL DE ATIVIDADES URBANAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261105",
    "display" : "ARQUIVISTA PESQUISADOR (JORNALISMO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261110",
    "display" : "ASSESSOR DE IMPRENSA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261115",
    "display" : "DIRETOR DE REDACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261120",
    "display" : "EDITOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261125",
    "display" : "JORNALISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261130",
    "display" : "PRODUTOR DE TEXTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261135",
    "display" : "REPORTER (EXCLUSIVE RADIO E TELEVISAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261140",
    "display" : "REVISOR DE TEXTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261205",
    "display" : "BIBLIOTECARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261210",
    "display" : "DOCUMENTALISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261215",
    "display" : "ANALISTA DE INFORMACOES (PESQUISADOR DE INFORMACOES DE REDE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261305",
    "display" : "ARQUIVISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261310",
    "display" : "MUSEOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261405",
    "display" : "FILOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261410",
    "display" : "INTERPRETE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261415",
    "display" : "LINGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261420",
    "display" : "TRADUTOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261425",
    "display" : "INTERPRETE DE LINGUA DE SINAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261430",
    "display" : "AUDIODESCRITOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261505",
    "display" : "AUTORROTEIRISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261510",
    "display" : "CRITICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261515",
    "display" : "ESCRITOR DE FICCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261520",
    "display" : "ESCRITOR DE NAO FICCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261525",
    "display" : "POETA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261530",
    "display" : "REDATOR DE TEXTOS TECNICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261605",
    "display" : "EDITOR DE JORNAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261610",
    "display" : "EDITOR DE LIVRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261615",
    "display" : "EDITOR DE MIDIA ELETRONICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261620",
    "display" : "EDITOR DE REVISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261625",
    "display" : "EDITOR DE REVISTA CIENTIFICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261705",
    "display" : "ANCORA DE RADIO E TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261710",
    "display" : "COMENTARISTA DE RADIO E TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261715",
    "display" : "LOCUTOR DE RADIO E TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261720",
    "display" : "LOCUTOR PUBLICITARIO DE RADIO E TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261725",
    "display" : "NARRADOR EM PROGRAMAS DE RADIO E TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261730",
    "display" : "REPORTER DE RADIO E TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261805",
    "display" : "FOTOGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261810",
    "display" : "FOTOGRAFO PUBLICITARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261815",
    "display" : "FOTOGRAFO RETRATISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261820",
    "display" : "REPOTER FOTOGRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262105",
    "display" : "EMPRESARIO DE ESPETACULO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262110",
    "display" : "PRODUTOR CINEMATOGRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262115",
    "display" : "PRODUTOR DE RADIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262120",
    "display" : "PRODUTOR DE TEATRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262125",
    "display" : "PRODUTOR DE TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262130",
    "display" : "TECNOLOGO EM PRODUCAO FONOGRAFICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262135",
    "display" : "TECNOLOGO EM PRODUCAO AUDIOVISUAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262205",
    "display" : "DIRETOR DE CINEMA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262210",
    "display" : "DIRETOR DE PROGRAMAS DE RADIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262215",
    "display" : "DIRETOR DE PROGRAMAS DE TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262220",
    "display" : "DIRETOR TEATRAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262305",
    "display" : "CENOGRAFO CARNAVALESCO E FESTAS POPULARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262310",
    "display" : "CENOGRAFO DE CINEMA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262315",
    "display" : "CENOGRAFO DE EVENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262320",
    "display" : "CENOGRAFO DE TEATRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262325",
    "display" : "CENOGRAFO DE TV",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262330",
    "display" : "DIRETOR DE ARTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262405",
    "display" : "ARTISTA (ARTES VISUAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262410",
    "display" : "DESENHISTA INDUSTRIAL (DESIGNER)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262415",
    "display" : "CONSERVADORRESTAURADOR DE BENS CULTURAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262420",
    "display" : "DESENHISTA INDUSTRIAL DE PRODUTO (DESIGNER DE PRODUTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262425",
    "display" : "DESENHISTA INDUSTRIAL DE PRODUTO DE MODA (DESIGNER DE MODA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262505",
    "display" : "ATOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262605",
    "display" : "COMPOSITOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262610",
    "display" : "MUSICO ARRANJADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262615",
    "display" : "MUSICO REGENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262620",
    "display" : "MUSICOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262705",
    "display" : "MUSICO INTERPRETE CANTOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262710",
    "display" : "MUSICO INTERPRETE INSTRUMENTISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262805",
    "display" : "ASSISTENTE DE COREOGRAFIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262810",
    "display" : "BAILARINO (EXCETO DANCAS POPULARES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262815",
    "display" : "COREOGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262820",
    "display" : "DRAMATURGO DE DANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262825",
    "display" : "ENSAIADOR DE DANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262830",
    "display" : "PROFESSOR DE DANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262905",
    "display" : "DECORADOR DE INTERIORES DE NIVEL SUPERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "263105",
    "display" : "MINISTRO DE CULTO RELIGIOSO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "263110",
    "display" : "MISSIONARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "263115",
    "display" : "TEOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "271105",
    "display" : "CHEFE DE COZINHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "271110",
    "display" : "TECNOLOGO EM GASTRONOMIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "300105",
    "display" : "TECNICO EM MECATRONICA  AUTOMACAO DA MANUFATURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "300110",
    "display" : "TECNICO EM MECATRONICA  ROBOTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "300305",
    "display" : "TECNICO EM ELETROMECANICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "301105",
    "display" : "TECNICO DE LABORATORIO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "301110",
    "display" : "TECNICO DE LABORATORIO DE ANALISES FISICOQUIMICAS (MATERIAIS DE CONSTRUCAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "301115",
    "display" : "TECNICO QUIMICO DE PETROLEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "301205",
    "display" : "TECNICO DE APOIO A BIOENGENHARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311105",
    "display" : "TECNICO QUIMICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311110",
    "display" : "TECNICO DE CELULOSE E PAPEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311115",
    "display" : "TECNICO EM CURTIMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311205",
    "display" : "TECNICO EM PETROQUIMICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311305",
    "display" : "TECNICO EM MATERIAIS, PRODUTOS CERAMICOS E VIDROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311405",
    "display" : "TECNICO EM BORRACHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311410",
    "display" : "TECNICO EM PLASTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311505",
    "display" : "TECNICO DE CONTROLE DE MEIO AMBIENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311510",
    "display" : "TECNICO DE METEOROLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311515",
    "display" : "TECNICO DE UTILIDADE (PRODUCAO E DISTRIBUICAO DE VAPOR, GASES, OLEOS, COMBUSTIVEIS, ENERGIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311520",
    "display" : "TECNICO EM TRATAMENTO DE EFLUENTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311605",
    "display" : "TECNICO TEXTIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311610",
    "display" : "TECNICO TEXTIL (TRATAMENTOS QUIMICOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311615",
    "display" : "TECNICO TEXTIL DE FIACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311620",
    "display" : "TECNICO TEXTIL DE MALHARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311625",
    "display" : "TECNICO TEXTIL DE TECELAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311705",
    "display" : "COLORISTA DE PAPEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311710",
    "display" : "COLORISTA TEXTIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311715",
    "display" : "PREPARADOR DE TINTAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311720",
    "display" : "PREPARADOR DE TINTAS (FABRICA DE TECIDOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "311725",
    "display" : "TINGIDOR DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "312105",
    "display" : "TECNICO DE OBRAS CIVIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "312205",
    "display" : "TECNICO DE ESTRADAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "312210",
    "display" : "TECNICO DE SANEAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "312305",
    "display" : "TECNICO EM AGRIMENSURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "312310",
    "display" : "TECNICO EM GEODESIA E CARTOGRAFIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "312315",
    "display" : "TECNICO EM HIDROGRAFIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "312320",
    "display" : "TOPOGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313105",
    "display" : "ELETROTECNICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313110",
    "display" : "ELETROTECNICO (PRODUCAO DE ENERGIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313115",
    "display" : "ELETROTENICO NA FABRICACAO, MONTAGEM E INSTALACAO DE MAQUINAS E EQUIPAMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313120",
    "display" : "TECNICO DE MANUTENCAO ELETRICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313125",
    "display" : "TECNICO DE MANUTENCAO ELETRICA DE MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313130",
    "display" : "TECNICO ELETRICISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313205",
    "display" : "TECNICO DE MANUTENCAO ELETRONICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313210",
    "display" : "TECNICO DE MANUTENCAO ELETRONICA (CIRCUITOS DE MAQUINAS COM COMANDO NUMERICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313215",
    "display" : "TECNICO ELETRONICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313220",
    "display" : "TECNICO EM MANUTENCAO DE EQUIPAMENTOS DE INFORMATICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313305",
    "display" : "TECNICO DE COMUNICACAO DE DADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313310",
    "display" : "TECNICO DE REDE (TELECOMUNICACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313315",
    "display" : "TECNICO DE TELECOMUNICACOES (TELEFONIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313320",
    "display" : "TECNICO DE TRANSMISSAO (TELECOMUNICACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313405",
    "display" : "TECNICO EM CALIBRACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313410",
    "display" : "TECNICO EM INSTRUMENTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313415",
    "display" : "ENCARREGADO DE MANUTENCAO DE INSTRUMENTOS DE CONTROLE, MEDICAO E SIMILARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "313505",
    "display" : "TECNICO EM FOTONICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "3135D1",
    "display" : "TECNICO EM REABILITACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "3135D2",
    "display" : "TECNICO EM EQUIPAMENTO MEDICO HOSPITALAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314105",
    "display" : "TECNICO EM MECANICA DE PRECISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314110",
    "display" : "TECNICO MECANICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314115",
    "display" : "TECNICO MECANICO (CALEFACAO, VENTILACAO E REFRIGERACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314120",
    "display" : "TECNICO MECANICO (MAQUINAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314125",
    "display" : "TECNICO MECANICO (MOTORES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314205",
    "display" : "TECNICO MECANICO NA FABRICACAO DE FERRAMENTAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314210",
    "display" : "TECNICO MECANICO NA MANUTENCAO DE FERRAMENTAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314305",
    "display" : "TECNICO EM AUTOMOBILISTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314310",
    "display" : "TECNICO MECANICO (AERONAVES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314315",
    "display" : "TECNICO MECANICO (EMBARCACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314405",
    "display" : "TECNICO DE MANUTENCAO DE SISTEMAS E INSTRUMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314410",
    "display" : "TECNICO EM MANUTENCAO DE MAQUINAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314605",
    "display" : "INSPETOR DE SOLDAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314610",
    "display" : "TECNICO EM CALDEIRARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314615",
    "display" : "TECNICO EM ESTRUTURAS METALICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314620",
    "display" : "TECNICO EM SOLDAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314625",
    "display" : "TECNOLOGO EM SOLDAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314705",
    "display" : "TECNICO DE ACABAMENTO EM SIDERURGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314710",
    "display" : "TECNICO DE ACIARIA EM SIDERURGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314715",
    "display" : "TECNICO DE FUNDICAO EM SIDERURGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314720",
    "display" : "TECNICO DE LAMINACAO EM SIDERURGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314725",
    "display" : "TECNICO DE REDUCAO NA SIDERURGIA (PRIMEIRA FUSAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314730",
    "display" : "TECNICO DE REFRATARIO EM SIDERURGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316105",
    "display" : "TECNICO EM GEOFISICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316110",
    "display" : "TECNICO EM GEOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316115",
    "display" : "TECNICO EM GEOQUIMICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316120",
    "display" : "TECNICO EM GEOTECNIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316305",
    "display" : "TECNICO DE MINERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316310",
    "display" : "TECNICO DE MINERACAO (OLEO E PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316315",
    "display" : "TECNICO EM PROCESSAMENTO MINERAL (EXCETO PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316320",
    "display" : "TECNICO EM PESQUISA MINERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316325",
    "display" : "TECNICO DE PRODUCAO EM REFINO DE PETROLEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316330",
    "display" : "TECNICO EM PLANEJAMENTO DE LAVRA DE MINAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316335",
    "display" : "DESINCRUSTADOR (POCOS DE PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "316340",
    "display" : "CIMENTADOR (POCOS DE PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "317105",
    "display" : "PROGRAMADOR DE INTERNET",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "317110",
    "display" : "PROGRAMADOR DE SISTEMAS DE INFORMACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "317115",
    "display" : "PROGRAMADOR DE MAQUINAS  FERRAMENTA COM COMANDO NUMERICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "317120",
    "display" : "PROGRAMADOR DE MULTIMIDIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "317205",
    "display" : "OPERADOR DE COMPUTADOR (INCLUSIVE MICROCOMPUTADOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "317210",
    "display" : "TECNICO DE APOIO AO USUARIO DE INFORMATICA (HELPDESK)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318005",
    "display" : "DESENHISTA TECNICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318010",
    "display" : "DESENHISTA COPISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318015",
    "display" : "DESENHISTA DETALHISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318105",
    "display" : "DESENHISTA TECNICO (ARQUITETURA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318110",
    "display" : "DESENHISTA TECNICO (CARTOGRAFIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318115",
    "display" : "DESENHISTA TECNICO (CONSTRUCAO CIVIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318120",
    "display" : "DESENHISTA TECNICO (INSTALACOES HIDROSSANITARIAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318205",
    "display" : "DESENHISTA TECNICO MECANICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318210",
    "display" : "DESENHISTA TECNICO AERONAUTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318215",
    "display" : "DESENHISTA TECNICO NAVAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318305",
    "display" : "DESENHISTA TECNICO (ELETRICIDADE E ELETRONICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318310",
    "display" : "DESENHISTA TECNICO (CALEFACAO, VENTILACAO E REFRIGERACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318405",
    "display" : "DESENHISTA TECNICO (ARTES GRAFICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318410",
    "display" : "DESENHISTA TECNICO (ILUSTRACOES ARTISTICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318415",
    "display" : "DESENHISTA TECNICO (ILUSTRACOES TECNICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318420",
    "display" : "DESENHISTA TECNICO (INDUSTRIA TEXTIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318425",
    "display" : "DESENHISTA TECNICO (MOBILIARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318430",
    "display" : "DESENHISTA TECNICO DE EMBALAGENS, MAQUETES E LEIAUTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318505",
    "display" : "DESENHISTA PROJETISTA DE ARQUITETURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318510",
    "display" : "DESENHISTA PROJETISTA DE CONSTRUCAO CIVIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318605",
    "display" : "DESENHISTA PROJETISTA DE MAQUINAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318610",
    "display" : "DESENHISTA PROJETISTA MECANICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318705",
    "display" : "DESENHISTA PROJETISTA DE ELETRICIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318710",
    "display" : "DESENHISTA PROJETISTA ELETRONICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318805",
    "display" : "PROJETISTA DE MOVEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318810",
    "display" : "MODELISTA DE ROUPAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "318815",
    "display" : "MODELISTA DE CALCADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "319105",
    "display" : "TECNICO EM CALCADOS E ARTEFATOS DE COURO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "319110",
    "display" : "TECNICO EM CONFECCOES DO VESTUARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "319205",
    "display" : "TECNICO DO MOBILIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "320105",
    "display" : "TECNICO EM BIOTERISMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "320110",
    "display" : "TECNICO EM HISTOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "321105",
    "display" : "TECNICO AGRICOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "321110",
    "display" : "TECNICO AGROPECUARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "321205",
    "display" : "TECNICO EM MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "321210",
    "display" : "TECNICO FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "321305",
    "display" : "TECNICO EM PISCICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "321310",
    "display" : "TECNICO EM CARCINICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "321315",
    "display" : "TECNICO EM MITILICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "321320",
    "display" : "TECNICO EM RANICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322105",
    "display" : "TECNICO EM ACUPUNTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322110",
    "display" : "PODOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322115",
    "display" : "TECNICO EM QUIROPRAXIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322120",
    "display" : "MASSOTERAPEUTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322125",
    "display" : "TERAPEUTA HOLISTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322130",
    "display" : "ESTETICISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322135",
    "display" : "DOULA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322205",
    "display" : "TECNICO DE ENFERMAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322210",
    "display" : "TECNICO DE ENFERMAGEM DE TERAPIA INTENSIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322215",
    "display" : "TECNICO DE ENFERMAGEM DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322220",
    "display" : "TECNICO DE ENFERMAGEM PSIQUIATRICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322225",
    "display" : "INSTRUMENTADOR CIRURGICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322230",
    "display" : "AUXILIAR DE ENFERMAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322235",
    "display" : "AUXILIAR DE ENFERMAGEM DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322240",
    "display" : "AUXILIAR DE SAUDE (NAVEGACAO MARITIMA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322245",
    "display" : "TECNICO DE ENFERMAGEM DA ESTRATEGIA DE SAUDE DA FAMILIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322250",
    "display" : "AUXILIAR DE ENFERMAGEM DA ESTRATEGIA DE SAUDE DA FAMILIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322305",
    "display" : "TECNICO EM OPTICA E OPTOMETRIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322405",
    "display" : "TECNICO EM SAUDE BUCAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322410",
    "display" : "PROTETICO DENTARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322415",
    "display" : "AUXILIAR EM SAUDE BUCAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322420",
    "display" : "AUXILIAR DE PROTESE DENTARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322425",
    "display" : "TECNICO EM SAUDE BUCAL DA ESTRATEGIA DE SAUDE DA FAMILIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322430",
    "display" : "AUXILIAR EM SAUDE BUCAL DA ESTRATEGIA DE SAUDE DA FAMILIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "322505",
    "display" : "TECNICO DE ORTOPEDIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322605",
    "display" : "TECNICO DE IMOBILIZACAO ORTOPEDICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "323105",
    "display" : "TECNICO EM PECUARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "324105",
    "display" : "TECNICO EM METODOS ELETROGRAFICOS EM ENCEFALOGRAFIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "324110",
    "display" : "TECNICO EM METODOS GRAFICOS EM CARDIOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "324115",
    "display" : "TECNICO EM RADIOLOGIA E IMAGENOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "324120",
    "display" : "TECNOLOGO EM RADIOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "324125",
    "display" : "TECNOLOGO OFTALMICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "324205",
    "display" : "TECNICO EM PATOLOGIA CLINICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "324210",
    "display" : "AUXILIAR TECNICO EM PATOLOGIA CLINICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "324215",
    "display" : "CITOTECNICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "324220",
    "display" : "TECNICO EM HEMOTERAPIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325005",
    "display" : "ENOLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325010",
    "display" : "AROMISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325015",
    "display" : "PERFUMISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325105",
    "display" : "AUXILIAR TECNICO EM LABORATORIO DE FARMACIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325110",
    "display" : "TECNICO EM LABORATORIO DE FARMACIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325115",
    "display" : "TECNICO EM FARMACIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325205",
    "display" : "TECNICO DE ALIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325210",
    "display" : "TECNICO EM NUTRICAO E DIETETICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325305",
    "display" : "TECNICO EM BIOTECNOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "325310",
    "display" : "TECNICO EM IMUNOBIOLOGICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "328105",
    "display" : "EMBALSAMADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "328110",
    "display" : "TAXIDERMISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "331105",
    "display" : "PROFESSOR DE NIVEL MEDIO NA EDUCACAO INFANTIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "331110",
    "display" : "AUXILIAR DE DESENVOLVIMENTO INFANTIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "331205",
    "display" : "PROFESSOR DE NIVEL MEDIO NO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "331305",
    "display" : "PROFESSOR DE NIVEL MEDIO NO ENSINO PROFISSIONALIZANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "332105",
    "display" : "PROFESSOR LEIGO NO ENSINO FUNDAMENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "332205",
    "display" : "PROFESSOR PRATICO NO ENSINO PROFISSIONALIZANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "333105",
    "display" : "INSTRUTOR DE AUTOESCOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "333110",
    "display" : "INSTRUTOR DE CURSOS LIVRES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "333115",
    "display" : "PROFESSORES DE CURSOS LIVRES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "334105",
    "display" : "INSPETOR DE ALUNOS DE ESCOLA PRIVADA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "334110",
    "display" : "INSPETOR DE ALUNOS DE ESCOLA PUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "334115",
    "display" : "MONITOR DE TRANSPORTE ESCOLAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341105",
    "display" : "PILOTO COMERCIAL (EXCETO LINHAS AEREAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341110",
    "display" : "PILOTO COMERCIAL DE HELICOPTERO (EXCETO LINHAS AEREAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341115",
    "display" : "MECANICO DE VOO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341120",
    "display" : "PILOTO AGRICOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341205",
    "display" : "CONTRAMESTRE DE CABOTAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341210",
    "display" : "MESTRE DE CABOTAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341215",
    "display" : "MESTRE FLUVIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341220",
    "display" : "PATRAO DE PESCA DE ALTOMAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341225",
    "display" : "PATRAO DE PESCA NA NAVEGACAO INTERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341230",
    "display" : "PILOTO FLUVIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341305",
    "display" : "CONDUTOR MAQUINISTA FLUVIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341310",
    "display" : "CONDUTOR MAQUINISTA MARITIMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341315",
    "display" : "ELETRICISTA DE BORDO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341320",
    "display" : "CONDUTOR DE MAQUINAS (BOMBEADOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341325",
    "display" : "CONDUTOR DE MAQUINAS (MECANICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342105",
    "display" : "ANALISTA DE TRANSPORTE EM COMERCIO EXTERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342110",
    "display" : "OPERADOR DE TRANSPORTE MULTIMODAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342115",
    "display" : "CONTROLADOR DE SERVICOS DE MAQUINAS E VEICULOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342120",
    "display" : "AFRETADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342125",
    "display" : "TECNOLOGO EM LOGISTICA DE TRANSPORTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342205",
    "display" : "AJUDANTE DE DESPACHANTE ADUANEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342210",
    "display" : "DESPACHANTE ADUANEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342305",
    "display" : "CHEFE DE SERVICO DE TRANSPORTE RODOVIARIO (PASSAGEIROS E CARGAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342310",
    "display" : "INSPETOR DE SERVICOS DE TRANSPORTES RODOVIARIOS (PASSAGEIROS E CARGAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342315",
    "display" : "SUPERVISOR DE CARGA E DESCARGA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342405",
    "display" : "AGENTE DE ESTACAO (FERROVIA E METRO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342410",
    "display" : "OPERADOR DE CENTRO DE CONTROLE (FERROVIA E METRO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342505",
    "display" : "CONTROLADOR DE TRAFEGO AEREO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342510",
    "display" : "DESPACHANTE OPERACIONAL DE VOO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342515",
    "display" : "FISCAL DE AVIACAO CIVIL (FAC)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342520",
    "display" : "GERENTE DA ADMINISTRACAO DE AEROPORTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342525",
    "display" : "GERENTE DE EMPRESA AEREA EM AEROPORTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342530",
    "display" : "INSPETOR DE AVIACAO CIVIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342535",
    "display" : "OPERADOR DE ATENDIMENTO AEROVIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342540",
    "display" : "SUPERVISOR DA ADMINISTRACAO DE AEROPORTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342545",
    "display" : "SUPERVISOR DE EMPRESA AEREA EM AEROPORTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342550",
    "display" : "AGENTE DE PROTECAO DE AVIACAO CIVIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342605",
    "display" : "CHEFE DE ESTACAO PORTUARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342610",
    "display" : "SUPERVISOR DE OPERACOES PORTUARIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351105",
    "display" : "TECNICO DE CONTABILIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351110",
    "display" : "CHEFE DE CONTABILIDADE (TECNICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351115",
    "display" : "CONSULTOR CONTABIL (TECNICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351305",
    "display" : "TECNICO EM ADMINISTRACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351310",
    "display" : "TECNICO EM ADMINISTRACAO DE COMERCIO EXTERIOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351315",
    "display" : "AGENTE DE RECRUTAMENTO E SELECAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351405",
    "display" : "ESCREVENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351410",
    "display" : "ESCRIVAO JUDICIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351415",
    "display" : "ESCRIVAO EXTRA  JUDICIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351420",
    "display" : "ESCRIVAO DE POLICIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351425",
    "display" : "OFICIAL DE JUSTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351430",
    "display" : "AUXILIAR DE SERVICOS JURIDICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351505",
    "display" : "TECNICO EM SECRETARIADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351510",
    "display" : "TAQUIGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351515",
    "display" : "ESTENOTIPISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351605",
    "display" : "TECNICO EM SEGURANCA NO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351610",
    "display" : "TECNICO EM HIGIENE OCUPACIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351705",
    "display" : "ANALISTA DE SEGUROS (TECNICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351710",
    "display" : "ANALISTA DE SINISTROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351715",
    "display" : "ASSISTENTE COMERCIAL DE SEGUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351720",
    "display" : "ASSISTENTE TECNICO DE SEGUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351725",
    "display" : "INSPETOR DE RISCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351730",
    "display" : "INSPETOR DE SINISTROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351735",
    "display" : "TECNICO DE RESSEGUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351740",
    "display" : "TECNICO DE SEGUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351805",
    "display" : "DETETIVE PROFISSIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351810",
    "display" : "INVESTIGADOR DE POLICIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351815",
    "display" : "PAPILOSCOPISTA POLICIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351905",
    "display" : "AGENTE DE INTELIGENCIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351910",
    "display" : "AGENTE TECNICO DE INTELIGENCIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "352205",
    "display" : "AGENTE DE DEFESA AMBIENTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "352210",
    "display" : "AGENTE DE SAUDE PUBLICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "352305",
    "display" : "METROLOGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "352310",
    "display" : "AGENTE FISCAL DE QUALIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "352315",
    "display" : "AGENTE FISCAL METROLOGICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "352320",
    "display" : "AGENTE FISCAL TEXTIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "352405",
    "display" : "AGENTE DE DIREITOS AUTORAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "352410",
    "display" : "AVALIADOR DE PRODUTOS DO MEIO DE COMUNICACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "352420",
    "display" : "TECNICO EM DIREITOS AUTORAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "353205",
    "display" : "TECNICO DE OPERACOES E SERVICOS BANCARIOS  CAMBIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "353210",
    "display" : "TECNICO DE OPERACOES E SERVICOS BANCARIOS  CREDITO IMOBILIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "353215",
    "display" : "TECNICO DE OPERACOES E SERVICOS BANCARIOS  CREDITO RURAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "353220",
    "display" : "TECNICO DE OPERACOES E SERVICOS BANCARIOS  LEASING",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "353225",
    "display" : "TECNICO DE OPERACOES E SERVICOS BANCARIOS  RENDA FIXA E VARIAVEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "353230",
    "display" : "TESOUREIRO DE BANCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "353235",
    "display" : "CHEFE DE SERVICOS BANCARIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354110",
    "display" : "AGENCIADOR DE PROPAGANDA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354120",
    "display" : "AGENTE DE VENDAS DE SERVICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354125",
    "display" : "ASSISTENTE DE VENDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354130",
    "display" : "PROMOTOR DE VENDAS ESPECIALIZADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354135",
    "display" : "TECNICO DE VENDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354140",
    "display" : "TECNICO EM ATENDIMENTO E VENDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354145",
    "display" : "VENDEDOR PRACISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354150",
    "display" : "PROPAGANDISTA DE PRODUTOS FAMACEUTICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354205",
    "display" : "COMPRADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354210",
    "display" : "SUPERVISOR DE COMPRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354305",
    "display" : "ANALISTA DE EXPORTACAO E IMPORTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354405",
    "display" : "LEILOEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354410",
    "display" : "AVALIADOR DE IMOVEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354415",
    "display" : "AVALIADOR DE BENS MOVEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354505",
    "display" : "CORRETOR DE SEGUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354605",
    "display" : "CORRETOR DE IMOVEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354705",
    "display" : "REPRESENTANTE COMERCIAL AUTONOMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354805",
    "display" : "TECNICO EM TURISMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354810",
    "display" : "OPERADOR DE TURISMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354815",
    "display" : "AGENTE DE VIAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354820",
    "display" : "ORGANIZADOR DE EVENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354825",
    "display" : "CERIMONIALISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "371105",
    "display" : "AUXILIAR DE BIBLIOTECA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "371110",
    "display" : "TECNICO EM BIBLIOTECONOMIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "371205",
    "display" : "COLECIONADOR DE SELOS E MOEDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "371210",
    "display" : "TECNICO EM MUSEOLOGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "371305",
    "display" : "TECNICO EM PROGRAMACAO VISUAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "371310",
    "display" : "TECNICO GRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "371405",
    "display" : "RECREADOR DE ACANTONAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "371410",
    "display" : "RECREADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "372105",
    "display" : "DIRETOR DE FOTOGRAFIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "372110",
    "display" : "ILUMINADOR (TELEVISAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "372115",
    "display" : "OPERADOR DE CAMERA DE TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "372205",
    "display" : "OPERADOR DE REDE DE TELEPROCESSAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "372210",
    "display" : "RADIOTELEGRAFISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373105",
    "display" : "OPERADOR DE AUDIO DE CONTINUIDADE (RADIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373110",
    "display" : "OPERADOR DE CENTRAL DE RADIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373115",
    "display" : "OPERADOR DE EXTERNA (RADIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373120",
    "display" : "OPERADOR DE GRAVACAO DE RADIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373125",
    "display" : "OPERADOR DE TRANSMISSOR DE RADIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373205",
    "display" : "TECNICO EM OPERACAO DE EQUIPAMENTOS DE PRODUCAO PARA TELEVISAO E PRODUTORAS DE VIDEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373210",
    "display" : "TECNICO EM OPERACAO DE EQUIPAMENTO DE EXIBICAO DE TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373215",
    "display" : "TECNICO EM OPERACAO DE EQUIPAMENTOS DE TRANSMISSAORECEPCAO DE TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373220",
    "display" : "SUPERVISOR TECNICO OPERACIONAL DE SISTEMAS DE TELEVISAO E PRODUTORAS DE VIDEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374105",
    "display" : "TECNICO EM GRAVACAO DE AUDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374110",
    "display" : "TECNICO EM INSTALACAO DE EQUIPAMENTOS DE AUDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374115",
    "display" : "TECNICO EM MASTERIZACAO DE AUDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374120",
    "display" : "PROJETISTA DE SOM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374125",
    "display" : "TECNICO EM SONORIZACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374130",
    "display" : "TECNICO EM MIXAGEM DE AUDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374135",
    "display" : "PROJETISTA DE SISTEMAS DE AUDIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374140",
    "display" : "MICROFONISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374145",
    "display" : "DJ (DISC JOCKEY)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374205",
    "display" : "CENOTECNICO (CINEMA, VIDEO, TELEVISAO, TEATRO E ESPETACULOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374210",
    "display" : "MAQUINISTA DE CINEMA E VIDEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374215",
    "display" : "MAQUINISTA DE TEATRO E ESPETACULOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374305",
    "display" : "OPERADOR DE PROJETOR CINEMATOGRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374310",
    "display" : "OPERADORMANTENEDOR DE PROJETOR CINEMATOGRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374405",
    "display" : "EDITOR DE TV E VIDEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374410",
    "display" : "FINALIZADOR DE FILMES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374415",
    "display" : "FINALIZADOR DE VIDEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374420",
    "display" : "MONTADOR DE FILMES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "375105",
    "display" : "DESIGNER DE INTERIORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "375110",
    "display" : "DESIGNER DE VITRINES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "375115",
    "display" : "VISUAL MERCHANDISER",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "375120",
    "display" : "DECORADOR DE EVENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376105",
    "display" : "DANCARINO TRADICIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376110",
    "display" : "DANCARINO POPULAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376205",
    "display" : "ACROBATA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376210",
    "display" : "ARTISTA AEREO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376215",
    "display" : "ARTISTA DE CIRCO (OUTROS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376220",
    "display" : "CONTORCIONISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376225",
    "display" : "DOMADOR DE ANIMAIS (CIRCENSE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376230",
    "display" : "EQUILIBRISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376235",
    "display" : "MAGICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376240",
    "display" : "MALABARISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376245",
    "display" : "PALHACO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376250",
    "display" : "TITERITEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376255",
    "display" : "TRAPEZISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376305",
    "display" : "APRESENTADOR DE EVENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376310",
    "display" : "APRESENTADOR DE FESTAS POPULARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376315",
    "display" : "APRESENTADOR DE PROGRAMAS DE RADIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376320",
    "display" : "APRESENTADOR DE PROGRAMAS DE TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376325",
    "display" : "APRESENTADOR DE CIRCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376330",
    "display" : "MESTRE DE CERIMONIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376405",
    "display" : "MODELO ARTISTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376410",
    "display" : "MODELO DE MODAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "376415",
    "display" : "MODELO PUBLICITARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377105",
    "display" : "ATLETA PROFISSIONAL (OUTRAS MODALIDADES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377110",
    "display" : "ATLETA PROFISSIONAL DE FUTEBOL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377115",
    "display" : "ATLETA PROFISSIONAL DE GOLFE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377120",
    "display" : "ATLETA PROFISSIONAL DE LUTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377125",
    "display" : "ATLETA PROFISSIONAL DE TENIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377130",
    "display" : "JOQUEI",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377135",
    "display" : "PILOTO DE COMPETICAO AUTOMOBILISTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377140",
    "display" : "PROFISSIONAL DE ATLETISMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377145",
    "display" : "PUGILISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377205",
    "display" : "ARBITRO DESPORTIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377210",
    "display" : "ARBITRO DE ATLETISMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377215",
    "display" : "ARBITRO DE BASQUETE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377220",
    "display" : "ARBITRO DE FUTEBOL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377225",
    "display" : "ARBITRO DE FUTEBOL DE SALAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377230",
    "display" : "ARBITRO DE JUDO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377235",
    "display" : "ARBITRO DE KARATE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377240",
    "display" : "ARBITRO DE POLO AQUATICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "377245",
    "display" : "ARBITRO DE VOLEI",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391105",
    "display" : "CRONOANALISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391110",
    "display" : "CRONOMETRISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391115",
    "display" : "CONTROLADOR DE ENTRADA E SAIDA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391120",
    "display" : "PLANEJISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391125",
    "display" : "TECNICO DE PLANEJAMENTO DE PRODUCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391130",
    "display" : "TECNICO DE PLANEJAMENTO E PROGRAMACAO DA MANUTENCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391135",
    "display" : "TECNICO DE MATERIAPRIMA E MATERIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391205",
    "display" : "INSPETOR DE QUALIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391210",
    "display" : "TECNICO DE GARANTIA DA QUALIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391215",
    "display" : "OPERADOR DE INSPECAO DE QUALIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391220",
    "display" : "TECNICO DE PAINEL DE CONTROLE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391225",
    "display" : "ESCOLHEDOR DE PAPEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391230",
    "display" : "TECNICO OPERACIONAL DE SERVICOS DE CORREIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "395105",
    "display" : "TECNICO DE APOIO EM PESQUISA E DESENVOLVIMENTO (EXCETO AGROPECUARIO E FLORESTAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "395110",
    "display" : "TECNICO DE APOIO EM PESQUISA E DESENVOLVIMENTO AGROPECUARIO FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "410105",
    "display" : "SUPERVISOR ADMINISTRATIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "410205",
    "display" : "SUPERVISOR DE ALMOXARIFADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "410210",
    "display" : "SUPERVISOR DE CAMBIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "410215",
    "display" : "SUPERVISOR DE CONTAS A PAGAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "410220",
    "display" : "SUPERVISOR DE CONTROLE PATRIMONIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "410225",
    "display" : "SUPERVISOR DE CREDITO E COBRANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "410230",
    "display" : "SUPERVISOR DE ORCAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "410235",
    "display" : "SUPERVISOR DE TESOURARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411005",
    "display" : "AUXILIAR DE ESCRITORIO, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411010",
    "display" : "ASSISTENTE ADMINISTRATIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411015",
    "display" : "ATENDENTE DE JUDICIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411020",
    "display" : "AUXILIAR DE JUDICIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411025",
    "display" : "AUXILIAR DE CARTORIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411030",
    "display" : "AUXILIAR DE PESSOAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411035",
    "display" : "AUXILIAR DE ESTATISTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411040",
    "display" : "AUXILIAR DE SEGUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411045",
    "display" : "AUXILIAR DE SERVICOS DE IMPORTACAO E EXPORTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411050",
    "display" : "AGENTE DE MICROCREDITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "412105",
    "display" : "DATILOGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "412110",
    "display" : "DIGITADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "412115",
    "display" : "OPERADOR DE MENSAGENS DE TELECOMUNICACOES (CORREIOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "412120",
    "display" : "SUPERVISOR DE DIGITACAO E OPERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "412205",
    "display" : "CONTINUO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "413105",
    "display" : "ANALISTA DE FOLHA DE PAGAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "413110",
    "display" : "AUXILIAR DE CONTABILIDADE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "413115",
    "display" : "AUXILIAR DE FATURAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "413205",
    "display" : "ATENDENTE DE AGENCIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "413210",
    "display" : "CAIXA DE BANCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "413215",
    "display" : "COMPENSADOR DE BANCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "413220",
    "display" : "CONFERENTE DE SERVICOS BANCARIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "413225",
    "display" : "ESCRITURARIO DE BANCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "413230",
    "display" : "OPERADOR DE COBRANCA BANCARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414105",
    "display" : "ALMOXARIFE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414110",
    "display" : "ARMAZENISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414115",
    "display" : "BALANCEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414205",
    "display" : "APONTADOR DE MAODEOBRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414210",
    "display" : "APONTADOR DE PRODUCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414215",
    "display" : "CONFERENTE DE CARGA E DESCARGA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415105",
    "display" : "ARQUIVISTA DE DOCUMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415115",
    "display" : "CODIFICADOR DE DADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415120",
    "display" : "FITOTECARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415125",
    "display" : "KARDEXISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415130",
    "display" : "OPERADOR DE MAQUINA COPIADORA (EXCETO OPERADOR DE GRAFICA RAPIDA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415205",
    "display" : "CARTEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415210",
    "display" : "OPERADOR DE TRIAGEM E TRANSBORDO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415215",
    "display" : "ENTREGADOR DE PUBLICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "420105",
    "display" : "SUPERVISOR DE CAIXAS E BILHETEIROS (EXCETO CAIXA DE BANCO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "420110",
    "display" : "SUPERVISOR DE COBRANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "420115",
    "display" : "SUPERVISOR DE COLETADORES DE APOSTAS E DE JOGOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "420120",
    "display" : "SUPERVISOR DE ENTREVISTADORES E RECENSEADORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "420125",
    "display" : "SUPERVISOR DE RECEPCIONISTAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "420130",
    "display" : "SUPERVISOR DE TELEFONISTAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "420135",
    "display" : "SUPERVISOR DE TELEMARKETING E ATENDIMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421105",
    "display" : "ATENDENTE COMERCIAL (AGENCIA POSTAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421110",
    "display" : "BILHETEIRO DE TRANSPORTES COLETIVOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421115",
    "display" : "BILHETEIRO NO SERVICO DE DIVERSOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421120",
    "display" : "EMISSOR DE PASSAGENS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421125",
    "display" : "OPERADOR DE CAIXA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421205",
    "display" : "RECEBEDOR DE APOSTAS (LOTERIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421210",
    "display" : "RECEBEDOR DE APOSTAS (TURFE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421305",
    "display" : "COBRADOR EXTERNO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421310",
    "display" : "COBRADOR INTERNO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "421315",
    "display" : "LOCALIZADOR (COBRADOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422105",
    "display" : "RECEPCIONISTA, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422110",
    "display" : "RECEPCIONISTA DE CONSULTORIO MEDICO OU DENTARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "422115",
    "display" : "RECEPCIONISTA DE SEGURO SAUDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422120",
    "display" : "RECEPCIONISTA DE HOTEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422125",
    "display" : "RECEPCIONISTA DE BANCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422130",
    "display" : "CONCIERGE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422205",
    "display" : "TELEFONISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422210",
    "display" : "TELEOPERADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422215",
    "display" : "MONITOR DE TELEATENDIMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422220",
    "display" : "OPERADOR DE RADIOCHAMADA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422305",
    "display" : "OPERADOR DE TELEMARKETING ATIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422310",
    "display" : "OPERADOR DE TELEMARKETING ATIVO E RECEPTIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422315",
    "display" : "OPERADOR DE TELEMARKETING RECEPTIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422320",
    "display" : "OPERADOR DE TELEMARKETING TECNICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "423105",
    "display" : "DESPACHANTE DOCUMENTALISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "423110",
    "display" : "DESPACHANTE DE TRANSITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "424105",
    "display" : "ENTREVISTADOR CENSITARIO E DE PESQUISAS AMOSTRAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "424110",
    "display" : "ENTREVISTADOR DE PESQUISA DE OPINIAO E MIDIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "424115",
    "display" : "ENTREVISTADOR DE PESQUISAS DE MERCADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "424120",
    "display" : "ENTREVISTADOR DE PRECOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "424125",
    "display" : "ESCRITURARIO EM ESTATISTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "424130",
    "display" : "ENTREVISTADOR SOCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "510105",
    "display" : "SUPERVISOR DE TRANSPORTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "510110",
    "display" : "ADMINISTRADOR DE EDIFICIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "510115",
    "display" : "SUPERVISOR DE ANDAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "510120",
    "display" : "CHEFE DE PORTARIA DE HOTEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "510130",
    "display" : "CHEFE DE BAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "510135",
    "display" : "MAITRE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "510205",
    "display" : "SUPERVISOR DE LAVANDERIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "510305",
    "display" : "SUPERVISOR DE BOMBEIROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "510310",
    "display" : "SUPERVISOR DE VIGILANTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511105",
    "display" : "COMISSARIO DE VOO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511110",
    "display" : "COMISSARIO DE TREM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511115",
    "display" : "TAIFEIRO (EXCETO MILITARES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511205",
    "display" : "FISCAL DE TRANSPORTES COLETIVOS (EXCETO TREM)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511210",
    "display" : "DESPACHANTE DE TRANSPORTES COLETIVOS (EXCETO TREM)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511215",
    "display" : "COBRADOR DE TRANSPORTES COLETIVOS (EXCETO TREM)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511220",
    "display" : "BILHETEIRO (ESTACOES DE METRO, FERROVIARIAS E ASSEMELHADAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511405",
    "display" : "GUIA DE TURISMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511505",
    "display" : "CONDUTOR DE TURISMO DE AVENTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "511510",
    "display" : "CONDUTOR DE TURISMO DE PESCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "512105",
    "display" : "EMPREGADO DOMESTICO NOS SERVICOS GERAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "512110",
    "display" : "EMPREGADO DOMESTICO ARRUMADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "512115",
    "display" : "EMPREGADO DOMESTICO FAXINEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "512120",
    "display" : "EMPREGADO DOMESTICO DIARISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513105",
    "display" : "MORDOMO DE RESIDENCIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513110",
    "display" : "MORDOMO DE HOTELARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513115",
    "display" : "GOVERNANTA DE HOTELARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513205",
    "display" : "COZINHEIRO GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513210",
    "display" : "COZINHEIRO DO SERVICO DOMESTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513215",
    "display" : "COZINHEIRO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513220",
    "display" : "COZINHEIRO DE HOSPITAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513225",
    "display" : "COZINHEIRO DE EMBARCACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513305",
    "display" : "CAMAREIRA DE TEATRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513310",
    "display" : "CAMAREIRA DE TELEVISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513315",
    "display" : "CAMAREIRO DE HOTEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513320",
    "display" : "CAMAREIRO DE EMBARCACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513325",
    "display" : "GUARDAROUPEIRA DE CINEMA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513405",
    "display" : "GARCOM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513410",
    "display" : "GARCOM (SERVICOS DE VINHOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513415",
    "display" : "CUMIM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513420",
    "display" : "BARMAN",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513425",
    "display" : "COPEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513430",
    "display" : "COPEIRO DE HOSPITAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513435",
    "display" : "ATENDENTE DE LANCHONETE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513440",
    "display" : "BARISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513505",
    "display" : "AUXILIAR NOS SERVICOS DE ALIMENTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513605",
    "display" : "CHURRASQUEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513610",
    "display" : "PIZZAIOLO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "513615",
    "display" : "SUSHIMAN",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514105",
    "display" : "ASCENSORISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514110",
    "display" : "GARAGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514115",
    "display" : "SACRISTAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514120",
    "display" : "ZELADOR DE EDIFICIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514205",
    "display" : "COLETOR DE LIXO DOMICILIAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514215",
    "display" : "VARREDOR DE RUA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514225",
    "display" : "TRABALHADOR DE SERVICOS DE LIMPEZA E CONSERVACAO DE AREAS PUBLICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514230",
    "display" : "COLETOR DE RESIDUOS SOLIDOS DE SERVICOS DE SAUDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514305",
    "display" : "LIMPADOR DE VIDROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514310",
    "display" : "AUXILIAR DE MANUTENCAO PREDIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514315",
    "display" : "LIMPADOR DE FACHADAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514320",
    "display" : "FAXINEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514325",
    "display" : "TRABALHADOR DA MANUTENCAO DE EDIFICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "514330",
    "display" : "LIMPADOR DE PISCINAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515105",
    "display" : "AGENTE COMUNITARIO DE SAUDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515110",
    "display" : "ATENDENTE DE ENFERMAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "515115",
    "display" : "PARTEIRA LEIGA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515120",
    "display" : "VISITADOR SANITARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515125",
    "display" : "AGENTE INDIGENA DE SAUDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515130",
    "display" : "AGENTE INDIGENA DE SANEAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515135",
    "display" : "SOCORRISTA (EXCETO MEDICOS E ENFERMEIROS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515140",
    "display" : "AGENTE DE COMBATE AS ENDEMIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "5151F1",
    "display" : "AGENTE DE COMBATE A ENDEMIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515205",
    "display" : "AUXILIAR DE BANCO DE SANGUE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515210",
    "display" : "AUXILIAR DE FARMACIA DE MANIPULACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515215",
    "display" : "AUXILIAR DE LABORATORIO DE ANALISES CLINICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515220",
    "display" : "AUXILIAR DE LABORATORIO DE IMUNOBIOLOGICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515225",
    "display" : "AUXILIAR DE PRODUCAO FARMACEUTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "5152A1",
    "display" : "MICROSCOPISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515305",
    "display" : "EDUCADOR SOCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515310",
    "display" : "AGENTE DE ACAO SOCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515315",
    "display" : "MONITOR DE DEPENDENTE QUIMICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515320",
    "display" : "CONSELHEIRO TUTELAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515325",
    "display" : "SOCIOEDUCADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516105",
    "display" : "BARBEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516110",
    "display" : "CABELEIREIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516120",
    "display" : "MANICURE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516125",
    "display" : "MAQUIADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516130",
    "display" : "MAQUIADOR DE CARACTERIZACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516140",
    "display" : "PEDICURE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516205",
    "display" : "BABA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516210",
    "display" : "CUIDADOR DE IDOSOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516215",
    "display" : "MAE SOCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516220",
    "display" : "CUIDADOR EM SAUDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516305",
    "display" : "LAVADEIRO, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516310",
    "display" : "LAVADOR DE ROUPAS A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516315",
    "display" : "LAVADOR DE ARTEFATOS DE TAPECARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516320",
    "display" : "LIMPADOR A SECO, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516325",
    "display" : "PASSADOR DE ROUPAS EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516330",
    "display" : "TINGIDOR DE ROUPAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516335",
    "display" : "CONFERENTEEXPEDIDOR DE ROUPAS (LAVANDERIAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516340",
    "display" : "ATENDENTE DE LAVANDERIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516345",
    "display" : "AUXILIAR DE LAVANDERIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516405",
    "display" : "LAVADOR DE ROUPAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516410",
    "display" : "LIMPADOR DE ROUPAS A SECO, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516415",
    "display" : "PASSADOR DE ROUPAS, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516505",
    "display" : "AGENTE FUNERARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516605",
    "display" : "OPERADOR DE FORNO (SERVICOS FUNERARIOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516610",
    "display" : "SEPULTADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516705",
    "display" : "ASTROLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516710",
    "display" : "NUMEROLOGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516805",
    "display" : "ESOTERICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "516810",
    "display" : "PARANORMAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517105",
    "display" : "BOMBEIRO DE AERODROMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517110",
    "display" : "BOMBEIRO DE SEGURANCA DO TRABALHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517115",
    "display" : "SALVAVIDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517205",
    "display" : "AGENTE DE POLICIA FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517210",
    "display" : "POLICIAL RODOVIARIO FEDERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517215",
    "display" : "GUARDACIVIL MUNICIPAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517220",
    "display" : "AGENTE DE TRANSITO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517305",
    "display" : "AGENTE DE PROTECAO DE AEROPORTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517310",
    "display" : "AGENTE DE SEGURANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517315",
    "display" : "AGENTE DE SEGURANCA PENITENCIARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517320",
    "display" : "VIGIA FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517325",
    "display" : "VIGIA PORTUARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517330",
    "display" : "VIGILANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517335",
    "display" : "GUARDA PORTUARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517405",
    "display" : "PORTEIRO (HOTEL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517410",
    "display" : "PORTEIRO DE EDIFICIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517415",
    "display" : "PORTEIRO DE LOCAIS DE DIVERSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517420",
    "display" : "VIGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517425",
    "display" : "FISCAL DE LOJA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519105",
    "display" : "CICLISTA MENSAGEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519110",
    "display" : "MOTOCICLISTA NO TRANSPORTE DE DOCUMENTOS E PEQUENOS VOLUMES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519115",
    "display" : "MOTOTAXISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519205",
    "display" : "CATADOR DE MATERIAL RECICLAVEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519210",
    "display" : "SELECIONADOR DE MATERIAL RECICLAVEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519215",
    "display" : "OPERADOR DE PRENSA DE MATERIAL RECICLAVEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519305",
    "display" : "AUXILIAR DE VETERINARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519310",
    "display" : "ESTETICISTA DE ANIMAIS DOMESTICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519315",
    "display" : "BANHISTA DE ANIMAIS DOMESTICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519320",
    "display" : "TOSADOR DE ANIMAIS DOMESTICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519805",
    "display" : "PROFISSIONAL DO SEXO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519905",
    "display" : "CARTAZEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519910",
    "display" : "CONTROLADOR DE PRAGAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519915",
    "display" : "ENGRAXATE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519920",
    "display" : "GANDULA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519925",
    "display" : "GUARDADOR DE VEICULOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519930",
    "display" : "LAVADOR DE GARRAFAS, VIDROS E OUTROS UTENSILIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519935",
    "display" : "LAVADOR DE VEICULOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519940",
    "display" : "LEITURISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "519945",
    "display" : "RECEPCIONISTA DE CASAS DE ESPETACULOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "520105",
    "display" : "SUPERVISOR DE VENDAS DE SERVICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "520110",
    "display" : "SUPERVISOR DE VENDAS COMERCIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "521105",
    "display" : "VENDEDOR EM COMERCIO ATACADISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "521110",
    "display" : "VENDEDOR DE COMERCIO VAREJISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "521115",
    "display" : "PROMOTOR DE VENDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "521120",
    "display" : "DEMONSTRADOR DE MERCADORIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "521125",
    "display" : "REPOSITOR DE MERCADORIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "521130",
    "display" : "ATENDENTE DE FARMACIA  BALCONISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "521135",
    "display" : "FRENTISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "521140",
    "display" : "ATENDENTE DE LOJAS E MERCADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "523105",
    "display" : "INSTALADOR DE CORTINAS E PERSIANAS, PORTAS SANFONADAS E BOXE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "523110",
    "display" : "INSTALADOR DE SOM E ACESSORIOS DE VEICULOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "523115",
    "display" : "CHAVEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "524105",
    "display" : "VENDEDOR EM DOMICILIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "524205",
    "display" : "FEIRANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "524210",
    "display" : "JORNALEIRO (EM BANCA DE JORNAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "524215",
    "display" : "VENDEDOR PERMISSIONARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "524305",
    "display" : "VENDEDOR AMBULANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "524310",
    "display" : "PIPOQUEIRO AMBULANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "611005",
    "display" : "PRODUTOR AGROPECUARIO, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612005",
    "display" : "PRODUTOR AGRICOLA POLIVALENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612105",
    "display" : "PRODUTOR DE ARROZ",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612110",
    "display" : "PRODUTOR DE CANADEACUCAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612115",
    "display" : "PRODUTOR DE CEREAIS DE INVERNO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612120",
    "display" : "PRODUTOR DE GRAMINEAS FORRAGEIRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612125",
    "display" : "PRODUTOR DE MILHO E SORGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612205",
    "display" : "PRODUTOR DE ALGODAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612210",
    "display" : "PRODUTOR DE CURAUA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612215",
    "display" : "PRODUTOR DE JUTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612220",
    "display" : "PRODUTOR DE RAMI",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612225",
    "display" : "PRODUTOR DE SISAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612305",
    "display" : "PRODUTOR NA OLERICULTURA DE LEGUMES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612310",
    "display" : "PRODUTOR NA OLERICULTURA DE RAIZES, BULBOS E TUBERCULOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612315",
    "display" : "PRODUTOR NA OLERICULTURA DE TALOS, FOLHAS E FLORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612320",
    "display" : "PRODUTOR NA OLERICULTURA DE FRUTOS E SEMENTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612405",
    "display" : "PRODUTOR DE FLORES DE CORTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612410",
    "display" : "PRODUTOR DE FLORES EM VASO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612415",
    "display" : "PRODUTOR DE FORRACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612420",
    "display" : "PRODUTOR DE PLANTAS ORNAMENTAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612505",
    "display" : "PRODUTOR DE ARVORES FRUTIFERAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612510",
    "display" : "PRODUTOR DE ESPECIES FRUTIFERAS RASTEIRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612515",
    "display" : "PRODUTOR DE ESPECIES FRUTIFERAS TREPADEIRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612605",
    "display" : "CAFEICULTOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612610",
    "display" : "PRODUTOR DE CACAU",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612615",
    "display" : "PRODUTOR DE ERVAMATE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612620",
    "display" : "PRODUTOR DE FUMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612625",
    "display" : "PRODUTOR DE GUARANA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612705",
    "display" : "PRODUTOR DA CULTURA DE AMENDOIM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612710",
    "display" : "PRODUTOR DA CULTURA DE CANOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612715",
    "display" : "PRODUTOR DA CULTURA DE COCODABAIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612720",
    "display" : "PRODUTOR DA CULTURA DE DENDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612725",
    "display" : "PRODUTOR DA CULTURA DE GIRASSOL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612730",
    "display" : "PRODUTOR DA CULTURA DE LINHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612735",
    "display" : "PRODUTOR DA CULTURA DE MAMONA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612740",
    "display" : "PRODUTOR DA CULTURA DE SOJA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612805",
    "display" : "PRODUTOR DE ESPECIARIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "612810",
    "display" : "PRODUTOR DE PLANTAS AROMATICAS E MEDICINAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613005",
    "display" : "CRIADOR EM PECUARIA POLIVALENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613010",
    "display" : "CRIADOR DE ANIMAIS DOMESTICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613105",
    "display" : "CRIADOR DE ASININOS E MUARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613110",
    "display" : "CRIADOR DE BOVINOS (CORTE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613115",
    "display" : "CRIADOR DE BOVINOS (LEITE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613120",
    "display" : "CRIADOR DE BUBALINOS (CORTE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613125",
    "display" : "CRIADOR DE BUBALINOS (LEITE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613130",
    "display" : "CRIADOR DE EQINOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613205",
    "display" : "CRIADOR DE CAPRINOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613210",
    "display" : "CRIADOR DE OVINOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613215",
    "display" : "CRIADOR DE SUINOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613305",
    "display" : "AVICULTOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613310",
    "display" : "CUNICULTOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613405",
    "display" : "APICULTOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613410",
    "display" : "CRIADOR DE ANIMAIS PRODUTORES DE VENENO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613415",
    "display" : "MINHOCULTOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "613420",
    "display" : "SERICULTOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "620105",
    "display" : "SUPERVISOR DE EXPLORACAO AGRICOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "620110",
    "display" : "SUPERVISOR DE EXPLORACAO AGROPECUARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "620115",
    "display" : "SUPERVISOR DE EXPLORACAO PECUARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "621005",
    "display" : "TRABALHADOR AGROPECUARIO EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622005",
    "display" : "CASEIRO (AGRICULTURA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622010",
    "display" : "JARDINEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622015",
    "display" : "TRABALHADOR NA PRODUCAO DE MUDAS E SEMENTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622020",
    "display" : "TRABALHADOR VOLANTE DA AGRICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622105",
    "display" : "TRABALHADOR DA CULTURA DE ARROZ",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622110",
    "display" : "TRABALHADOR DA CULTURA DE CANADEACUCAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622115",
    "display" : "TRABALHADOR DA CULTURA DE MILHO E SORGO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622120",
    "display" : "TRABALHADOR DA CULTURA DE TRIGO, AVEIA, CEVADA E TRITICALE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622205",
    "display" : "TRABALHADOR DA CULTURA DE ALGODAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622210",
    "display" : "TRABALHADOR DA CULTURA DE SISAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622215",
    "display" : "TRABALHADOR DA CULTURA DO RAMI",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622305",
    "display" : "TRABALHADOR NA OLERICULTURA (FRUTOS E SEMENTES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622310",
    "display" : "TRABALHADOR NA OLERICULTURA (LEGUMES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622315",
    "display" : "TRABALHADOR NA OLERICULTURA (RAIZES, BULBOS E TUBERCULOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622320",
    "display" : "TRABALHADOR NA OLERICULTURA (TALOS, FOLHAS E FLORES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622405",
    "display" : "TRABALHADOR NO CULTIVO DE FLORES E FOLHAGENS DE CORTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622410",
    "display" : "TRABALHADOR NO CULTIVO DE FLORES EM VASO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622415",
    "display" : "TRABALHADOR NO CULTIVO DE FORRACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622420",
    "display" : "TRABALHADOR NO CULTIVO DE MUDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622425",
    "display" : "TRABALHADOR NO CULTIVO DE PLANTAS ORNAMENTAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622505",
    "display" : "TRABALHADOR NO CULTIVO DE ARVORES FRUTIFERAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622510",
    "display" : "TRABALHADOR NO CULTIVO DE ESPECIES FRUTIFERAS RASTEIRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622515",
    "display" : "TRABALHADOR NO CULTIVO DE TREPADEIRAS FRUTIFERAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622605",
    "display" : "TRABALHADOR DA CULTURA DE CACAU",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622610",
    "display" : "TRABALHADOR DA CULTURA DE CAFE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622615",
    "display" : "TRABALHADOR DA CULTURA DE ERVAMATE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622620",
    "display" : "TRABALHADOR DA CULTURA DE FUMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622625",
    "display" : "TRABALHADOR DA CULTURA DE GUARANA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622705",
    "display" : "TRABALHADOR NA CULTURA DE AMENDOIM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622710",
    "display" : "TRABALHADOR NA CULTURA DE CANOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622715",
    "display" : "TRABALHADOR NA CULTURA DE COCODABAIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622720",
    "display" : "TRABALHADOR NA CULTURA DE DENDE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622725",
    "display" : "TRABALHADOR NA CULTURA DE MAMONA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622730",
    "display" : "TRABALHADOR NA CULTURA DE SOJA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622735",
    "display" : "TRABALHADOR NA CULTURA DO GIRASSOL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622740",
    "display" : "TRABALHADOR NA CULTURA DO LINHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622805",
    "display" : "TRABALHADOR DA CULTURA DE ESPECIARIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "622810",
    "display" : "TRABALHADOR DA CULTURA DE PLANTAS AROMATICAS E MEDICINAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623005",
    "display" : "ADESTRADOR DE ANIMAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623010",
    "display" : "INSEMINADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623015",
    "display" : "TRABALHADOR DE PECUARIA POLIVALENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623020",
    "display" : "TRATADOR DE ANIMAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623025",
    "display" : "CASQUEADOR DE ANIMAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623030",
    "display" : "FERRADOR DE ANIMAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623105",
    "display" : "TRABALHADOR DA PECUARIA (ASININOS E MUARES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623110",
    "display" : "TRABALHADOR DA PECUARIA (BOVINOS CORTE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623115",
    "display" : "TRABALHADOR DA PECUARIA (BOVINOS LEITE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623120",
    "display" : "TRABALHADOR DA PECUARIA (BUBALINOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623125",
    "display" : "TRABALHADOR DA PECUARIA (EQINOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623205",
    "display" : "TRABALHADOR DA CAPRINOCULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623210",
    "display" : "TRABALHADOR DA OVINOCULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623215",
    "display" : "TRABALHADOR DA SUINOCULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623305",
    "display" : "TRABALHADOR DA AVICULTURA DE CORTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623310",
    "display" : "TRABALHADOR DA AVICULTURA DE POSTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623315",
    "display" : "OPERADOR DE INCUBADORA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623320",
    "display" : "TRABALHADOR DA CUNICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623325",
    "display" : "SEXADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623405",
    "display" : "TRABALHADOR EM CRIATORIOS DE ANIMAIS PRODUTORES DE VENENO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623410",
    "display" : "TRABALHADOR NA APICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623415",
    "display" : "TRABALHADOR NA MINHOCULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "623420",
    "display" : "TRABALHADOR NA SERICICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "630105",
    "display" : "SUPERVISOR DA AQICULTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "630110",
    "display" : "SUPERVISOR DA AREA FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631005",
    "display" : "CATADOR DE CARANGUEJOS E SIRIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631010",
    "display" : "CATADOR DE MARISCOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631015",
    "display" : "PESCADOR ARTESANAL DE LAGOSTAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631020",
    "display" : "PESCADOR ARTESANAL DE PEIXES E CAMAROES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631105",
    "display" : "PESCADOR ARTESANAL DE AGUA DOCE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631205",
    "display" : "PESCADOR INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631210",
    "display" : "PESCADOR PROFISSIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631305",
    "display" : "CRIADOR DE CAMAROES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631310",
    "display" : "CRIADOR DE JACARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631315",
    "display" : "CRIADOR DE MEXILHOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631320",
    "display" : "CRIADOR DE OSTRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631325",
    "display" : "CRIADOR DE PEIXES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631330",
    "display" : "CRIADOR DE QUELONIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631335",
    "display" : "CRIADOR DE RAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631405",
    "display" : "GELADOR INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631410",
    "display" : "GELADOR PROFISSIONAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631415",
    "display" : "PROEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "631420",
    "display" : "REDEIRO (PESCA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632005",
    "display" : "GUIA FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632010",
    "display" : "RAIZEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632015",
    "display" : "VIVEIRISTA FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632105",
    "display" : "CLASSIFICADOR DE TORAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632110",
    "display" : "CUBADOR DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632115",
    "display" : "IDENTIFICADOR FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632120",
    "display" : "OPERADOR DE MOTOSSERRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632125",
    "display" : "TRABALHADOR DE EXTRACAO FLORESTAL, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632205",
    "display" : "SERINGUEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632210",
    "display" : "TRABALHADOR DA EXPLORACAO DE ESPECIES PRODUTORAS DE GOMAS NAO ELASTICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632215",
    "display" : "TRABALHADOR DA EXPLORACAO DE RESINAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632305",
    "display" : "TRABALHADOR DA EXPLORACAO DE ANDIROBA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632310",
    "display" : "TRABALHADOR DA EXPLORACAO DE BABACU",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632315",
    "display" : "TRABALHADOR DA EXPLORACAO DE BACABA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632320",
    "display" : "TRABALHADOR DA EXPLORACAO DE BURITI",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632325",
    "display" : "TRABALHADOR DA EXPLORACAO DE CARNAUBA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632330",
    "display" : "TRABALHADOR DA EXPLORACAO DE COCODAPRAIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632335",
    "display" : "TRABALHADOR DA EXPLORACAO DE COPAIBA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632340",
    "display" : "TRABALHADOR DA EXPLORACAO DE MALVA (PAINA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632345",
    "display" : "TRABALHADOR DA EXPLORACAO DE MURUMURU",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632350",
    "display" : "TRABALHADOR DA EXPLORACAO DE OITICICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632355",
    "display" : "TRABALHADOR DA EXPLORACAO DE OURICURI",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632360",
    "display" : "TRABALHADOR DA EXPLORACAO DE PEQUI",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632365",
    "display" : "TRABALHADOR DA EXPLORACAO DE PIACAVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632370",
    "display" : "TRABALHADOR DA EXPLORACAO DE TUCUM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632405",
    "display" : "TRABALHADOR DA EXPLORACAO DE ACAI",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632410",
    "display" : "TRABALHADOR DA EXPLORACAO DE CASTANHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632415",
    "display" : "TRABALHADOR DA EXPLORACAO DE PINHAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632420",
    "display" : "TRABALHADOR DA EXPLORACAO DE PUPUNHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632505",
    "display" : "TRABALHADOR DA EXPLORACAO DE ARVORES E ARBUSTOS PRODUTORES DE SUBSTANCIAS AROMAT , MEDIC  E TOXICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632510",
    "display" : "TRABALHADOR DA EXPLORACAO DE CIPOS PRODUTORES DE SUBSTANCIAS AROMATICAS, MEDICINAIS E TOXICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632515",
    "display" : "TRABALHADOR DA EXPLORACAO DE MADEIRAS TANANTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632520",
    "display" : "TRABALHADOR DA EXPLORACAO DE RAIZES PRODUTORAS DE SUBSTANCIAS AROMATICAS, MEDICINAIS E TOXICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632525",
    "display" : "TRABALHADOR DA EXTRACAO DE SUBSTANCIAS AROMATICAS, MEDICINAIS E TOXICAS, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632605",
    "display" : "CARVOEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632610",
    "display" : "CARBONIZADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "632615",
    "display" : "AJUDANTE DE CARVOARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "641005",
    "display" : "OPERADOR DE COLHEITADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "641010",
    "display" : "OPERADOR DE MAQUINAS DE BENEFICIAMENTO DE PRODUTOS AGRICOLAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "641015",
    "display" : "TRATORISTA AGRICOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "642005",
    "display" : "OPERADOR DE COLHEDOR FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "642010",
    "display" : "OPERADOR DE MAQUINAS FLORESTAIS ESTATICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "642015",
    "display" : "OPERADOR DE TRATOR FLORESTAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "643005",
    "display" : "TRABALHADOR NA OPERACAO DE SISTEMA DE IRRIGACAO LOCALIZADA (MICROASPERSAO E GOTEJAMENTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "643010",
    "display" : "TRABALHADOR NA OPERACAO DE SISTEMA DE IRRIGACAO POR ASPERSAO (PIVO CENTRAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "643015",
    "display" : "TRABALHADOR NA OPERACAO DE SISTEMAS CONVENCIONAIS DE IRRIGACAO POR ASPERSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "643020",
    "display" : "TRABALHADOR NA OPERACAO DE SISTEMAS DE IRRIGACAO E ASPERSAO (ALTO PROPELIDO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "643025",
    "display" : "TRABALHADOR NA OPERACAO DE SISTEMAS DE IRRIGACAO POR SUPERFICIE E DRENAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710105",
    "display" : "SUPERVISOR DE APOIO OPERACIONAL NA MINERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710110",
    "display" : "SUPERVISOR DE EXTRACAO DE SAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710115",
    "display" : "SUPERVISOR DE PERFURACAO E DESMONTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710120",
    "display" : "SUPERVISOR DE PRODUCAO NA MINERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710125",
    "display" : "SUPERVISOR DE TRANSPORTE NA MINERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710205",
    "display" : "MESTRE (CONSTRUCAO CIVIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710210",
    "display" : "MESTRE DE LINHAS (FERROVIAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710215",
    "display" : "INSPETOR DE TERRAPLENAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710220",
    "display" : "SUPERVISOR DE USINA DE CONCRETO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "710225",
    "display" : "FISCAL DE PATIO DE USINA DE CONCRETO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711105",
    "display" : "AMOSTRADOR DE MINERIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711110",
    "display" : "CANTEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711115",
    "display" : "DESTROCADOR DE PEDRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711120",
    "display" : "DETONADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711125",
    "display" : "ESCORADOR DE MINAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711130",
    "display" : "MINEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711205",
    "display" : "OPERADOR DE CAMINHAO (MINAS E PEDREIRAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711210",
    "display" : "OPERADOR DE CARREGADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711215",
    "display" : "OPERADOR DE MAQUINA CORTADORA (MINAS E PEDREIRAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711220",
    "display" : "OPERADOR DE MAQUINA DE EXTRACAO CONTINUA (MINAS DE CARVAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711225",
    "display" : "OPERADOR DE MAQUINA PERFURADORA (MINAS E PEDREIRAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711230",
    "display" : "OPERADOR DE MAQUINA PERFURATRIZ",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711235",
    "display" : "OPERADOR DE MOTONIVELADORA (EXTRACAO DE MINERAIS SOLIDOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711240",
    "display" : "OPERADOR DE SCHUTTHECAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711245",
    "display" : "OPERADOR DE TRATOR (MINAS E PEDREIRAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711305",
    "display" : "OPERADOR DE SONDA DE PERCUSSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711310",
    "display" : "OPERADOR DE SONDA ROTATIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711315",
    "display" : "SONDADOR (POCOS DE PETROLEO E GAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711320",
    "display" : "SONDADOR DE POCOS (EXCETO DE PETROLEO E GAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711325",
    "display" : "PLATAFORMISTA (PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711330",
    "display" : "TORRISTA (PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711405",
    "display" : "GARIMPEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "711410",
    "display" : "OPERADOR DE SALINA (SAL MARINHO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712105",
    "display" : "MOLEIRO DE MINERIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712110",
    "display" : "OPERADOR DE APARELHO DE FLOTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712115",
    "display" : "OPERADOR DE APARELHO DE PRECIPITACAO (MINAS DE OURO OU PRATA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712120",
    "display" : "OPERADOR DE BRITADOR DE MANDIBULAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712125",
    "display" : "OPERADOR DE ESPESSADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712130",
    "display" : "OPERADOR DE JIG (MINAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712135",
    "display" : "OPERADOR DE PENEIRAS HIDRAULICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712205",
    "display" : "CORTADOR DE PEDRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712210",
    "display" : "GRAVADOR DE INSCRICOES EM PEDRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712215",
    "display" : "GRAVADOR DE RELEVOS EM PEDRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712220",
    "display" : "POLIDOR DE PEDRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712225",
    "display" : "TORNEIRO (LAVRA DE PEDRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "712230",
    "display" : "TRACADOR DE PEDRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715105",
    "display" : "OPERADOR DE BATEESTACAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715110",
    "display" : "OPERADOR DE COMPACTADORA DE SOLOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715115",
    "display" : "OPERADOR DE ESCAVADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715120",
    "display" : "OPERADOR DE MAQUINA DE ABRIR VALAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715125",
    "display" : "OPERADOR DE MAQUINAS DE CONSTRUCAO CIVIL E MINERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715130",
    "display" : "OPERADOR DE MOTONIVELADORA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715135",
    "display" : "OPERADOR DE PA CARREGADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715140",
    "display" : "OPERADOR DE PAVIMENTADORA (ASFALTO, CONCRETO E MATERIAIS SIMILARES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715145",
    "display" : "OPERADOR DE TRATOR DE LAMINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715205",
    "display" : "CALCETEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715210",
    "display" : "PEDREIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715215",
    "display" : "PEDREIRO (CHAMINES INDUSTRIAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715220",
    "display" : "PEDREIRO (MATERIAL REFRATARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715225",
    "display" : "PEDREIRO (MINERACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715230",
    "display" : "PEDREIRO DE EDIFICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715305",
    "display" : "ARMADOR DE ESTRUTURA DE CONCRETO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715310",
    "display" : "MOLDADOR DE CORPOS DE PROVA EM USINAS DE CONCRETO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715315",
    "display" : "ARMADOR DE ESTRUTURA DE CONCRETO ARMADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715405",
    "display" : "OPERADOR DE BETONEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715410",
    "display" : "OPERADOR DE BOMBA DE CONCRETO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715415",
    "display" : "OPERADOR DE CENTRAL DE CONCRETO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715505",
    "display" : "CARPINTEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715510",
    "display" : "CARPINTEIRO (ESQUADRIAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715515",
    "display" : "CARPINTEIRO (CENARIOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715520",
    "display" : "CARPINTEIRO (MINERACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715525",
    "display" : "CARPINTEIRO DE OBRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715530",
    "display" : "CARPINTEIRO (TELHADOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715535",
    "display" : "CARPINTEIRO DE FORMAS PARA CONCRETO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715540",
    "display" : "CARPINTEIRO DE OBRAS CIVIS DE ARTE (PONTES, TUNEIS, BARRAGENS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715545",
    "display" : "MONTADOR DE ANDAIMES (EDIFICACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715605",
    "display" : "ELETRICISTA DE INSTALACOES (CENARIOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715610",
    "display" : "ELETRICISTA DE INSTALACOES (EDIFICIOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715615",
    "display" : "ELETRICISTA DE INSTALACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715705",
    "display" : "APLICADOR DE ASFALTO IMPERMEABILIZANTE (COBERTURAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715710",
    "display" : "INSTALADOR DE ISOLANTES ACUSTICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715715",
    "display" : "INSTALADOR DE ISOLANTES TERMICOS (REFRIGERACAO E CLIMATIZACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715720",
    "display" : "INSTALADOR DE ISOLANTES TERMICOS DE CALDEIRA E TUBULACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715725",
    "display" : "INSTALADOR DE MATERIAL ISOLANTE, A MAO (EDIFICACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715730",
    "display" : "INSTALADOR DE MATERIAL ISOLANTE, A MAQUINA (EDIFICACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716105",
    "display" : "ACABADOR DE SUPERFICIES DE CONCRETO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716110",
    "display" : "REVESTIDOR DE SUPERFICIES DE CONCRETO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716205",
    "display" : "TELHADOR (TELHAS DE ARGILA E MATERIAS SIMILARES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716210",
    "display" : "TELHADOR (TELHAS DE CIMENTOAMIANTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716215",
    "display" : "TELHADOR (TELHAS METALICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716220",
    "display" : "TELHADOR (TELHAS PLATICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716305",
    "display" : "VIDRACEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716310",
    "display" : "VIDRACEIRO (EDIFICACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716315",
    "display" : "VIDRACEIRO (VITRAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716405",
    "display" : "GESSEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716505",
    "display" : "ASSOALHADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716510",
    "display" : "LADRILHEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716515",
    "display" : "PASTILHEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716520",
    "display" : "LUSTRADOR DE PISO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716525",
    "display" : "MARMORISTA (CONSTRUCAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716530",
    "display" : "MOSAISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716535",
    "display" : "TAQUEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716605",
    "display" : "CALAFETADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716610",
    "display" : "PINTOR DE OBRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716615",
    "display" : "REVESTIDOR DE INTERIORES (PAPEL, MATERIAL PLASTICO E EMBORRACHADOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "717005",
    "display" : "DEMOLIDOR DE EDIFICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "717010",
    "display" : "OPERADOR DE MARTELETE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "717015",
    "display" : "POCEIRO (EDIFICACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "717020",
    "display" : "SERVENTE DE OBRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "717025",
    "display" : "VIBRADORISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720105",
    "display" : "MESTRE (AFIADOR DE FERRAMENTAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720110",
    "display" : "MESTRE DE CALDEIRARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720115",
    "display" : "MESTRE DE FERRAMENTARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720120",
    "display" : "MESTRE DE FORJARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720125",
    "display" : "MESTRE DE FUNDICAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720130",
    "display" : "MESTRE DE GALVANOPLASTIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720135",
    "display" : "MESTRE DE PINTURA (TRATAMENTO DE SUPERFICIES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720140",
    "display" : "MESTRE DE SOLDAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720145",
    "display" : "MESTRE DE TREFILACAO DE METAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720150",
    "display" : "MESTRE DE USINAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720155",
    "display" : "MESTRE SERRALHEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720160",
    "display" : "SUPERVISOR DE CONTROLE DE TRATAMENTO TERMICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720205",
    "display" : "MESTRE (CONSTRUCAO NAVAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720210",
    "display" : "MESTRE (INDUSTRIA DE AUTOMOTORES E MATERIAL DE TRANSPORTES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720215",
    "display" : "MESTRE (INDUSTRIA DE MAQUINAS E OUTROS EQUIPAMENTOS MECANICOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "720220",
    "display" : "MESTRE DE CONSTRUCAO DE FORNOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721105",
    "display" : "FERRAMENTEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721110",
    "display" : "FERRAMENTEIRO DE MANDRIS, CALIBRADORES E OUTROS DISPOSITIVOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721115",
    "display" : "MODELADOR DE METAIS (FUNDICAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721205",
    "display" : "OPERADOR DE MAQUINA DE ELETROEROSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721210",
    "display" : "OPERADOR DE MAQUINAS OPERATRIZES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721215",
    "display" : "OPERADOR DE MAQUINASFERRAMENTA CONVENCIONAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721220",
    "display" : "OPERADOR DE USINAGEM CONVENCIONAL POR ABRASAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721225",
    "display" : "PREPARADOR DE MAQUINASFERRAMENTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721305",
    "display" : "AFIADOR DE CARDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721310",
    "display" : "AFIADOR DE CUTELARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721315",
    "display" : "AFIADOR DE FERRAMENTAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721320",
    "display" : "AFIADOR DE SERRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721325",
    "display" : "POLIDOR DE METAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721405",
    "display" : "OPERADOR DE CENTRO DE USINAGEM COM COMANDO NUMERICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721410",
    "display" : "OPERADOR DE FRESADORA COM COMANDO NUMERICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721415",
    "display" : "OPERADOR DE MANDRILADORA COM COMANDO NUMERICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721420",
    "display" : "OPERADOR DE MAQUINA ELETROEROSAO, A FIO, COM COMANDO NUMERICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721425",
    "display" : "OPERADOR DE RETIFICADORA COM COMANDO NUMERICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "721430",
    "display" : "OPERADOR DE TORNO COM COMANDO NUMERICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722105",
    "display" : "FORJADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722110",
    "display" : "FORJADOR A MARTELO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722115",
    "display" : "FORJADOR PRENSISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722205",
    "display" : "FUNDIDOR DE METAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722210",
    "display" : "LINGOTADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722215",
    "display" : "OPERADOR DE ACABAMENTO DE PECAS FUNDIDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722220",
    "display" : "OPERADOR DE MAQUINA CENTRIFUGADORA DE FUNDICAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722225",
    "display" : "OPERADOR DE MAQUINA DE FUNDIR SOB PRESSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722230",
    "display" : "OPERADOR DE VAZAMENTO (LINGOTAMENTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722235",
    "display" : "PREPARADOR DE PANELAS (LINGOTAMENTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722305",
    "display" : "MACHEIRO, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722310",
    "display" : "MACHEIRO, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722315",
    "display" : "MOLDADOR, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722320",
    "display" : "MOLDADOR, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722325",
    "display" : "OPERADOR DE EQUIPAMENTOS DE PREPARACAO DE AREIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722330",
    "display" : "OPERADOR DE MAQUINA DE MOLDAR AUTOMATIZADA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722405",
    "display" : "CABLEADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722410",
    "display" : "ESTIRADOR DE TUBOS DE METAL SEM COSTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "722415",
    "display" : "TREFILADOR DE METAIS, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723105",
    "display" : "CEMENTADOR DE METAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723110",
    "display" : "NORMALIZADOR DE METAIS E DE COMPOSITOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723115",
    "display" : "OPERADOR DE EQUIPAMENTO PARA RESFRIAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723120",
    "display" : "OPERADOR DE FORNO DE TRATAMENTO TERMICO DE METAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723125",
    "display" : "TEMPERADOR DE METAIS E DE COMPOSITOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723205",
    "display" : "DECAPADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723210",
    "display" : "FOSFATIZADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723215",
    "display" : "GALVANIZADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723220",
    "display" : "METALIZADOR A PISTOLA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723225",
    "display" : "METALIZADOR (BANHO QUENTE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723230",
    "display" : "OPERADOR DE MAQUINA RECOBRIDORA DE ARAME",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723235",
    "display" : "OPERADOR DE ZINCAGEM (PROCESSO ELETROLITICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723240",
    "display" : "OXIDADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723305",
    "display" : "OPERADOR DE EQUIPAMENTO DE SECAGEM DE PINTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723310",
    "display" : "PINTOR A PINCEL E ROLO (EXCETO OBRAS E ESTRUTURAS METALICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723315",
    "display" : "PINTOR DE ESTRUTURAS METALICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723320",
    "display" : "PINTOR DE VEICULOS (FABRICACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723325",
    "display" : "PINTOR POR IMERSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "723330",
    "display" : "PINTOR, A PISTOLA (EXCETO OBRAS E ESTRUTURAS METALICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724105",
    "display" : "ASSENTADOR DE CANALIZACAO (EDIFICACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724110",
    "display" : "ENCANADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724115",
    "display" : "INSTALADOR DE TUBULACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724120",
    "display" : "INSTALADOR DE TUBULACOES (AERONAVES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724125",
    "display" : "INSTALADOR DE TUBULACOES (EMBARCACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724130",
    "display" : "INSTALADOR DE TUBULACOES DE GAS COMBUSTIVEL (PRODUCAO E DISTRIBUICAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724135",
    "display" : "INSTALADOR DE TUBULACOES DE VAPOR (PRODUCAO E DISTRIBUICAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724205",
    "display" : "MONTADOR DE ESTRUTURAS METALICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724210",
    "display" : "MONTADOR DE ESTRUTURAS METALICAS DE EMBARCACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724215",
    "display" : "REBITADOR A MARTELO PNEUMATICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724220",
    "display" : "PREPARADOR DE ESTRUTURAS METALICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724225",
    "display" : "RISCADOR DE ESTRUTURAS METALICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724230",
    "display" : "REBITADOR, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724305",
    "display" : "BRASADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724310",
    "display" : "OXICORTADOR A MAO E A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724315",
    "display" : "SOLDADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724320",
    "display" : "SOLDADOR A OXIGAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724325",
    "display" : "SOLDADOR ELETRICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724405",
    "display" : "CALDEIREIRO (CHAPAS DE COBRE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724410",
    "display" : "CALDEIREIRO (CHAPAS DE FERRO E ACO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724415",
    "display" : "CHAPEADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724420",
    "display" : "CHAPEADOR DE CARROCERIAS METALICAS (FABRICACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724425",
    "display" : "CHAPEADOR NAVAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724430",
    "display" : "CHAPEADOR DE AERONAVES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724435",
    "display" : "FUNILEIRO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724440",
    "display" : "SERRALHEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724505",
    "display" : "OPERADOR DE MAQUINA DE CILINDRAR CHAPAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724510",
    "display" : "OPERADOR DE MAQUINA DE DOBRAR CHAPAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724515",
    "display" : "PRENSISTA (OPERADOR DE PRENSA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724605",
    "display" : "OPERADOR DE LACOS DE CABOS DE ACO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "724610",
    "display" : "TRANCADOR DE CABOS DE ACO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725005",
    "display" : "AJUSTADOR FERRAMENTEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725010",
    "display" : "AJUSTADOR MECANICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725015",
    "display" : "AJUSTADOR MECANICO (USINAGEM EM BANCADA E EM MAQUINASFERRAMENTAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725020",
    "display" : "AJUSTADOR MECANICO EM BANCADA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725025",
    "display" : "AJUSTADOR NAVAL (REPARO E CONSTRUCAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725105",
    "display" : "MONTADOR DE MAQUINAS, MOTORES E ACESSORIOS (MONTAGEM EM SERIE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725205",
    "display" : "MONTADOR DE MAQUINAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725210",
    "display" : "MONTADOR DE MAQUINAS GRAFICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725215",
    "display" : "MONTADOR DE MAQUINAS OPERATRIZES PARA MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725220",
    "display" : "MONTADOR DE MAQUINAS TEXTEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725225",
    "display" : "MONTADOR DE MAQUINASFERRAMENTAS (USINAGEM DE METAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725305",
    "display" : "MONTADOR DE EQUIPAMENTO DE LEVANTAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725310",
    "display" : "MONTADOR DE MAQUINAS AGRICOLAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725315",
    "display" : "MONTADOR DE MAQUINAS DE MINAS E PEDREIRAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725320",
    "display" : "MONTADOR DE MAQUINAS DE TERRAPLENAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725405",
    "display" : "MECANICO MONTADOR DE MOTORES DE AERONAVES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725410",
    "display" : "MECANICO MONTADOR DE MOTORES DE EMBARCACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725415",
    "display" : "MECANICO MONTADOR DE MOTORES DE EXPLOSAO E DIESEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725420",
    "display" : "MECANICO MONTADOR DE TURBOALIMENTADORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725505",
    "display" : "MONTADOR DE VEICULOS (LINHA DE MONTAGEM)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725510",
    "display" : "OPERADOR DE TIME DE MONTAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725605",
    "display" : "MONTADOR DE ESTRUTURAS DE AERONAVES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725610",
    "display" : "MONTADOR DE SISTEMAS DE COMBUSTIVEL DE AERONAVES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725705",
    "display" : "MECANICO DE REFRIGERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "730105",
    "display" : "SUPERVISOR DE MONTAGEM E INSTALACAO ELETROELETRONICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731105",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRONICOS (APARELHOS MEDICOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731110",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRONICOS (COMPUTADORES E EQUIPAMENTOS AUXILIARES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731115",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRICOS (INSTRUMENTOS DE MEDICAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731120",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRICOS (APARELHOS ELETRODOMESTICOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731125",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRICOS (CENTRAIS ELETRICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731130",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRICOS (MOTORES E DINAMOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731135",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731140",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRONICOS (INSTALACOES DE SINALIZACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731145",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRONICOS (MAQUINAS INDUSTRIAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731150",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRONICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731155",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRICOS (ELEVADORES E EQUIPAMENTOS SIMILARES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731160",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRICOS (TRANSFORMADORES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731165",
    "display" : "BOBINADOR ELETRICISTA, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731170",
    "display" : "BOBINADOR ELETRICISTA, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731175",
    "display" : "OPERADOR DE LINHA DE MONTAGEM (APARELHOS ELETRICOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731180",
    "display" : "OPERADOR DE LINHA DE MONTAGEM (APARELHOS ELETRONICOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731205",
    "display" : "MONTADOR DE EQUIPAMENTOS ELETRONICOS (ESTACAO DE RADIO, TV E EQUIPAMENTOS DE RADAR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731305",
    "display" : "INSTALADORREPARADOR DE EQUIPAMENTOS DE COMUTACAO EM TELEFONIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731310",
    "display" : "INSTALADORREPARADOR DE EQUIPAMENTOS DE ENERGIA EM TELEFONIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731315",
    "display" : "INSTALADORREPARADOR DE EQUIPAMENTOS DE TRANSMISSAO EM TELEFONIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731320",
    "display" : "INSTALADORREPARADOR DE LINHAS E APARELHOS DE TELECOMUNICACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731325",
    "display" : "INSTALADORREPARADOR DE REDES E CABOS TELEFONICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "731330",
    "display" : "REPARADOR DE APARELHOS DE TELECOMUNICACOES EM LABORATORIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "732105",
    "display" : "ELETRICISTA DE MANUTENCAO DE LINHAS ELETRICAS, TELEFONICAS E DE COMUNICACAO DE DADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "732110",
    "display" : "EMENDADOR DE CABOS ELETRICOS E TELEFONICOS (AEREOS E SUBTERRANEOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "732115",
    "display" : "EXAMINADOR DE CABOS, LINHAS ELETRICAS E TELEFONICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "732120",
    "display" : "INSTALADOR DE LINHAS ELETRICAS DE ALTA E BAIXATENSAO (REDE AEREA E SUBTERRANEA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "732125",
    "display" : "INSTALADOR ELETRICISTA (TRACAO DE VEICULOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "732130",
    "display" : "INSTALADORREPARADOR DE REDES TELEFONICAS E DE COMUNICACAO DE DADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "732135",
    "display" : "LIGADOR DE LINHAS TELEFONICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "740105",
    "display" : "SUPERVISOR DA MECANICA DE PRECISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "740110",
    "display" : "SUPERVISOR DE FABRICACAO DE INSTRUMENTOS MUSICAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "741105",
    "display" : "AJUSTADOR DE INSTRUMENTOS DE PRECISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "741110",
    "display" : "MONTADOR DE INSTRUMENTOS DE OPTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "741115",
    "display" : "MONTADOR DE INSTRUMENTOS DE PRECISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "741120",
    "display" : "RELOJOEIRO (FABRICACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "741125",
    "display" : "RELOJOEIRO (REPARACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "742105",
    "display" : "AFINADOR DE INSTRUMENTOS MUSICAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "742110",
    "display" : "CONFECCIONADOR DE ACORDEAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "742115",
    "display" : "CONFECCIONADOR DE INSTRUMENTOS DE CORDA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "742120",
    "display" : "CONFECCIONADOR DE INSTRUMENTOS DE PERCUSSAO (PELE, COURO OU PLASTICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "742125",
    "display" : "CONFECCIONADOR DE INSTRUMENTOS DE SOPRO (MADEIRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "742130",
    "display" : "CONFECCIONADOR DE INSTRUMENTOS DE SOPRO (METAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "742135",
    "display" : "CONFECCIONADOR DE ORGAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "742140",
    "display" : "CONFECCIONADOR DE PIANO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "750105",
    "display" : "SUPERVISOR DE JOALHERIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "750205",
    "display" : "SUPERVISOR DA INDUSTRIA DE MINERAIS NAO METALICOS (EXCETO OS DERIVADOS DE PETROLEO E CARVAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751005",
    "display" : "ENGASTADOR (JOIAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751010",
    "display" : "JOALHEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751015",
    "display" : "JOALHEIRO (REPARACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751020",
    "display" : "LAPIDADOR (JOIAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751105",
    "display" : "BATEFOLHA A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751110",
    "display" : "FUNDIDOR (JOALHERIA E OURIVESARIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751115",
    "display" : "GRAVADOR (JOALHERIA E OURIVESARIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751120",
    "display" : "LAMINADOR DE METAIS PRECIOSOS A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751125",
    "display" : "OURIVES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "751130",
    "display" : "TREFILADOR (JOALHERIA E OURIVESARIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752105",
    "display" : "ARTESAO MODELADOR (VIDROS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752110",
    "display" : "MOLDADOR (VIDROS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752115",
    "display" : "SOPRADOR DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752120",
    "display" : "TRANSFORMADOR DE TUBOS DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752205",
    "display" : "APLICADOR SERIGRAFICO EM VIDROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752210",
    "display" : "CORTADOR DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752215",
    "display" : "GRAVADOR DE VIDRO A AGUAFORTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752220",
    "display" : "GRAVADOR DE VIDRO A ESMERIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752225",
    "display" : "GRAVADOR DE VIDRO A JATO DE AREIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752230",
    "display" : "LAPIDADOR DE VIDROS E CRISTAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752235",
    "display" : "SURFASSAGISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752305",
    "display" : "CERAMISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752310",
    "display" : "CERAMISTA (TORNO DE PEDAL E MOTOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752315",
    "display" : "CERAMISTA (TORNO SEMIAUTOMATICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752320",
    "display" : "CERAMISTA MODELADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752325",
    "display" : "CERAMISTA MOLDADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752330",
    "display" : "CERAMISTA PRENSADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752405",
    "display" : "DECORADOR DE CERAMICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752410",
    "display" : "DECORADOR DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752415",
    "display" : "DECORADOR DE VIDRO A PINCEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752420",
    "display" : "OPERADOR DE ESMALTADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752425",
    "display" : "OPERADOR DE ESPELHAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "752430",
    "display" : "PINTOR DE CERAMICA, A PINCEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760105",
    "display" : "CONTRAMESTRE DE ACABAMENTO (INDUSTRIA TEXTIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760110",
    "display" : "CONTRAMESTRE DE FIACAO (INDUSTRIA TEXTIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760115",
    "display" : "CONTRAMESTRE DE MALHARIA (INDUSTRIA TEXTIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760120",
    "display" : "CONTRAMESTRE DE TECELAGEM (INDUSTRIA TEXTIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760125",
    "display" : "MESTRE (INDUSTRIA TEXTIL E DE CONFECCOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760205",
    "display" : "SUPERVISOR DE CURTIMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760305",
    "display" : "ENCARREGADO DE CORTE NA CONFECCAO DO VESTUARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760310",
    "display" : "ENCARREGADO DE COSTURA NA CONFECCAO DO VESTUARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760405",
    "display" : "SUPERVISOR (INDUSTRIA DE CALCADOS E ARTEFATOS DE COURO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760505",
    "display" : "SUPERVISOR DA CONFECCAO DE ARTEFATOS DE TECIDOS, COUROS E AFINS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "760605",
    "display" : "SUPERVISOR DAS ARTES GRAFICAS (INDUSTRIA EDITORIAL E GRAFICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761005",
    "display" : "OPERADOR POLIVALENTE DA INDUSTRIA TEXTIL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761105",
    "display" : "CLASSIFICADOR DE FIBRAS TEXTEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761110",
    "display" : "LAVADOR DE LA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761205",
    "display" : "OPERADOR DE ABERTURA (FIACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761210",
    "display" : "OPERADOR DE BINADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761215",
    "display" : "OPERADOR DE BOBINADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761220",
    "display" : "OPERADOR DE CARDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761225",
    "display" : "OPERADOR DE CONICALEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761230",
    "display" : "OPERADOR DE FILATORIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761235",
    "display" : "OPERADOR DE LAMINADEIRA E REUNIDEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761240",
    "display" : "OPERADOR DE MACAROQUEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761245",
    "display" : "OPERADOR DE OPENEND",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761250",
    "display" : "OPERADOR DE PASSADOR (FIACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761255",
    "display" : "OPERADOR DE PENTEADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761260",
    "display" : "OPERADOR DE RETORCEDEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761303",
    "display" : "TECELAO (REDES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761306",
    "display" : "TECELAO (RENDAS E BORDADOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761309",
    "display" : "TECELAO (TEAR AUTOMATICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761312",
    "display" : "TECELAO (TEAR JACQUARD)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761315",
    "display" : "TECELAO (TEAR MECANICO DE MAQUINETA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761318",
    "display" : "TECELAO (TEAR MECANICO DE XADREZ)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761321",
    "display" : "TECELAO (TEAR MECANICO LISO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761324",
    "display" : "TECELAO (TEAR MECANICO, EXCETO JACQUARD)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761327",
    "display" : "TECELAO DE MALHAS, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761330",
    "display" : "TECELAO DE MALHAS (MAQUINA CIRCULAR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761333",
    "display" : "TECELAO DE MALHAS (MAQUINA RETILINEA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761336",
    "display" : "TECELAO DE MEIAS, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761339",
    "display" : "TECELAO DE MEIAS (MAQUINA CIRCULAR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761342",
    "display" : "TECELAO DE MEIAS (MAQUINA RETILINEA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761345",
    "display" : "TECELAO DE TAPETES, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761348",
    "display" : "OPERADOR DE ENGOMADEIRA DE URDUME",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761351",
    "display" : "OPERADOR DE ESPULADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761354",
    "display" : "OPERADOR DE MAQUINA DE CORDOALHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761357",
    "display" : "OPERADOR DE URDIDEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761360",
    "display" : "PASSAMANEIRO A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761363",
    "display" : "REMETEDOR DE FIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761366",
    "display" : "PICOTADOR DE CARTOES JACQUARD",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761405",
    "display" : "ALVEJADOR (TECIDOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761410",
    "display" : "ESTAMPADOR DE TECIDO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761415",
    "display" : "OPERADOR DE CALANDRAS (TECIDOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761420",
    "display" : "OPERADOR DE CHAMUSCADEIRA DE TECIDOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761425",
    "display" : "OPERADOR DE IMPERMEABILIZADOR DE TECIDOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761430",
    "display" : "OPERADOR DE MAQUINA DE LAVAR FIOS E TECIDOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761435",
    "display" : "OPERADOR DE RAMEUSE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761805",
    "display" : "INSPETOR DE ESTAMPARIA (PRODUCAO TEXTIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761810",
    "display" : "REVISOR DE FIOS (PRODUCAO TEXTIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761815",
    "display" : "REVISOR DE TECIDOS ACABADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "761820",
    "display" : "REVISOR DE TECIDOS CRUS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762005",
    "display" : "TRABALHADOR POLIVALENTE DO CURTIMENTO DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762105",
    "display" : "CLASSIFICADOR DE PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762110",
    "display" : "DESCARNADOR DE COUROS E PELES, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762115",
    "display" : "ESTIRADOR DE COUROS E PELES (PREPARACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762120",
    "display" : "FULONEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762125",
    "display" : "RACHADOR DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762205",
    "display" : "CURTIDOR (COUROS E PELES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762210",
    "display" : "CLASSIFICADOR DE COUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762215",
    "display" : "ENXUGADOR DE COUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762220",
    "display" : "REBAIXADOR DE COUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762305",
    "display" : "ESTIRADOR DE COUROS E PELES (ACABAMENTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762310",
    "display" : "FULONEIRO NO ACABAMENTO DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762315",
    "display" : "LIXADOR DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762320",
    "display" : "MATIZADOR DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762325",
    "display" : "OPERADOR DE MAQUINAS DO ACABAMENTO DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762330",
    "display" : "PRENSADOR DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762335",
    "display" : "PALECIONADOR DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762340",
    "display" : "PREPARADOR DE COUROS CURTIDOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "762345",
    "display" : "VAQUEADOR DE COUROS E PELES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763005",
    "display" : "ALFAIATE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763010",
    "display" : "COSTUREIRA DE PECAS SOB ENCOMENDA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763015",
    "display" : "COSTUREIRA DE REPARACAO DE ROUPAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763020",
    "display" : "COSTUREIRO DE ROUPA DE COURO E PELE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763105",
    "display" : "AUXILIAR DE CORTE (PREPARACAO DA CONFECCAO DE ROUPAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763110",
    "display" : "CORTADOR DE ROUPAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763115",
    "display" : "ENFESTADOR DE ROUPAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763120",
    "display" : "RISCADOR DE ROUPAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763125",
    "display" : "AJUDANTE DE CONFECCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763205",
    "display" : "COSTUREIRO DE ROUPAS DE COURO E PELE, A MAQUINA NA CONFECCAO EM SERIE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763210",
    "display" : "COSTUREIRO NA CONFECCAO EM SERIE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763215",
    "display" : "COSTUREIRO, A MAQUINA NA CONFECCAO EM SERIE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763305",
    "display" : "ARREMATADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763310",
    "display" : "BORDADOR, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763315",
    "display" : "MARCADOR DE PECAS CONFECCIONADAS PARA BORDAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763320",
    "display" : "OPERADOR DE MAQUINA DE COSTURA DE ACABAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "763325",
    "display" : "PASSADEIRA DE PECAS CONFECCIONADAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "764005",
    "display" : "TRABALHADOR POLIVALENTE DA CONFECCAO DE CALCADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "764105",
    "display" : "CORTADOR DE CALCADOS, A MAQUINA (EXCETO SOLAS E PALMILHAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "764110",
    "display" : "CORTADOR DE SOLAS E PALMILHAS, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "764115",
    "display" : "PREPARADOR DE CALCADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "764120",
    "display" : "PREPARADOR DE SOLAS E PALMILHAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "764205",
    "display" : "COSTURADOR DE CALCADOS, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "764210",
    "display" : "MONTADOR DE CALCADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "764305",
    "display" : "ACABADOR DE CALCADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765005",
    "display" : "CONFECCIONADOR DE ARTEFATOS DE COURO (EXCETO SAPATOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765010",
    "display" : "CHAPELEIRO DE SENHORAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765015",
    "display" : "BONELEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765105",
    "display" : "CORTADOR DE ARTEFATOS DE COURO (EXCETO ROUPAS E CALCADOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765110",
    "display" : "CORTADOR DE TAPECARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765205",
    "display" : "COLCHOEIRO (CONFECCAO DE COLCHOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765215",
    "display" : "CONFECCIONADOR DE BRINQUEDOS DE PANO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765225",
    "display" : "CONFECCIONADOR DE VELAS NAUTICAS, BARRACAS E TOLDOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765230",
    "display" : "ESTOFADOR DE AVIOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765235",
    "display" : "ESTOFADOR DE MOVEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765240",
    "display" : "TAPECEIRO DE AUTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765310",
    "display" : "COSTURADOR DE ARTEFATOS DE COURO, A MAQUINA (EXCETO ROUPAS E CALCADOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765315",
    "display" : "MONTADOR DE ARTEFATOS DE COURO (EXCETO ROUPAS E CALCADOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "765405",
    "display" : "TRABALHADOR DO ACABAMENTO DE ARTEFATOS DE TECIDOS E COUROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766105",
    "display" : "COPIADOR DE CHAPA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766115",
    "display" : "GRAVADOR DE MATRIZ PARA FLEXOGRAFIA (CLICHERISTA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766120",
    "display" : "EDITOR DE TEXTO E IMAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766125",
    "display" : "MONTADOR DE FOTOLITO (ANALOGICO E DIGITAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766130",
    "display" : "GRAVADOR DE MATRIZ PARA ROTOGRAVURA (ELETROMECANICO E QUIMICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766135",
    "display" : "GRAVADOR DE MATRIZ CALCOGRAFICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766140",
    "display" : "GRAVADOR DE MATRIZ SERIGRAFICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766145",
    "display" : "OPERADOR DE SISTEMAS DE PROVA (ANALOGICO E DIGITAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766150",
    "display" : "OPERADOR DE PROCESSO DE TRATAMENTO DE IMAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766155",
    "display" : "PROGRAMADOR VISUAL GRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766205",
    "display" : "IMPRESSOR (SERIGRAFIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766210",
    "display" : "IMPRESSOR CALCOGRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766215",
    "display" : "IMPRESSOR DE OFSETE (PLANO E ROTATIVO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766220",
    "display" : "IMPRESSOR DE ROTATIVA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766225",
    "display" : "IMPRESSOR DE ROTOGRAVURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766230",
    "display" : "IMPRESSOR DIGITAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766235",
    "display" : "IMPRESSOR FLEXOGRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766240",
    "display" : "IMPRESSOR LETTERSET",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766245",
    "display" : "IMPRESSOR TAMPOGRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766250",
    "display" : "IMPRESSOR TIPOGRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766305",
    "display" : "ACABADOR DE EMBALAGENS (FLEXIVEIS E CARTOTECNICAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766310",
    "display" : "IMPRESSOR DE CORTE E VINCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766315",
    "display" : "OPERADOR DE ACABAMENTO (INDUSTRIA GRAFICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766320",
    "display" : "OPERADOR DE GUILHOTINA (CORTE DE PAPEL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766325",
    "display" : "PREPARADOR DE MATRIZES DE CORTE E VINCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766405",
    "display" : "LABORATORISTA FOTOGRAFICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766410",
    "display" : "REVELADOR DE FILMES FOTOGRAFICOS, EM PRETO E BRANCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766415",
    "display" : "REVELADOR DE FILMES FOTOGRAFICOS, EM CORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "766420",
    "display" : "AUXILIAR DE RADIOLOGIA (REVELACAO FOTOGRAFICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768105",
    "display" : "TECELAO (TEAR MANUAL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768110",
    "display" : "TECELAO DE TAPETES, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768115",
    "display" : "TRICOTEIRO, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768120",
    "display" : "REDEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768125",
    "display" : "CHAPELEIRO (CHAPEUS DE PALHA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768130",
    "display" : "CROCHETEIRO, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768205",
    "display" : "BORDADOR, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768210",
    "display" : "CERZIDOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768305",
    "display" : "ARTIFICE DO COURO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768310",
    "display" : "CORTADOR DE CALCADOS, A MAO (EXCETO SOLAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768315",
    "display" : "COSTURADOR DE ARTEFATOS DE COURO, A MAO (EXCETO ROUPAS E CALCADOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768320",
    "display" : "SAPATEIRO (CALCADOS SOB MEDIDA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768325",
    "display" : "SELEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768605",
    "display" : "TIPOGRAFO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768610",
    "display" : "LINOTIPISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768615",
    "display" : "MONOTIPISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768620",
    "display" : "PAGINADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768625",
    "display" : "PINTOR DE LETREIROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768630",
    "display" : "CONFECCIONADOR DE CARIMBOS DE BORRACHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768705",
    "display" : "GRAVADOR, A MAO (ENCADERNACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "768710",
    "display" : "RESTAURADOR DE LIVROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "770105",
    "display" : "MESTRE (INDUSTRIA DE MADEIRA E MOBILIARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "770110",
    "display" : "MESTRE CARPINTEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "771105",
    "display" : "MARCENEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "771110",
    "display" : "MODELADOR DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "771115",
    "display" : "MAQUETISTA NA MARCENARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "771120",
    "display" : "TANOEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "772105",
    "display" : "CLASSIFICADOR DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "772110",
    "display" : "IMPREGNADOR DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "772115",
    "display" : "SECADOR DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773105",
    "display" : "CORTADOR DE LAMINADOS DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773110",
    "display" : "OPERADOR DE SERRAS NO DESDOBRAMENTO DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773115",
    "display" : "SERRADOR DE BORDAS NO DESDOBRAMENTO DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773120",
    "display" : "SERRADOR DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773125",
    "display" : "SERRADOR DE MADEIRA (SERRA CIRCULAR MULTIPLA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773130",
    "display" : "SERRADOR DE MADEIRA (SERRA DE FITA MULTIPLA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773205",
    "display" : "OPERADOR DE MAQUINA INTERCALADORA E PLACAS (COMPENSADOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773210",
    "display" : "PRENSISTA DE AGLOMERADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773215",
    "display" : "PRENSISTA DE COMPENSADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773220",
    "display" : "PREPARADOR DE AGLOMERANTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773305",
    "display" : "OPERADOR DE DESEMPENADEIRA NA USINAGEM CONVENCIONAL DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773310",
    "display" : "OPERADOR DE ENTALHADEIRA (USINAGEM DE MADEIRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773315",
    "display" : "OPERADOR DE FRESADORA (USINAGEM DE MADEIRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773320",
    "display" : "OPERADOR DE LIXADEIRA (USINAGEM DE MADEIRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773325",
    "display" : "OPERADOR DE MAQUINA DE USINAGEM MADEIRA, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773330",
    "display" : "OPERADOR DE MOLDURADORA (USINAGEM DE MADEIRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773335",
    "display" : "OPERADOR DE PLAINA DESENGROSSADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773340",
    "display" : "OPERADOR DE SERRAS (USINAGEM DE MADEIRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773345",
    "display" : "OPERADOR DE TORNO AUTOMATICO (USINAGEM DE MADEIRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773350",
    "display" : "OPERADOR DE TUPIA (USINAGEM DE MADEIRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773355",
    "display" : "TORNEIRO NA USINAGEM CONVENCIONAL DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773405",
    "display" : "OPERADOR DE MAQUINA BORDATRIZ",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773410",
    "display" : "OPERADOR DE MAQUINA DE CORTINA DAGUA (PRODUCAO DE MOVEIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773415",
    "display" : "OPERADOR DE MAQUINA DE USINAGEM DE MADEIRA (PRODUCAO EM SERIE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773420",
    "display" : "OPERADOR DE PRENSA DE ALTA FREQENCIA NA USINAGEM DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773505",
    "display" : "OPERADOR DE CENTRO DE USINAGEM DE MADEIRA (CNC)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "773510",
    "display" : "OPERADOR DE MAQUINAS DE USINAR MADEIRA (CNC)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "774105",
    "display" : "MONTADOR DE MOVEIS E ARTEFATOS DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "775105",
    "display" : "ENTALHADOR DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "775110",
    "display" : "FOLHEADOR DE MOVEIS DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "775115",
    "display" : "LUSTRADOR DE PECAS DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "775120",
    "display" : "MARCHETEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "776405",
    "display" : "CESTEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "776410",
    "display" : "CONFECCIONADOR DE ESCOVAS, PINCEIS E PRODUTOS SIMILARES (A MAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "776415",
    "display" : "CONFECCIONADOR DE ESCOVAS, PINCEIS E PRODUTOS SIMILARES (A MAQUINA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "776420",
    "display" : "CONFECCIONADOR DE MOVEIS DE VIME, JUNCO E BAMBU",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "776425",
    "display" : "ESTEIREIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "776430",
    "display" : "VASSOUREIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "777105",
    "display" : "CARPINTEIRO NAVAL (CONSTRUCAO DE PEQUENAS EMBARCACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "777110",
    "display" : "CARPINTEIRO NAVAL (EMBARCACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "777115",
    "display" : "CARPINTEIRO NAVAL (ESTALEIROS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "777205",
    "display" : "CARPINTEIRO DE CARRETAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "777210",
    "display" : "CARPINTEIRO DE CARROCERIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "780105",
    "display" : "SUPERVISOR DE EMBALAGEM E ETIQUETAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "781105",
    "display" : "CONDUTOR DE PROCESSOS ROBOTIZADOS DE PINTURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "781110",
    "display" : "CONDUTOR DE PROCESSOS ROBOTIZADOS DE SOLDAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "781305",
    "display" : "OPERADOR DE VEICULOS SUBAQUATICOS CONTROLADOS REMOTAMENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "781705",
    "display" : "MERGULHADOR PROFISSIONAL (RASO E PROFUNDO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782105",
    "display" : "OPERADOR DE DRAGA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782110",
    "display" : "OPERADOR DE GUINDASTE (FIXO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782115",
    "display" : "OPERADOR DE GUINDASTE MOVEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782120",
    "display" : "OPERADOR DE MAQUINA RODOFERROVIARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782125",
    "display" : "OPERADOR DE MONTACARGAS (CONSTRUCAO CIVIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782130",
    "display" : "OPERADOR DE PONTE ROLANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782135",
    "display" : "OPERADOR DE PORTICO ROLANTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782140",
    "display" : "OPERADOR DE TALHA ELETRICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782145",
    "display" : "SINALEIRO (PONTEROLANTE)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782205",
    "display" : "GUINCHEIRO (CONSTRUCAO CIVIL)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782210",
    "display" : "OPERADOR DE DOCAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782220",
    "display" : "OPERADOR DE EMPILHADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782305",
    "display" : "MOTORISTA DE CARRO DE PASSEIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782310",
    "display" : "MOTORISTA DE FURGAO OU VEICULO SIMILAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782315",
    "display" : "MOTORISTA DE TAXI",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782320",
    "display" : "CONDUTOR DE AMBULANCIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782405",
    "display" : "MOTORISTA DE ONIBUS RODOVIARIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782410",
    "display" : "MOTORISTA DE ONIBUS URBANO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782415",
    "display" : "MOTORISTA DE TROLEBUS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782505",
    "display" : "CAMINHONEIRO AUTONOMO (ROTAS REGIONAIS E INTERNACIONAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782510",
    "display" : "MOTORISTA DE CAMINHAO (ROTAS REGIONAIS E INTERNACIONAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782515",
    "display" : "MOTORISTA OPERACIONAL DE GUINCHO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782605",
    "display" : "OPERADOR DE TREM DE METRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782610",
    "display" : "MAQUINISTA DE TREM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782615",
    "display" : "MAQUINISTA DE TREM METROPOLITANO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782620",
    "display" : "MOTORNEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782625",
    "display" : "AUXILIAR DE MAQUINISTA DE TREM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782630",
    "display" : "OPERADOR DE TELEFERICO (PASSAGEIROS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782705",
    "display" : "MARINHEIRO DE CONVES (MARITIMO E FLUVIARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782710",
    "display" : "MARINHEIRO DE MAQUINAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782715",
    "display" : "MOCO DE CONVES (MARITIMO E FLUVIARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782720",
    "display" : "MOCO DE MAQUINAS (MARITIMO E FLUVIARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782725",
    "display" : "MARINHEIRO DE ESPORTE E RECREIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782730",
    "display" : "MARINHEIRO AUXILIAR DE CONVES (MARITIMO E AQUAVIARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782735",
    "display" : "MARINHEIRO AUXILIAR DE MAQUINAS (MARITIMO E AQUAVIARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782805",
    "display" : "CONDUTOR DE VEICULOS DE TRACAO ANIMAL (RUAS E ESTRADAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782810",
    "display" : "TROPEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782815",
    "display" : "BOIADEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "782820",
    "display" : "CONDUTOR DE VEICULOS A PEDAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783105",
    "display" : "AGENTE DE PATIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783110",
    "display" : "MANOBRADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783205",
    "display" : "CARREGADOR (AERONAVES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783210",
    "display" : "CARREGADOR (ARMAZEM)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783215",
    "display" : "CARREGADOR (VEICULOS DE TRANSPORTES TERRESTRES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783220",
    "display" : "ESTIVADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783225",
    "display" : "AJUDANTE DE MOTORISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783230",
    "display" : "BLOQUEIRO (TRABALHADOR PORTUARIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "784105",
    "display" : "EMBALADOR, A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "784110",
    "display" : "EMBALADOR, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "784115",
    "display" : "OPERADOR DE MAQUINA DE ETIQUETAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "784120",
    "display" : "OPERADOR DE MAQUINA DE ENVASAR LIQUIDOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "784125",
    "display" : "OPERADOR DE PRENSA DE ENFARDAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "784205",
    "display" : "ALIMENTADOR DE LINHA DE PRODUCAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791105",
    "display" : "ARTESAO BORDADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791110",
    "display" : "ARTESAO CERAMISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791115",
    "display" : "ARTESAO COM MATERIAL RECICLAVEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791120",
    "display" : "ARTESAO CONFECCIONADOR DE BIOJOIAS E ECOJOIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791125",
    "display" : "ARTESAO DO COURO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791130",
    "display" : "ARTESAO ESCULTOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791135",
    "display" : "ARTESAO MOVELEIRO (EXCETO RECICLADO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791140",
    "display" : "ARTESAO TECELAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791145",
    "display" : "ARTESAO TRANCADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791150",
    "display" : "ARTESAO CROCHETEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791155",
    "display" : "ARTESAO TRICOTEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "791160",
    "display" : "ARTESAO RENDEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "810105",
    "display" : "MESTRE (INDUSTRIA PETROQUIMICA E CARBOQUIMICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "810110",
    "display" : "MESTRE DE PRODUCAO QUIMICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "810205",
    "display" : "MESTRE (INDUSTRIA DE BORRACHA E PLASTICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "810305",
    "display" : "MESTRE DE PRODUCAO FARMACEUTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811005",
    "display" : "OPERADOR DE PROCESSOS QUIMICOS E PETROQUIMICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811010",
    "display" : "OPERADOR DE SALA DE CONTROLE DE INSTALACOES QUIMICAS, PETROQUIMICAS E AFINS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811105",
    "display" : "MOLEIRO (TRATAMENTOS QUIMICOS E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811110",
    "display" : "OPERADOR DE MAQUINA MISTURADEIRA (TRATAMENTOS QUIMICOS E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811115",
    "display" : "OPERADOR DE BRITADEIRA (TRATAMENTOS QUIMICOS E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811120",
    "display" : "OPERADOR DE CONCENTRACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811125",
    "display" : "TRABALHADOR DA FABRICACAO DE RESINAS E VERNIZES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811130",
    "display" : "TRABALHADOR DE FABRICACAO DE TINTAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811205",
    "display" : "OPERADOR DE CALCINACAO (TRATAMENTO QUIMICO E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811215",
    "display" : "OPERADOR DE TRATAMENTO QUIMICO DE MATERIAIS RADIOATIVOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811305",
    "display" : "OPERADOR DE CENTRIFUGADORA (TRATAMENTOS QUIMICOS E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811310",
    "display" : "OPERADOR DE EXPLORACAO DE PETROLEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811315",
    "display" : "OPERADOR DE FILTRO DE SECAGEM (MINERACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811320",
    "display" : "OPERADOR DE FILTRO DE TAMBOR ROTATIVO (TRATAMENTOS QUIMICOS E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811325",
    "display" : "OPERADOR DE FILTROESTEIRA (MINERACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811330",
    "display" : "OPERADOR DE FILTROPRENSA (TRATAMENTOS QUIMICOS E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811335",
    "display" : "OPERADOR DE FILTROS DE PARAFINA (TRATAMENTOS QUIMICOS E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811405",
    "display" : "DESTILADOR DE MADEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811410",
    "display" : "DESTILADOR DE PRODUTOS QUIMICOS (EXCETO PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811415",
    "display" : "OPERADOR DE ALAMBIQUE DE FUNCIONAMENTO CONTINUO (PRODUTOS QUIMICOS, EXCETO PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811420",
    "display" : "OPERADOR DE APARELHO DE REACAO E CONVERSAO (PRODUTOS QUIMICOS, EXCETO PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811425",
    "display" : "OPERADOR DE EQUIPAMENTO DE DESTILACAO DE ALCOOL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811430",
    "display" : "OPERADOR DE EVAPORADOR NA DESTILACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811505",
    "display" : "OPERADOR DE PAINEL DE CONTROLE (REFINACAO DE PETROLEO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811510",
    "display" : "OPERADOR DE TRANSFERENCIA E ESTOCAGEM  NA REFINACAO DO PETROLEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811605",
    "display" : "OPERADOR DE BRITADOR DE COQUE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811610",
    "display" : "OPERADOR DE CARRO DE APAGAMENTO E COQUE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811615",
    "display" : "OPERADOR DE DESTILACAO E SUBPRODUTOS DE COQUE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811620",
    "display" : "OPERADOR DE ENFORNAMENTO E DESENFORNAMENTO DE COQUE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811625",
    "display" : "OPERADOR DE EXAUSTOR (COQUERIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811630",
    "display" : "OPERADOR DE PAINEL DE CONTROLE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811635",
    "display" : "OPERADOR DE PRESERVACAO E CONTROLE TERMICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811640",
    "display" : "OPERADOR DE REATOR DE COQUE DE PETROLEO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811645",
    "display" : "OPERADOR DE REFRIGERACAO (COQUERIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811650",
    "display" : "OPERADOR DE SISTEMA DE REVERSAO (COQUERIA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811705",
    "display" : "BAMBURISTA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811710",
    "display" : "CALANDRISTA DE BORRACHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811715",
    "display" : "CONFECCIONADOR DE PNEUMATICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811725",
    "display" : "CONFECCIONADOR DE VELAS POR IMERSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811735",
    "display" : "CONFECCIONADOR DE VELAS POR MOLDAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811745",
    "display" : "LAMINADOR DE PLASTICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811750",
    "display" : "MOLDADOR DE BORRACHA POR COMPRESSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811760",
    "display" : "MOLDADOR DE PLASTICO POR COMPRESSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811770",
    "display" : "MOLDADOR DE PLASTICO POR INJECAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811775",
    "display" : "TREFILADOR DE BORRACHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811805",
    "display" : "OPERADOR DE MAQUINA DE PRODUTOS FARMACEUTICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811810",
    "display" : "DRAGEADOR (MEDICAMENTOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811815",
    "display" : "OPERADOR DE MAQUINA DE FABRICACAO DE COSMETICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "811820",
    "display" : "OPERADOR DE MAQUINA DE FABRICACAO DE PRODUTOS DE HIGIENE E LIMPEZA (SABAO, SABONETE, DETERGENTE, ABSORVENTE, FRALDAS COTONETES E OUTROS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "812105",
    "display" : "PIROTECNICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "812110",
    "display" : "TRABALHADOR DA FABRICACAO DE MUNICAO E EXPLOSIVOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "813105",
    "display" : "CILINDRISTA (PETROQUIMICA E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "813110",
    "display" : "OPERADOR DE CALANDRA (QUIMICA, PETROQUIMICA E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "813115",
    "display" : "OPERADOR DE EXTRUSORA (QUIMICA, PETROQUIMICA E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "813120",
    "display" : "OPERADOR DE PROCESSO (QUIMICA, PETROQUIMICA E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "813125",
    "display" : "OPERADOR DE PRODUCAO (QUIMICA, PETROQUIMICA E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "813130",
    "display" : "TECNICO DE OPERACAO (QUIMICA, PETROQUIMICA E AFINS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "818105",
    "display" : "ASSISTENTE DE LABORATORIO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "818110",
    "display" : "AUXILIAR DE LABORATORIO DE ANALISES FISICOQUIMICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "820105",
    "display" : "MESTRE DE SIDERURGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "820110",
    "display" : "MESTRE DE ACIARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "820115",
    "display" : "MESTRE DE ALTOFORNO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "820120",
    "display" : "MESTRE DE FORNO ELETRICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "820125",
    "display" : "MESTRE DE LAMINACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "820205",
    "display" : "SUPERVISOR DE FABRICACAO DE PRODUTOS CERAMICOS, PORCELANATOS E AFINS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "820210",
    "display" : "SUPERVISOR DE FABRICACAO DE PRODUTOS DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821105",
    "display" : "OPERADOR DE CENTRO DE CONTROLE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821110",
    "display" : "OPERADOR DE MAQUINA DE SINTERIZAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821205",
    "display" : "FORNEIRO E OPERADOR (ALTOFORNO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821210",
    "display" : "FORNEIRO E OPERADOR (CONVERSOR A OXIGENIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821215",
    "display" : "FORNEIRO E OPERADOR (FORNO ELETRICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821220",
    "display" : "FORNEIRO E OPERADOR (REFINO DE METAIS NAOFERROSOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821225",
    "display" : "FORNEIRO E OPERADOR DE FORNO DE REDUCAO DIRETA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821230",
    "display" : "OPERADOR DE ACIARIA (BASCULAMENTO DE CONVERTEDOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821235",
    "display" : "OPERADOR DE ACIARIA (DESSULFURACAO DE GUSA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821240",
    "display" : "OPERADOR DE ACIARIA (RECEBIMENTO DE GUSA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821245",
    "display" : "OPERADOR DE AREA DE CORRIDA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821250",
    "display" : "OPERADOR DE DESGASEIFICACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821255",
    "display" : "SOPRADOR DE CONVERTEDOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821305",
    "display" : "OPERADOR DE LAMINADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821310",
    "display" : "OPERADOR DE LAMINADOR DE BARRAS A FRIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821315",
    "display" : "OPERADOR DE LAMINADOR DE BARRAS A QUENTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821320",
    "display" : "OPERADOR DE LAMINADOR DE METAIS NAOFERROSOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821325",
    "display" : "OPERADOR DE LAMINADOR DE TUBOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821330",
    "display" : "OPERADOR DE MONTAGEM DE CILINDROS E MANCAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821335",
    "display" : "RECUPERADOR DE GUIAS E CILINDROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821405",
    "display" : "ENCARREGADO DE ACABAMENTO DE CHAPAS E METAIS (TEMPERA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821410",
    "display" : "ESCARFADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821415",
    "display" : "MARCADOR DE PRODUTOS (SIDERURGICO E METALURGICO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821420",
    "display" : "OPERADOR DE BOBINADEIRA DE TIRAS A QUENTE, NO ACABAMENTO DE CHAPAS E METAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821425",
    "display" : "OPERADOR DE CABINE DE LAMINACAO (FIOMAQUINA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821430",
    "display" : "OPERADOR DE ESCORIA E SUCATA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821435",
    "display" : "OPERADOR DE JATO ABRASIVO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821440",
    "display" : "OPERADOR DE TESOURA MECANICA E MAQUINA DE CORTE, NO ACABAMENTO DE CHAPAS E METAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821445",
    "display" : "PREPARADOR DE SUCATA E APARAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "821450",
    "display" : "REBARBADOR DE METAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "822105",
    "display" : "FORNEIRO DE CUBILO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "822110",
    "display" : "FORNEIRO DE FORNOPOCO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "822115",
    "display" : "FORNEIRO DE FUNDICAO (FORNO DE REDUCAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "822120",
    "display" : "FORNEIRO DE REAQUECIMENTO E TRATAMENTO TERMICO NA METALURGIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "822125",
    "display" : "FORNEIRO DE REVERBERO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823105",
    "display" : "PREPARADOR DE MASSA (FABRICACAO DE ABRASIVOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823110",
    "display" : "PREPARADOR DE MASSA (FABRICACAO DE VIDRO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823115",
    "display" : "PREPARADOR DE MASSA DE ARGILA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823120",
    "display" : "PREPARADOR DE BARBOTINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823125",
    "display" : "PREPARADOR DE ESMALTES (CERAMICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823130",
    "display" : "PREPARADOR DE ADITIVOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823135",
    "display" : "OPERADOR DE ATOMIZADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823210",
    "display" : "EXTRUSOR DE FIOS OU FIBRAS DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823215",
    "display" : "FORNEIRO NA FUNDICAO DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823220",
    "display" : "FORNEIRO NO RECOZIMENTO DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823230",
    "display" : "MOLDADOR DE ABRASIVOS NA FABRICACAO DE CERAMICA, VIDRO E PORCELANA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823235",
    "display" : "OPERADOR DE BANHO METALICO DE VIDRO POR FLUTUACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823240",
    "display" : "OPERADOR DE MAQUINA DE SOPRAR VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823245",
    "display" : "OPERADOR DE MAQUINA EXTRUSORA DE VARETAS E TUBOS DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823250",
    "display" : "OPERADOR DE PRENSA DE MOLDAR VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823255",
    "display" : "TEMPERADOR DE VIDRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823265",
    "display" : "TRABALHADOR NA FABRICACAO DE PRODUTOS ABRASIVOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823305",
    "display" : "CLASSIFICADOR E EMPILHADOR DE TIJOLOS REFRATARIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823315",
    "display" : "FORNEIRO (MATERIAIS DE CONSTRUCAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823320",
    "display" : "TRABALHADOR DA ELABORACAO DE PREFABRICADOS (CIMENTO AMIANTO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823325",
    "display" : "TRABALHADOR DA ELABORACAO DE PREFABRICADOS (CONCRETO ARMADO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "823330",
    "display" : "TRABALHADOR DA FABRICACAO DE PEDRAS ARTIFICIAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "828105",
    "display" : "OLEIRO (FABRICACAO DE TELHAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "828110",
    "display" : "OLEIRO (FABRICACAO DE TIJOLOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "830105",
    "display" : "MESTRE (INDUSTRIA DE CELULOSE, PAPEL E PAPELAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "831105",
    "display" : "CILINDREIRO NA PREPARACAO DE PASTA PARA FABRICACAO DE PAPEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "831110",
    "display" : "OPERADOR DE BRANQUEADOR DE PASTA PARA FABRICACAO DE PAPEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "831115",
    "display" : "OPERADOR DE DIGESTOR DE PASTA PARA FABRICACAO DE PAPEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "831120",
    "display" : "OPERADOR DE LAVAGEM E DEPURACAO DE PASTA PARA FABRICACAO DE PAPEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "831125",
    "display" : "OPERADOR DE MAQUINA DE SECAR CELULOSE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "832105",
    "display" : "CALANDRISTA DE PAPEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "832110",
    "display" : "OPERADOR DE CORTADEIRA DE PAPEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "832115",
    "display" : "OPERADOR DE MAQUINA DE FABRICAR PAPEL (FASE UMIDA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "832120",
    "display" : "OPERADOR DE MAQUINA DE FABRICAR PAPEL (FASE SECA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "832125",
    "display" : "OPERADOR DE MAQUINA DE FABRICAR PAPEL E PAPELAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "832135",
    "display" : "OPERADOR DE REBOBINADEIRA NA FABRICACAO DE PAPEL E PAPELAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "833105",
    "display" : "CARTONAGEIRO, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "833110",
    "display" : "CONFECCIONADOR DE BOLSAS, SACOS E SACOLAS E PAPEL, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "833115",
    "display" : "CONFECCIONADOR DE SACOS DE CELOFANE, A MAQUINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "833120",
    "display" : "OPERADOR DE MAQUINA DE CORTAR E DOBRAR PAPELAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "833125",
    "display" : "OPERADOR DE PRENSA DE EMBUTIR PAPELAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "833205",
    "display" : "CARTONAGEIRO, A MAO (CAIXAS DE PAPELAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "840105",
    "display" : "SUPERVISOR DE PRODUCAO DA INDUSTRIA ALIMENTICIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "840110",
    "display" : "SUPERVISOR DA INDUSTRIA DE BEBIDAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "840115",
    "display" : "SUPERVISOR DA INDUSTRIA DE FUMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "840120",
    "display" : "CHEFE DE CONFEITARIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841105",
    "display" : "MOLEIRO DE CEREAIS (EXCETO ARROZ)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841110",
    "display" : "MOLEIRO DE ESPECIARIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841115",
    "display" : "OPERADOR DE PROCESSO DE MOAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841205",
    "display" : "MOEDOR DE SAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841210",
    "display" : "REFINADOR DE SAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841305",
    "display" : "OPERADOR DE CRISTALIZACAO NA REFINACAO DE ACUCAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841310",
    "display" : "OPERADOR DE EQUIPAMENTOS DE REFINACAO DE ACUCAR (PROCESSO CONTINUO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841315",
    "display" : "OPERADOR DE MOENDA NA FABRICACAO DE ACUCAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841320",
    "display" : "OPERADOR DE TRATAMENTO DE CALDA NA REFINACAO DE ACUCAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841408",
    "display" : "COZINHADOR (CONSERVACAO DE ALIMENTOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841416",
    "display" : "COZINHADOR DE CARNES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841420",
    "display" : "COZINHADOR DE FRUTAS E LEGUMES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841428",
    "display" : "COZINHADOR DE PESCADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841432",
    "display" : "DESIDRATADOR DE ALIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841440",
    "display" : "ESTERILIZADOR DE ALIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841444",
    "display" : "HIDROGENADOR DE OLEOS E GORDURAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841448",
    "display" : "LAGAREIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841456",
    "display" : "OPERADOR DE CAMARAS FRIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841460",
    "display" : "OPERADOR DE PREPARACAO DE GRAOS VEGETAIS (OLEOS E GORDURAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841464",
    "display" : "PRENSADOR DE FRUTAS (EXCETO OLEAGINOSAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841468",
    "display" : "PREPARADOR DE RACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841472",
    "display" : "REFINADOR DE OLEO E GORDURA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841476",
    "display" : "TRABALHADOR DE FABRICACAO DE MARGARINA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841484",
    "display" : "TRABALHADOR DE PREPARACAO DE PESCADOS (LIMPEZA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841505",
    "display" : "TRABALHADOR DE TRATAMENTO DO LEITE E FABRICACAO DE LATICINIOS E AFINS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841605",
    "display" : "MISTURADOR DE CAFE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841610",
    "display" : "TORRADOR DE CAFE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841615",
    "display" : "MOEDOR DE CAFE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841620",
    "display" : "OPERADOR DE EXTRACAO DE CAFE SOLUVEL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841625",
    "display" : "TORRADOR DE CACAU",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841630",
    "display" : "MISTURADOR DE CHA OU MATE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841705",
    "display" : "ALAMBIQUEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841710",
    "display" : "FILTRADOR DE CERVEJA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841715",
    "display" : "FERMENTADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841720",
    "display" : "TRABALHADOR DE FABRICACAO DE VINHOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841725",
    "display" : "MALTEIRO (GERMINACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841730",
    "display" : "COZINHADOR DE MALTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841735",
    "display" : "DESSECADOR DE MALTE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841740",
    "display" : "VINAGREIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841745",
    "display" : "XAROPEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841805",
    "display" : "OPERADOR DE FORNO (FABRICACAO DE PAES, BISCOITOS E SIMILARES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841810",
    "display" : "OPERADOR DE MAQUINAS DE FABRICACAO DE DOCES, SALGADOS E MASSAS ALIMENTICIAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "841815",
    "display" : "OPERADOR DE MAQUINAS DE FABRICACAO DE CHOCOLATES E ACHOCOLATADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842105",
    "display" : "PREPARADOR DE MELADO E ESSENCIA DE FUMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842110",
    "display" : "PROCESSADOR DE FUMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842115",
    "display" : "CLASSIFICADOR DE FUMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842120",
    "display" : "AUXILIAR DE PROCESSAMENTO DE FUMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842125",
    "display" : "OPERADOR DE MAQUINA DE FABRICAR CIGARROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842135",
    "display" : "OPERADOR DE MAQUINA DE PREPARACAO DE MATERIA PRIMA PARA PRODUCAO DE CIGARROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842205",
    "display" : "PREPARADOR DE FUMO NA FABRICACAO DE CHARUTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842210",
    "display" : "OPERADOR DE MAQUINA DE FABRICAR CHARUTOS E CIGARRILHAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842215",
    "display" : "CLASSIFICADOR DE CHARUTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842220",
    "display" : "CORTADOR DE CHARUTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842225",
    "display" : "CELOFANISTA NA FABRICACAO DE CHARUTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842230",
    "display" : "CHARUTEIRO A MAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "842235",
    "display" : "DEGUSTADOR DE CHARUTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848105",
    "display" : "DEFUMADOR DE CARNES E PESCADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848110",
    "display" : "SALGADOR DE ALIMENTOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848115",
    "display" : "SALSICHEIRO (FABRICACAO DE LINGICA, SALSICHA E PRODUTOS SIMILARES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848205",
    "display" : "PASTEURIZADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848210",
    "display" : "QUEIJEIRO NA FABRICACAO DE LATICINIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848215",
    "display" : "MANTEIGUEIRO NA FABRICACAO DE LATICINIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848305",
    "display" : "PADEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848310",
    "display" : "CONFEITEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848315",
    "display" : "MASSEIRO (MASSAS ALIMENTICIAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848325",
    "display" : "TRABALHADOR DE FABRICACAO DE SORVETE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848405",
    "display" : "DEGUSTADOR DE CAFE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848410",
    "display" : "DEGUSTADOR DE CHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848415",
    "display" : "DEGUSTADOR DE DERIVADOS DE CACAU",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848420",
    "display" : "DEGUSTADOR DE VINHOS OU LICORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848425",
    "display" : "CLASSIFICADOR DE GRAOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848505",
    "display" : "ABATEDOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848510",
    "display" : "ACOUGUEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848515",
    "display" : "DESOSSADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848520",
    "display" : "MAGAREFE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848525",
    "display" : "RETALHADOR DE CARNE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "848605",
    "display" : "TRABALHADOR DO BENEFICIAMENTO DE FUMO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "860105",
    "display" : "SUPERVISOR DE MANUTENCAO ELETROMECANICA (UTILIDADES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "860110",
    "display" : "SUPERVISOR DE OPERACAO DE FLUIDOS (DISTRIBUICAO, CAPTACAO, TRATAMENTO DE AGUA, GASES, VAPOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "860115",
    "display" : "SUPERVISOR DE OPERACAO ELETRICA (GERACAO, TRANSMISSAO E DISTRIBUICAO DE ENERGIA ELETRICA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "861105",
    "display" : "OPERADOR DE CENTRAL HIDRELETRICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "861110",
    "display" : "OPERADOR DE QUADRO DE DISTRIBUICAO DE ENERGIA ELETRICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "861115",
    "display" : "OPERADOR DE CENTRAL TERMOELETRICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "861120",
    "display" : "OPERADOR DE REATOR NUCLEAR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "861205",
    "display" : "OPERADOR DE SUBESTACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862105",
    "display" : "FOGUISTA (LOCOMOTIVAS A VAPOR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862110",
    "display" : "MAQUINISTA DE EMBARCACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862115",
    "display" : "OPERADOR DE BATERIA DE GAS DE HULHA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862120",
    "display" : "OPERADOR DE CALDEIRA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862130",
    "display" : "OPERADOR DE COMPRESSOR DE AR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862140",
    "display" : "OPERADOR DE ESTACAO DE BOMBEAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862150",
    "display" : "OPERADOR DE MAQUINAS FIXAS, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862155",
    "display" : "OPERADOR DE UTILIDADE (PRODUCAO E DISTRIBUICAO DE VAPOR, GAS, OLEO, COMBUSTIVEL, ENERGIA, OXIGENIO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862160",
    "display" : "OPERADOR DE ABASTECIMENTO DE COMBUSTIVEL DE AERONAVE",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : true
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862205",
    "display" : "OPERADOR DE ESTACAO DE CAPTACAO, TRATAMENTO E DISTRIBUICAO DE AGUA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862305",
    "display" : "OPERADOR DE ESTACAO DE TRATAMENTO DE AGUA E EFLUENTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862310",
    "display" : "OPERADOR DE FORNO DE INCINERACAO NO TRATAMENTO DE AGUA, EFLUENTES E RESIDUOS INDUSTRIAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862405",
    "display" : "OPERADOR DE INSTALACAO DE EXTRACAO, PROCESSAMENTO, ENVASAMENTO E DISTRIBUICAO DE GASES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862505",
    "display" : "OPERADOR DE INSTALACAO DE REFRIGERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862510",
    "display" : "OPERADOR DE REFRIGERACAO COM AMONIA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "862515",
    "display" : "OPERADOR DE INSTALACAO DE ARCONDICIONADO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910105",
    "display" : "ENCARREGADO DE MANUTENCAO MECANICA DE SISTEMAS OPERACIONAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910110",
    "display" : "SUPERVISOR DE MANUTENCAO DE APARELHOS TERMICOS, DE CLIMATIZACAO E DE REFRIGERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910115",
    "display" : "SUPERVISOR DE MANUTENCAO DE BOMBAS, MOTORES, COMPRESSORES E EQUIPAMENTOS DE TRANSMISSAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910120",
    "display" : "SUPERVISOR DE MANUTENCAO DE MAQUINAS GRAFICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910125",
    "display" : "SUPERVISOR DE MANUTENCAO DE MAQUINAS INDUSTRIAIS TEXTEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910130",
    "display" : "SUPERVISOR DE MANUTENCAO DE MAQUINAS OPERATRIZES E DE USINAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910205",
    "display" : "SUPERVISOR DA MANUTENCAO E REPARACAO DE VEICULOS LEVES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910210",
    "display" : "SUPERVISOR DA MANUTENCAO E REPARACAO DE VEICULOS PESADOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910905",
    "display" : "SUPERVISOR DE REPAROS LINHAS FERREAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "910910",
    "display" : "SUPERVISOR DE MANUTENCAO DE VIAS FERREAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911105",
    "display" : "MECANICO DE MANUTENCAO DE BOMBA INJETORA (EXCETO DE VEICULOS AUTOMOTORES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911110",
    "display" : "MECANICO DE MANUTENCAO DE BOMBAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911115",
    "display" : "MECANICO DE MANUTENCAO DE COMPRESSORES DE AR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911120",
    "display" : "MECANICO DE MANUTENCAO DE MOTORES DIESEL (EXCETO DE VEICULOS AUTOMOTORES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911125",
    "display" : "MECANICO DE MANUTENCAO DE REDUTORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911130",
    "display" : "MECANICO DE MANUTENCAO DE TURBINAS (EXCETO DE AERONAVES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911135",
    "display" : "MECANICO DE MANUTENCAO DE TURBOCOMPRESSORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911205",
    "display" : "MECANICO DE MANUTENCAO E INSTALACAO DE APARELHOS DE CLIMATIZACAO E REFRIGERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911305",
    "display" : "MECANICO DE MANUTENCAO DE MAQUINAS, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911310",
    "display" : "MECANICO DE MANUTENCAO DE MAQUINAS GRAFICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911315",
    "display" : "MECANICO DE MANUTENCAO DE MAQUINAS OPERATRIZES (LAVRA DE MADEIRA)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911320",
    "display" : "MECANICO DE MANUTENCAO DE MAQUINAS TEXTEIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "911325",
    "display" : "MECANICO DE MANUTENCAO DE MAQUINASFERRAMENTAS (USINAGEM DE METAIS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "913105",
    "display" : "MECANICO DE MANUTENCAO DE APARELHOS DE LEVANTAMENTO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "913110",
    "display" : "MECANICO DE MANUTENCAO DE EQUIPAMENTO DE MINERACAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "913115",
    "display" : "MECANICO DE MANUTENCAO DE MAQUINAS AGRICOLAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "913120",
    "display" : "MECANICO DE MANUTENCAO DE MAQUINAS DE CONSTRUCAO E TERRAPLENAGEM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "914105",
    "display" : "MECANICO DE MANUTENCAO DE AERONAVES, EM GERAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "914110",
    "display" : "MECANICO DE MANUTENCAO DE SISTEMA HIDRAULICO DE AERONAVES (SERVICOS DE PISTA E HANGAR)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "914205",
    "display" : "MECANICO DE MANUTENCAO DE MOTORES E EQUIPAMENTOS NAVAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "914305",
    "display" : "MECANICO DE MANUTENCAO DE VEICULOS FERROVIARIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "914405",
    "display" : "MECANICO DE MANUTENCAO DE AUTOMOVEIS, MOTOCICLETAS E VEICULOS SIMILARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "914410",
    "display" : "MECANICO DE MANUTENCAO DE EMPILHADEIRAS E OUTROS VEICULOS DE CARGAS LEVES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "914415",
    "display" : "MECANICO DE MANUTENCAO DE MOTOCICLETAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "914420",
    "display" : "MECANICO DE MANUTENCAO DE TRATORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "914425",
    "display" : "MECANICO DE VEICULOS AUTOMOTORES A DIESEL (EXCETO TRATORES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "915105",
    "display" : "TECNICO EM MANUTENCAO DE INSTRUMENTOS DE MEDICAO E PRECISAO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "915110",
    "display" : "TECNICO EM MANUTENCAO DE HIDROMETROS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "915115",
    "display" : "TECNICO EM MANUTENCAO DE BALANCAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "915205",
    "display" : "RESTAURADOR DE INSTRUMENTOS MUSICAIS (EXCETO CORDAS ARCADAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "915210",
    "display" : "REPARADOR DE INSTRUMENTOS MUSICAIS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "915215",
    "display" : "LUTHIER (RESTAURACAO DE CORDAS ARCADAS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "915305",
    "display" : "TECNICO EM MANUTENCAO DE EQUIPAMENTOS E INSTRUMENTOS MEDICOHOSPITALARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "915405",
    "display" : "REPARADOR DE EQUIPAMENTOS FOTOGRAFICOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "919105",
    "display" : "LUBRIFICADOR INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "919110",
    "display" : "LUBRIFICADOR DE VEICULOS AUTOMOTORES (EXCETO EMBARCACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "919115",
    "display" : "LUBRIFICADOR DE EMBARCACOES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "919205",
    "display" : "MECANICO DE MANUTENCAO DE MAQUINAS CORTADORAS DE GRAMA, ROCADEIRAS, MOTOSSERRAS E SIMILARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "919305",
    "display" : "MECANICO DE MANUTENCAO DE APARELHOS ESPORTIVOS E DE GINASTICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "919310",
    "display" : "MECANICO DE MANUTENCAO DE BICICLETAS E VEICULOS SIMILARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "919315",
    "display" : "MONTADOR DE BICICLETAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "950105",
    "display" : "SUPERVISOR DE MANUTENCAO ELETRICA DE ALTA TENSAO INDUSTRIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "950110",
    "display" : "SUPERVISOR DE MANUTENCAO ELETROMECANICA INDUSTRIAL, COMERCIAL E PREDIAL",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "950205",
    "display" : "ENCARREGADO DE MANUTENCAO ELETRICA DE VEICULOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "950305",
    "display" : "SUPERVISOR DE MANUTENCAO ELETROMECANICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "951105",
    "display" : "ELETRICISTA DE MANUTENCAO ELETROELETRONICA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "951305",
    "display" : "INSTALADOR DE SISTEMAS ELETROELETRONICOS DE SEGURANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "951310",
    "display" : "MANTENEDOR DE SISTEMAS ELETROELETRONICOS DE SEGURANCA",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "951315",
    "display" : "MONITOR DE SISTEMAS ELETRONICOS DE SEGURANCA INTERNO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "951320",
    "display" : "MONITOR DE SISTEMAS ELETRONICOS DE SEGURANCA EXTERNO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "953105",
    "display" : "ELETRICISTA DE INSTALACOES (AERONAVES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "953110",
    "display" : "ELETRICISTA DE INSTALACOES (EMBARCACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "953115",
    "display" : "ELETRICISTA DE INSTALACOES (VEICULOS AUTOMOTORES E MAQUINAS OPERATRIZES, EXCETO AERONAVES E EMBARCACOES)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "954105",
    "display" : "ELETROMECANICO DE MANUTENCAO DE ELEVADORES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "954110",
    "display" : "ELETROMECANICO DE MANUTENCAO DE ESCADAS ROLANTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "954115",
    "display" : "ELETROMECANICO DE MANUTENCAO DE PORTAS AUTOMATICAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "954120",
    "display" : "MECANICO DE MANUTENCAO DE INSTALACOES MECANICAS DE EDIFICIOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "954125",
    "display" : "OPERADOR ELETROMECANICO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "954205",
    "display" : "REPARADOR DE APARELHOS ELETRODOMESTICOS (EXCETO IMAGEM E SOM)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "954210",
    "display" : "REPARADOR DE RADIO, TV E SOM",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "954305",
    "display" : "REPARADOR DE EQUIPAMENTOS DE ESCRITORIO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "991105",
    "display" : "CONSERVADOR DE VIA PERMANENTE (TRILHOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "991110",
    "display" : "INSPETOR DE VIA PERMANENTE (TRILHOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "991115",
    "display" : "OPERADOR DE MAQUINAS ESPECIAIS EM CONSERVACAO DE VIA PERMANENTE (TRILHOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "991120",
    "display" : "SOLDADOR ALUMINOTERMICO EM CONSERVACAO DE TRILHOS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "991205",
    "display" : "MANTENEDOR DE EQUIPAMENTOS DE PARQUES DE DIVERSOES E SIMILARES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "991305",
    "display" : "FUNILEIRO DE VEICULOS (REPARACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "991310",
    "display" : "MONTADOR DE VEICULOS (REPARACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "991315",
    "display" : "PINTOR DE VEICULOS (REPARACAO)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "991410",
    "display" : "CONSERVADOR DE FACHADAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "992105",
    "display" : "ALINHADOR DE PNEUS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "992110",
    "display" : "BALANCEADOR",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "992115",
    "display" : "BORRACHEIRO",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "992120",
    "display" : "LAVADOR DE PECAS",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "992205",
    "display" : "ENCARREGADO GERAL DE OPERACOES DE CONSERVACAO DE VIAS PERMANENTES (EXCETO TRILHOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "992210",
    "display" : "ENCARREGADO DE EQUIPE DE CONSERVACAO DE VIAS PERMANENTES (EXCETO TRILHOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "992215",
    "display" : "OPERADOR DE CEIFADEIRA NA CONSERVACAO DE VIAS PERMANENTES",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "992220",
    "display" : "PEDREIRO DE CONSERVACAO DE VIAS PERMANENTES (EXCETO TRILHOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "992225",
    "display" : "AUXILIAR GERAL DE CONSERVACAO DE VIAS PERMANENTES (EXCETO TRILHOS)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141805",
    "display" : "Gerente de administração em aeroportos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141810",
    "display" : "Gerente de empresa aérea e empresa de serviços auxiliares ao transporte aéreo (esata) em aeroportos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141815",
    "display" : "Gerente de operações em aeroportos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141820",
    "display" : "Gerente de operações de cargas",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141825",
    "display" : "Gerente de segurança da aviação civil",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "141830",
    "display" : "Gerente de segurança operacional (aviação civil)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142125",
    "display" : "Analista de compliance",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142130",
    "display" : "Analista de riscos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142135",
    "display" : "Oficial de proteção de dados pessoais (dpo)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142345",
    "display" : "Profissional de relações institucionais e governamentais",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142350",
    "display" : "Profissonal de relações internacionais",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "142355",
    "display" : "Analista de e-commerce",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "204110",
    "display" : "Perito judicial",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212425",
    "display" : "Arquiteto de soluções de tecnologia da informação",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "212430",
    "display" : "Analista de testes de tecnologia da informação",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214375",
    "display" : "Engenheiro de energia",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214380",
    "display" : "Engenheiro biomédico",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214540",
    "display" : "Engenheiro têxtil",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "214945",
    "display" : "Engenheiro de logistica",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "222125",
    "display" : "Tecnólogo em agronegócio",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223575",
    "display" : "Obstetriz",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "223915",
    "display" : "Psicomotricista",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "224140",
    "display" : "Profissional de educação física na saúde",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "225355",
    "display" : "Médico radiologista intervencionista",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239440",
    "display" : "Neuropsicopedagogo clinico",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "239445",
    "display" : "Neuropsicopedagogo institucional",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "241405",
    "display" : "Conselheiro julgador",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252705",
    "display" : "Analista de pcp (programação e controle da produção)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252710",
    "display" : "Analista de planejamento de materias",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252715",
    "display" : "Analista de logistica",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252720",
    "display" : "Analista de projetos logisticos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "252725",
    "display" : "Analista de gestão de estoque",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253120",
    "display" : "Diretor de mídia (publicidade)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253125",
    "display" : "Diretor de arte (publicidade)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253405",
    "display" : "Analista de mídias sociais",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "253410",
    "display" : "Influenciador digital",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261905",
    "display" : "Continuista",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "261910",
    "display" : "Assistente de direção (tv)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262225",
    "display" : "Diretor de programação",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262230",
    "display" : "Diretor de produção",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "262235",
    "display" : "Diretor artistíco",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314805",
    "display" : "Inspetor de equipamentos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314810",
    "display" : "Inspetor de fabricação",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314815",
    "display" : "Inspetor de ensaios não destrutivos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314825",
    "display" : "Inspetor de dutos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314830",
    "display" : "Inspetor de controle dimensional",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314835",
    "display" : "Inspetor de pintura",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314840",
    "display" : "Inspetor de manutenção",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "314845",
    "display" : "Inspetor de soldagem",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "322255",
    "display" : "Técnico em agente comunitário de saúde",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "324130",
    "display" : "Técnico em espirometria",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "324135",
    "display" : "Técnico em polissonografia",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341235",
    "display" : "Técnico em sinalização náutica",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341240",
    "display" : "Técnicos em manobras em equipamentos de convés",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341245",
    "display" : "Técnico em sinais navais",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "341250",
    "display" : "Auxiliar técnico de sinalização nautica",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342215",
    "display" : "Analista de desembaraço aduaneiro",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342555",
    "display" : "Fiscal de pista de aeroporto",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "342560",
    "display" : "Operador de rampa ( transporte aéreo)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351435",
    "display" : "Mediador de conflitos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "351440",
    "display" : "Árbitro extrajudicial",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "354610",
    "display" : "Corretor de grãos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373130",
    "display" : "Técnico de sistemas audiovisuais",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373135",
    "display" : "Operador de controle mestre",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373140",
    "display" : "Coordenador de programação",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373145",
    "display" : "Assistente de operações audiovisuais",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373225",
    "display" : "Supervisor de operações (mídias audiovisuais)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "373230",
    "display" : "Supervisor técnico (mídias audiovisuais)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374150",
    "display" : "Sonoplasta",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374155",
    "display" : "Analista musical",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "374425",
    "display" : "Diretor de imagens (tv)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "375125",
    "display" : "Produtor de moda",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "375130",
    "display" : "Profissional de organização (personal organizer)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391140",
    "display" : "Analista de manutenção (equipamentos aéreos)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "391145",
    "display" : "Analista de planejamento de manutenção",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "410240",
    "display" : "Supervisor de logística",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "411055",
    "display" : "Captador de recursos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414120",
    "display" : "Conferente mercadoria (exceto carga e descarga)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414125",
    "display" : "Estoquista",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414135",
    "display" : "Expedidor de mercadorias",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "414140",
    "display" : "Auxiliar de logistica",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415305",
    "display" : "Registrador de câncer",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "415310",
    "display" : "Analista de informação em saúde",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422330",
    "display" : "Teleatendente de emergência",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "422335",
    "display" : "Monitor de teleatendimento",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "424205",
    "display" : "Coordenador de provas (concurso, avaliação, exame)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "424210",
    "display" : "Aplicador de provas (concurso, avaliação,exame)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "515330",
    "display" : "Monitor de ressocialização prisional",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517120",
    "display" : "Brigadista florestal",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517125",
    "display" : "Chefe de brigada",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517225",
    "display" : "Policial legislativo",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517230",
    "display" : "Policial penal",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "517235",
    "display" : "Guarda portuário",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "523120",
    "display" : "Aplicador de vinil autoadesivo",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "523125",
    "display" : "Estampador de placa de identificação veicular (epiv)",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "524315",
    "display" : "Baiana de acarajé",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "715420",
    "display" : "Operador de usina de asfalto",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "716540",
    "display" : "Rejuntador de revestimentos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "725030",
    "display" : "Operador de manutenção e recarga de extintor de incêndio",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "732140",
    "display" : "Instalador de sistemas fotovoltaicos",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "781310",
    "display" : "Operador de aeronaves não tripuladas",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783235",
    "display" : "Trabalhador portuário de capatazia",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "783240",
    "display" : "Amarrador e desamarrado de embarcações",
    "property" : [{
      "code" : "healthcare",
      "valueBoolean" : false
    },
    {
      "code" : "regulated",
      "valueBoolean" : false
    }]
  }]
}

```
