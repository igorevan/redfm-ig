# Classificação Internacional de Atenção Primária - Segunda Edição (CIAP2) - Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS v1.0.0-release

## CodeSystem: Classificação Internacional de Atenção Primária - Segunda Edição (CIAP2) 

 
Classifica os problemas identificados no contato assistencial pelos profissionais de saúde, os motivos da contato assistencial e as respostas propostas pela equipe seguindo a sistematização SOAP. 

This Code system is referenced in the definition of the following value sets:

* [BRProblemaDiagnostico](ValueSet-BRProblemaDiagnostico.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRCIAP2",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/redfm/1.0.0/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/redfm/1.0.0/ImplementationGuide/br.gov.saude.redfm.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCIAP2",
  "version" : "1.0.0-release",
  "name" : "BRCIAP2",
  "title" : "Classificação Internacional de Atenção Primária - Segunda Edição (CIAP2)",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-11T19:10:21.0842411+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Classifica os problemas identificados no contato assistencial pelos profissionais de saúde, os motivos da contato assistencial e as respostas propostas pela equipe seguindo a sistematização SOAP.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "A01",
    "display" : "Dor generalizada /múltipla"
  },
  {
    "code" : "A02",
    "display" : "Arrepios/ calafrios"
  },
  {
    "code" : "A03",
    "display" : "Febre"
  },
  {
    "code" : "A04",
    "display" : "Debilidade/cansaço geral/fadiga"
  },
  {
    "code" : "A05",
    "display" : "Sentir-se doente"
  },
  {
    "code" : "A06",
    "display" : "Desmaio/síncope"
  },
  {
    "code" : "A07",
    "display" : "Coma"
  },
  {
    "code" : "A08",
    "display" : "Inchaço"
  },
  {
    "code" : "A09",
    "display" : "Problemas de sudorese"
  },
  {
    "code" : "A10",
    "display" : "Sangramento/Hemorragia NE"
  },
  {
    "code" : "A11",
    "display" : "Dores torácicas NE"
  },
  {
    "code" : "A13",
    "display" : "Receio/Medo do tratamento"
  },
  {
    "code" : "A16",
    "display" : "Criança irritável"
  },
  {
    "code" : "A18",
    "display" : "Preocupação com aparência"
  },
  {
    "code" : "A20",
    "display" : "Pedido/discussão eutanásia"
  },
  {
    "code" : "A21",
    "display" : "Fator de risco de malignidade"
  },
  {
    "code" : "A23",
    "display" : "Fator de risco NE"
  },
  {
    "code" : "A25",
    "display" : "Medo de morrer/medo da morte"
  },
  {
    "code" : "A26",
    "display" : "Medo de câncer NE"
  },
  {
    "code" : "A27",
    "display" : "Medo de outra doença NE"
  },
  {
    "code" : "A28",
    "display" : "Limitação funcional/incapacidade NE"
  },
  {
    "code" : "A29",
    "display" : "Outros sinais/sintomas gerais"
  },
  {
    "code" : "A70",
    "display" : "Tuberculose"
  },
  {
    "code" : "A71",
    "display" : "Sarampo"
  },
  {
    "code" : "A72",
    "display" : "Varicela"
  },
  {
    "code" : "A73",
    "display" : "Malária"
  },
  {
    "code" : "A74",
    "display" : "Rubéola"
  },
  {
    "code" : "A75",
    "display" : "Mononucleose infecciosa"
  },
  {
    "code" : "A76",
    "display" : "Outro exantema viral"
  },
  {
    "code" : "A77",
    "display" : "Dengue e outras doenças virais NE"
  },
  {
    "code" : "A78",
    "display" : "Hanseníase e outras doenças infecciosas NE"
  },
  {
    "code" : "A79",
    "display" : "Carcinomatose (localização primária desconhecida)"
  },
  {
    "code" : "A80",
    "display" : "Lesão traumática/acidente NE"
  },
  {
    "code" : "A81",
    "display" : "Politraumatismos/ferimentos múltiplos"
  },
  {
    "code" : "A82",
    "display" : "Efeito secundário de lesão traumática"
  },
  {
    "code" : "A84",
    "display" : "Intoxicação por medicamento"
  },
  {
    "code" : "A85",
    "display" : "Efeito adverso de fármaco dose correta"
  },
  {
    "code" : "A86",
    "display" : "Efeito tóxico de substância não medicinal"
  },
  {
    "code" : "A87",
    "display" : "Complicações de tratamento médico"
  },
  {
    "code" : "A88",
    "display" : "Efeito adverso de fator físico"
  },
  {
    "code" : "A89",
    "display" : "Efeito da prótese"
  },
  {
    "code" : "A90",
    "display" : "Malformação congênita NE/múltiplas"
  },
  {
    "code" : "A91",
    "display" : "Investigação com resultado anormal NE"
  },
  {
    "code" : "A92",
    "display" : "Alergia/reação alérgica NE"
  },
  {
    "code" : "A93",
    "display" : "Recém nascido prematuro"
  },
  {
    "code" : "A94",
    "display" : "Morbidade perinatal, outra"
  },
  {
    "code" : "A95",
    "display" : "Mortalidade perinatal"
  },
  {
    "code" : "A96",
    "display" : "Morte"
  },
  {
    "code" : "A97",
    "display" : "Sem doença"
  },
  {
    "code" : "A98",
    "display" : "Medicina preventiva/manutenção da saúde"
  },
  {
    "code" : "A99",
    "display" : "Outras doenças gerais NE"
  },
  {
    "code" : "B02",
    "display" : "Gânglio linfático aumentado/doloroso"
  },
  {
    "code" : "B04",
    "display" : "Sinais/sintomas sangue"
  },
  {
    "code" : "B25",
    "display" : "Medo de VIH/ HIV/SIDA/ AIDS"
  },
  {
    "code" : "B26",
    "display" : "Medo de câncer no sangue/linfático"
  },
  {
    "code" : "B27",
    "display" : "Medo de outras doenças do sangue /vasos linfáticos"
  },
  {
    "code" : "B28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "B29",
    "display" : "Outros sinais/ sintomas do sangue/ sistema linfático/ baço NE"
  },
  {
    "code" : "B70",
    "display" : "Linfadenite aguda"
  },
  {
    "code" : "B71",
    "display" : "Linfadenite crónica NE"
  },
  {
    "code" : "B72",
    "display" : "Doença de Hodgkin/linfomas"
  },
  {
    "code" : "B73",
    "display" : "Leucemia"
  },
  {
    "code" : "B74",
    "display" : "Outra neoplasia maligna no sangue"
  },
  {
    "code" : "B75",
    "display" : "Neoplasia benigna NE"
  },
  {
    "code" : "B76",
    "display" : "Rotura traumática do baço"
  },
  {
    "code" : "B77",
    "display" : "Outras lesões traumáticas do sangue/linfa/baço"
  },
  {
    "code" : "B78",
    "display" : "Anemia hemolítica hereditária"
  },
  {
    "code" : "B79",
    "display" : "Outra malformação congênita do sangue/linfática"
  },
  {
    "code" : "B80",
    "display" : "Anemia por deficiência de ferro"
  },
  {
    "code" : "B81",
    "display" : "Anemia perniciosa/deficiência de folatos"
  },
  {
    "code" : "B82",
    "display" : "Outras anemias NE"
  },
  {
    "code" : "B83",
    "display" : "Púrpura/defeitos de coagulação"
  },
  {
    "code" : "B84",
    "display" : "Glóbulos brancos anormais"
  },
  {
    "code" : "B87",
    "display" : "Esplenomegalia"
  },
  {
    "code" : "B90",
    "display" : "Infecção por VIH/ HIV/SIDA/ AIDS"
  },
  {
    "code" : "B99",
    "display" : "Outra doença do sangue/linfáticos/baço"
  },
  {
    "code" : "D01",
    "display" : "Dor abdominal generalizada/cólicas"
  },
  {
    "code" : "D02",
    "display" : "Dores abdominais, epigástricas"
  },
  {
    "code" : "D03",
    "display" : "Azia/ Queimação"
  },
  {
    "code" : "D04",
    "display" : "Dor anal/retal"
  },
  {
    "code" : "D05",
    "display" : "Irritação perianal"
  },
  {
    "code" : "D06",
    "display" : "Outras dores abdominais localizadas"
  },
  {
    "code" : "D07",
    "display" : "Dispepsia/indigestão"
  },
  {
    "code" : "D08",
    "display" : "Flatulência /gases/eructações"
  },
  {
    "code" : "D09",
    "display" : "Náusea"
  },
  {
    "code" : "D10",
    "display" : "Vomito"
  },
  {
    "code" : "D11",
    "display" : "Diarreia"
  },
  {
    "code" : "D12",
    "display" : "Obstipação"
  },
  {
    "code" : "D13",
    "display" : "Icterícia"
  },
  {
    "code" : "D14",
    "display" : "Hematêmese/vómito sangue"
  },
  {
    "code" : "D15",
    "display" : "Melena"
  },
  {
    "code" : "D16",
    "display" : "Hemorragia retal"
  },
  {
    "code" : "D17",
    "display" : "Incontinência fecal"
  },
  {
    "code" : "D18",
    "display" : "Alterações nas fezes/mov. intestinais"
  },
  {
    "code" : "D19",
    "display" : "Sinais/sintomas dos dentes/gengivas"
  },
  {
    "code" : "D20",
    "display" : "Sinais/sintomas da boca/língua/lábios"
  },
  {
    "code" : "D21",
    "display" : "Problemas de deglutição"
  },
  {
    "code" : "D23",
    "display" : "Hepatomegalia"
  },
  {
    "code" : "D24",
    "display" : "Massa abdominal NE"
  },
  {
    "code" : "D25",
    "display" : "Distensão abdominal"
  },
  {
    "code" : "D26",
    "display" : "Medo de câncer no aparelho digestivo"
  },
  {
    "code" : "D27",
    "display" : "Medo de outras doenças aparelho digestivo"
  },
  {
    "code" : "D28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "D29",
    "display" : "Outros sinais/sintomas digestivos"
  },
  {
    "code" : "D70",
    "display" : "Infecção gastrointestinal"
  },
  {
    "code" : "D71",
    "display" : "Caxumba/parotidite epidêmica"
  },
  {
    "code" : "D72",
    "display" : "Hepatite viral"
  },
  {
    "code" : "D73",
    "display" : "Gastroenterite, presumível infecção"
  },
  {
    "code" : "D74",
    "display" : "Neoplasia maligna do estômago"
  },
  {
    "code" : "D75",
    "display" : "Neoplasia maligna do cólon/reto"
  },
  {
    "code" : "D76",
    "display" : "Neoplasia maligna do pâncreas"
  },
  {
    "code" : "D77",
    "display" : "Neoplasia maligna do aparelho digestivo NE"
  },
  {
    "code" : "D78",
    "display" : "Neoplasia benigna do aparelho digestivo/incerta"
  },
  {
    "code" : "D79",
    "display" : "Corpo estranho no aparelho digestivo"
  },
  {
    "code" : "D80",
    "display" : "Outras lesões traumáticas"
  },
  {
    "code" : "D81",
    "display" : "Malformações congênitas do aparelho digestivo"
  },
  {
    "code" : "D82",
    "display" : "Doença dos dentes/gengivas"
  },
  {
    "code" : "D83",
    "display" : "Doença da boca/língua/lábios"
  },
  {
    "code" : "D84",
    "display" : "Doença do esôfago"
  },
  {
    "code" : "D85",
    "display" : "Úlcera do duodeno"
  },
  {
    "code" : "D86",
    "display" : "Úlcera péptica, outra"
  },
  {
    "code" : "D87",
    "display" : "Alterações funcionais estômago"
  },
  {
    "code" : "D88",
    "display" : "Apendicite"
  },
  {
    "code" : "D89",
    "display" : "Hérnia inguinal"
  },
  {
    "code" : "D90",
    "display" : "Hérnia de hiato /diafragmática"
  },
  {
    "code" : "D91",
    "display" : "Hérnia abdominal, outras"
  },
  {
    "code" : "D92",
    "display" : "Doença diverticular intestinal"
  },
  {
    "code" : "D93",
    "display" : "Síndrome do cólon irritável"
  },
  {
    "code" : "D94",
    "display" : "Enterite crónica/colite ulcerosa"
  },
  {
    "code" : "D95",
    "display" : "Fissura anal / abcesso perianal"
  },
  {
    "code" : "D96",
    "display" : "Lombrigas /outros parasitas"
  },
  {
    "code" : "D97",
    "display" : "Doenças do fígado /NE"
  },
  {
    "code" : "D98",
    "display" : "Colecistite, colelitiase"
  },
  {
    "code" : "D99",
    "display" : "Outra doença do aparelho digestivo"
  },
  {
    "code" : "F01",
    "display" : "Dor no olho"
  },
  {
    "code" : "F02",
    "display" : "Olho vermelho"
  },
  {
    "code" : "F03",
    "display" : "Secreção ocular"
  },
  {
    "code" : "F04",
    "display" : "Moscas volantes/pontos luminosos/escotomas/ manchas"
  },
  {
    "code" : "F05",
    "display" : "Outras perturbações visuais"
  },
  {
    "code" : "F13",
    "display" : "Sensações oculares anormais"
  },
  {
    "code" : "F14",
    "display" : "Movimentos oculares anormais"
  },
  {
    "code" : "F15",
    "display" : "Aparência anormal nos olhos"
  },
  {
    "code" : "F16",
    "display" : "Sinais/sintomas das pálpebras"
  },
  {
    "code" : "F17",
    "display" : "Sinais/sintomas relacionados a óculos"
  },
  {
    "code" : "F18",
    "display" : "Sinais/sintomas relacionados a lentes de contato"
  },
  {
    "code" : "F27",
    "display" : "Medo de doença ocular"
  },
  {
    "code" : "F28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "F29",
    "display" : "Outros sinais/sintomas oculares"
  },
  {
    "code" : "F70",
    "display" : "Conjuntivite infecciosa"
  },
  {
    "code" : "F71",
    "display" : "Conjuntivite alérgica"
  },
  {
    "code" : "F72",
    "display" : "Blefarite/hordéolo/calázio"
  },
  {
    "code" : "F73",
    "display" : "Outras infecções/inflamações oculares"
  },
  {
    "code" : "F74",
    "display" : "Neoplasia do olho/anexos"
  },
  {
    "code" : "F75",
    "display" : "Contusão/hemorragia ocular"
  },
  {
    "code" : "F76",
    "display" : "Corpo estranho ocular"
  },
  {
    "code" : "F79",
    "display" : "Outras lesões traumáticas oculares"
  },
  {
    "code" : "F80",
    "display" : "Obstrução canal lacrimal da criança"
  },
  {
    "code" : "F81",
    "display" : "Outras malformações congênitas do olho"
  },
  {
    "code" : "F82",
    "display" : "Descolamento da retina"
  },
  {
    "code" : "F83",
    "display" : "Retinopatia"
  },
  {
    "code" : "F84",
    "display" : "Degeneração macular"
  },
  {
    "code" : "F85",
    "display" : "Ulcera da córnea"
  },
  {
    "code" : "F86",
    "display" : "Tracoma"
  },
  {
    "code" : "F91",
    "display" : "Erro de refração"
  },
  {
    "code" : "F92",
    "display" : "Catarata"
  },
  {
    "code" : "F93",
    "display" : "Glaucoma"
  },
  {
    "code" : "F94",
    "display" : "Cegueira"
  },
  {
    "code" : "F95",
    "display" : "Estrabismo"
  },
  {
    "code" : "F99",
    "display" : "Outra doenças oculares/anexos"
  },
  {
    "code" : "H01",
    "display" : "Dor de ouvidos"
  },
  {
    "code" : "H02",
    "display" : "Problemas de audição"
  },
  {
    "code" : "H03",
    "display" : "Acufeno, zumbidos, ruído, assobios"
  },
  {
    "code" : "H04",
    "display" : "Secreção no ouvido"
  },
  {
    "code" : "H05",
    "display" : "Hemorragia no ouvido"
  },
  {
    "code" : "H13",
    "display" : "Sensação de ouvido tapado"
  },
  {
    "code" : "H15",
    "display" : "Preocupação com a aparência das orelhas"
  },
  {
    "code" : "H27",
    "display" : "Medo de doença do ouvido"
  },
  {
    "code" : "H28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "H29",
    "display" : "Outros sinais/sintomas ouvido"
  },
  {
    "code" : "H70",
    "display" : "Otite externa"
  },
  {
    "code" : "H71",
    "display" : "Otite media aguda/miringite"
  },
  {
    "code" : "H72",
    "display" : "Otite média serosa"
  },
  {
    "code" : "H73",
    "display" : "Infecção da Trompa de Eustáquio"
  },
  {
    "code" : "H74",
    "display" : "Otite media crónica"
  },
  {
    "code" : "H75",
    "display" : "Neoplasia do ouvido"
  },
  {
    "code" : "H76",
    "display" : "Corpo estranho do ouvido"
  },
  {
    "code" : "H77",
    "display" : "Perfuração do tímpano"
  },
  {
    "code" : "H78",
    "display" : "Traumatismo superficial do ouvido"
  },
  {
    "code" : "H79",
    "display" : "Outros traumatismos do ouvido"
  },
  {
    "code" : "H80",
    "display" : "Malformações congênitas do ouvido"
  },
  {
    "code" : "H81",
    "display" : "Cerúmen no ouvido em excesso"
  },
  {
    "code" : "H82",
    "display" : "Síndrome vertiginosa"
  },
  {
    "code" : "H83",
    "display" : "Otoesclerose"
  },
  {
    "code" : "H84",
    "display" : "Presbiacusia"
  },
  {
    "code" : "H85",
    "display" : "Lesão acústica"
  },
  {
    "code" : "H86",
    "display" : "Surdez"
  },
  {
    "code" : "H99",
    "display" : "Outra doença do ouvido/mastóide"
  },
  {
    "code" : "K01",
    "display" : "Dor atribuída ao coração"
  },
  {
    "code" : "K02",
    "display" : "Sensação de pressão/aperto atribuída ao coração"
  },
  {
    "code" : "K03",
    "display" : "Dores atribuídas ao aparelho circulatório NE"
  },
  {
    "code" : "K04",
    "display" : "Palpitações/percepção dos batimentos cardíacos"
  },
  {
    "code" : "K05",
    "display" : "Outras irregularidades dos batimentos cardíacos"
  },
  {
    "code" : "K06",
    "display" : "Veias proeminentes"
  },
  {
    "code" : "K07",
    "display" : "Tornozelos inchados/edema"
  },
  {
    "code" : "K22",
    "display" : "Fator de risco para doença cardiovascular"
  },
  {
    "code" : "K24",
    "display" : "Medo de doença cardíaca"
  },
  {
    "code" : "K25",
    "display" : "Medo de hipertensão"
  },
  {
    "code" : "K27",
    "display" : "Medo de outra doença cardiovascular"
  },
  {
    "code" : "K28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "K29",
    "display" : "Outros sinais/sintomas cardiovasculares"
  },
  {
    "code" : "K70",
    "display" : "Doença infecciosa do aparelho circulatório"
  },
  {
    "code" : "K71",
    "display" : "Febre reumática/cardiopatia"
  },
  {
    "code" : "K72",
    "display" : "Neoplasia do aparelho circulatório"
  },
  {
    "code" : "K73",
    "display" : "Malformações congênitas do aparelho circulatório"
  },
  {
    "code" : "K74",
    "display" : "Doença cardíaca isquémica com angina"
  },
  {
    "code" : "K75",
    "display" : "Infarto ou Enfarte agudo miocárdio"
  },
  {
    "code" : "K76",
    "display" : "Doença cardíaca isquémica sem angina"
  },
  {
    "code" : "K77",
    "display" : "Insuficiência cardíaca"
  },
  {
    "code" : "K78",
    "display" : "Fibrilação/flutter auricular/ atrial"
  },
  {
    "code" : "K79",
    "display" : "Taquicardia Paroxística"
  },
  {
    "code" : "K80",
    "display" : "Arritmia cardíaca NE"
  },
  {
    "code" : "K81",
    "display" : "Sopro cardíaco/arterial NE"
  },
  {
    "code" : "K82",
    "display" : "Doença cardiopulmonar"
  },
  {
    "code" : "K83",
    "display" : "Doença valvular cardíaca NE"
  },
  {
    "code" : "K84",
    "display" : "Outras doenças cardíacas"
  },
  {
    "code" : "K85",
    "display" : "Pressão arterial elevada"
  },
  {
    "code" : "K86",
    "display" : "Hipertensão sem complicações"
  },
  {
    "code" : "K87",
    "display" : "Hipertensão com complicações"
  },
  {
    "code" : "K88",
    "display" : "Hipotensão postural"
  },
  {
    "code" : "K89",
    "display" : "Isquêmia/ acidente cerebral transitória(o)"
  },
  {
    "code" : "K90",
    "display" : "Trombose/acidente vascular cerebral"
  },
  {
    "code" : "K91",
    "display" : "Doença vascular cerebral"
  },
  {
    "code" : "K92",
    "display" : "Aterosclerose/doença vascular periférica"
  },
  {
    "code" : "K93",
    "display" : "Embolia pulmonar"
  },
  {
    "code" : "K94",
    "display" : "Flebite/tromboflebite"
  },
  {
    "code" : "K95",
    "display" : "Veias varicosas da perna"
  },
  {
    "code" : "K96",
    "display" : "Hemorróidas"
  },
  {
    "code" : "K99",
    "display" : "Outras doenças do aparelho circulatório"
  },
  {
    "code" : "L01",
    "display" : "Sinais/sintomas do pescoço"
  },
  {
    "code" : "L02",
    "display" : "Sinais/sintomas da região dorsal"
  },
  {
    "code" : "L03",
    "display" : "Sinais/sintomas da região lombar"
  },
  {
    "code" : "L04",
    "display" : "Sinais/sintomas do tórax"
  },
  {
    "code" : "L05",
    "display" : "Sinais/sintomas da axila"
  },
  {
    "code" : "L07",
    "display" : "Sinais/sintomas da mandíbula"
  },
  {
    "code" : "L08",
    "display" : "Sinais/sintomas dos ombros"
  },
  {
    "code" : "L09",
    "display" : "Sinais/sintomas dos braços"
  },
  {
    "code" : "L10",
    "display" : "Sinais/sintomas dos cotovelos"
  },
  {
    "code" : "L11",
    "display" : "Sinais/sintomas dos punhos"
  },
  {
    "code" : "L12",
    "display" : "Sinais/sintomas das mãos e dedos"
  },
  {
    "code" : "L13",
    "display" : "Sinais/sintomas do quadril"
  },
  {
    "code" : "L14",
    "display" : "Sinais/sintomas da coxa/perna"
  },
  {
    "code" : "L15",
    "display" : "Sinais/sintomas do joelho"
  },
  {
    "code" : "L16",
    "display" : "Sinais/sintomas do tornozelo"
  },
  {
    "code" : "L17",
    "display" : "Sinais/sintomas do pé/dedos pé"
  },
  {
    "code" : "L18",
    "display" : "Dores musculares"
  },
  {
    "code" : "L19",
    "display" : "Sinais/sintomas musculares NE"
  },
  {
    "code" : "L20",
    "display" : "Sinais/sintomas das articulações NE"
  },
  {
    "code" : "L26",
    "display" : "Medo de câncer no aparelho músculo-esquelético"
  },
  {
    "code" : "L27",
    "display" : "Medo de doença no aparelho músculo-esquelético, outro"
  },
  {
    "code" : "L28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "L29",
    "display" : "Outros sinais/sintomas do aparelho músculo-esquelético"
  },
  {
    "code" : "L70",
    "display" : "Infecções do aparelho músculo-esquelético"
  },
  {
    "code" : "L71",
    "display" : "Neoplasia maligna do aparelho músculo-esquelético"
  },
  {
    "code" : "L72",
    "display" : "Fratura: rádio/cúbito"
  },
  {
    "code" : "L73",
    "display" : "Fratura: tíbia/perônio/ fíbula"
  },
  {
    "code" : "L74",
    "display" : "Fratura: osso da mão/pé"
  },
  {
    "code" : "L75",
    "display" : "Fratura: fémur"
  },
  {
    "code" : "L76",
    "display" : "Outras fraturas"
  },
  {
    "code" : "L77",
    "display" : "Entorses e distensões do tornozelo"
  },
  {
    "code" : "L78",
    "display" : "Entorses e distensões do joelho"
  },
  {
    "code" : "L79",
    "display" : "Entorses e distensões das articulações NE"
  },
  {
    "code" : "L80",
    "display" : "Luxação/subluxação"
  },
  {
    "code" : "L81",
    "display" : "Traumatismos do aparelho musculoesquelético NE"
  },
  {
    "code" : "L82",
    "display" : "Malformações congênitas do aparelho músculo-esquelético"
  },
  {
    "code" : "L83",
    "display" : "Doenças ou síndromes da coluna cervical"
  },
  {
    "code" : "L84",
    "display" : "Doenças ou síndromes da coluna sem irradiação de dor"
  },
  {
    "code" : "L85",
    "display" : "Deformação adquirida da coluna"
  },
  {
    "code" : "L86",
    "display" : "Síndrome vertebral com irradiação dor"
  },
  {
    "code" : "L87",
    "display" : "Bursite/tendinite/sinovite NE"
  },
  {
    "code" : "L88",
    "display" : "Artrite reumatóide/seropositiva"
  },
  {
    "code" : "L89",
    "display" : "Osteoartrose do quadril"
  },
  {
    "code" : "L90",
    "display" : "Osteoartrose do joelho"
  },
  {
    "code" : "L91",
    "display" : "Outras osteoartroses"
  },
  {
    "code" : "L92",
    "display" : "Síndrome do ombro doloroso"
  },
  {
    "code" : "L93",
    "display" : "Cotovelo de tenista"
  },
  {
    "code" : "L94",
    "display" : "Osteocondrose"
  },
  {
    "code" : "L95",
    "display" : "Osteoporose"
  },
  {
    "code" : "L96",
    "display" : "Lesão interna aguda do joelho"
  },
  {
    "code" : "L97",
    "display" : "Neoplasia benigna/incertas"
  },
  {
    "code" : "L98",
    "display" : "Malformação adquirida de um membro"
  },
  {
    "code" : "L99",
    "display" : "Outra doença do aparelho músculo-esquelético"
  },
  {
    "code" : "N01",
    "display" : "Cefaléia"
  },
  {
    "code" : "N03",
    "display" : "Dores da face"
  },
  {
    "code" : "N04",
    "display" : "Síndrome das pernas inquietas"
  },
  {
    "code" : "N05",
    "display" : "Formigamento/ parestesia nos dedos das mãos/pés"
  },
  {
    "code" : "N06",
    "display" : "Outras alterações da sensibilidade"
  },
  {
    "code" : "N07",
    "display" : "Convulsões/ataques"
  },
  {
    "code" : "N08",
    "display" : "Movimentos involuntários anormais"
  },
  {
    "code" : "N16",
    "display" : "Alterações do olfato/gosto"
  },
  {
    "code" : "N17",
    "display" : "Vertigens/tonturas"
  },
  {
    "code" : "N18",
    "display" : "Paralisia/fraqueza"
  },
  {
    "code" : "N19",
    "display" : "Perturbações da fala"
  },
  {
    "code" : "N26",
    "display" : "Medo de câncer do sistema neurológico"
  },
  {
    "code" : "N27",
    "display" : "Medo de outras doenças neurológicas"
  },
  {
    "code" : "N28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "N29",
    "display" : "Sinais/sintomas do sistema neurológico, outros"
  },
  {
    "code" : "N70",
    "display" : "Poliomielite"
  },
  {
    "code" : "N71",
    "display" : "Meningite/encefalite"
  },
  {
    "code" : "N72",
    "display" : "Tétano"
  },
  {
    "code" : "N73",
    "display" : "Outra infecção neurológica"
  },
  {
    "code" : "N74",
    "display" : "Neoplasia maligna do sistema neurológico"
  },
  {
    "code" : "N75",
    "display" : "Neoplasia benigna do sistema neurológico"
  },
  {
    "code" : "N76",
    "display" : "Neoplasia do sistema neurológico de natureza incerta"
  },
  {
    "code" : "N79",
    "display" : "Concussão"
  },
  {
    "code" : "N80",
    "display" : "Outras lesões cranianas"
  },
  {
    "code" : "N81",
    "display" : "Outra lesão do sistema neurológico"
  },
  {
    "code" : "N85",
    "display" : "Malformações congênitas"
  },
  {
    "code" : "N86",
    "display" : "Esclerose múltipla"
  },
  {
    "code" : "N87",
    "display" : "Parkinsonismo"
  },
  {
    "code" : "N88",
    "display" : "Epilepsia"
  },
  {
    "code" : "N89",
    "display" : "Enxaqueca"
  },
  {
    "code" : "N90",
    "display" : "Cefaléia de cluster"
  },
  {
    "code" : "N91",
    "display" : "Paralisia facial/paralisia de Bell"
  },
  {
    "code" : "N92",
    "display" : "Nevralgia do trigémio"
  },
  {
    "code" : "N93",
    "display" : "Síndrome do túnel do carpo/ Síndrome do canal cárpico"
  },
  {
    "code" : "N94",
    "display" : "Neurite/ Nevrite/neuropatia periférica"
  },
  {
    "code" : "N95",
    "display" : "Cefaléia tensional"
  },
  {
    "code" : "N99",
    "display" : "Outras doenças do sistema neurológico"
  },
  {
    "code" : "P01",
    "display" : "Sensação de ansiedade/nervosismo/tensão"
  },
  {
    "code" : "P02",
    "display" : "Reação aguda ao estresse"
  },
  {
    "code" : "P03",
    "display" : "Tristeza/ Sensação de depressão"
  },
  {
    "code" : "P04",
    "display" : "Sentir/comportar-se de forma irritável/zangada"
  },
  {
    "code" : "P05",
    "display" : "Sensação/comportamento senil"
  },
  {
    "code" : "P06",
    "display" : "Perturbação do sono"
  },
  {
    "code" : "P07",
    "display" : "Diminuição do desejo sexual"
  },
  {
    "code" : "P08",
    "display" : "Diminuição da satisfação sexual"
  },
  {
    "code" : "P09",
    "display" : "Preocupação com a preferência sexual"
  },
  {
    "code" : "P10",
    "display" : "Gaguejar/balbuciar/tiques"
  },
  {
    "code" : "P11",
    "display" : "Problemas de alimentação da criança"
  },
  {
    "code" : "P12",
    "display" : "Molhar a cama/enurese"
  },
  {
    "code" : "P13",
    "display" : "Encoprese/outros problemas de incontinência fecal"
  },
  {
    "code" : "P15",
    "display" : "Abuso crônico de álcool"
  },
  {
    "code" : "P16",
    "display" : "Abuso agudo de álcool"
  },
  {
    "code" : "P17",
    "display" : "Abuso do tabaco"
  },
  {
    "code" : "P18",
    "display" : "Abuso de medicação"
  },
  {
    "code" : "P19",
    "display" : "Abuso de drogas"
  },
  {
    "code" : "P20",
    "display" : "Alterações da memória"
  },
  {
    "code" : "P22",
    "display" : "Sinais/sintomas relacionados ao comportamento da criança"
  },
  {
    "code" : "P23",
    "display" : "Sinais/sintomas relacionados ao comportamento do adolescente"
  },
  {
    "code" : "P24",
    "display" : "Dificuldades especificas de aprendizagem"
  },
  {
    "code" : "P25",
    "display" : "Problemas da fase de vida de adulto"
  },
  {
    "code" : "P27",
    "display" : "Medo de perturbações mentais"
  },
  {
    "code" : "P28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "P29",
    "display" : "Sinais/sintomas psicológicos, outros"
  },
  {
    "code" : "P70",
    "display" : "Demência"
  },
  {
    "code" : "P71",
    "display" : "Outras psicoses orgânicas NE"
  },
  {
    "code" : "P72",
    "display" : "Esquizofrenia"
  },
  {
    "code" : "P73",
    "display" : "Psicose afetiva"
  },
  {
    "code" : "P74",
    "display" : "Distúrbio ansioso/estado de ansiedade"
  },
  {
    "code" : "P75",
    "display" : "Somatização"
  },
  {
    "code" : "P76",
    "display" : "Perturbações depressivas"
  },
  {
    "code" : "P77",
    "display" : "Suicídio/tentativa de suicídio"
  },
  {
    "code" : "P78",
    "display" : "Neurastenia"
  },
  {
    "code" : "P79",
    "display" : "Fobia/perturbação compulsiva"
  },
  {
    "code" : "P80",
    "display" : "Perturbações de personalidade"
  },
  {
    "code" : "P81",
    "display" : "Perturbação hipercinética"
  },
  {
    "code" : "P82",
    "display" : "Estresse pós traumático"
  },
  {
    "code" : "P85",
    "display" : "Retardo/ Atraso mental"
  },
  {
    "code" : "P86",
    "display" : "Anorexia nervosa, bulimia"
  },
  {
    "code" : "P98",
    "display" : "Outras psicoses NE"
  },
  {
    "code" : "P99",
    "display" : "Outras perturbações psicológicas"
  },
  {
    "code" : "R01",
    "display" : "Dor atribuída ao aparelho respiratório"
  },
  {
    "code" : "R02",
    "display" : "Dificuldade respiratória, dispneia"
  },
  {
    "code" : "R03",
    "display" : "Respiração ruidosa"
  },
  {
    "code" : "R04",
    "display" : "Outros problemas respiratórios"
  },
  {
    "code" : "R05",
    "display" : "Tosse"
  },
  {
    "code" : "R06",
    "display" : "Hemorragia nasal/epistaxe"
  },
  {
    "code" : "R07",
    "display" : "Espirro/congestão nasal"
  },
  {
    "code" : "R08",
    "display" : "Outros sinais/sintomas nasais"
  },
  {
    "code" : "R09",
    "display" : "Sinais/sintomas dos seios paranasais"
  },
  {
    "code" : "R21",
    "display" : "Sinais/sintomas da garganta"
  },
  {
    "code" : "R23",
    "display" : "Sinais/sintomas da voz"
  },
  {
    "code" : "R24",
    "display" : "Hemoptise"
  },
  {
    "code" : "R25",
    "display" : "Expectoração/mucosidade anormal"
  },
  {
    "code" : "R26",
    "display" : "Medo de câncer do aparelho respiratório"
  },
  {
    "code" : "R27",
    "display" : "Medo de outras doenças respiratórias"
  },
  {
    "code" : "R28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "R29",
    "display" : "Sinais/sintomas do aparelho respiratório, outros"
  },
  {
    "code" : "R71",
    "display" : "Tosse convulsa/ pertussis"
  },
  {
    "code" : "R72",
    "display" : "Infecção estreptocócica da orofaringe"
  },
  {
    "code" : "R73",
    "display" : "Abcesso/furúnculo no nariz"
  },
  {
    "code" : "R74",
    "display" : "Infecção aguda do aparelho respiratório superior (IVAS)"
  },
  {
    "code" : "R75",
    "display" : "Sinusite crónica/aguda"
  },
  {
    "code" : "R76",
    "display" : "Amigdalite aguda"
  },
  {
    "code" : "R77",
    "display" : "Laringite/traqueíte aguda"
  },
  {
    "code" : "R78",
    "display" : "Bronquite/bronquiolite aguda"
  },
  {
    "code" : "R79",
    "display" : "Bronquite crônica"
  },
  {
    "code" : "R80",
    "display" : "Gripe"
  },
  {
    "code" : "R81",
    "display" : "Pneumonia"
  },
  {
    "code" : "R82",
    "display" : "Pleurite/derrame pleural"
  },
  {
    "code" : "R83",
    "display" : "Outra infecção respiratória"
  },
  {
    "code" : "R84",
    "display" : "Neoplasia maligna dos brônquios/pulmão"
  },
  {
    "code" : "R85",
    "display" : "Outra neoplasia respiratória maligna"
  },
  {
    "code" : "R86",
    "display" : "Neoplasia benigna respiratória"
  },
  {
    "code" : "R87",
    "display" : "Corpo estranho nariz/laringe/brônquios"
  },
  {
    "code" : "R88",
    "display" : "Outra lesão respiratória"
  },
  {
    "code" : "R89",
    "display" : "Malformação congénita do aparelho respiratório"
  },
  {
    "code" : "R90",
    "display" : "Hipertrofia das amígdalas/adenóides"
  },
  {
    "code" : "R92",
    "display" : "Neoplasia respiratória NE"
  },
  {
    "code" : "R95",
    "display" : "Doença pulmonar obstrutiva crónica"
  },
  {
    "code" : "R96",
    "display" : "Asma"
  },
  {
    "code" : "R97",
    "display" : "Rinite alérgica"
  },
  {
    "code" : "R98",
    "display" : "Síndrome de hiperventilação"
  },
  {
    "code" : "R99",
    "display" : "Outras doenças respiratórias"
  },
  {
    "code" : "S01",
    "display" : "Dor/sensibilidade dolorosa da pele"
  },
  {
    "code" : "S02",
    "display" : "Prurido"
  },
  {
    "code" : "S03",
    "display" : "Verrugas"
  },
  {
    "code" : "S04",
    "display" : "Tumor/inchaço localizado"
  },
  {
    "code" : "S05",
    "display" : "Tumores/inchaços generalizados"
  },
  {
    "code" : "S06",
    "display" : "Erupção cutânea localizada"
  },
  {
    "code" : "S07",
    "display" : "Erupção cutânea generalizada"
  },
  {
    "code" : "S08",
    "display" : "Alterações da cor da pele"
  },
  {
    "code" : "S09",
    "display" : "Infecção dos dedos das mãos/pés"
  },
  {
    "code" : "S10",
    "display" : "Furúnculo/carbúnculo"
  },
  {
    "code" : "S11",
    "display" : "Infecção pós-traumática da pele"
  },
  {
    "code" : "S12",
    "display" : "Picada ou mordedura de inseto"
  },
  {
    "code" : "S13",
    "display" : "Mordedura animal/humana"
  },
  {
    "code" : "S14",
    "display" : "Queimadura/escaldão"
  },
  {
    "code" : "S15",
    "display" : "Corpo estranho na pele"
  },
  {
    "code" : "S16",
    "display" : "Traumatismo/contusão"
  },
  {
    "code" : "S17",
    "display" : "Abrasão/arranhão/bolhas"
  },
  {
    "code" : "S18",
    "display" : "Laceração/corte"
  },
  {
    "code" : "S19",
    "display" : "Outra lesão cutânea"
  },
  {
    "code" : "S20",
    "display" : "Calos/calosidades"
  },
  {
    "code" : "S21",
    "display" : "Sinais/sintomas da textura da pele"
  },
  {
    "code" : "S22",
    "display" : "Sinais/sintomas das unhas"
  },
  {
    "code" : "S23",
    "display" : "Queda de cabelo/calvície"
  },
  {
    "code" : "S24",
    "display" : "Sinais/sintomas do cabelo/couro cabeludo"
  },
  {
    "code" : "S26",
    "display" : "Medo de câncer de pele"
  },
  {
    "code" : "S27",
    "display" : "Medo de outra doença da pele"
  },
  {
    "code" : "S28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "S29",
    "display" : "Sinais/sintomas da pele, outros"
  },
  {
    "code" : "S70",
    "display" : "Herpes zoster"
  },
  {
    "code" : "S71",
    "display" : "Herpes simples"
  },
  {
    "code" : "S72",
    "display" : "Escabiose/outras acaríases"
  },
  {
    "code" : "S73",
    "display" : "Pediculose/outras infecções da pele"
  },
  {
    "code" : "S74",
    "display" : "Dermatofitose"
  },
  {
    "code" : "S75",
    "display" : "Monilíase oral/candidíase na pele"
  },
  {
    "code" : "S76",
    "display" : "Outras infecções da pele"
  },
  {
    "code" : "S77",
    "display" : "Neoplasias malignas da pele"
  },
  {
    "code" : "S78",
    "display" : "Lipoma"
  },
  {
    "code" : "S79",
    "display" : "Neoplasia cutânea benigna/incerta"
  },
  {
    "code" : "S80",
    "display" : "Ceratose/ Queratose solar/queimadura solar"
  },
  {
    "code" : "S81",
    "display" : "Hemangioma/linfangioma"
  },
  {
    "code" : "S82",
    "display" : "Nevos/sinais da pele"
  },
  {
    "code" : "S83",
    "display" : "Lesões da pele congênitas, outras"
  },
  {
    "code" : "S84",
    "display" : "Impetigo"
  },
  {
    "code" : "S85",
    "display" : "Cisto pilonidal/fistula"
  },
  {
    "code" : "S86",
    "display" : "Dermatite seborreica"
  },
  {
    "code" : "S87",
    "display" : "Dermatite/eczema atópico"
  },
  {
    "code" : "S88",
    "display" : "Dermatite de contato/alérgica"
  },
  {
    "code" : "S89",
    "display" : "Dermatite das fraldas"
  },
  {
    "code" : "S90",
    "display" : "Pitiríase rosada"
  },
  {
    "code" : "S91",
    "display" : "Psoríase"
  },
  {
    "code" : "S92",
    "display" : "Doença das glândulas sudoríparas"
  },
  {
    "code" : "S93",
    "display" : "Cisto sebáceo"
  },
  {
    "code" : "S94",
    "display" : "Unha encravada"
  },
  {
    "code" : "S95",
    "display" : "Molusco contagioso"
  },
  {
    "code" : "S96",
    "display" : "Acne"
  },
  {
    "code" : "S97",
    "display" : "Úlcera crónica da pele"
  },
  {
    "code" : "S98",
    "display" : "Urticária"
  },
  {
    "code" : "S99",
    "display" : "Outras doenças da pele"
  },
  {
    "code" : "T01",
    "display" : "Sede excessiva"
  },
  {
    "code" : "T02",
    "display" : "Apetite excessivo"
  },
  {
    "code" : "T03",
    "display" : "Perda de apetite"
  },
  {
    "code" : "T04",
    "display" : "Problemas alimentares de lactente/criança"
  },
  {
    "code" : "T05",
    "display" : "Problemas alimentares do adulto"
  },
  {
    "code" : "T07",
    "display" : "Aumento de peso"
  },
  {
    "code" : "T08",
    "display" : "Perda de peso"
  },
  {
    "code" : "T10",
    "display" : "Atraso do crescimento"
  },
  {
    "code" : "T11",
    "display" : "Desidratação"
  },
  {
    "code" : "T26",
    "display" : "Medo de câncer do sistema endócrino"
  },
  {
    "code" : "T27",
    "display" : "Medo de outra doença endócrina/metabólica"
  },
  {
    "code" : "T28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "T29",
    "display" : "Sinais/sintomas endocrinológicos/metabolicos/nutricionais, outros"
  },
  {
    "code" : "T70",
    "display" : "Infecção endócrina"
  },
  {
    "code" : "T71",
    "display" : "Neoplasia maligna da tiróide"
  },
  {
    "code" : "T72",
    "display" : "Neoplasia benigna da tiróide"
  },
  {
    "code" : "T73",
    "display" : "Outra neoplasia endócrina NE"
  },
  {
    "code" : "T78",
    "display" : "Cisto do canal tiroglosso"
  },
  {
    "code" : "T80",
    "display" : "Malformação congénita endócrina/metabólica"
  },
  {
    "code" : "T81",
    "display" : "Bócio"
  },
  {
    "code" : "T82",
    "display" : "Obesidade"
  },
  {
    "code" : "T83",
    "display" : "Excesso de peso"
  },
  {
    "code" : "T85",
    "display" : "Hipertiroidismo/tireotoxicose"
  },
  {
    "code" : "T86",
    "display" : "Hipotiroidismo/mixedema"
  },
  {
    "code" : "T87",
    "display" : "Hipoglicemia"
  },
  {
    "code" : "T89",
    "display" : "Diabetes insulino-dependente"
  },
  {
    "code" : "T90",
    "display" : "Diabetes não insulino-dependente"
  },
  {
    "code" : "T91",
    "display" : "Deficiência vitamínica/nutricional"
  },
  {
    "code" : "T92",
    "display" : "Gota"
  },
  {
    "code" : "T93",
    "display" : "Alteração no metabolismo dos lípidos"
  },
  {
    "code" : "T99",
    "display" : "Outras doenças endocrinológica/metabólica/nutricionais"
  },
  {
    "code" : "U01",
    "display" : "Disúria/micção dolorosa"
  },
  {
    "code" : "U02",
    "display" : "Micção frequente/urgência urinária/ polaciúria"
  },
  {
    "code" : "U04",
    "display" : "Incontinência urinária"
  },
  {
    "code" : "U05",
    "display" : "Outros problemas com a micção"
  },
  {
    "code" : "U06",
    "display" : "Hematúria"
  },
  {
    "code" : "U07",
    "display" : "Outros sinais/sintomas urinários"
  },
  {
    "code" : "U08",
    "display" : "Retenção urinária"
  },
  {
    "code" : "U13",
    "display" : "Sinais/sintomas da bexiga, outros"
  },
  {
    "code" : "U14",
    "display" : "Sinais/sintomas dos rins"
  },
  {
    "code" : "U26",
    "display" : "Medo de câncer no aparelho urinário"
  },
  {
    "code" : "U27",
    "display" : "Medo de outra doença urinária"
  },
  {
    "code" : "U28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "U29",
    "display" : "Sinais/sintomas aparelho urinário, outros"
  },
  {
    "code" : "U70",
    "display" : "Pielonefrite"
  },
  {
    "code" : "U71",
    "display" : "Cistite/outra infecção urinária"
  },
  {
    "code" : "U72",
    "display" : "Uretrite"
  },
  {
    "code" : "U75",
    "display" : "Neoplasia maligna do rim"
  },
  {
    "code" : "U76",
    "display" : "Neoplasia benigna do rim"
  },
  {
    "code" : "U77",
    "display" : "Neoplasia maligna do aparelho urinário, outra"
  },
  {
    "code" : "U78",
    "display" : "Neoplasia benigna do aparelho urinário"
  },
  {
    "code" : "U79",
    "display" : "Neoplasia do aparelho urinário NE"
  },
  {
    "code" : "U80",
    "display" : "Lesões traumáticas do aparelho urinário"
  },
  {
    "code" : "U85",
    "display" : "Malformação congénita do aparelho urinário"
  },
  {
    "code" : "U88",
    "display" : "Glomerulonefrite/ sindrome nefrótica"
  },
  {
    "code" : "U90",
    "display" : "Albuminúria/proteinúria ortostática"
  },
  {
    "code" : "U95",
    "display" : "Cálculo urinário"
  },
  {
    "code" : "U98",
    "display" : "Análise de urina anormal NE"
  },
  {
    "code" : "U99",
    "display" : "Outras doenças urinárias"
  },
  {
    "code" : "W01",
    "display" : "Questão sobre gravidez"
  },
  {
    "code" : "W02",
    "display" : "Medo de estar grávida"
  },
  {
    "code" : "W03",
    "display" : "Hemorragia antes do parto"
  },
  {
    "code" : "W05",
    "display" : "Vómitos/náuseas durante a gravidez"
  },
  {
    "code" : "W10",
    "display" : "Contracepção pós-coital"
  },
  {
    "code" : "W11",
    "display" : "Contracepção oral"
  },
  {
    "code" : "W12",
    "display" : "Contracepção intra-uterina/ Dispositivo Intrauterino/ DIU"
  },
  {
    "code" : "W13",
    "display" : "Esterilização"
  },
  {
    "code" : "W14",
    "display" : "Contracepção/outros"
  },
  {
    "code" : "W15",
    "display" : "Infertilidade/subfertildade"
  },
  {
    "code" : "W17",
    "display" : "Hemorragia pós-parto"
  },
  {
    "code" : "W18",
    "display" : "Sinais/sintomas pós-parto"
  },
  {
    "code" : "W19",
    "display" : "Sinais/sintomas da mama/lactação"
  },
  {
    "code" : "W21",
    "display" : "Preocupação com a imagem corporal na gravidez"
  },
  {
    "code" : "W27",
    "display" : "Medo de complicações na gravidez"
  },
  {
    "code" : "W28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "W29",
    "display" : "Sinais/sintomas da gravidez, outros"
  },
  {
    "code" : "W70",
    "display" : "Sepsis/infecção puerperal"
  },
  {
    "code" : "W71",
    "display" : "Infecções que complicam a gravidez"
  },
  {
    "code" : "W72",
    "display" : "Neoplasia maligna relacionada com gravidez"
  },
  {
    "code" : "W73",
    "display" : "Neoplasia benigna/incerta relacionada com a gravidez"
  },
  {
    "code" : "W75",
    "display" : "Lesões traumáticas que complicam a gravidez"
  },
  {
    "code" : "W76",
    "display" : "Malformação congénita que complica a gravidez"
  },
  {
    "code" : "W78",
    "display" : "Gravidez"
  },
  {
    "code" : "W79",
    "display" : "Gravidez não desejada"
  },
  {
    "code" : "W80",
    "display" : "Gravidez ectópica"
  },
  {
    "code" : "W81",
    "display" : "Toxemia gravídica/ DHEG"
  },
  {
    "code" : "W82",
    "display" : "Aborto espontâneo"
  },
  {
    "code" : "W83",
    "display" : "Aborto provocado"
  },
  {
    "code" : "W84",
    "display" : "Gravidez de alto risco"
  },
  {
    "code" : "W85",
    "display" : "Diabetes gestacional"
  },
  {
    "code" : "W90",
    "display" : "Parto sem complicações de nascido vivo"
  },
  {
    "code" : "W91",
    "display" : "Parto sem complicações de natimorto"
  },
  {
    "code" : "W92",
    "display" : "Parto com complicações de nascido vivo"
  },
  {
    "code" : "W93",
    "display" : "Parto com complicações de natimorto"
  },
  {
    "code" : "W94",
    "display" : "Mastite puerperal"
  },
  {
    "code" : "W95",
    "display" : "Outros problemas da mama durante gravidez/puerpério"
  },
  {
    "code" : "W96",
    "display" : "Outras complicações do puerpério"
  },
  {
    "code" : "W99",
    "display" : "Outros problemas da gravidez/parto"
  },
  {
    "code" : "X01",
    "display" : "Dor genital"
  },
  {
    "code" : "X02",
    "display" : "Dores menstruais"
  },
  {
    "code" : "X03",
    "display" : "Dores intermenstruais"
  },
  {
    "code" : "X04",
    "display" : "Relação sexual dolorosa na mulher"
  },
  {
    "code" : "X05",
    "display" : "Menstruação escassa/ausente"
  },
  {
    "code" : "X06",
    "display" : "Menstruação excessiva"
  },
  {
    "code" : "X07",
    "display" : "Menstruação irregular/frequente"
  },
  {
    "code" : "X08",
    "display" : "Hemorragia intermenstrual"
  },
  {
    "code" : "X09",
    "display" : "Sinais/sintomas pré-menstruais"
  },
  {
    "code" : "X10",
    "display" : "Desejo de alterar a data menstruação"
  },
  {
    "code" : "X11",
    "display" : "Sinais/sintomas da menopausa/ climatério"
  },
  {
    "code" : "X12",
    "display" : "Hemorragia pós-menopausa"
  },
  {
    "code" : "X13",
    "display" : "Hemorragia pós-coital"
  },
  {
    "code" : "X14",
    "display" : "Secreção vaginal"
  },
  {
    "code" : "X15",
    "display" : "Sinais/sintomas da vagina"
  },
  {
    "code" : "X16",
    "display" : "Sinais/sintomas da vulva"
  },
  {
    "code" : "X17",
    "display" : "Sinais/sintomas da pélvis feminina"
  },
  {
    "code" : "X18",
    "display" : "Dor na mama feminina"
  },
  {
    "code" : "X19",
    "display" : "Tumor ou nódulo na mama feminina"
  },
  {
    "code" : "X20",
    "display" : "Sinais/sintomas do mamilo da mulher"
  },
  {
    "code" : "X21",
    "display" : "Sinais/sintomas da mama feminina, outros"
  },
  {
    "code" : "X22",
    "display" : "Preocupação com a aparência da mama feminina"
  },
  {
    "code" : "X23",
    "display" : "Medo de doença de transmissão sexual"
  },
  {
    "code" : "X24",
    "display" : "Medo de disfunção sexual"
  },
  {
    "code" : "X25",
    "display" : "Medo de câncer genital"
  },
  {
    "code" : "X26",
    "display" : "Medo de câncer na mama"
  },
  {
    "code" : "X27",
    "display" : "Medo de outra doença genital/mama"
  },
  {
    "code" : "X28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "X29",
    "display" : "Sinais/sintomas do aparelho genital feminino, outra"
  },
  {
    "code" : "X70",
    "display" : "Sífilis feminina"
  },
  {
    "code" : "X71",
    "display" : "Gonorréia feminina"
  },
  {
    "code" : "X72",
    "display" : "Candidíase genital feminina"
  },
  {
    "code" : "X73",
    "display" : "Tricomoníase genital feminina"
  },
  {
    "code" : "X74",
    "display" : "Doença inflamatória pélvica"
  },
  {
    "code" : "X75",
    "display" : "Neoplasia maligna do colo"
  },
  {
    "code" : "X76",
    "display" : "Neoplasia maligna da mama feminina"
  },
  {
    "code" : "X77",
    "display" : "Neoplasia maligna genital feminina, outra"
  },
  {
    "code" : "X78",
    "display" : "Fibromioma uterino"
  },
  {
    "code" : "X79",
    "display" : "Neoplasia benigna da mama feminina/ fibroadenoma"
  },
  {
    "code" : "X80",
    "display" : "Neoplasia benigna genital"
  },
  {
    "code" : "X81",
    "display" : "Neoplasia genital feminina, outra/NE"
  },
  {
    "code" : "X82",
    "display" : "Lesão traumática genital feminina"
  },
  {
    "code" : "X83",
    "display" : "Malformações congênitas genitais"
  },
  {
    "code" : "X84",
    "display" : "Vaginite/vulvite NE"
  },
  {
    "code" : "X85",
    "display" : "Doença do colo NE"
  },
  {
    "code" : "X86",
    "display" : "Esfregaço de Papanicolau/colpocitologia oncótica anormal"
  },
  {
    "code" : "X87",
    "display" : "Prolapso utero-vaginal"
  },
  {
    "code" : "X88",
    "display" : "Doença fibrocística da mama"
  },
  {
    "code" : "X89",
    "display" : "Síndrome da tensão pré-menstrual"
  },
  {
    "code" : "X90",
    "display" : "Herpes genital feminino"
  },
  {
    "code" : "X91",
    "display" : "Condiloma acuminado feminino"
  },
  {
    "code" : "X92",
    "display" : "Infecção por clamídia"
  },
  {
    "code" : "X99",
    "display" : "Doença genital feminina, outra"
  },
  {
    "code" : "Y01",
    "display" : "Dor no pênis"
  },
  {
    "code" : "Y02",
    "display" : "Dor no escroto/testículos"
  },
  {
    "code" : "Y03",
    "display" : "Secreção uretral"
  },
  {
    "code" : "Y04",
    "display" : "Sinais/sintomas do pênis, outros"
  },
  {
    "code" : "Y05",
    "display" : "Sinais/sintomas do escroto/testículos, outros"
  },
  {
    "code" : "Y06",
    "display" : "Sinais/sintomas da próstata"
  },
  {
    "code" : "Y07",
    "display" : "Impotência NE"
  },
  {
    "code" : "Y08",
    "display" : "Sinais/sintomas da função sexual masculina, outros"
  },
  {
    "code" : "Y10",
    "display" : "Infertilidade/subfertildade masculina"
  },
  {
    "code" : "Y13",
    "display" : "Esterilização masculina"
  },
  {
    "code" : "Y14",
    "display" : "Planejamento familiar, outros"
  },
  {
    "code" : "Y16",
    "display" : "Sinais/sintomas da mama masculina"
  },
  {
    "code" : "Y24",
    "display" : "Medo de disfunção sexual masculina"
  },
  {
    "code" : "Y25",
    "display" : "Medo de doença sexualmente transmissível"
  },
  {
    "code" : "Y26",
    "display" : "Medo de câncer genital masculino"
  },
  {
    "code" : "Y27",
    "display" : "Medo de doença genital masculina, outra"
  },
  {
    "code" : "Y28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "Y29",
    "display" : "Sinais/sintomas, outros"
  },
  {
    "code" : "Y70",
    "display" : "Sífilis masculina"
  },
  {
    "code" : "Y71",
    "display" : "Gonorréia masculina"
  },
  {
    "code" : "Y72",
    "display" : "Herpes genital"
  },
  {
    "code" : "Y73",
    "display" : "Prostatite/vesiculite seminal"
  },
  {
    "code" : "Y74",
    "display" : "Orquite/epididimite"
  },
  {
    "code" : "Y75",
    "display" : "Balanite/ Balanopostite"
  },
  {
    "code" : "Y76",
    "display" : "Condiloma acuminado"
  },
  {
    "code" : "Y77",
    "display" : "Neoplasia maligna da próstata"
  },
  {
    "code" : "Y78",
    "display" : "Neoplasia maligna genital masculina, outra"
  },
  {
    "code" : "Y79",
    "display" : "Neoplasia benigna genital masculina NE"
  },
  {
    "code" : "Y80",
    "display" : "Traumatismo genital masculino, outro"
  },
  {
    "code" : "Y81",
    "display" : "Fimose/prepúcio redundante"
  },
  {
    "code" : "Y82",
    "display" : "Hipospádias"
  },
  {
    "code" : "Y83",
    "display" : "Testículo não descido/ Criptorquidia/ Testículo ectópico"
  },
  {
    "code" : "Y84",
    "display" : "Malformação genital congénita masculina, outra"
  },
  {
    "code" : "Y85",
    "display" : "Hipertrofia benigna da próstata/ hiperplasia prostática benigna"
  },
  {
    "code" : "Y86",
    "display" : "Hidrocele"
  },
  {
    "code" : "Y99",
    "display" : "Doença genital masculina, outra"
  },
  {
    "code" : "Z01",
    "display" : "Pobreza/problemas econômicos"
  },
  {
    "code" : "Z02",
    "display" : "Problemas relacionados a água/alimentação"
  },
  {
    "code" : "Z03",
    "display" : "Problemas de habitação/vizinhança"
  },
  {
    "code" : "Z04",
    "display" : "Problema socio-cultural"
  },
  {
    "code" : "Z05",
    "display" : "Problemas com condições de trabalho"
  },
  {
    "code" : "Z06",
    "display" : "Problemas de desemprego"
  },
  {
    "code" : "Z07",
    "display" : "Problemas relacionados com educação"
  },
  {
    "code" : "Z08",
    "display" : "Problema relacionado com sistema de segurança social"
  },
  {
    "code" : "Z09",
    "display" : "Problema de ordem legal"
  },
  {
    "code" : "Z10",
    "display" : "Problema relacionado com sistema de saúde"
  },
  {
    "code" : "Z11",
    "display" : "Problema relacionado com estar doente"
  },
  {
    "code" : "Z12",
    "display" : "Problema de relacionamento com parceiro/ conjugal"
  },
  {
    "code" : "Z13",
    "display" : "Problema comportamental do parceiro/  companheiro"
  },
  {
    "code" : "Z14",
    "display" : "Problema por doença do parceiro/ companheiro"
  },
  {
    "code" : "Z15",
    "display" : "Perda ou falecimento do parceiro/ companheiro"
  },
  {
    "code" : "Z16",
    "display" : "Problema de relacionamento com criança"
  },
  {
    "code" : "Z18",
    "display" : "Problema com criança doente"
  },
  {
    "code" : "Z19",
    "display" : "Perda ou falecimento de criança"
  },
  {
    "code" : "Z20",
    "display" : "Problema de relacionamento com familiares"
  },
  {
    "code" : "Z21",
    "display" : "Problema comportamental de familiar"
  },
  {
    "code" : "Z22",
    "display" : "Problema por doença familiar"
  },
  {
    "code" : "Z23",
    "display" : "Perda/falecimento de familiar"
  },
  {
    "code" : "Z24",
    "display" : "Problema de relacionamento com amigos"
  },
  {
    "code" : "Z25",
    "display" : "Ato ou acontecimento violento"
  },
  {
    "code" : "Z27",
    "display" : "Medo de problema social"
  },
  {
    "code" : "Z28",
    "display" : "Limitação funcional/incapacidade"
  },
  {
    "code" : "Z29",
    "display" : "Problema social NE"
  }]
}

```
