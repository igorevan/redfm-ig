# br.gov.saude.redfm.fhir#1.0.0-release: Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS(en)

## Pages

* [Principal](index.md)
* [Credenciamento](credenciamento.md)
* [Modelo Computacional](mc.md)
* [Downloads](downloads.md)
* [Suporte da RNDS](suporte.md)
* [Feedback](forms.md)
* [Abstract](abstract.md)
* [Integração](integracao.md)
* [Artifacts Summary](artifacts.md)
* [Histórico de mudanças](changes.md)
* [Exemplos](exemplos.md)
* [Modelo de Informação](mi.md)

## Resources

### CodeSystems

* [Classificação Brasileira de Ocupações - CBO (CodeSystem)](CodeSystem-BRCBO.md)
* [Classificação Internacional de Atenção Primária - Segunda Edição (CIAP2)](CodeSystem-BRCIAP2.md)
* [Classificação Internacional de Doenças - Décima Revisão (CID-10)](CodeSystem-BRCID10.md)
* [Conselhos profissionais de saúde do Brasil](CodeSystem-BRConselhoProfissional.md)
* [Justificativa da Impossibilidade de Identificação do Indivíduo (CodeSystem)](CodeSystem-BRJustificativaIndividuoNaoIdentificado.md)
* [Terminologia de Produto Medicinal Comercial com Apresentação (AMPP) na Ontologia Brasileira de Medicamentos (OBM)](CodeSystem-BRObmAMPP.md)
* [Terminologia de Produto Medicinal Comercial com Apresentação (AMPP) na Agência Nacional de Vigilância Sanitária (Anvisa)](CodeSystem-BRObmANVISA.md)
* [Terminologia de Produto Medicinal Virtual (VMP) no Catálogo de Materiais (CATMAT)](CodeSystem-BRObmCATMAT.md)
* [Terminologia de Produto Medicinal Virtual (VMP) na GS1.org](CodeSystem-BRObmEAN.md)
* [Terminologia de Produto Medicinal Virtual (VMP) na Ontologia Brasileira de Medicamentos (OBM)](CodeSystem-BRObmVMP.md)
* [Tipo de Dispensação Realizada (CodeSystem)](CodeSystem-BRTipoDispensacaoRealizada.md)
* [Tipo de Documento (CodeSystem)](CodeSystem-BRTipoDocumento.md)
* [Unidade de Medida](CodeSystem-BRUnidadeMedida.md)
* [Via de Administração (CodeSystem)](CodeSystem-BRViaAdministracao.md)

### ValueSets

* [Conselhos regionais de Enfermagem do Brasil](ValueSet-BRCOREN.md)
* [Conselhos regionais de Farmácia do Brasil](ValueSet-BRCRF.md)
* [Conselhos regionais de Medicina do Brasil](ValueSet-BRCRM.md)
* [Conselhos regionais de Odontologia do Brasil](ValueSet-BRCRO.md)
* [Classificação de uma condição](ValueSet-BRCategoriaCondicao.md)
* [Estado do Documento](ValueSet-BREstadoDocumento-1.0.md)
* [Estado da Resolução de Diagnóstico ou Problema](ValueSet-BREstadoResolucaoDiagnosticoProblema-1.0.md)
* [Justificativa da Impossibilidade de Identificação do Indivíduo (ValueSet)](ValueSet-BRJustificativaIndividuoNaoIdentificado-1.0.md)
* [Classificação Brasileira de Ocupações - CBO (ValueSet)](ValueSet-BROcupacao-1.0.md)
* [Conselhos regionais de outros profissionais da saúde do Brasil](ValueSet-BROutrosProfissionais.md)
* [Classificação Internacional de Doenças (Atenção Primária)](ValueSet-BRProblemaDiagnostico.md)
* [Sexo](ValueSet-BRSexo-1.0.md)
* [Terminologia dos medicamentos](ValueSet-BRTerminologiaMedicamento.md)
* [Tipo de Dispensação Realizada (ValueSet)](ValueSet-BRTipoDispensacaoRealizada.md)
* [Tipo de Documento (ValueSet)](ValueSet-BRTipoDocumento-1.0.md)
* [Unidade de Medida de Medicamento](ValueSet-BRUnidadeMedidaMedicamento.md)
* [Via de Administração (ValueSet)](ValueSet-BRViaAdministracao-1.0.md)
* [Unidade de Medida RNDS](ValueSet-RNDSUnidadeMedida.md)

### Resource Profiles

* [ProblemaDiagnóstico](StructureDefinition-BRProblemaDiagnostico.md)
* [Dispensação ou Fornecimento de Medicamento](StructureDefinition-RNDSDispensacaoMedicamento.md)
* [Estabelecimento de Saúde RNDS](StructureDefinition-RNDSEstabelecimentoSaude.md)
* [RNDSLotacaoProfissional](StructureDefinition-RNDSLotacaoProfissional.md)
* [Medicamento](StructureDefinition-RNDSMedicamento.md)
* [Prescrição de Medicamento - RNDS](StructureDefinition-RNDSPrescricaoMedicamento.md)
* [Profissional RNDS](StructureDefinition-RNDSProfissional.md)
* [Registro Eletrônico de Dispensação ou Fornecimento de Medicamentos - REDFM](StructureDefinition-RNDSRegistroEletronicoDispensacaoFornecimentoMedicamentos.md)
* [BR Core Composition](StructureDefinition-br-core-composition.md)
* [br-core-healthcareservice](StructureDefinition-br-core-healthcareservice.md)
* [br-core-location](StructureDefinition-br-core-location.md)
* [BR Core Medication](StructureDefinition-br-core-medication.md)
* [BR Core Organization](StructureDefinition-br-core-organization.md)
* [BR Core Practitioner](StructureDefinition-br-core-practitioner.md)
* [BR Core PractitionerRole](StructureDefinition-br-core-practitionerrole.md)
* [BRCoreRelatedPerson](StructureDefinition-br-core-relatedperson.md)

### Extensions

* [Informações Complementares de Indivíduos Não Identificados](StructureDefinition-BRIndividuoNaoIdentificado-1.0.md)

### ImplementationGuides

* [Guia de Implementação do Registro Eletrônico de Dispensação ou Fornecimento de Medicamento (REDFM) da RNDS](ImplementationGuide-br.gov.saude.redfm.fhir.md)

### Examples

* [example-redfm-01-prescricao-na-rnds (Bundle)](Bundle-example-redfm-01-prescricao-na-rnds.md)
* [example-redfm-02-prescricao-fora-rnds (Bundle)](Bundle-example-redfm-02-prescricao-fora-rnds.md)
* [example-redfm-03-fornecimento-sem-crf (Bundle)](Bundle-example-redfm-03-fornecimento-sem-crf.md)
* [example-redfm-04-fornecedor-e-dispensador (Bundle)](Bundle-example-redfm-04-fornecedor-e-dispensador.md)
* [example-redfm-05-nao-atendida-com-justificativa (Bundle)](Bundle-example-redfm-05-nao-atendida-com-justificativa.md)
* [example-redfm-06-parcial-com-justificativa (Bundle)](Bundle-example-redfm-06-parcial-com-justificativa.md)
* [example-redfm-07-lote-validade (Bundle)](Bundle-example-redfm-07-lote-validade.md)
* [example-redfm-08-author-valido-cnpj (Bundle)](Bundle-example-redfm-08-author-valido-cnpj.md)
* [example-redfm-09-author-valido-cpf (Bundle)](Bundle-example-redfm-09-author-valido-cpf.md)
* [example-redfm-10-ampp-sem-forma-fabricante (Bundle)](Bundle-example-redfm-10-ampp-sem-forma-fabricante.md)
